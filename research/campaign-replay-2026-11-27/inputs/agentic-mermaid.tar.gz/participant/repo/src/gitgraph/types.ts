import type { PixelTextBlock } from '../shared/prepared-text.ts'
import type { PositionedDiagram } from '../types.ts'

export type GitGraphDirection = 'LR' | 'TB' | 'BT'
export type GitGraphCommitType = 'NORMAL' | 'REVERSE' | 'HIGHLIGHT' | 'MERGE' | 'CHERRY_PICK'

export interface GitGraphCommit {
  id: string
  /** Authored duplicate ID when the stable occurrence identity differs. */
  sourceId?: string
  message?: string
  type: GitGraphCommitType
  /** Visual override authored on a semantic merge commit. */
  customType?: Exclude<GitGraphCommitType, 'MERGE' | 'CHERRY_PICK'>
  tags: string[]
  branch: string
  parents: string[]
  sequence: number
  source: 'commit' | 'merge' | 'cherry-pick'
  mergeBranch?: string
  cherrySource?: string
  cherryParent?: string
  /** Parser-owned visual tag synthesized only when cherry-pick has no authored tags. */
  syntheticCherryTag?: string
  /** True when the author supplied id:, false for deterministic c<N> ids. */
  customId: boolean
}

export interface GitGraphBranch {
  name: string
  order: number
  /** Source creation order; deterministic tiebreaker for equal explicit orders. */
  sequence: number
  head?: string
}

export type GitGraphStatement = { kind: 'commit'; ref: string } | { kind: 'branch'; name: string; order?: number } | { kind: 'checkout'; branch: string; keyword: 'checkout' | 'switch' } | { kind: 'merge'; ref: string; branch: string } | { kind: 'cherry-pick'; ref: string; source: string; parent?: string }

export interface GitGraphDiagram {
  direction: GitGraphDirection
  mainBranchName: string
  /** Frontmatter diagram title, rendered separately from accessibility metadata. */
  title?: string
  commits: GitGraphCommit[]
  branches: GitGraphBranch[]
  statements: GitGraphStatement[]
  accessibilityTitle?: string
  accessibilityDescription?: string
}

export interface PositionedGitGraphCommit extends GitGraphCommit {
  labelBlock?: PixelTextBlock
  tagBlocks?: PixelTextBlock[]
  x: number
  y: number
  lane: number
}

export interface PositionedGitGraphBranch extends GitGraphBranch {
  labelBlock?: PixelTextBlock
  lane: number
  x1: number
  y1: number
  x2: number
  y2: number
}

export interface PositionedGitGraphEdge {
  from: string
  to: string
  kind: 'parent' | 'merge' | 'cherry-pick'
  points: Array<{ x: number; y: number }>
}

export interface PositionedGitGraphDiagram extends PositionedDiagram {
  titleBlock?: PixelTextBlock
  direction: GitGraphDirection
  title?: string
  commits: PositionedGitGraphCommit[]
  branches: PositionedGitGraphBranch[]
  edges: PositionedGitGraphEdge[]
  accessibilityTitle?: string
  accessibilityDescription?: string
  showBranches: boolean
  showCommitLabel: boolean
  rotateCommitLabel: boolean
  /** Present only when a connector still passes a commit or runs along
   *  another connector (gitGraphRouteViolations): drawn, but uncertified. */
  uncertifiedLayout?: import('../layout/uncertified-layout.ts').UncertifiedLayoutReceipt
}

/** Keep source labels independent of collision-free typed occurrence IDs. */
export function gitGraphCommitLabel(commit: Pick<GitGraphCommit, 'id' | 'sourceId' | 'message' | 'source' | 'customId'>): string {
  if (commit.source === 'merge' && commit.customId) return commit.sourceId || commit.id
  return commit.message || commit.sourceId || commit.id
}
