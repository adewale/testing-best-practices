import { RESOLVED_SCENE_CAPABILITY } from '../scene/resolved-types.ts'
import { flagEnabled, flagValue, PNG_RENDER_FLAGS, type ParsedArgs, type ValueFlagName } from './args.ts'
import { PNG_DEFAULT_SCALE } from '../output-policy-versions.ts'
import { GLOBAL_USAGE } from './help.ts'
import { CliArgumentError, preflightCli, reportArgumentError, type PreparedCli } from './preflight.ts'
export * from './args.ts'
export { GLOBAL_USAGE, COMMAND_HELP } from './help.ts'
import { applyMutationBatch } from '../agent/mutate.ts'
import { applyOps, type VerifySummary } from '../agent/apply.ts'
import type { SourceEditPreservation } from '../agent/source-projection.ts'
// ============================================================================
// am — agentic-mermaid CLI (v4).
// ============================================================================

import { spawnSync } from 'node:child_process'
import { existsSync, mkdtempSync, readFileSync, statSync, watch, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { basename, dirname, join, resolve } from 'node:path'
import { DESCRIBE_FORMATS, describeMermaid, describeMermaidTree, isDescribeFormat } from '../agent/describe.ts'
import { describeMermaidFacts } from '../agent/facts.ts'
import type { BuiltinFamilyId, FamilyConformanceReport } from '../agent/families.ts'
import { BUILTIN_FAMILY_METADATA, builtinFamilyMetadata, getFamily, getFamilyConformanceReport, isBuiltinFamilyId, knownFamilies } from '../agent/families.ts'
import { layoutMermaidWithReceipt, renderMermaidASCII, renderMermaidASCIIWithReceipt, renderMermaidPNG, renderMermaidPNGWithReceipt, renderMermaidSVG, renderMermaidSVGWithReceipt } from '../agent/index.ts'
import { verifyMutationResult } from '../agent/apply.ts'
import { mutateChecked } from '../agent/mutate.ts'
import { parseRegisteredMermaid } from '../agent/parse.ts'
import type { PngOptions, PngRasterWarning } from '../agent/png.ts'
import { serializeMermaid, synthesizeFromGraph } from '../agent/serialize.ts'
import { logToolInvocation } from '../agent/trace-log.ts'
import type { AnyMutationOp, LayoutWarning, MutableValidDiagram, MutationError, ParsedDiagram, ParseError, Result, ValidDiagram, WarningCode, WarningOrigin, WarningSeverity } from '../agent/types.ts'
import { WARNING_SEVERITY, WARNING_TIER } from '../agent/types.ts'
import { renderConfigWarningsForMermaid, verifyMermaid } from '../agent/verify.ts'
import { verifyOptionsProblem } from '../agent/verify-options.ts'
import { WARNING_CATALOG } from '../agent/warning-catalog.ts'
import { familyDetectionDiagnosticFromPreservedBody, MermaidFamilyDetectionError } from '../family-detection.ts'
import type { CliRenderFormat, RenderRequestReceipt } from '../render-contract.ts'
import { CLI_RENDER_FORMATS, DEFAULT_CLI_RENDER_FORMAT, isCliRenderFormat, renderOutputForCliFormat, validateSerializableRenderOptions } from '../render-contract.ts'
import { parseFailedDiagnostic, projectRenderErrorDiagnostic, type ParseFailedDiagnostic, type RenderErrorDiagnostic } from '../render-error-diagnostic.ts'
import type { StyleInput, StyleSpec } from '../scene/style-registry.ts'
import { inferBackend, knownStyleDescriptors, resolveStyleStack, validateStyleSpec } from '../scene/style-registry.ts'
import { collectBatched } from '../shared/batched.ts'
import type { RenderOptions } from '../types.ts'
import { PACKAGE_VERSION } from '../version.ts'
import { EXIT_ARG_ERROR, EXIT_INTERNAL, EXIT_OK, EXIT_VERIFY_FAILED } from './exit-codes.ts'
import { initAgentFiles } from './init-agent.ts'
import { extractMermaidFences } from './markdown-fences.ts'
import { HOSTED_MCP_TOOL_NAMES, inlineToolList, LOCAL_MCP_TOOL_NAMES } from '../mcp/tool-names.ts'
import { compactVerification, verifySummaryPayload } from '../mcp/source-tools.ts'
import { EXISTING_DIAGRAM_WORKFLOW, FAMILY_NARROWING_NOTE, NEW_DIAGRAM_POLICY } from '../shared/agent-workflow.ts'

/**
 * Loop 12 M1: build a structured CLI error envelope. Keeps `message` a short
 * human string (the first error's message) and carries the full structured
 * ParseError[] in `details` — so an agent reads `error.details` instead of
 * re-parsing a JSON string buried in `error.message`.
 */
function parseErrorEnvelope(errors: ParseError[]): { ok: false; error: ParseFailedDiagnostic } {
  return { ok: false, error: parseFailedDiagnostic(errors) }
}

type CliStructuredFailure = {
  ok: false
  error: { code: string; message: string; details?: unknown }
}

function isCliStructuredFailure(value: unknown): value is CliStructuredFailure {
  if (typeof value !== 'object' || value === null) return false
  const candidate = value as { ok?: unknown; error?: unknown }
  if (candidate.ok !== false || typeof candidate.error !== 'object' || candidate.error === null) return false
  const error = candidate.error as { code?: unknown; message?: unknown }
  return typeof error.code === 'string' && typeof error.message === 'string'
}

function cliStructuredRenderFailure(error: unknown, source?: string): CliStructuredFailure {
  if (isCliStructuredFailure(error)) return error
  return { ok: false, error: projectRenderErrorDiagnostic(error, { source }) }
}

/** A render failure is the caller's input (exit 2: the source, its
 * configuration, or an option) unless the engine is at fault (exit 4). */
function renderFailureExitCode(failure: CliStructuredFailure): number {
  return failure.error.code === 'INTERNAL_ERROR' ? EXIT_INTERNAL : EXIT_ARG_ERROR
}

/** CLI render accepts installed extensions but cannot execute a source-only
 * preserved envelope. Keep that distinction structured instead of converting
 * unknown/future families into either a parse failure or an internal error. */
function preflightCliRenderableSource(source: string): ParsedDiagram {
  const parsed = parseRegisteredMermaid(source)
  if (!parsed.ok) throw parseErrorEnvelope(parsed.error)
  if (parsed.value.body.kind === 'preserved') {
    throw new MermaidFamilyDetectionError(familyDetectionDiagnosticFromPreservedBody(parsed.value.body))
  }
  return parsed.value
}

function readSourceArg(arg: string | undefined): string {
  if (!arg || arg === '-') {
    // Loop 9 M5: TTY-stdin guard. When stdin is an interactive TTY (no
    // pipe), the read blocks forever waiting for the user to paste + Ctrl-D
    // — confusing UX. Fail fast with a clear hint.
    if (process.stdin.isTTY) throw new CliArgumentError('needs a file argument or piped stdin')
    try {
      return readFileSync(0).toString('utf8')
    } catch {
      return ''
    }
  }
  if (!existsSync(arg)) throw new CliArgumentError(`File not found: ${arg}`)
  return readFileSync(arg, 'utf8')
}

function replacer(_k: string, v: unknown): unknown {
  return v instanceof Map ? Object.fromEntries(v) : v instanceof Set ? Array.from(v) : v
}

export function runCli(argv: string[]): number | Promise<number> {
  const prepared = preflightCli(argv)
  return 'exitCode' in prepared ? prepared.exitCode : runPreparedCli(prepared)
}

/** Argument/help preflight and ordinary commands stay synchronous; batch streams. */
export function runPreparedCli({ args, json }: PreparedCli): number | Promise<number> {
  // Opt-in invocation logging: when AM_TRACE_LOG names a file, append one JSON
  // line per real command run. Shares the sink with the library and hosted MCP
  // (src/agent/trace-log.ts) so the agent-usage eval can grade traceOk from
  // observed calls on ANY channel. The library verify/mutate/create the CLI
  // commands call also log, so `am verify`/`am mutate` are covered even here.
  logToolInvocation(args.command)
  try {
    switch (args.command) {
      case 'render':
        return cmdRender(args, json)
      case 'verify':
        return cmdVerify(args)
      case 'parse':
        return cmdParse(args)
      case 'serialize':
        return cmdSerialize()
      case 'mutate':
        return cmdMutate(args, json)
      case 'preview':
        return cmdPreview(args, json)
      case 'format':
        return cmdFormat(args)
      case 'describe':
        return cmdDescribe(args, json)
      case 'capabilities':
        return cmdCapabilities(args)
      case 'styles':
        return cmdStyles(json)
      case 'llms-txt':
        return cmdLlmsTxt()
      case 'init-agent':
        return cmdInitAgent(args, json)
      case 'batch':
        return cmdBatch().catch(e => reportCliFailure(args, json, e))
      case 'render-markdown':
        return cmdRenderMarkdown(args)
      default:
        process.stderr.write(`Unknown command: ${args.command}\n${GLOBAL_USAGE}`)
        return EXIT_ARG_ERROR
    }
  } catch (e) {
    return reportCliFailure(args, json, e)
  }
}

function reportCliFailure(args: ParsedArgs, json: boolean, e: unknown): number {
  // Argument and file-shape failures (missing file, TTY stdin, a bad flag)
  // are not renderer failures even when they occur under the render command.
  if (e instanceof CliArgumentError) return reportArgumentError(e.message, json)
  const msg = e instanceof Error ? e.message : String(e)
  const structured = args.command === 'render' || args.command === 'preview' || isCliStructuredFailure(e) ? cliStructuredRenderFailure(e) : undefined
  if (structured) {
    if (json) process.stdout.write(JSON.stringify(structured) + '\n')
    else process.stderr.write(`Error: ${structured.error.code}: ${structured.error.message}\n`)
    return renderFailureExitCode(structured)
  }
  if (json) process.stdout.write(JSON.stringify({ ok: false, error: { code: 'INTERNAL', message: msg } }) + '\n')
  else process.stderr.write(`Error: ${msg}\n`)
  return EXIT_INTERNAL
}
function cmdRender(args: ParsedArgs, json: boolean): number {
  const numeric = (name: ValueFlagName): number | undefined => {
    const value = flagValue(args, name)
    return value === undefined ? undefined : Number(value)
  }
  const format = flagValue(args, 'format') ?? DEFAULT_CLI_RENDER_FORMAT
  const securityFlag = flagValue(args, 'security')
  const security = securityFlag === 'strict' ? ('strict' as const) : undefined
  // Explicit gantt clock (rendering never reads wall-clock time).
  const ganttToday = flagValue(args, 'gantt-today')
  const targetWidth = numeric('target-width')
  if (!isCliRenderFormat(format)) {
    throw new CliArgumentError(`am render: unsupported --format ${format}; expected ${CLI_RENDER_FORMATS.join(', ')}`)
  }
  const output = renderOutputForCliFormat(format)!
  if (securityFlag !== undefined && securityFlag !== 'strict') {
    throw new CliArgumentError('am render --security accepts only strict')
  }
  let advancedOptions: RenderOptions = {}
  const optionsFlag = flagValue(args, 'options')
  if (optionsFlag !== undefined) {
    try {
      advancedOptions = parseRenderOptionsFlag(optionsFlag)
    } catch (error) {
      throw new CliArgumentError(`am render --options: ${error instanceof Error ? error.message : String(error)}`)
    }
  }
  const graphLayout = flagValue(args, 'graph-layout')
  const graphLayoutFallback = flagValue(args, 'graph-layout-fallback')
  if (graphLayout !== undefined || graphLayoutFallback !== undefined) {
    const candidate = {
      backend: graphLayout ?? advancedOptions.graphLayout?.backend ?? 'elk',
      ...(graphLayoutFallback !== undefined || advancedOptions.graphLayout?.fallback !== undefined
        ? { fallback: graphLayoutFallback ?? advancedOptions.graphLayout?.fallback } : {}),
    }
    const problems = validateSerializableRenderOptions({ graphLayout: candidate })
    if (problems.length) {
      throw new CliArgumentError(`am render: ${problems.join('; ')}`)
    }
    advancedOptions = { ...advancedOptions, graphLayout: candidate as NonNullable<RenderOptions['graphLayout']> }
  }
  if (targetWidth !== undefined && (!Number.isInteger(targetWidth) || targetWidth <= 0)) {
    throw new CliArgumentError('am render --target-width expects a positive integer number of terminal cells')
  }
  if (targetWidth !== undefined && output.id !== 'ascii' && output.id !== 'unicode') {
    throw new CliArgumentError('am render --target-width is valid only with --format ascii or unicode')
  }
  const pngOnly = PNG_RENDER_FLAGS.filter(name => args.flags[name] !== undefined)
  if (output.id !== 'png' && pngOnly.length > 0) {
    throw new CliArgumentError(`am render: ${pngOnly.map(name => `--${name}`).join(', ')} ${pngOnly.length > 1 ? 'are' : 'is'} valid only with --format png`)
  }
  const certificates = flagEnabled(args, 'certificates')
  const watch = flagEnabled(args, 'watch')
  if (certificates && output.id !== 'layout') {
    throw new CliArgumentError('am render: --certificates is valid only with --format layout')
  }
  if (watch && args.positional.length > 1) {
    throw new CliArgumentError('am render --watch accepts exactly one input file')
  }

  // --style: a stack of names and/or .json spec files; fail fast (exit 2) on
  // unknown names or invalid specs instead of surfacing an internal error.
  let style: StyleInput[] | undefined
  const styleFlag = flagValue(args, 'style')
  if (styleFlag !== undefined) {
    try {
      style = parseStyleFlag(styleFlag)
      resolveStyleStack(style)
    } catch (e) {
      throw new CliArgumentError(`am render --style: ${e instanceof Error ? e.message : String(e)}`)
    }
  }
  const seed = numeric('seed')
  if (seed !== undefined && !Number.isFinite(seed)) {
    throw new CliArgumentError('am render --seed expects a finite number')
  }
  const formatOptions: RenderFormatOptions = {
    ...advancedOptions,
    ...(security === undefined ? {} : { security }),
    ...(style === undefined ? {} : { style }),
    ...(seed === undefined ? {} : { seed }),
    ...(ganttToday === undefined ? {} : { ganttToday }),
    certificates,
    targetWidth,
  }

  if (args.positional.length > 1 && output.id === 'png') {
    throw new CliArgumentError('am render --format png accepts exactly one input; run once per file with a distinct --output path')
  }

  // #959: multi-input — when more than one positional file is given, render
  // each and emit a JSON array of results, skipping bad files (like #543).
  // Single-input keeps the existing single-output behavior. PNG is excluded
  // because it writes bytes to a single --output path.
  if (args.positional.length > 1) {
    const results = args.positional.map((file, index) => {
      try {
        const src = readSourceArg(file)
        const warnings = renderConfigWarningsForMermaid(src, formatOptions)
        emitConfigWarnings(warnings, `am render ${file}`)
        const rendered = renderSourceToFormatWithReceipt(src, format, reportingConfigDiagnosticsOnce(formatOptions, warnings))
        return { index, file, ok: true, output: rendered.output, receipt: rendered.receipt, warnings }
      } catch (e) {
        return {
          index,
          file,
          ok: false,
          error: e instanceof CliArgumentError ? { code: 'ARG', message: e.message } : cliStructuredRenderFailure(e).error,
        }
      }
    })
    process.stdout.write(JSON.stringify({ ok: true, files: results }) + '\n')
    return EXIT_OK
  }

  // #930: watch mode — re-render on file change.
  if (watch && output.id === 'png') {
    throw new CliArgumentError('am render --format png does not support --watch; run non-watch PNG renders with --output <file.png>')
  }
  if (watch && typeof args.positional[0] === 'string' && args.positional[0] !== '-') {
    return cmdRenderWatch(args.positional[0], format, args, json, formatOptions)
  }

  const source = readSourceArg(args.positional[0])
  // The render surface is open to installed descriptors while future/unknown
  // source-only envelopes retain their exact capability classification.
  try {
    preflightCliRenderableSource(source)
  } catch (error) {
    const structured = cliStructuredRenderFailure(error)
    process.stdout.write(JSON.stringify(structured) + '\n')
    return renderFailureExitCode(structured)
  }

  const configWarnings = renderConfigWarningsForMermaid(source, formatOptions)

  const outFile = flagValue(args, 'o') ?? flagValue(args, 'output') ?? ''
  if (output.id === 'png') {
    if (!outFile) {
      throw new CliArgumentError('am render --format png requires --output <file.png> (PNG bytes corrupt terminals if piped to stdout)')
    }
    const scale = numeric('scale') ?? PNG_DEFAULT_SCALE
    if (!Number.isFinite(scale) || scale <= 0) {
      throw new CliArgumentError('am render --scale expects a positive finite number')
    }
    const background = flagValue(args, 'bg')
    const fitWidth = numeric('fit-width')
    const fitHeight = numeric('fit-height')
    if (fitWidth !== undefined && fitHeight !== undefined) {
      throw new CliArgumentError('am render PNG fitting accepts --fit-width or --fit-height, not both')
    }
    if ((fitWidth !== undefined && (!Number.isSafeInteger(fitWidth) || fitWidth <= 0)) || (fitHeight !== undefined && (!Number.isSafeInteger(fitHeight) || fitHeight <= 0))) {
      throw new CliArgumentError('am render --fit-width/--fit-height expects a positive integer pixel value')
    }
    const fitTo = fitWidth !== undefined ? { width: fitWidth } : fitHeight !== undefined ? { height: fitHeight } : undefined
    const minLabelPx = numeric('min-label-px')
    if (minLabelPx !== undefined && (!Number.isFinite(minLabelPx) || minLabelPx < 0)) {
      throw new CliArgumentError('am render --min-label-px expects a non-negative finite number')
    }
    const fontDirs = flagValue(args, 'font-dirs')
      ?.split(',')
      .map(s => s.trim())
      .filter(Boolean)
    const loadSystemFonts = flagEnabled(args, 'system-fonts')
    // PNG render is native-sync via resvg; keep bytes off stdout and write the
    // raster artifact explicitly to the requested output path.
    const { certificates: _certificates, targetWidth: _targetWidth, ...sharedOptions } = reportingConfigDiagnosticsOnce(formatOptions, configWarnings)
    return renderPngSync(source, { ...sharedOptions, scale, background, fitTo, minLabelPx, fontDirs, loadSystemFonts }, outFile, json, configWarnings)
  }
  // Loop 9 M3/M4, #7645: layout = layout shape; unicode is the default text
  // renderer; `--security strict` enforces the shared SVG output-security policy.
  emitConfigWarnings(configWarnings, 'am render')
  const rendered = renderPreflightedSourceToFormatWithReceipt(source, format, reportingConfigDiagnosticsOnce(formatOptions, configWarnings))
  const out = rendered.output
  const layoutWarnings = configWarnings.length > 0 ? { warnings: configWarnings } : {}
  // The artifact is what plain stdout carries. --output writes it for every
  // single-shot format, matching the documented
  // `am render --format svg --output diagram.svg`; --json never changes the
  // file's bytes, it reports the write on stdout as the PNG path does.
  const artifact = typeof out === 'string' ? (out.endsWith('\n') ? out : out + '\n') : JSON.stringify({ ...out, receipt: rendered.receipt, ...layoutWarnings }) + '\n'
  if (outFile) {
    writeFileSync(outFile, artifact)
    if (json) process.stdout.write(JSON.stringify({ ok: true, path: outFile, bytes: Buffer.byteLength(artifact), receipt: rendered.receipt, warnings: configWarnings }) + '\n')
    return EXIT_OK
  }
  if (!json) {
    process.stdout.write(artifact)
    return EXIT_OK
  }
  const envelope = typeof out === 'string' ? { ok: true, [format]: out, receipt: rendered.receipt, warnings: configWarnings } : { ok: true, ...out, receipt: rendered.receipt, ...layoutWarnings }
  process.stdout.write(JSON.stringify(envelope) + '\n')
  return EXIT_OK
}

export interface RenderFormatOptions extends RenderOptions {
  certificates?: boolean
  targetWidth?: number
}

/** The ONE format dispatch behind every render path — single-input,
 *  multi-input, and watch differ only in I/O and error envelopes, so they
 *  share this core instead of re-enumerating formats (the style/seed
 *  threading previously had to touch three copies). JSON parse failures
 *  throw the structured envelope; callers decide how to surface it. */
export interface RenderFormatResult {
  output: string | object
  receipt: RenderRequestReceipt
}

export function renderSourceToFormatWithReceipt(source: string, format: string, opts: RenderFormatOptions = {}): RenderFormatResult {
  preflightCliRenderableSource(source)
  return renderPreflightedSourceToFormatWithReceipt(source, format, opts)
}

function renderPreflightedSourceToFormatWithReceipt(source: string, format: string, opts: RenderFormatOptions = {}): RenderFormatResult {
  const { certificates, targetWidth, ...sharedOptions } = opts
  const descriptor = renderOutputForCliFormat(format)
  if (!descriptor) throw new Error(`unsupported render format: ${format}`)
  if (descriptor.id === 'ascii' || descriptor.id === 'unicode') {
    const rendered = renderMermaidASCIIWithReceipt(source, { ...sharedOptions, useAscii: descriptor.id === 'ascii', targetWidth })
    return { output: rendered.text, receipt: rendered.receipt }
  }
  if (descriptor.id === 'layout') {
    // Delegate the original request after the shared preflight so the CLI and library
    // resolve the same source/configuration receipt. Passing the parsed value
    // here re-serialized some families (notably timeline) before hashing.
    const rendered = layoutMermaidWithReceipt(source, {
      ...sharedOptions,
      ...(certificates === true ? { debug: true } : {}),
    })
    return { output: rendered.layout, receipt: rendered.receipt }
  }
  if (descriptor.id === 'svg') {
    const rendered = renderMermaidSVGWithReceipt(source, sharedOptions)
    return { output: rendered.svg, receipt: rendered.receipt }
  }
  throw new Error(`unsupported render format: ${format}`)
}

function renderSourceToFormat(source: string, format: string, opts: RenderFormatOptions = {}): string | object {
  return renderSourceToFormatWithReceipt(source, format, opts).output
}

/**
 * #930: one `--watch` frame for the file's current contents — the rendered
 * output (absent after a failed render) and the stderr lines the watcher
 * prints, in order. The watch loop and its tests share it, so it is testable
 * without fs.watch timing.
 */
export function renderWatchFrame(file: string, format: string, opts: RenderFormatOptions, json: boolean): { output?: string; stderr: string[] } {
  const stderr: string[] = []
  const write = (line: string) => { stderr.push(line) }
  try {
    const src = readFileSync(file, 'utf8')
    const warnings = renderConfigWarningsForMermaid(src, opts)
    emitConfigWarnings(warnings, 'am render --watch', write)
    const out = renderSourceToFormat(src, format, reportingConfigDiagnosticsOnce(opts, warnings, write))
    return { output: typeof out === 'string' ? out : JSON.stringify(out), stderr }
  } catch (e) {
    const structured = cliStructuredRenderFailure(e)
    if (json && structured) write(`${JSON.stringify(structured)}\n`)
    else {
      const error = structured?.error
      const message = error?.message ?? (e instanceof Error ? e.message : String(e))
      write(`render error: ${error ? `${error.code}: ` : ''}${message}\n`)
    }
    return { stderr }
  }
}

export interface PathWatchHandle {
  close(): void
}

/** Watch the containing directory so rename-over atomic saves keep following
 * the input pathname rather than a stale inode. A metadata poll closes the
 * documented fs.watch event-loss gap; both signals share one coalescer. */
export function watchPathForChanges(file: string, onChange: () => void, debounceMs = 25, watchDirectory: typeof watch = watch): PathWatchHandle {
  const absolute = resolve(file)
  const watchedName = basename(absolute)
  const fingerprint = (): string => {
    try {
      const stat = statSync(absolute, { bigint: true })
      return `${stat.dev}:${stat.ino}:${stat.size}:${stat.mtimeNs}:${stat.ctimeNs}`
    } catch {
      return 'missing'
    }
  }
  let lastFingerprint = fingerprint()
  let timer: ReturnType<typeof setTimeout> | undefined
  let closed = false
  const detectChange = () => {
    if (closed) return
    const next = fingerprint()
    if (next === lastFingerprint) return
    lastFingerprint = next
    if (timer !== undefined) clearTimeout(timer)
    timer = setTimeout(() => {
      timer = undefined
      if (!closed) onChange()
    }, debounceMs)
  }
  const watcher = watchDirectory(dirname(absolute), { persistent: true }, (_event, filename) => {
    const changed = filename === null ? undefined : basename(String(filename))
    if (changed === undefined || changed === watchedName) detectChange()
  })
  // fs.watch is explicitly allowed to omit events and filenames. Poll only
  // metadata (not file bytes) as a bounded fallback, retaining pathname and
  // rename identity through dev/inode plus nanosecond timestamps.
  const poll = setInterval(detectChange, Math.max(25, Math.min(250, debounceMs * 4)))
  return Object.freeze({
    close(): void {
      closed = true
      if (timer !== undefined) clearTimeout(timer)
      timer = undefined
      clearInterval(poll)
      watcher.close()
    },
  })
}

function cmdRenderWatch(file: string, format: string, args: ParsedArgs, json: boolean, opts: RenderFormatOptions = {}): number {
  const outFile = flagValue(args, 'output') ?? ''
  if (outFile && resolve(outFile) === resolve(file)) {
    throw new CliArgumentError('am render --watch output must differ from the input file')
  }
  const emit = () => {
    const frame = renderWatchFrame(file, format, opts, json)
    for (const line of frame.stderr) process.stderr.write(line)
    if (frame.output === undefined) return
    const text = frame.output
    try {
      if (outFile) {
        writeFileSync(outFile, text)
        process.stderr.write(`rendered → ${outFile}\n`)
      } else process.stdout.write(text + (text.endsWith('\n') ? '' : '\n'))
    } catch (e) {
      process.stderr.write(`render error: ${e instanceof Error ? e.message : String(e)}\n`)
    }
  }
  emit() // initial render
  process.stderr.write(`watching ${file} (Ctrl-C to stop)…\n`)
  watchPathForChanges(file, emit)
  // Block forever — the watcher keeps the event loop alive.
  return EXIT_OK
}

/** The render's own config diagnostics, minus those already reported as
 * `warnings` (emitConfigWarnings writes those to stderr), so each reaches the
 * terminal once; any other, such as a declined layout fallback, still does. */
function reportingConfigDiagnosticsOnce<Options extends RenderOptions>(options: Options, reported: readonly LayoutWarning[], write: (line: string) => void = writeStderr): Options {
  const seen = new Set(reported.map(warning => JSON.stringify(warning)))
  return { ...options, onConfigDiagnostic: diagnostic => { if (!seen.has(JSON.stringify(diagnostic))) write(`${diagnostic.message}\n`) } }
}

function writeStderr(line: string): void {
  process.stderr.write(line)
}

function emitConfigWarnings(warnings: LayoutWarning[], prefix: string, write: (line: string) => void = writeStderr): void {
  for (const warning of warnings) {
    write(`${prefix}: warning ${warning.code}${'field' in warning ? ` (${warning.field})` : ''}: ${'message' in warning ? warning.message : 'configuration has no effect'}\n`)
  }
}

/** PNG failures surface through the same render envelope and exit codes as
 * every other format (reportCliFailure). */
function renderPngSync(source: string, opts: PngOptions, outFile: string, json: boolean, configWarnings: LayoutWarning[] = []): number {
  // Glyph-coverage and legibility warnings (CJK/emoji without a covering
  // font; text rasterized below the minLabelPx floor) go to stderr — the
  // PNG itself can't show what silently became tofu or unreadable — and
  // ride along in the --json envelope for programmatic callers.
  const rasterWarnings: PngRasterWarning[] = []
  const rendered = renderMermaidPNGWithReceipt(source, { ...opts, onWarning: w => rasterWarnings.push(w) })
  const png = rendered.png
  const warnings: Array<PngRasterWarning | LayoutWarning> = [...configWarnings, ...rasterWarnings]
  writeFileSync(outFile, png)
  for (const w of warnings) process.stderr.write(`am render --format png: warning ${w.code}: ${'message' in w ? w.message : 'configuration has no effect'}\n`)
  if (json) process.stdout.write(JSON.stringify({ ok: true, path: outFile, bytes: png.length, receipt: rendered.receipt, runtime: rendered.runtime, warnings }) + '\n')
  return EXIT_OK
}

function cmdVerify(args: ParsedArgs): number {
  const summary = summaryViewRequested(args, 'verify')
  const source = readSourceArg(args.positional[0])
  const suppressFlag = flagValue(args, 'suppress')
  let suppress: WarningCode[] | undefined
  if (suppressFlag !== undefined) {
    const values = suppressFlag
      .split(',')
      .map(value => value.trim())
      .filter(Boolean)
    const known = new Set(Object.keys(WARNING_SEVERITY))
    if (values.length === 0 || values.some(value => !known.has(value))) {
      throw new CliArgumentError('am verify --suppress accepts only known warning codes')
    }
    suppress = values as WarningCode[]
  }
  const labelCapFlag = flagValue(args, 'label-cap')
  let labelCharCap: number | undefined
  if (labelCapFlag !== undefined) {
    // A flag is text: only decimal digits name the integer the library admits.
    labelCharCap = /^[1-9]\d*$/.test(labelCapFlag.trim()) ? Number(labelCapFlag) : Number.NaN
    if (verifyOptionsProblem({ labelCharCap })) {
      throw new CliArgumentError('am verify --label-cap must be a positive safe integer')
    }
  }
  let style: StyleInput[] | undefined
  const styleFlag = flagValue(args, 'style')
  if (styleFlag !== undefined) {
    try {
      style = parseStyleFlag(styleFlag)
      resolveStyleStack(style)
    } catch (error) {
      throw new CliArgumentError(`am verify --style: ${error instanceof Error ? error.message : String(error)}`)
    }
  }
  const options = { suppress, labelCharCap, ...(style ? { renderOptions: { style } } : {}) }
  if (flagEnabled(args, 'markdown')) {
    const blocks = verifyMarkdownBlocks(source, options)
    const ok = blocks.every(block => block.ok)
    process.stdout.write(JSON.stringify({ ok, file: args.positional[0] ?? '<stdin>', blocks }, replacer) + '\n')
    return ok ? EXIT_OK : verifyFailureExit(blocks.flatMap(block => block.warnings))
  }
  if (summary) {
    const payload = verifySummaryPayload(source, options)
    process.stdout.write(JSON.stringify(payload, replacer) + '\n')
    return payload.ok ? EXIT_OK : verifyFailureExit(payload.warnings as LayoutWarning[])
  }
  const r = verifyMermaid(source, options)
  process.stdout.write(JSON.stringify(r, replacer) + '\n')
  return r.ok ? EXIT_OK : verifyFailureExit(r.warnings)
}

/** A verify failure whose every error is INTERNAL_ERROR is an engine defect,
 * not the diagram's, so it exits with the internal status. */
function verifyFailureExit(warnings: readonly LayoutWarning[]): number {
  const errors = warnings.filter(warning => WARNING_SEVERITY[warning.code] === 'error')
  return errors.length > 0 && errors.every(warning => warning.code === 'INTERNAL_ERROR') ? EXIT_INTERNAL : EXIT_VERIFY_FAILED
}

function cmdParse(args: ParsedArgs): number {
  // CLI parsing is a transport envelope rather than the closed TypeScript
  // ValidDiagram API. Use the registered parser so a trusted host that installs
  // an extension can inspect the same source it can already render and verify.
  // Built-in payloads remain byte-for-byte the existing ValidDiagram shape.
  const r = parseRegisteredMermaid(readSourceArg(args.positional[0]))
  if (!r.ok) {
    // Error envelope matches the documented batch shape (cli/index.ts:107).
    // Success emits the bare ParsedDiagram payload. Built-in results retain the
    // existing ValidDiagram shape and remain pipeable into `am serialize`.
    process.stdout.write(JSON.stringify(parseErrorEnvelope(r.error)) + '\n')
    return EXIT_ARG_ERROR
  }
  process.stdout.write(JSON.stringify(toJsonSafe(r.value), replacer) + '\n')
  return EXIT_OK
}

function cmdSerialize(): number {
  const stdin = readSourceArg('-')
  let payload: unknown
  try {
    payload = JSON.parse(stdin)
  } catch (e) {
    process.stderr.write(`serialize: invalid JSON: ${(e as Error).message}\n`)
    return EXIT_ARG_ERROR
  }
  const r = synthesizeFromGraph(payload as Parameters<typeof synthesizeFromGraph>[0])
  if (!r.ok) {
    process.stderr.write(`serialize: ${JSON.stringify(r.error)}\n`)
    return EXIT_ARG_ERROR
  }
  process.stdout.write(serializeMermaid(r.value))
  return EXIT_OK
}

type CliMutationError = MutationError | { code: string; message: string; details?: unknown }

/** `family` and `opIndex` mirror the MCP mutate envelope ({ok, family,
 * opIndex?, error}); `error.details` keeps the CLI's {index, op} locator. */
type MutationRunResult =
  | { ok: true; family: string; source: string; verify: VerifySummary; mode?: 'source-preserving'; preservation?: SourceEditPreservation }
  | { ok: false; family: string | null; opIndex?: number; error: CliMutationError; verify?: VerifySummary }

/** `full` embeds verify's complete result; `summary` embeds the compact
 * verification MCP verify returns. Source-preserving edits already embed the
 * compact { ok, warnings, checks } either way. */
export type MutationVerifyView = 'full' | 'summary'

function parseMutationOpsFlag(args: ParsedArgs): Result<AnyMutationOp[], CliMutationError> {
  const opStr = flagValue(args, 'op') ?? ''
  const opsStr = flagValue(args, 'ops') ?? ''
  if (opStr && opsStr) return { ok: false, error: { code: 'INVALID_OP', message: 'mutate accepts either --op or --ops, not both' } }
  if (!opStr && !opsStr) return { ok: false, error: { code: 'INVALID_OP', message: 'mutate requires --op <JSON> or --ops <JSON array|file.json>' } }
  try {
    if (opStr) return { ok: true, value: [JSON.parse(opStr) as AnyMutationOp] }
    const raw = existsSync(opsStr) ? readFileSync(opsStr, 'utf8') : opsStr
    const parsed = JSON.parse(raw) as unknown
    if (!Array.isArray(parsed)) return { ok: false, error: { code: 'INVALID_OP', message: '--ops must be a JSON array of MutationOps' } }
    if (parsed.length === 0) return { ok: false, error: { code: 'INVALID_OP', message: '--ops must contain at least one MutationOp' } }
    return { ok: true, value: parsed as AnyMutationOp[] }
  } catch (e) {
    return { ok: false, error: { code: 'INVALID_OP', message: `invalid mutation JSON: ${(e as Error).message}` } }
  }
}


export function mutateSource(source: string, ops: AnyMutationOp[], preserveSource = false, verifyView: MutationVerifyView = 'full'): MutationRunResult {
  if (preserveSource) {
    const result = applyOps({ source, ops, mode: 'source-preserving' })
    if (!result.ok) {
      const { opIndex } = result
      return { ok: false, family: result.family, ...(opIndex !== undefined ? { opIndex } : {}), error: { ...result.error, ...(opIndex !== undefined ? { details: { index: opIndex, op: ops[opIndex] } } : {}) } }
    }
    return { ok: true, family: result.family, source: result.source, verify: result.verify, mode: 'source-preserving', ...(result.preservation ? { preservation: result.preservation } : {}) }
  }
  const r0 = parseRegisteredMermaid(source)
  if (!r0.ok) {
    return { ok: false, family: null, error: parseFailedDiagnostic(r0.error) }
  }
  const family = r0.value.kind
  if (r0.value.body.kind === 'opaque' || r0.value.body.kind === 'preserved' || r0.value.body.kind === 'extension' || !getFamily(r0.value.kind)?.mutate) {
    return { ok: false, family, error: { code: 'UNSUPPORTED_FAMILY', message: `No structured mutation contract for ${family}` } }
  }
  const batch = applyMutationBatch(r0.value, ops)
  if (!batch.ok) {
    const { opIndex, ...error } = batch.error
    return { ok: false, family, opIndex, error: { ...error, details: { index: opIndex, op: ops[opIndex] } } }
  }
  const current = batch.value
  const { accepted, verification } = verifyMutationResult(current, r0.value)
  const verify = verifyView === 'summary' ? compactVerification(current, verification) : verification
  if (!accepted) {
    return {
      ok: false,
      family,
      error: { code: 'VERIFY_FAILED', message: 'mutated diagram failed verify; source was not emitted', details: verify.warnings },
      verify,
    }
  }
  return { ok: true, family, source: serializeMermaid(current), verify }
}

function cmdMutate(args: ParsedArgs, json: boolean): number {
  const source = readSourceArg(args.positional[0])
  const ops = parseMutationOpsFlag(args)
  if (!ops.ok) {
    throw new CliArgumentError(`mutate: ${ops.error.message}`)
  }
  if (args.flags['preserve-source'] === true && args.flags.canonical === true) throw new CliArgumentError('mutate: pass either --preserve-source or --canonical, not both')
  const verifyView = summaryViewRequested(args, 'mutate') ? 'summary' : 'full'
  return emitMutationRun(mutateSource(source, ops.value, args.flags['preserve-source'] === true, verifyView), json)
}

function emitMutationRun(r: MutationRunResult, json: boolean): number {
  if (!r.ok) {
    process.stdout.write(JSON.stringify({ ok: false, family: r.family, opIndex: r.opIndex, error: r.error, verify: r.verify }, replacer) + '\n')
    return r.error.code === 'VERIFY_FAILED' ? verifyFailureExit(r.verify?.warnings ?? []) : EXIT_ARG_ERROR
  }
  if (!json && r.preservation?.method === 'canonical') process.stderr.write(`mutate: source preservation fell back to canonical serialization: ${r.preservation.reason}\n`)
  process.stdout.write(json ? JSON.stringify({ ok: true, family: r.family, source: r.source, verify: r.verify, ...(r.mode ? { mode: r.mode } : {}), ...(r.preservation ? { preservation: r.preservation } : {}) }, replacer) + '\n' : r.source)
  return EXIT_OK
}

export function buildPreviewHtml(source: string, opts: { security?: 'default' | 'strict' } = {}): Result<string, { code: string; message: string; details?: unknown }> {
  const parsed = parseRegisteredMermaid(source)
  if (!parsed.ok) {
    const env = parseErrorEnvelope(parsed.error)
    return { ok: false, error: env.error }
  }
  const svg = renderMermaidSVG(source, { security: opts.security ?? 'strict' })
  const title = parsed.value.meta.frontmatter?.title ?? 'Mermaid preview'
  const escapedTitle = escapeHtml(String(title))
  const escapedSource = escapeHtml(source)
  return {
    ok: true,
    value: `<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>${escapedTitle}</title>
  <style>
    body { margin: 0; min-height: 100vh; display: grid; grid-template-rows: auto 1fr; background: #f8fafc; color: #0f172a; font-family: system-ui, sans-serif; }
    header { padding: 12px 16px; border-bottom: 1px solid #e2e8f0; background: white; }
    main { padding: 24px; overflow: auto; }
    .canvas { width: max-content; max-width: 100%; margin: 0 auto; background: white; box-shadow: 0 18px 70px rgba(15,23,42,.12); }
    svg { display: block; max-width: 100%; height: auto; }
    details { margin-top: 16px; }
    pre { white-space: pre-wrap; background: #0f172a; color: #e2e8f0; padding: 12px; border-radius: 8px; }
  </style>
</head>
<body>
  <header><strong>${escapedTitle}</strong></header>
  <main>
    <div class="canvas">${svg}</div>
    <details><summary>Mermaid source</summary><pre>${escapedSource}</pre></details>
  </main>
</body>
</html>`,
  }
}

function escapeHtml(s: string): string {
  return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;')
}

export function openPreviewFile(path: string): { ok: true } | { ok: false; error: string } {
  const override = process.env.AM_OPEN_COMMAND
  const command = override || (process.platform === 'darwin' ? 'open' : process.platform === 'win32' ? 'cmd' : 'xdg-open')
  const args = override ? [path] : process.platform === 'win32' ? ['/c', 'start', '', path] : [path]
  const r = spawnSync(command, args, { stdio: 'ignore' })
  if (r.error || r.status !== 0) return { ok: false, error: `open command failed: ${command}` }
  return { ok: true }
}

function cmdPreview(args: ParsedArgs, json: boolean): number {
  const source = readSourceArg(args.positional[0])
  const security = 'strict' as const
  const securityFlag = flagValue(args, 'security')
  if (securityFlag !== undefined && securityFlag !== 'strict') {
    throw new CliArgumentError('am preview --security accepts only strict')
  }
  const html = buildPreviewHtml(source, { security })
  if (!html.ok) {
    process.stdout.write(JSON.stringify({ ok: false, error: html.error }) + '\n')
    return EXIT_ARG_ERROR
  }
  const open = flagEnabled(args, 'open')
  let outFile = flagValue(args, 'output') ?? ''
  if (!outFile && open) outFile = join(mkdtempSync(join(tmpdir(), 'am-preview-')), 'preview.html')
  if (outFile) {
    const path = resolve(outFile)
    writeFileSync(path, html.value)
    let opened = false
    if (open) {
      const openedResult = openPreviewFile(path)
      if (!openedResult.ok) {
        process.stderr.write(`am preview --open: ${openedResult.error}\n`)
        return EXIT_INTERNAL
      }
      opened = true
    }
    if (json) process.stdout.write(JSON.stringify({ ok: true, path, opened, bytes: html.value.length }) + '\n')
    else process.stdout.write(`${path}\n`)
    return EXIT_OK
  }
  process.stdout.write(json ? JSON.stringify({ ok: true, html: html.value }) + '\n' : html.value)
  return EXIT_OK
}

function cmdFormat(args: ParsedArgs): number {
  const r = parseRegisteredMermaid(readSourceArg(args.positional[0]))
  if (!r.ok) {
    process.stderr.write(`format: parse failed: ${JSON.stringify(r.error)}\n`)
    return EXIT_ARG_ERROR
  }
  const wrapper = flagEnabled(args, 'canonical-wrapper') ? ('canonical' as const) : ('verbatim' as const)
  process.stdout.write(serializeMermaid(r.value, { wrapper }))
  return EXIT_OK
}

function cmdDescribe(args: ParsedArgs, json: boolean): number {
  const source = readSourceArg(args.positional[0])
  const rawFormat = flagValue(args, 'format')
  const format = rawFormat === undefined ? 'text' : isDescribeFormat(rawFormat) ? rawFormat : undefined
  if (!format) {
    throw new CliArgumentError(`am describe --format must be one of: ${DESCRIBE_FORMATS.join(', ')}`)
  }
  const parsed = parseRegisteredMermaid(source)
  if (!parsed.ok) {
    const env = parseErrorEnvelope(parsed.error)
    if (json || format === 'json') process.stdout.write(JSON.stringify(env) + '\n')
    else process.stderr.write(`describe: parse failed: ${env.error.message}\n`)
    return EXIT_ARG_ERROR
  }
  // Describe is a read surface, but a successful description is still a
  // commit point: it must not certify source that the canonical verifier says
  // cannot render. Keep the failure envelope aligned with the local/hosted MCP
  // describe tools and use the documented verify-failed exit status.
  const verification = verifyMermaid(parsed.value)
  if (!verification.ok) {
    const env = {
      ok: false,
      family: parsed.value.kind,
      warnings: verification.warnings,
    }
    if (json || format === 'json') process.stdout.write(JSON.stringify(env, replacer) + '\n')
    else process.stderr.write(`describe: verify failed: ${verification.warnings.map(warning => warning.code).join(', ')}\n`)
    return verifyFailureExit(verification.warnings)
  }
  // The --json envelope carries verify's warnings in every format, as the
  // MCP describe payload does; plain output stays the bare description.
  const envelope = (payload: Record<string, unknown>): string => JSON.stringify({ ok: true, ...payload, warnings: verification.warnings }, replacer) + '\n'
  if (format === 'json') {
    const tree = describeMermaidTree(parsed.value)
    process.stdout.write(json ? envelope({ tree }) : JSON.stringify(tree) + '\n')
    return EXIT_OK
  }
  if (format === 'facts') {
    const facts = describeMermaidFacts(parsed.value)
    process.stdout.write(json ? envelope({ facts }) : facts.join('\n') + '\n')
    return EXIT_OK
  }
  const described = describeMermaid(parsed.value)
  process.stdout.write(json ? envelope({ text: described }) : described + '\n')
  return EXIT_OK
}

// ---- Loop 7 / A3.1: capabilities ------------------------------------------

type FamilyEditPolicy = 'structured-when-narrowed' | 'source-level-only'

interface FamilyCapability {
  id: string
  identity: {
    id: string
    version: string
    compatibility: Readonly<Record<string, string>>
    provenance: Readonly<Record<string, string>>
  }
  /** Bounded discovery projection. Stable witness ids remain available from
   * `getFamilyConformanceReport`; routine discovery retains every field needed
   * for capability negotiation and diagnostics. */
  conformance: FamilyConformanceDiscovery
  hasMutate: boolean
  hasExtractLabels: boolean
  mutationOps: string[]
  /** Full field shapes for each op — { opKind: [{name, required, type}] }, with
   *  enum vocabularies spelled out inline in `type`. Lets a model fill an op
   *  correctly on the first try instead of guessing field names/values and
   *  learning them only from the INVALID_OP error. Absent for source-level-only
   *  families (no structured ops). */
  opFields?: Record<string, OpFieldDoc[]>
  editPolicy: FamilyEditPolicy
  /** The `as*` narrower to call before structured mutation (e.g. `asState`). */
  narrower?: string
  /** Mermaid header keyword(s) that open this family (e.g. `stateDiagram-v2`,
   *  `architecture-beta`) — so a model authoring from blank opens with the right
   *  header instead of inferring it from `example` or defaulting to flowchart. */
  headers?: readonly string[]
  /** Bounded canonical source (header + core syntax) used by executable
   * registration conformance and agent discovery. */
  example: string
}

interface WarningCodeCapability {
  code: WarningCode
  tier: string
  severity: string
  /** Who can cause this code: the source, its configuration, or the engine. */
  origins: readonly WarningOrigin[]
}

interface CapabilitiesEnvelope {
  resolvedScene: typeof RESOLVED_SCENE_CAPABILITY
  sdkVersion: string
  families: FamilyCapability[]
  warningCodes: WarningCodeCapability[]
  outputFormats: CliRenderFormat[]
}

// Source of truth now lives in the agent layer (src/agent/mutation-ops.ts) so
// the mutators can name their valid ops in errors; imported and re-exported here
// to keep the capabilities envelope and existing `from '../cli/index.ts'`
// importers working.
import { MUTATION_OPS_BY_FAMILY } from '../agent/mutation-ops.ts'

export { MUTATION_OPS_BY_FAMILY }

import { describeOps, hasOpSchema, type OpFieldDoc } from '../agent/op-schema.ts'

type MutableFamilyId = keyof typeof MUTATION_OPS_BY_FAMILY

function boundedStringRecord(value: object): Readonly<Record<string, string>> {
  return Object.fromEntries(Object.entries(value).filter((entry): entry is [string, string] => typeof entry[1] === 'string'))
}

type FamilyConformanceDiscovery = Omit<FamilyConformanceReport, 'capabilities'> & {
  readonly capabilities: readonly Omit<FamilyConformanceReport['capabilities'][number], 'witnessId'>[]
}

/** Keep routine capability negotiation bounded without weakening the full
 * public conformance report. The rest projection deliberately carries future
 * result fields forward; only the audit-oriented witness locator is omitted. */
function familyConformanceDiscovery(report: FamilyConformanceReport): FamilyConformanceDiscovery {
  return {
    ...report,
    capabilities: report.capabilities.map(({ witnessId: _witnessId, ...result }) => result),
  }
}

export function buildCapabilities(): CapabilitiesEnvelope {
  const sdkVersion = PACKAGE_VERSION
  const mutableFamilies = new Set(Object.keys(MUTATION_OPS_BY_FAMILY))
  const families: FamilyCapability[] = knownFamilies().map(id => {
    const p = getFamily(id)!
    const mutationOps = id in MUTATION_OPS_BY_FAMILY ? [...MUTATION_OPS_BY_FAMILY[id as MutableFamilyId]] : []
    const editPolicy: FamilyEditPolicy = mutationOps.length > 0 ? 'structured-when-narrowed' : 'source-level-only'
    return {
      id,
      identity: {
        id: p.identity.id,
        version: p.identity.version,
        compatibility: boundedStringRecord(p.identity.compatibility),
        provenance: boundedStringRecord(p.identity.provenance),
      },
      conformance: familyConformanceDiscovery(getFamilyConformanceReport(id)!),
      // Capabilities describe the public agent surface, not whether the
      // implementation currently lives in a FamilyDescriptor hook or central
      // dispatch. Every registered family parses, serializes, verifies, and
      // renders — so those constant booleans are omitted (they read as a
      // "probe-me" menu with nothing to branch on). Only what actually varies
      // is emitted: whether structured mutation and label extraction apply.
      hasMutate: mutableFamilies.has(id),
      hasExtractLabels: Boolean(p.extractLabels),
      mutationOps,
      opFields: hasOpSchema(id) ? describeOps(id) : undefined,
      editPolicy,
      narrower: isBuiltinFamilyId(id) ? builtinFamilyMetadata(id)?.narrower : undefined,
      headers: p.headers,
      example: p.example,
    }
  })
  const warningCodes: WarningCodeCapability[] = (Object.keys(WARNING_SEVERITY) as WarningCode[]).map(code => ({
    code,
    tier: WARNING_TIER[code],
    severity: WARNING_SEVERITY[code],
    origins: WARNING_CATALOG[code].origins,
  }))
  return {
    sdkVersion,
    resolvedScene: RESOLVED_SCENE_CAPABILITY,
    families,
    warningCodes,
    outputFormats: [...CLI_RENDER_FORMATS],
  }
}

/** Resolve the --style flag: comma-separated style names and/or .json spec
 *  files forming a stack (merged left → right by resolveStyleStack). JSON
 *  specs are validated before use so bad files are arg errors, not throws. */
function parseStyleFlag(value: string): StyleInput[] {
  return value
    .split(',')
    .map(entry => entry.trim())
    .filter(Boolean)
    .map(entry => {
      if (entry.endsWith('.json') || existsSync(entry)) {
        if (!existsSync(entry)) throw new Error(`style spec file not found: ${entry}`)
        const spec = JSON.parse(readFileSync(entry, 'utf8')) as unknown
        const problems = validateStyleSpec(spec)
        if (problems.length > 0) throw new Error(`invalid style spec ${entry}: ${problems.join('; ')}`)
        return spec as StyleSpec
      }
      return entry
    })
}

function parseRenderOptionsFlag(value: string): RenderOptions {
  const raw = existsSync(value) ? readFileSync(value, 'utf8') : value
  let parsed: unknown
  try {
    parsed = JSON.parse(raw)
  } catch (error) {
    throw new Error(`expected JSON object or JSON file: ${error instanceof Error ? error.message : String(error)}`)
  }
  const problems = validateSerializableRenderOptions(parsed)
  if (problems.length > 0) throw new Error(problems.join('; '))
  return parsed as RenderOptions
}

function cmdStyles(json: boolean): number {
  const rows = knownStyleDescriptors().map(descriptor => ({
    name: descriptor.inputName,
    canonicalId: descriptor.identity.id,
    label: descriptor.displayLabel,
    kind: descriptor.kind,
    isDefault: descriptor.isDefault,
    backend: inferBackend(descriptor.spec),
    ...(descriptor.spec.intent ? { intent: descriptor.spec.intent } : {}),
    blurb: descriptor.spec.blurb ?? '',
  }))
  if (json) {
    process.stdout.write(JSON.stringify(rows) + '\n')
    return EXIT_OK
  }
  const nameWidth = Math.max(...rows.map(r => r.name.length))
  for (const r of rows) {
    process.stdout.write(`${r.name.padEnd(nameWidth)}  ${r.kind.padEnd(7)}  ${r.blurb}\n`)
  }
  process.stdout.write(`\nStack styles with: am render <file> --style <name[,name|file.json...]> [--seed N]\nAuthor your own: docs/style-authoring.md (JSON records; validate with validateStyleSpec).\n`)
  return EXIT_OK
}

/** `--summary` view: what an agent needs to pick a family and its typed path,
 * with one `--family` call for the op field schemas, conformance and example. */
export interface CapabilitiesSummary {
  view: 'summary'
  sdkVersion: string
  families: Array<Pick<FamilyCapability, 'id' | 'editPolicy' | 'narrower' | 'headers' | 'mutationOps'>>
  warningCodes: WarningCode[]
  outputFormats: CliRenderFormat[]
  detail: string
}

export function capabilitiesSummary(capabilities: CapabilitiesEnvelope): CapabilitiesSummary {
  return {
    view: 'summary',
    sdkVersion: capabilities.sdkVersion,
    families: capabilities.families.map(({ id, editPolicy, narrower, headers, mutationOps }) => ({ id, editPolicy, narrower, headers, mutationOps })),
    warningCodes: capabilities.warningCodes.map(warning => warning.code),
    outputFormats: capabilities.outputFormats,
    detail: 'am capabilities --family <id>[,<id>...] for opFields, conformance, identity and example',
  }
}

/** The envelope with `families` narrowed to the requested ids, in request order. */
export function capabilitiesForFamilies(capabilities: CapabilitiesEnvelope, ids: readonly string[]): CapabilitiesEnvelope {
  const byId = new Map(capabilities.families.map(family => [family.id, family]))
  const unknown = ids.filter(id => !byId.has(id))
  if (ids.length === 0 || unknown.length > 0) {
    throw new CliArgumentError(`am capabilities --family: ${ids.length === 0 ? 'expected one or more family ids' : `unknown family ${unknown.map(id => JSON.stringify(id)).join(', ')}`}; valid ids: ${[...byId.keys()].join(', ')}`)
  }
  return { ...capabilities, families: [...new Set(ids)].map(id => byId.get(id)!) }
}

/** `--summary` and `--full` choose the view; `--full` names today's default
 * explicitly so a caller can pin it before the default changes. */
function summaryViewRequested(args: ParsedArgs, command: string): boolean {
  const summary = flagEnabled(args, 'summary')
  if (summary && flagEnabled(args, 'full')) throw new CliArgumentError(`am ${command}: --summary and --full are mutually exclusive`)
  return summary
}

function cmdCapabilities(args: ParsedArgs): number {
  const summary = summaryViewRequested(args, 'capabilities')
  const familyFlag = flagValue(args, 'family')
  let capabilities = buildCapabilities()
  if (familyFlag !== undefined) capabilities = capabilitiesForFamilies(capabilities, familyFlag.split(',').map(id => id.trim()).filter(Boolean))
  process.stdout.write(JSON.stringify(summary ? capabilitiesSummary(capabilities) : capabilities) + '\n')
  return EXIT_OK
}

// ---- Loop 11 / M4 (#6430): llms.txt agent-discovery digest ----------------

/**
 * Build an llms.txt digest (https://llmstxt.org) for agent discovery.
 * Derived from buildCapabilities() so the family list, warning codes, and
 * output formats stay in sync with the actual SDK surface.
 */
export function buildLlmsTxt(): string {
  const cap = buildCapabilities()
  const families = cap.families.map(f => f.id).join(', ')
  const structured = cap.families.filter(f => f.hasMutate).map(f => f.id)
  const narrowers = BUILTIN_FAMILY_METADATA.map(f => f.narrower).join(', ')
  const formats = cap.outputFormats.join(', ')
  const codes = cap.warningCodes.map(w => `${w.code} (${w.tier}/${w.severity})`).join(', ')
  const looks = knownStyleDescriptors()
    .filter(descriptor => descriptor.kind === 'look')
    .map(descriptor => `'${descriptor.inputName}'`)
    .join(', ')
  return `# Agentic Mermaid

> Agent-native Mermaid runtime: parse, verify, mutate, and round-trip
> Mermaid diagrams with a typed IR. Deterministic render outputs. No
> browser required. CLI + MCP + library.

Version: ${cap.sdkVersion}

## What it does

A typed editing surface over Mermaid for AI agents. Parse a diagram to a
ValidDiagram, mutate it with typed ops, verify source and renderability,
serialize back to canonical source. Layout is deterministic (verified
cross-process and same-machine cross-runtime on x86_64/ARM64).

## The agent loop

${NEW_DIAGRAM_POLICY}
${EXISTING_DIAGRAM_WORKFLOW}
Run verify at every commit point. Never serialize a diagram whose verify result
you haven't inspected.

## CLI verbs (\`am <verb>\`)

- render --format ${CLI_RENDER_FORMATS.join(', ')} [--security strict] — render a diagram; PNG requires --output and does not support multi-input/watch
- render --style <names|file.json> --seed N — styled graphical/terminal output; comma-separate to stack (--style hand-drawn,dracula)
- styles [--json] — list registered styles (default + full looks + palette-only themes)
- parse — diagram → ValidDiagram JSON
- serialize — ValidDiagram JSON on stdin → canonical source (the inverse of parse)
- verify — structural validation (exit 3 if invalid, 4 if only INTERNAL_ERROR)
- mutate --op '<json>' / --ops '<json array|file>' — apply typed mutation(s), verify, then emit source
- preview [--output file.html] [--open] — standalone strict-mode HTML preview for user inspection
- format — normalize / canonicalize source
- describe [--format text|json|facts] — natural-language, AX-tree, or semantic facts summary
- capabilities --json — machine-readable capability envelope incl. editPolicy + mutationOps
- batch --jsonl — bulk render/verify/parse/serialize/mutate ops, one JSON envelope per line
- render-markdown <file.md> [--ascii] — render fenced mermaid blocks, skip invalid ones
- llms-txt — this document
- init-agent [--dir .] [--force] — write AGENTS.md section, root skills/ bundle, and .mcp.json sample

Exit codes: 0 ok, 2 arg error, 3 verify-failed, 4 internal (including a verify whose errors are all INTERNAL_ERROR), 124 exceeded --timeout (default 120 s; RENDER_TIMEOUT).

## MCP tools

Local MCP exposes ${LOCAL_MCP_TOOL_NAMES.length} tools: ${inlineToolList(LOCAL_MCP_TOOL_NAMES)}.
Hosted MCP exposes ${HOSTED_MCP_TOOL_NAMES.length} tools: ${inlineToolList(HOSTED_MCP_TOOL_NAMES)}.
\`render_png\` is offline on the local server. Hosted successful deterministic
results may be reused by a private server-side compute cache for up to 24 hours;
the HTTP response is always \`cache-control: no-store\` and reports compute reuse
through \`x-agentic-mermaid-compute-cache\`.

## Output formats

Agentic Mermaid outputs SVG, PNG, ASCII, Unicode, and JSON layout. Full capability list: ${formats}. SVG strict mode (security: 'strict') emits zero external-fetch
references — safe for untrusted/agent-generated diagrams. See SECURITY.md.

## Diagram families

All families parse, verify, render, round-trip: ${families}.
Structured mutation (${cap.families.find(f => f.hasMutate)?.editPolicy}): ${structured.join(', ')}.
Narrowers: ${narrowers}.
${FAMILY_NARROWING_NOTE}
State diagrams own a dedicated body (BUILD-19): narrow with asState; state-shaped ops apply (asFlowchart returns null on them).
Source-level-only: ${
    cap.families
      .filter(f => !f.hasMutate)
      .map(f => f.id)
      .join(', ') || 'none — every renderable family ships structured mutation'
  }.
Opaque-fallback bodies (unmodeled syntax) round-trip losslessly via preserved source (never silently dropped) and stay source-level only.

## Warning codes

${codes}

## Library

\`import { parseRegisteredMermaid, mutate, verifyMermaid, analyzeMermaid,
analyzeMermaidSource, serializeMermaid, renderMermaidASCII,
renderMermaidPNG, renderMermaidSVG, renderMermaidASCIIWithMeta,
describeMermaid, asciiToMermaid, verifyNoExternalRefs,
registerStyle, knownStyles, validateStyleSpec } from 'agentic-mermaid/agent'\`

## Styles

Every render call accepts style: a registered look name (${looks}), any palette
name, an inline JSON spec, or a stack
merged left → right ({ style: ['hand-drawn', 'dracula'] }). seed re-rolls
ink wobble, never layout — (source, style, seed) reproduces an image
exactly. Custom styles are data: validateStyleSpec(json) checks untrusted
records, registerStyle({ name, … }) makes them addressable by name.
Authoring guide + quality rubric: docs/style-authoring.md.

## Docs

- docs/README.md — documentation index and structure
- Instructions_for_agents.md — canonical agent-use guide
- AGENT_NATIVE.md — architecture/spec rationale
- docs/features.md — current capability inventory
- docs/api.md — library/CLI/MCP API reference, including SVG/PNG/ASCII output
- docs/diagram-families.md — family examples and edit policy
- docs/theming.md — themes, CSS variables, and Shiki compatibility
- docs/style-authoring.md — styles: the composable Look + Palette system (stack names/specs; author custom styles as data records with the quality rubric)
- docs/quality.md — determinism + "good looking" rubric
- TODO.md — only active backlog
- SECURITY.md — threat model + strict-mode guarantee
- docs/agent-mutation-policy.md — structured-vs-source-level policy
- docs/agent-api-cookbook.md — copy-pasteable library/CLI/MCP recipes
- docs/mcp-code-mode-rationale.md — MCP surface rationale
- docs/agent-workflow-examples.md — runnable MCP/CLI + agent-improvement examples
- skills/ — agent-agnostic SKILL.md bundles for diagram workflow and live-editor development
- skill-evals/ — skill-eval-harness manifest, fixtures, and benchmark instructions
`
}

function cmdLlmsTxt(): number {
  process.stdout.write(buildLlmsTxt())
  return EXIT_OK
}

function cmdInitAgent(args: ParsedArgs, json: boolean): number {
  const dirFlag = flagValue(args, 'dir')
  const dir = dirFlag === undefined ? process.cwd() : resolve(dirFlag)
  const force = flagEnabled(args, 'force')
  const result = initAgentFiles({ dir, force })
  if (json) {
    process.stdout.write(JSON.stringify({ ok: true, ...result }) + '\n')
    return EXIT_OK
  }
  const rel = (p: string) => (p.startsWith(dir) ? '.' + p.slice(dir.length) : p)
  for (const p of result.written) process.stdout.write(`  created  ${rel(p)}\n`)
  for (const p of result.appended) process.stdout.write(`  updated  ${rel(p)}\n`)
  for (const p of result.skipped) process.stdout.write(`  skipped  ${rel(p)} (exists; use --force if applicable)\n`)
  process.stdout.write('\nNext: read AGENTS.md, connect the MCP server in .mcp.json, or run `am --agent-instructions`.\n')
  return EXIT_OK
}

// ---- Loop 12 M5 (#543): render-markdown — convert fenced blocks ------------

export interface MarkdownBlockResult {
  index: number
  /** 1-based Markdown line of the block's opening fence. */
  line: number
  ok: boolean
  format?: string
  output?: string
  error?: RenderErrorDiagnostic | { code: string; message: string }
}

/**
 * Extract Mermaid fenced code blocks (CommonMark fences whose info string
 * starts with `mermaid`) from markdown and render each. A bad diagram yields an
 * { ok:false } entry and does NOT abort the rest (#543: "skip invalid diagrams
 * instead of failing the whole conversion").
 */
export function renderMarkdownBlocks(md: string, format: 'svg' | 'ascii' = 'svg'): MarkdownBlockResult[] {
  const blocks = extractMermaidFences(md)
  return collectBatched(
    blocks,
    ({ source: src, line }, i): MarkdownBlockResult => {
      try {
        const output = format === 'ascii' ? renderMermaidASCII(src, { useAscii: true }) : renderMermaidSVG(src)
        return { index: i, line, ok: true, format, output }
      } catch (e) {
        return { index: i, line, ok: false, error: cliStructuredRenderFailure(e, src).error }
      }
    },
    'MARKDOWN_BLOCK_ERROR',
  ).map((r, i) => (r.ok ? r.value : { index: i, line: blocks[i]!.line, ok: false, error: r.error }))
}

/** Verify each block with the existing source/renderability contract. A line
 * without a precise source diagnostic is explicitly marked as the block start. */
export function verifyMarkdownBlocks(markdown: string, options?: Parameters<typeof verifyMermaid>[1]) {
  return extractMermaidFences(markdown).map(fence => ({ source: fence.source, startLine: fence.line + 1 })).map((block, index) => {
    const verified = verifyMermaid(block.source, options)
    const warnings = verified.warnings.map(warning => {
      const line = 'line' in warning && typeof warning.line === 'number' && Number.isSafeInteger(warning.line) && warning.line > 0 ? warning.line : undefined
      return { ...warning, line: block.startLine + (line ?? 1) - 1, ...(line === undefined ? { lineIsBlockStart: true } : {}) }
    })
    return { index, startLine: block.startLine, ok: verified.ok, warnings }
  })
}

function cmdRenderMarkdown(args: ParsedArgs): number {
  const md = readSourceArg(args.positional[0])
  const format = flagEnabled(args, 'ascii') ? ('ascii' as const) : ('svg' as const)
  const results = renderMarkdownBlocks(md, format)
  process.stdout.write(JSON.stringify({ ok: true, blocks: results }) + '\n')
  // Per-block failures don't fail the command (#543) — exit OK.
  return EXIT_OK
}

// ---- Loop 7 / A3.2: batch -------------------------------------------------

interface BatchLine {
  op: 'render' | 'verify' | 'parse' | 'serialize' | 'mutate'
  source: string
  options?: Record<string, unknown>
  mutation?: AnyMutationOp
  mutations?: AnyMutationOp[]
  preserveSource?: boolean
}

export interface BatchRenderOptions extends Record<string, unknown> {
  format?: CliRenderFormat
  certificates?: boolean
  targetWidth?: number
}

interface BatchOutput {
  ok: boolean
  op?: string
  /** mutate lines: the MCP mutate envelope's family and failing op index. */
  family?: string | null
  opIndex?: number
  data?: unknown
  verify?: unknown
  error?: { code: string; message: string; details?: unknown }
}

/**
 * Execute a single batch line. Exported for tests; the CLI just shuttles
 * lines into and out of this function.
 */
export function runBatchLine(rawLine: string, lineIndex = 0): BatchOutput {
  let parsed: BatchLine
  try {
    parsed = JSON.parse(rawLine) as BatchLine
  } catch (e) {
    return { ok: false, error: { code: 'INVALID_JSON', message: (e as Error).message } }
  }
  if (!parsed || typeof parsed !== 'object' || typeof parsed.op !== 'string') {
    return { ok: false, error: { code: 'INVALID_PAYLOAD', message: 'missing op string' } }
  }
  const op = parsed.op
  if (['render', 'verify', 'parse', 'serialize', 'mutate'].includes(op) && typeof parsed.source !== 'string') {
    return { ok: false, op, error: { code: 'INVALID_PAYLOAD', message: 'missing source string' } }
  }
  try {
    switch (op) {
      case 'render': {
        const options = parsed.options === undefined ? {} : parsed.options
        if (typeof options !== 'object' || options === null || Array.isArray(options)) {
          return { ok: false, op, error: { code: 'INVALID_OPTIONS', message: 'batch render options must be a plain JSON object' } }
        }
        const { format: requestedFormat, certificates, targetWidth, ...sharedCandidate } = options as BatchRenderOptions
        if (requestedFormat !== undefined && typeof requestedFormat !== 'string') {
          return { ok: false, op, error: { code: 'INVALID_OPTIONS', message: 'batch render option "format" must be a string' } }
        }
        const format = requestedFormat ?? DEFAULT_CLI_RENDER_FORMAT
        if (!isCliRenderFormat(format) || renderOutputForCliFormat(format)?.id === 'png') {
          const supported = CLI_RENDER_FORMATS.filter(candidate => renderOutputForCliFormat(candidate)?.id !== 'png')
          return { ok: false, op, error: { code: 'INVALID_OPTIONS', message: `batch render format must be one of ${supported.join(', ')}` } }
        }
        const output = renderOutputForCliFormat(format)!
        if (certificates !== undefined && typeof certificates !== 'boolean') {
          return { ok: false, op, error: { code: 'INVALID_OPTIONS', message: 'batch render option "certificates" must be a boolean' } }
        }
        if (certificates === true && output.id !== 'layout') {
          return { ok: false, op, error: { code: 'INVALID_OPTIONS', message: 'batch render option "certificates" is valid only with format "layout"' } }
        }
        if (targetWidth !== undefined && (!Number.isInteger(targetWidth) || targetWidth <= 0)) {
          return { ok: false, op, error: { code: 'INVALID_OPTIONS', message: 'batch render option "targetWidth" must be a positive integer' } }
        }
        if (targetWidth !== undefined && output.id !== 'ascii' && output.id !== 'unicode') {
          return { ok: false, op, error: { code: 'INVALID_OPTIONS', message: 'batch render option "targetWidth" is valid only with format "ascii" or "unicode"' } }
        }
        const problems = validateSerializableRenderOptions(sharedCandidate)
        if (problems.length > 0) {
          return { ok: false, op, error: { code: 'INVALID_OPTIONS', message: problems.join('; ') } }
        }
        const sharedOptions = sharedCandidate as RenderOptions
        // Classify source admission errors before entering renderer internals;
        // malformed batch input is a documented PARSE_FAILED response, never
        // an INTERNAL failure that can poison an otherwise healthy JSONL run.
        preflightCliRenderableSource(parsed.source)
        // #7540: auto-namespace SVG ids per batch line so the rendered
        // diagrams can coexist on one HTML page without def-id collisions,
        // while retaining a caller-provided suffix.
        const rendered = renderSourceToFormatWithReceipt(parsed.source, format, {
          ...sharedOptions,
          ...(output.id === 'svg' ? { idPrefix: `d${lineIndex}-${sharedOptions.idPrefix ?? ''}` } : {}),
          ...(certificates === undefined ? {} : { certificates }),
          ...(targetWidth === undefined ? {} : { targetWidth }),
        })
        return { ok: true, op, data: { [format]: rendered.output, receipt: rendered.receipt } }
      }
      case 'verify': {
        const options = parsed.options === undefined ? {} : parsed.options
        if (typeof options !== 'object' || options === null || Array.isArray(options)) {
          return { ok: false, op, error: { code: 'INVALID_OPTIONS', message: 'batch verify options must be a plain JSON object' } }
        }
        const unknown = Object.keys(options).filter(key => key !== 'suppress' && key !== 'labelCharCap')
        if (unknown.length > 0) {
          return { ok: false, op, error: { code: 'INVALID_OPTIONS', message: `unknown batch verify option: ${unknown.join(', ')}` } }
        }
        const problem = verifyOptionsProblem(options)
        if (problem) {
          return { ok: false, op, error: { code: 'INVALID_OPTIONS', message: problem.field === 'labelCharCap' ? 'batch verify option "labelCharCap" must be a positive safe integer' : 'batch verify option "suppress" must be an array of known warning-code strings' } }
        }
        const r = verifyMermaid(parsed.source, options as { suppress?: WarningCode[]; labelCharCap?: number })
        if (!r.ok) {
          const verify = JSON.parse(JSON.stringify(r, replacer))
          return {
            ok: false,
            op,
            error: {
              code: 'VERIFY_FAILED',
              message: 'diagram failed verify',
              details: verify.warnings,
            },
            verify,
          }
        }
        return { ok: true, op, data: JSON.parse(JSON.stringify(r, replacer)) }
      }
      case 'parse': {
        // Batch is the streaming form of `am parse`; keep both on the open
        // registered-family envelope while preserving built-in result shapes.
        const r = parseRegisteredMermaid(parsed.source)
        if (!r.ok) {
          const env = parseErrorEnvelope(r.error)
          return { ok: false, op, error: env.error }
        }
        return { ok: true, op, data: JSON.parse(JSON.stringify(toJsonSafe(r.value), replacer)) }
      }
      case 'serialize': {
        // For batch, the line's `source` field is a JSON-stringified ValidDiagram
        // (same shape as `am parse` emits). We re-hydrate it via synthesizeFromGraph.
        let payload: unknown
        try {
          payload = JSON.parse(parsed.source)
        } catch (e) {
          return { ok: false, op, error: { code: 'INVALID_JSON', message: (e as Error).message } }
        }
        const r = synthesizeFromGraph(payload as Parameters<typeof synthesizeFromGraph>[0])
        if (!r.ok) return { ok: false, op, error: { code: 'SYNTHESIZE_FAILED', message: JSON.stringify(r.error) } }
        return { ok: true, op, data: { source: serializeMermaid(r.value) } }
      }
      case 'mutate': {
        const hasMutation = Object.hasOwn(parsed, 'mutation')
        const hasMutations = Object.hasOwn(parsed, 'mutations')
        if (hasMutation === hasMutations) {
          return { ok: false, op, error: { code: 'INVALID_OP', message: 'mutate batch line requires exactly one of mutation or mutations[]' } }
        }
        if (hasMutations && !Array.isArray(parsed.mutations)) {
          return { ok: false, op, error: { code: 'INVALID_OP', message: 'mutate batch line mutations must be a non-empty array' } }
        }
        const ops = (hasMutations ? parsed.mutations : [parsed.mutation]) as Parameters<typeof mutateSource>[1]
        if (ops.length === 0) return { ok: false, op, error: { code: 'INVALID_OP', message: 'mutate batch line mutations must be a non-empty array' } }
        if (parsed.preserveSource !== undefined && typeof parsed.preserveSource !== 'boolean') return { ok: false, op, error: { code: 'INVALID_OP', message: 'preserveSource must be boolean' } }
        const r = mutateSource(parsed.source, ops, parsed.preserveSource === true)
        if (!r.ok)
          return {
            ok: false,
            op,
            family: r.family,
            ...(r.opIndex !== undefined ? { opIndex: r.opIndex } : {}),
            error: {
              code: r.error.code,
              message: r.error.message,
              ...('details' in r.error && r.error.details !== undefined ? { details: r.error.details } : {}),
            },
            ...(r.verify ? { verify: JSON.parse(JSON.stringify(r.verify, replacer)) } : {}),
          }
        return { ok: true, op, data: { family: r.family, source: r.source, verify: JSON.parse(JSON.stringify(r.verify, replacer)), ...(r.mode ? { mode: r.mode } : {}) } }
      }
      default:
        return { ok: false, op, error: { code: 'UNKNOWN_OP', message: `unknown op: ${op}` } }
    }
  } catch (e) {
    // Project documented render diagnostics (family-detection UNKNOWN_HEADER/
    // UNSUPPORTED_FAMILY, ASCII_TARGET_WIDTH_IMPOSSIBLE) the same way every other CLI render
    // transport does (cmdRender/preview/render-markdown), instead of collapsing them to a
    // generic internal error. cliStructuredRenderFailure first honours an already-structured
    // throw; any remaining render-path exception is still a bounded RENDER_FAILED response.
    return { ok: false, op, error: cliStructuredRenderFailure(e).error }
  }
}

async function cmdBatch(): Promise<number> {
  if (process.stdin.isTTY) throw new CliArgumentError('needs a file argument or piped stdin')
  const { streamJsonlBatch } = await import('./jsonl.ts')
  await streamJsonlBatch(process.stdin, process.stdout, runBatchLine)
  // Per-line failures don't abort; input/output transport failures do.
  return EXIT_OK
}

function toJsonSafe(d: ParsedDiagram): unknown {
  if (d.body.kind === 'flowchart') {
    const g = d.body.graph
    return {
      kind: d.kind,
      meta: d.meta,
      body: {
        kind: 'flowchart',
        graph: {
          direction: g.direction,
          nodes: Object.fromEntries(g.nodes),
          edges: g.edges,
          subgraphs: g.subgraphs,
          // Preserve styling so `am parse | am serialize` is lossless.
          classDefs: Object.fromEntries(g.classDefs),
          classAssignments: Object.fromEntries(g.classAssignments),
          nodeStyles: Object.fromEntries(g.nodeStyles),
          linkStyles: Object.fromEntries([...g.linkStyles].map(([k, v]) => [String(k), v])),
        },
      },
      canonicalSource: d.canonicalSource,
    }
  }
  return { kind: d.kind, meta: d.meta, body: d.body, canonicalSource: d.canonicalSource }
}
