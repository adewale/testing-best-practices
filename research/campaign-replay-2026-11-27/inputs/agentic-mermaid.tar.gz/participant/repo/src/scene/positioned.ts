import { isOwnedFamily } from '../experimental/owned-family.ts'
import { finalizeOwnedScene } from './owned-data.ts'
import { assertBackendConformance, isBuiltinDefaultBackend } from './backend.ts'
import { nativeDrawingOf, originalNativeDrawingOf, isOriginalSceneLowering, type DrawingProducer } from './drawing.ts'
import { drawNative, type NativeDrawing } from './native-drawing.ts'
import type { FamilyLayoutResult } from '../agent/families.ts'
import type { ResolvedRenderRequest } from '../render-contract.ts'
import { resolvedFamilyRenderContextOf, resolvedRenderExecutionPlanOf } from '../render-contract.ts'
import { positionedForNativeProducer, positionedForSceneLowering, retainedFamilyProjection } from '../positioning.ts'
import { withTextMeasurementExecution } from '../text-measurement-profile.ts'
import { admitFamilyScene } from './admission.ts'
import { sceneAssertionsEnabled } from './assertions.ts'
import { withDeferredTerminalProjections } from './deferred-terminal-projection.ts'
import type { SceneDoc } from './ir.ts'
import { certifyNativePaint, certifyScenePaint, type PaintLayoutCertification } from './paint-certification.ts'
import { observeCache, observeFallback } from '../performance-observations.ts'
import { cachedNativeDrawing, retainNativeDrawing, type RetainedNativeDrawing } from '../experimental/position-cache.ts'

interface PositionedScene { scene: SceneDoc; crossChecks: boolean; certification?: PaintLayoutCertification }
type RenderableNativeDrawing = Pick<NativeDrawing, 'svg' | 'preparedText'>
interface PositionedNative { drawing: RenderableNativeDrawing; producer: DrawingProducer; evidence?: NativeDrawing; certification?: PaintLayoutCertification }
const native = new WeakMap<FamilyLayoutResult, WeakMap<ResolvedRenderRequest, PositionedNative>>()
const retained = new WeakMap<FamilyLayoutResult, WeakMap<ResolvedRenderRequest, PositionedScene>>()
// Above this conservative native custody capacity, retain one immutable Scene
// before drawing. This avoids spending the paint allowance on an abandoned
// native capture; both adapters certify under the same unchanged limits.
const ER_NATIVE_PAINT_NODE_CAPACITY = 256

/** Lower once from the actual positioned artifact, shared by SVG, layout,
 * verification and receipt consumers. No source parse or layout is repeated. */
export function retainedPositionedScene(request: ResolvedRenderRequest, layout: FamilyLayoutResult): SceneDoc {
  let requests = retained.get(layout)
  if (!requests) { requests = new WeakMap(); retained.set(layout, requests) }
  const prior = requests.get(request)
  if (prior) {
    observeCache('positioned-scene', 'hit')
    if (sceneAssertionsEnabled(request) && !prior.crossChecks) {
      admitFamilyScene(resolvedRenderExecutionPlanOf(request).family, prior.scene, true)
      prior.crossChecks = true
    }
    return prior.scene
  }
  observeCache('positioned-scene', 'miss')
  const plan = resolvedRenderExecutionPlanOf(request)
  if (!plan.family.lowerScene) throw new Error(`Resolved ${request.output} family has no Scene lowering`)
  const colors = request.output === 'png' && request.appearance.colors.embedFontImport !== false
    ? { ...request.appearance.colors, embedFontImport: false } : request.appearance.colors
  const assertions = sceneAssertionsEnabled(request)
  const lower = () => {
    const scene = plan.family.lowerScene!({ positioned: positionedForSceneLowering(layout), colors, resolved: resolvedFamilyRenderContextOf(request) })
    // Freeze only the unwrapped constructor program's result, directly at its
    // owning boundary. Replaced/inherited hooks retain external-data copying.
    return isOwnedFamily(plan.family) && isOriginalSceneLowering(plan.family.lowerScene) ? finalizeOwnedScene(scene) : scene
  }
  const scene = withTextMeasurementExecution(plan.textMeasurement, () => admitFamilyScene(plan.family,
    !assertions && !plan.family.id.startsWith('family:') ? withDeferredTerminalProjections(lower) : lower(), assertions))
  requests.set(request, { scene, crossChecks: assertions })
  return scene
}

/** Native crisp work has no Scene document/group tree. Strong evidence and
 * alternate backends deliberately retain the extension-facing Scene adapter. */
export function retainedNativeDrawing(request: ResolvedRenderRequest, layout: FamilyLayoutResult): RenderableNativeDrawing | undefined {
  const plan = resolvedRenderExecutionPlanOf(request)
  let bypass = sceneAssertionsEnabled(request) ? 'scene-assertions' : plan.family.id.startsWith('family:') ? 'external-family'
    : plan.backend && !isBuiltinDefaultBackend(plan.backend.backend) ? 'alternate-backend'
      : !(plan.mode === 'layout' ? request.appearance.inferredBackend === 'default' : plan.mode === 'scene' && plan.backend?.inputName === 'default') ? 'unsupported-mode' : undefined
  if (!bypass && plan.family.id === 'er' && (retainedFamilyProjection(layout)?.nodes.length ?? 0) > ER_NATIVE_PAINT_NODE_CAPACITY) bypass = 'paint-proof-capacity'
  let producer = bypass ? undefined : nativeDrawingOf(plan.family.lowerScene)
  if (!producer) bypass ??= 'no-native-producer'
  if (bypass) {
    observeCache('native-drawing', 'bypass', bypass)
    observeFallback('native-drawing', bypass)
    return undefined
  }
  let requests = native.get(layout)
  if (!requests) { requests = new WeakMap(); native.set(layout, requests) }
  const prior = requests.get(request)
  if (prior) {
    observeCache('native-drawing', 'hit')
    if (prior.producer === nativeDrawingOf(plan.family.lowerScene)) return prior.drawing
    observeCache('native-drawing', 'bypass', 'changed-producer')
    requests.delete(request)
  }
  // Reading conformance proves the same default writer capability as render().
  if (plan.backend) assertBackendConformance(plan.backend.conformance, plan.backend.inputName)
  // Positioning's ownership proof must still hold after layout observers run.
  // A changed producer executes on its detached graph and cannot publish a
  // drawing under the original producer's private cache entry.
  producer = nativeDrawingOf(plan.family.lowerScene)
  const cached = cachedNativeDrawing(request, layout, producer === originalNativeDrawingOf(plan.family.lowerScene))
  if (cached) {
    observeCache('native-drawing', 'hit', undefined, 'positioned-owner')
    const cachedProducer = producer
    if (cachedProducer && cachedProducer === nativeDrawingOf(plan.family.lowerScene) && cachedProducer === originalNativeDrawingOf(plan.family.lowerScene)) {
      requests.set(request, { drawing: cached, producer: cachedProducer, certification: cached.certification })
      return cached
    }
    // An observation callback changed the producer after the lookup. Revoke
    // this operation's proof and construct from the producer now installed.
    observeCache('native-drawing', 'bypass', 'changed-producer')
    cachedNativeDrawing(request, layout, false)
    producer = nativeDrawingOf(plan.family.lowerScene)
  }
  observeCache('native-drawing', 'miss')
  producer = nativeDrawingOf(plan.family.lowerScene)
  if (!producer) {
    observeCache('native-drawing', 'bypass', 'no-native-producer')
    observeFallback('native-drawing', 'no-native-producer')
    return undefined
  }
  const drawingProducer = producer
  const colors = request.output === 'png' && request.appearance.colors.embedFontImport !== false
    ? { ...request.appearance.colors, embedFontImport: false } : request.appearance.colors
  const drawing = withTextMeasurementExecution(plan.textMeasurement, () => drawNative(drawingProducer,
    { positioned: positionedForNativeProducer(layout, drawingProducer), colors, resolved: resolvedFamilyRenderContextOf(request) }, plan.family.id, request.appearance.styled ? request.appearance.style : undefined, isOwnedFamily(plan.family) && drawingProducer === originalNativeDrawingOf(plan.family.lowerScene)))
  requests.set(request, { drawing, producer: drawingProducer, evidence: drawing })
  return drawing
}

/** The receipt's layout certificate also records geometry drawn uncertified
 * and a graph laid out under the bounded cost profile. */
function withGeometryCertification(certification: PaintLayoutCertification, layout: FamilyLayoutResult): PaintLayoutCertification {
  const layoutCost = (layout.positioned as { layoutCost?: PaintLayoutCertification['layoutCost'] }).layoutCost
  if (!layout.uncertifiedLayout && !layoutCost) return certification
  return Object.freeze({ ...certification, ...(layout.uncertifiedLayout ? { geometry: layout.uncertifiedLayout } : {}), ...(layoutCost ? { layoutCost } : {}) })
}

export function positionedPaintCertification(request: ResolvedRenderRequest, layout: FamilyLayoutResult): PaintLayoutCertification {
  const existing = native.get(layout)?.get(request)
  const drawing = existing?.drawing ?? retainedNativeDrawing(request, layout)
  if (drawing) {
    const entry = native.get(layout)!.get(request)!
    observeCache('paint-certification', entry.certification ? 'hit' : 'miss', undefined, 'native')
    if (entry.certification) return entry.certification
    const evidence = entry.evidence!
    const certification = withGeometryCertification(certifyNativePaint(evidence.header, evidence.paint, retainedFamilyProjection(layout), { outputSupported: !request.appearance.colors.shadow }), layout)
    entry.certification = certification
    const retained: RetainedNativeDrawing = Object.freeze({ svg: drawing.svg, preparedText: drawing.preparedText, certification })
    const lower = resolvedRenderExecutionPlanOf(request).family.lowerScene
    if (entry.producer === nativeDrawingOf(lower) && entry.producer === originalNativeDrawingOf(lower)) retainNativeDrawing(request, layout, retained)
    else {
      observeCache('native-drawing', 'store-skipped', 'changed-producer')
      cachedNativeDrawing(request, layout, false)
    }
    return certification
  }
  const scene = retainedPositionedScene(request, layout)
  const entry = retained.get(layout)!.get(request)!
  observeCache('paint-certification', entry.certification ? 'hit' : 'miss', undefined, 'scene')
  if (entry.certification) return entry.certification
  const plan = resolvedRenderExecutionPlanOf(request)
  const supported = !request.appearance.colors.shadow && (plan.mode === 'layout' ? request.appearance.inferredBackend === 'default' : plan.mode === 'scene' && plan.backend?.inputName === 'default')
  return entry.certification = withGeometryCertification(certifyScenePaint(scene, retainedFamilyProjection(layout), { outputSupported: supported }), layout)
}
