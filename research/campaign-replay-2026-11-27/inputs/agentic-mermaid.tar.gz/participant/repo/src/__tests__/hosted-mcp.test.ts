// Hosted MCP server core (src/mcp/hosted-server.ts): the tool surface the
// website Worker serves at /mcp. Pure tools run for real; the execute /
// renderPng seams — a Dynamic Worker isolate and resvg-wasm in production —
// are purpose-built fakes that record their calls.

import { describe, expect, test } from 'bun:test'
import {
  handleHostedRequest, HOSTED_MCP_SERVER_NAME, HOSTED_TOOLS, MAX_CODE_BYTES, MAX_SOURCE_BYTES,
  SUPPORTED_PROTOCOL_VERSIONS, cacheKeyFor, type HostedMcpContext, type ExecuteResult,
} from '../mcp/hosted-server.ts'
import { MCP_SERVER_NAME, createRenderPngTool, validateMcpToolArguments } from '../mcp/tool-surface.ts'
import { summarizeRenderReceipt } from '../mcp/receipt-summary.ts'
import { renderMermaidPNGWithReceipt } from '../agent/png.ts'
import type { JsonRpcRequest } from '../mcp/protocol.ts'
import { isLegacyProtocolVersion } from '../mcp/protocol-versions.ts'
import pkg from '../../package.json'
import { visualWidth } from '../ascii/width.ts'
import { renderMermaidASCII, renderMermaidSVG, verifyNoExternalRefs, type RenderOptions } from '../index.ts'
import { MAX_HOSTED_PNG_BYTES, PNG_WASM_RUNTIME, PngRasterizerError } from '../png-contract.ts'
import { mkdtempSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { runCli } from '../cli/index.ts'
import { createTracingMermaid } from '../mcp/facade.ts'
import { HOSTED_CODE_MODE_HOST_POLICY } from '../render-host-policy.ts'
import { captureCli } from './helpers/cli-capture.ts'
import { AjvJsonSchemaValidator } from '@modelcontextprotocol/sdk/validation/ajv'
import { handleRequest, LOCAL_TOOLS } from '../mcp/server.ts'
import { styleSpecJsonSchema } from '../scene/style-spec.ts'
import { knownStyleDescriptors } from '../scene/style-registry.ts'

const FLOW = 'flowchart TD\n  A[Start] --> B{OK?}\n  B -->|yes| C[Done]'
// The published view URI and the MCP Apps MIME type are public contracts.
const VIEW_URI = 'ui://agentic-mermaid/preview'
const MCP_APP_MIME = 'text/html;profile=mcp-app'
const TEST_PNG_RECEIPT = { version: 2, output: 'png', sharedRequestDigest: 'test-shared', requestDigest: 'test-request', appearanceDigest: 'test-appearance', capabilityDecision: { version: 1, accepted: true, resolutions: [] } } as const

function makeContext(overrides: Partial<HostedMcpContext> = {}): HostedMcpContext & { executeCalls: Array<{ code: string; timeoutMs: number }>; pngCalls: Array<{ source: string; scale?: number; background?: string; security?: 'default' | 'strict'; embedFontImport?: boolean }> } {
  const executeCalls: Array<{ code: string; timeoutMs: number }> = []
  const pngCalls: Array<{ source: string; scale?: number; background?: string; security?: 'default' | 'strict'; embedFontImport?: boolean }> = []
  return {
    executeCalls,
    pngCalls,
    async execute(code, timeoutMs): Promise<ExecuteResult> {
      executeCalls.push({ code, timeoutMs })
      return { ok: true, value: 42, logs: [] }
    },
    async renderPng(source, opts) {
      pngCalls.push({ source, ...opts })
      return { png: new Uint8Array([0x89, 0x50, 0x4e, 0x47]), warnings: [], receipt: TEST_PNG_RECEIPT, runtime: PNG_WASM_RUNTIME }
    },
    ...overrides,
  }
}

function rpc(method: string, params?: unknown, id: number | string = 1): JsonRpcRequest {
  return { jsonrpc: '2.0', id, method, params }
}

function call(name: string, args: Record<string, unknown>): JsonRpcRequest {
  return rpc('tools/call', { name, arguments: args })
}

function payloadOf(res: Awaited<ReturnType<typeof handleHostedRequest>>): any {
  const result = res?.result as { content: Array<{ text: string }>; isError: boolean }
  return { ...JSON.parse(result.content[0]!.text), isError: result.isError }
}

describe('hosted MCP handshake', () => {
  const legacyVersions = SUPPORTED_PROTOCOL_VERSIONS.filter(isLegacyProtocolVersion)
  const initializeParams = (protocolVersion: string) => ({
    protocolVersion,
    capabilities: {},
    clientInfo: { name: 'hosted-test', version: '0' },
  })

  test('initialize echoes a supported legacy protocol version', async () => {
    for (const version of legacyVersions) {
      const res = await handleHostedRequest(rpc('initialize', initializeParams(version)), makeContext())
      expect((res?.result as any).protocolVersion).toBe(version)
    }
  })

  test('initialize falls back to the newest served legacy version', async () => {
    for (const version of ['1999-01-01', '2026-07-28']) {
      const res = await handleHostedRequest(rpc('initialize', initializeParams(version)), makeContext())
      expect((res?.result as any).protocolVersion).toBe(legacyVersions.at(-1))
    }
  })

  test.each([undefined, {}, { protocolVersion: '2025-11-25' }, {
    protocolVersion: '2025-11-25', capabilities: {}, clientInfo: { name: 'missing-version' },
  }])('initialize rejects malformed params %#', async params => {
    const res = await handleHostedRequest(rpc('initialize', params), makeContext())
    expect(res?.error?.code).toBe(-32602)
  })

  test('initialize reports the package version and hosted instructions', async () => {
    const res = await handleHostedRequest(rpc('initialize', initializeParams('2025-11-25')), makeContext())
    const result = res?.result as any
    expect(result.serverInfo).toEqual({ name: 'agentic-mermaid-hosted', version: pkg.version })
    expect(result.instructions).toContain('stateless')
    expect(result.instructions).toContain('render_svg')
    expect(result.capabilities).toEqual({
      tools: {},
      resources: { subscribe: false, listChanged: false },
    })
  })

  test('the hosted identity is distinct from the local stdio server', () => {
    // Registries and clients cache tool lists by server identity; the hosted
    // surface (10 tools) must never shadow the local server's (4 tools).
    expect(HOSTED_MCP_SERVER_NAME).not.toBe(MCP_SERVER_NAME)
  })

  test('tools/list exposes exactly the hosted tool surface', async () => {
    const res = await handleHostedRequest(rpc('tools/list'), makeContext())
    const names = (res?.result as any).tools.map((t: { name: string }) => t.name)
    expect(names).toEqual(['execute', 'describe_sdk', 'render_svg', 'render_ascii', 'render_png', 'verify', 'describe', 'mutate', 'build', 'preview'])
    expect((res?.result as any).tools).toBe(HOSTED_TOOLS)
    const execute = (res?.result as any).tools.find((tool: { name: string }) => tool.name === 'execute')
    for (const signature of ['renderMermaidSVGWithReceipt(', 'renderMermaidASCIIWithReceipt(', 'layoutMermaidWithReceipt(']) {
      expect(execute.description).toContain(signature)
    }
    for (const tool of (res?.result as any).tools) {
      expect(tool.title).toEqual(expect.any(String))
      expect(tool.title.trim()).not.toBe('')
      expect(tool.annotations).toEqual(expect.objectContaining({
        readOnlyHint: true,
        destructiveHint: false,
        openWorldHint: false,
      }))
    }
    expect((res?.result as any).tools.find((tool: any) => tool.name === 'execute').annotations.idempotentHint).toBe(false)
    for (const name of ['describe_sdk', 'render_svg', 'render_ascii', 'render_png', 'verify', 'describe', 'mutate', 'build', 'preview']) {
      expect((res?.result as any).tools.find((tool: any) => tool.name === name).annotations.idempotentHint).toBe(true)
    }
  })

  test('render_svg discovery uses the canonical nested Style schema', () => {
    const renderSvg = HOSTED_TOOLS.find(tool => tool.name === 'render_svg')!
    const options = (renderSvg.inputSchema.properties as Record<string, any>).options
    const styleDescription = options?.properties?.style?.description ?? ''
    expect(styleDescription).toContain('registered name')
    expect(styleDescription.toLowerCase()).not.toContain('cupertino')
  })

  // Every render tool on both surfaces: tools/list loads these into each agent
  // context, so the ~8 KB StyleSpec record (and the role records it names) must
  // be defined once per tool, not inlined per style alternative, and every
  // reference must resolve from the tool schema a client receives.
  const renderTools = [...HOSTED_TOOLS, ...LOCAL_TOOLS].filter(tool => tool.name.startsWith('render_'))

  test('render tool schemas define each shared record once and resolve every $ref from the tool root', () => {
    const recordDescription = (styleSpecJsonSchema() as { description: string }).description
    const resolve = (root: unknown, ref: string) => ref.startsWith('#/')
      ? ref.slice(2).split('/').reduce<any>((node, part) => node?.[part.replaceAll('~1', '/').replaceAll('~0', '~')], root)
      : undefined
    const ajv = new AjvJsonSchemaValidator()
    for (const tool of renderTools) {
      const text = JSON.stringify(tool.inputSchema)
      expect({ tool: tool.name, records: text.split(JSON.stringify(recordDescription)).length - 1 }).toEqual({ tool: tool.name, records: 1 })
      const refs: string[] = []
      const nestedResources: string[] = []
      const refSiblings: string[] = []
      // Keys of a `properties`/`$defs` map are names (StyleSpec has a `$schema`
      // field), not keywords; only keyword positions are inspected.
      const walk = (node: unknown, depth: number, names = false) => {
        if (Array.isArray(node)) return node.forEach(child => walk(child, depth + 1))
        if (!node || typeof node !== 'object') return
        // draft-07 validators ignore every keyword beside a `$ref`, so a
        // constraint placed there would be advertised but not enforced.
        if (!names && '$ref' in node) refSiblings.push(...Object.keys(node).filter(key => key !== '$ref'))
        for (const [key, child] of Object.entries(node)) {
          if (!names && key === '$ref' && typeof child === 'string') refs.push(child)
          if (!names && depth > 0 && (key === '$id' || key === '$schema')) nestedResources.push(key)
          walk(child, depth + 1, !names && (key === 'properties' || key === '$defs'))
        }
      }
      walk(tool.inputSchema, 0)
      expect({ tool: tool.name, nestedResources, refSiblings }).toEqual({ tool: tool.name, nestedResources: [], refSiblings: [] })
      expect({ tool: tool.name, unresolved: refs.filter(ref => resolve(tool.inputSchema, ref) === undefined) }).toEqual({ tool: tool.name, unresolved: [] })
      // A validator we did not write (the MCP SDK's client-side Ajv provider)
      // still checks every field through the references.
      const check = ajv.getValidator(tool.inputSchema as never)
      expect(check({ source: FLOW, options: { style: ['hand-drawn', { roughness: 2 }], mermaidConfig: { flowchart: { curve: 'basis' } } } }).valid).toBe(true)
      expect(check({ source: FLOW, options: { style: [{ roughness: 'rough' }] } }).valid).toBe(false)
      expect(check({ source: FLOW, options: { style: { nope: 1 } } }).valid).toBe(false)
    }
  })

  test('every render tool describes options with the same registered Look and Palette menu', () => {
    const descriptions = new Set(renderTools.map(tool => (tool.inputSchema.properties as Record<string, any>).options.description))
    expect(descriptions.size).toBe(1)
    const [description] = descriptions
    for (const descriptor of knownStyleDescriptors()) expect(description).toContain(descriptor.inputName)
  })

  test('unknown methods and unknown tools are JSON-RPC errors', async () => {
    const method = await handleHostedRequest(rpc('resources/subscribe'), makeContext())
    expect(method?.error?.code).toBe(-32601)
    const tool = await handleHostedRequest(call('render_gif', { source: FLOW }), makeContext())
    expect(tool?.error?.code).toBe(-32602)
  })

  test('resources/list publishes the MCP Apps view and no templates', async () => {
    const resources = await handleHostedRequest(rpc('resources/list'), makeContext())
    expect((resources?.result as any).resources).toEqual([expect.objectContaining({ uri: VIEW_URI, mimeType: MCP_APP_MIME })])
    // The spec places _meta.ui on the read contents item, never on the listing.
    expect((resources?.result as any).resources[0]._meta).toBeUndefined()
    const templates = await handleHostedRequest(rpc('resources/templates/list'), makeContext())
    expect((templates?.result as any).resourceTemplates).toEqual([])
    // Both rosters fit one page; a cursor the server never issued is refused.
    for (const method of ['resources/list', 'resources/templates/list']) {
      expect((await handleHostedRequest(rpc(method, { cursor: 'garbage' }), makeContext()))?.error?.code).toBe(-32602)
    }
  })

  test('resources/read serves the view with a CSP that grants no origin; other URIs are invalid params', async () => {
    const read = await handleHostedRequest(rpc('resources/read', { uri: VIEW_URI }), makeContext())
    expect((read?.result as any).contents).toEqual([{
      uri: VIEW_URI,
      mimeType: MCP_APP_MIME,
      text: expect.stringMatching(/^<!doctype html>/),
      _meta: {
        ui: {
          csp: { connectDomains: [], resourceDomains: [], frameDomains: [], baseUriDomains: [] },
          prefersBorder: true,
        },
      },
    }])
    const missing = await handleHostedRequest(rpc('resources/read', { uri: 'ui://agentic-mermaid/nope' }), makeContext())
    expect(missing?.error?.code).toBe(-32602)
    expect(missing?.error?.data).toEqual({ uri: 'ui://agentic-mermaid/nope' })
    const badParams = await handleHostedRequest(rpc('resources/read', {}), makeContext())
    expect(badParams?.error?.code).toBe(-32602)
  })

  test('every UI-linked tool points at a listed view', async () => {
    const preview = HOSTED_TOOLS.find(tool => tool.name === 'preview')!
    expect(preview._meta).toEqual({ ui: { resourceUri: VIEW_URI } })
    const listed = ((await handleHostedRequest(rpc('resources/list'), makeContext()))?.result as any).resources
      .map((resource: { uri: string }) => resource.uri)
    for (const tool of HOSTED_TOOLS) {
      const uri = tool._meta?.ui?.resourceUri
      if (uri !== undefined) expect({ tool: tool.name, listed: listed.includes(uri) }).toEqual({ tool: tool.name, listed: true })
    }
  })

  test('preview gives the model the verify facts and only the view the strict SVG', async () => {
    const res = await handleHostedRequest(call('preview', { source: FLOW }), makeContext())
    const result = res?.result as { content: Array<{ text: string }>; structuredContent: Record<string, any>; isError: boolean }
    const forModel = JSON.parse(result.content[0]!.text)
    expect(Object.keys(forModel).sort()).toEqual(['checks', 'family', 'ok', 'summary', 'warnings'])
    expect(forModel).toMatchObject({ ok: true, family: 'flowchart', summary: expect.stringContaining('flowchart') })
    expect(result.isError).toBe(false)
    // The view gets the same facts plus the SVG, which MCP Apps hosts keep out
    // of model context.
    const { svg, ...facts } = result.structuredContent
    expect(facts).toEqual(forModel)
    expect(svg.startsWith('<svg')).toBe(true)
    expect(verifyNoExternalRefs(svg).ok).toBe(true)
  })

  test('preview reports parse failures with the family example hint', async () => {
    const payload = payloadOf(await handleHostedRequest(call('preview', { source: 'flowchart TD\n  A -->' }), makeContext()))
    expect(payload.ok).toBe(false)
    expect(payload.errors).toEqual([expect.objectContaining({ code: 'PARSE_FAILED' })])
    expect(payload.svg).toBeUndefined()
    expect(payload.family).toBe('flowchart')
  })

  test('notifications return null; ping pongs', async () => {
    expect(await handleHostedRequest({ jsonrpc: '2.0', method: 'notifications/initialized' }, makeContext())).toBeNull()
    expect((await handleHostedRequest(rpc('ping'), makeContext()))?.result).toEqual({})
  })
})

describe('hosted pure tools', () => {
  test('dispatch rejects malformed convenience and advanced arguments as -32602', async () => {
    const context = makeContext()
    const malformed: JsonRpcRequest[] = [
      rpc('tools/call', { name: 'render_svg', arguments: [] }),
      call('render_svg', { source: FLOW, bg: 123 }),
      call('render_svg', { source: FLOW, seed: 'bad' }),
      call('render_svg', { source: FLOW, options: { padding: 'wide' } }),
      call('render_svg', { source: FLOW, style: 'not-a-registered-style' }),
      call('render_svg', { source: FLOW, bg: 'url(https://invalid.example)' }),
      call('render_ascii', { source: FLOW, useAscii: 'yes' }),
      call('render_ascii', { source: FLOW, targetWidth: 3.5 }),
      call('render_ascii', { source: FLOW, targetWidth: 0 }),
      call('render_png', { source: FLOW, scale: 'large' }),
      call('render_png', { source: FLOW, background: 123 }),
      call('render_png', { source: FLOW, seed: 'bad' }),
      call('describe', { source: FLOW, format: 'yaml' }),
      call('verify', { source: 42 }),
      call('execute', { code: '1 + 1', timeoutMs: 'fast' }),
      call('render_svg', { source: FLOW, unexpected: true }),
      // preview advertises options as a pointer to render_svg's schema but
      // validates them against the same canonical schema.
      call('preview', { source: FLOW, options: { padding: 'wide' } }),
      call('preview', { source: FLOW, options: { style: 'not-a-registered-style' } }),
    ]
    for (const request of malformed) {
      const response = await handleHostedRequest(request, context)
      expect(response?.error?.code).toBe(-32602)
      expect(response?.error?.message).toContain('Invalid')
    }
    expect(context.executeCalls).toEqual([])
    expect(context.pngCalls).toEqual([])
  })

  test('dispatch rejects a below-64KB deeply nested advanced config without throwing', async () => {
    let config: unknown = true
    for (let index = 0; index < 8_000; index++) config = { a: config }
    const args = { source: FLOW, options: { mermaidConfig: config } }
    expect(JSON.stringify(args).length).toBeLessThan(64 * 1024)
    const context = makeContext()
    const response = await handleHostedRequest(call('render_svg', args), context)
    expect(response?.error?.code).toBe(-32602)
    expect(response?.error?.message).toContain('exceeds maximum nesting depth 64')
    expect(context.executeCalls).toEqual([])
    expect(context.pngCalls).toEqual([])
  })

  // The StyleSpec validator owns these diagnoses; a union over its shapes
  // must not replace them with "must be a registered Style name or StyleSpec".
  test.each([
    [{ roughness: 99 }, '"roughness" must be between 0 and 10'],
    [{ bogus: 1 }, 'unknown field "bogus"'],
    [{ colors: { bg: 'url(http://x)' } }, 'color token "bg" must be a safe non-fetching CSS color'],
    [['hand-drawn', { colors: { bg: '#12345' } }], 'color token "bg" must be a safe non-fetching CSS color'],
    ['handdrawn', 'Unknown style "handdrawn". Did you mean "hand-drawn"?'],
    ['Dracula', 'Unknown style "Dracula". Did you mean "dracula"?'],
  ])('MCP tools and the library name the same StyleInput problem for %j', async (style, problem) => {
    const hosted = await handleHostedRequest(call('render_svg', { source: FLOW, options: { style } }), makeContext())
    expect(hosted?.error?.code).toBe(-32602)
    expect(hosted?.error?.message).toContain(problem)
    expect(validateMcpToolArguments(createRenderPngTool('local'), { source: FLOW, options: { style } }).join('\n')).toContain(problem)
    expect(() => renderMermaidSVG(FLOW, { style } as RenderOptions)).toThrow(problem)
  })

  test('a guessed theme render option points at mermaidConfig.theme and style on every surface', async () => {
    const hint = 'set a Mermaid theme with mermaidConfig.theme, or a registered Style or Palette with style'
    const hosted = await handleHostedRequest(call('render_svg', { source: FLOW, options: { theme: 'dark' } }), makeContext())
    expect(hosted?.error?.message).toContain(`arguments.options.theme is not allowed; ${hint}`)
    expect(validateMcpToolArguments(createRenderPngTool('local'), { source: FLOW, options: { theme: 'dark' } }))
      .toEqual([`arguments.options.theme is not allowed; ${hint}`])
    expect(() => renderMermaidSVG(FLOW, { theme: 'dark' } as RenderOptions)).toThrow(`unknown render option "theme"; ${hint}`)
  })

  test('render_svg renders deterministic themeable SVG', async () => {
    const first = payloadOf(await handleHostedRequest(call('render_svg', { source: FLOW }), makeContext()))
    expect(first.ok).toBe(true)
    expect(first.isError).toBe(false)
    expect(first.svg).toStartWith('<svg')
    expect(first.svg).toContain('Start')
    expect(verifyNoExternalRefs(first.svg)).toEqual({ ok: true, refs: [] })
    const second = payloadOf(await handleHostedRequest(call('render_svg', { source: FLOW }), makeContext()))
    expect(second.svg).toBe(first.svg)
    const dark = payloadOf(await handleHostedRequest(call('render_svg', {
      source: FLOW,
      options: { bg: '#101014', fg: '#e6e6f0' },
    }), makeContext()))
    expect(dark.svg).toContain('#101014')
    expect(dark.svg).not.toBe(first.svg)
    const weaker = payloadOf(await handleHostedRequest(call('render_svg', {
      source: FLOW,
      options: { security: 'default', embedFontImport: true },
    }), makeContext()))
    expect(weaker.svg).toBe(first.svg)
    expect(verifyNoExternalRefs(weaker.svg)).toEqual({ ok: true, refs: [] })
    expect(weaker.svg).not.toContain('@import')
  })

  test('render_svg rejects removed top-level render options', async () => {
    const response = await handleHostedRequest(call('render_svg', {
      source: FLOW,
      bg: '#101014',
      seed: 7,
    }), makeContext())
    expect(response?.error?.code).toBe(-32602)
    expect(response?.error?.message).toContain('arguments.bg')
  })

  test('render_svg does not advertise or accept the removed theme input', async () => {
    const tool = HOSTED_TOOLS.find(candidate => candidate.name === 'render_svg')!
    expect((tool.inputSchema.properties as Record<string, any>)).not.toHaveProperty('theme')
    const response = await handleHostedRequest(call('render_svg', { source: FLOW, theme: 'paper' }), makeContext())
    expect(response?.error?.code).toBe(-32602)
    expect(response?.error?.message).toContain('arguments.theme')
  })

  test('render_svg rejects raw theme CSS instead of rewriting active content', async () => {
    const injected = '@import url(https://evil.example/font.css);</style><svg id="hosted-xss" onload="globalThis.pwned=1"></svg><style>'
    const source = `%%{init: ${JSON.stringify({ themeCSS: injected })}}%%\nxychart-beta\n  x-axis [A, B]\n  y-axis 0 --> 10\n  bar [1, 2]`
    const payload = payloadOf(await handleHostedRequest(call('render_svg', { source }), makeContext()))
    expect(payload.ok).toBe(false)
    expect(payload.isError).toBe(true)
    expect(payload.error).toEqual({ code: 'RENDER_FAILED', origin: 'config', message: expect.stringContaining('themeCSS is not allowed in strict security mode') })
    expect(payload).not.toHaveProperty('svg')
  })

  test('render tools expose source config diagnostics instead of dropping them', async () => {
    const source = '---\nconfig:\n  state:\n    titleTopMargin: 10\n---\nstateDiagram-v2\n  A --> B'
    for (const name of ['render_svg', 'render_ascii']) {
      const payload = payloadOf(await handleHostedRequest(call(name, { source }), makeContext()))
      expect(payload.ok).toBe(true)
      expect(payload.warnings).toContainEqual(expect.objectContaining({
        code: 'INEFFECTIVE_CONFIG', field: 'state.titleTopMargin',
      }))
    }
  })

  test('render tools on every surface report config warnings for the mermaidConfig the caller passed', async () => {
    const mermaidConfig = { theme: 'darkk', flowchart: { madeUpKey: 1 } }
    const expected = [
      expect.objectContaining({ code: 'INEFFECTIVE_CONFIG', field: 'theme' }),
      expect.objectContaining({ code: 'INEFFECTIVE_CONFIG', field: 'flowchart.madeUpKey' }),
    ]
    const surfaces: Array<[string, unknown]> = []
    for (const name of ['render_svg', 'render_ascii', 'render_png']) {
      surfaces.push([`hosted ${name}`, payloadOf(await handleHostedRequest(call(name, { source: FLOW, options: { mermaidConfig } }), makeContext())).warnings])
    }
    surfaces.push(['stdio render_png', payloadOf(await handleRequest(call('render_png', { source: FLOW, options: { mermaidConfig } })) as any).warnings])
    const input = join(mkdtempSync(join(tmpdir(), 'am-config-warnings-')), 'flow.mmd')
    writeFileSync(input, FLOW)
    const cli = captureCli(() => runCli(['render', input, '--format', 'svg', '--json', '--options', JSON.stringify({ mermaidConfig })]))
    surfaces.push(['cli render', JSON.parse(cli.out).warnings])
    for (const [surface, warnings] of surfaces) {
      expect({ surface, warnings }).toEqual({ surface, warnings: expect.arrayContaining(expected) })
    }
  })

  test('render_ascii returns the library drawing in the Unicode and ASCII charsets', async () => {
    const source = 'flowchart LR\n  A[Start] --> B{OK?}'
    const unicode = payloadOf(await handleHostedRequest(call('render_ascii', { source }), makeContext()))
    expect(unicode.ok).toBe(true)
    expect(unicode.text).toBe(renderMermaidASCII(source, { colorMode: 'none' }))
    expect(unicode.text).toContain('┌')
    const ascii = payloadOf(await handleHostedRequest(call('render_ascii', { source, useAscii: true }), makeContext()))
    expect(ascii.text).toBe(renderMermaidASCII(source, { useAscii: true, colorMode: 'none' }))
    expect(ascii.text).not.toContain('┌')
  })

  test('render_ascii reports only options the caller passed, and the same warnings as the CLI', async () => {
    // The host's SVG policy cannot change terminal text, and an option the
    // caller never passed is not reported as one terminals ignore.
    const source = 'flowchart LR\n  A --> B\n  B --> C\n  C --> C'
    const optionNotes = (payload: any) => payload.receipt.diagnostics
      .filter((diagnostic: { code: string }) => diagnostic.code.startsWith('TERMINAL_RENDER_OPTION'))
      .map((diagnostic: { feature: string }) => diagnostic.feature)
    const baseline = payloadOf(await handleHostedRequest(call('render_ascii', { source }), makeContext()))
    expect(baseline.ok).toBe(true)
    expect(baseline.warnings).toEqual([])
    expect(optionNotes(baseline)).toEqual([])
    const input = join(mkdtempSync(join(tmpdir(), 'am-hosted-ascii-')), 'chain.mmd')
    writeFileSync(input, source)
    const cli = captureCli(() => runCli(['render', input, '--format', 'unicode', '--json']))
    expect(JSON.parse(cli.out)).toMatchObject({ ok: true, unicode: baseline.text, warnings: baseline.warnings })

    const asked = payloadOf(await handleHostedRequest(call('render_ascii', {
      source,
      options: { security: 'default', embedFontImport: true },
    }), makeContext()))
    expect(asked.text).toBe(baseline.text)
    expect(asked.warnings).toEqual([])
    expect(optionNotes(asked)).toEqual(['render-option:embedFontImport', 'render-option:security'])

    // Code Mode under the hosted policy follows the same rule.
    const hostedCodeMode = createTracingMermaid(undefined, undefined, undefined, HOSTED_CODE_MODE_HOST_POLICY)
    expect(optionNotes(hostedCodeMode.renderMermaidASCIIWithReceipt(source, { colorMode: 'none' }))).toEqual([])
  })

  test('render_ascii exposes targetWidth and typed impossible-width errors', async () => {
    const bounded = payloadOf(await handleHostedRequest(call('render_ascii', {
      source: 'flowchart TD\n  A["日本語 descriptive terminal label"] --> B[Done]',
      targetWidth: 28,
    }), makeContext()))
    expect(bounded.ok).toBe(true)
    expect(Math.max(...bounded.text.split('\n').map(visualWidth))).toBeLessThanOrEqual(28)

    const impossible = payloadOf(await handleHostedRequest(call('render_ascii', {
      source: 'flowchart TD\n  A[🙂]',
      targetWidth: 1,
    }), makeContext()))
    expect(impossible.ok).toBe(false)
    expect(impossible.error).toMatchObject({
      code: 'ASCII_TARGET_WIDTH_IMPOSSIBLE',
      requestedWidth: 1,
      family: 'flowchart',
      reason: 'UNBREAKABLE_GRAPHEME',
    })
  })

  test('verify returns warnings and a layout summary for valid sources', async () => {
    const p = payloadOf(await handleHostedRequest(call('verify', { source: FLOW }), makeContext()))
    expect(p.ok).toBe(true)
    expect(Array.isArray(p.warnings)).toBe(true)
    expect(p.layout.nodes).toBe(3)
    expect(p.layout.edges).toBe(2)
    expect(p.layout.bounds.w).toBeGreaterThan(0)
    // The result echoes the detected family + a summary so ok:true is never a
    // silent pass on the wrong diagram type.
    expect(p.family).toBe('flowchart')
    expect(typeof p.summary).toBe('string')
    expect(p.summary.length).toBeGreaterThan(0)
  })

  test('verify echoes the detected family so a wrong-type diagram is self-evident', async () => {
    // Asked (elsewhere) for an architecture diagram but authored a flowchart:
    // verify still passes structurally, but the echoed family reveals the mismatch.
    const p = payloadOf(await handleHostedRequest(call('verify', { source: 'graph TD\n  API --> DB' }), makeContext()))
    expect(p.ok).toBe(true)
    expect(p.family).toBe('flowchart')
    expect(p.summary.toLowerCase()).toContain('flowchart')
  })

  test('verify surfaces parse errors as structured payloads, not crashes', async () => {
    const p = payloadOf(await handleHostedRequest(call('verify', { source: 'flowchart XX\n  A --> B' }), makeContext()))
    expect(p.ok).toBe(false)
    expect(p.isError).toBe(true)
    expect(p.errors.length).toBeGreaterThan(0)
    expect(typeof p.errors[0].message).toBe('string')
    // Self-describing: the header names a known family, so the failure response
    // carries that family's canonical example to author from.
    expect(p.family).toBe('flowchart')
    expect(p.example).toContain('flowchart')
  })

  test('describe summarizes a diagram and can return json or facts', async () => {
    const text = payloadOf(await handleHostedRequest(call('describe', { source: FLOW }), makeContext()))
    expect(text.ok).toBe(true)
    expect(text.text).toContain('flowchart')
    const tree = payloadOf(await handleHostedRequest(call('describe', { source: FLOW, format: 'json' }), makeContext()))
    expect(tree.ok).toBe(true)
    expect(tree.tree.kind).toBe('flowchart')
    const facts = payloadOf(await handleHostedRequest(call('describe', { source: FLOW, format: 'facts' }), makeContext()))
    expect(facts.ok).toBe(true)
    expect(facts.facts).toContain('edge A -> B')
    expect(facts.facts).toContain('edge B -> C : yes')
  })

  test('pure tools reject missing source and cap oversized source', async () => {
    for (const name of ['render_svg', 'render_ascii', 'verify', 'describe']) {
      const missing = await handleHostedRequest(call(name, {}), makeContext())
      expect(missing?.error?.code).toBe(-32602)
      const big = payloadOf(await handleHostedRequest(call(name, { source: 'flowchart TD\n' + 'x'.repeat(MAX_SOURCE_BYTES) }), makeContext()))
      expect(big.ok).toBe(false)
      expect(big.error.code).toBe('SOURCE_TOO_LARGE')
      expect(big.error.message).toContain('agentic-mermaid.dev/docs/mcp')
    }
  })
})

describe('hosted declarative mutate/build tools', () => {
  test('build authors a diagram from ops and returns the canonical envelope', async () => {
    const res = await handleHostedRequest(call('build', { family: 'class', ops: [
      { kind: 'add_class', id: 'Duck' }, { kind: 'add_member', class: 'Duck', text: '+quack()' },
    ] }), makeContext())
    const p = payloadOf(res)
    expect(p.isError).toBe(false)
    expect(p.ok).toBe(true)
    expect(p.family).toBe('class')
    expect(p.source).toContain('Duck')
    expect(p.verify).toHaveProperty('ok')
  })

  test('mutate edits existing source', async () => {
    const res = await handleHostedRequest(call('mutate', { source: 'classDiagram\n  class Animal', ops: [{ kind: 'add_class', id: 'Dog' }] }), makeContext())
    const p = payloadOf(res)
    expect(p.ok).toBe(true)
    expect(p.source).toContain('class Dog')
  })

  test('mutate and build publish intentional empty results with truthful diagnostics', async () => {
    const mutated = payloadOf(await handleHostedRequest(call('mutate', {
      source: 'flowchart TD\n  A[Only]\n',
      ops: [{ kind: 'remove_node', id: 'A' }],
    }), makeContext()))
    expect(mutated).toMatchObject({
      ok: true,
      family: 'flowchart',
      source: 'flowchart TD\n',
      verify: { ok: false, warnings: [{ code: 'EMPTY_DIAGRAM' }] },
    })

    const built = payloadOf(await handleHostedRequest(call('build', {
      family: 'flowchart',
      ops: [
        { kind: 'add_node', id: 'A', label: 'A' },
        { kind: 'remove_node', id: 'A' },
      ],
    }), makeContext()))
    expect(built).toMatchObject({ ok: true, source: 'flowchart TD\n', verify: { ok: false, warnings: [{ code: 'EMPTY_DIAGRAM' }] } })
  })

  test('Architecture junction, boundary-edge, accessibility, and in-place edge ops cross the hosted boundary', async () => {
    const built = payloadOf(await handleHostedRequest(call('build', { family: 'architecture', ops: [
      { kind: 'set_accessibility_title', title: 'Hosted topology' },
      { kind: 'add_group', id: 'app', label: 'Application' },
      { kind: 'add_service', id: 'api', label: 'API', group: 'app' },
      { kind: 'add_junction', id: 'bus' },
      { kind: 'add_edge', from: 'api', to: 'bus', fromSide: 'R', toSide: 'L', fromBoundary: 'group', label: 'events' },
    ] }), makeContext()))
    expect(built.ok).toBe(true)
    expect(built.source).toContain('accTitle: Hosted topology')
    expect(built.source).toContain('api{group}:R -[events]-> L:bus')

    const mutated = payloadOf(await handleHostedRequest(call('mutate', { source: built.source, ops: [
      { kind: 'update_edge', index: 0, fromBoundary: 'item', fromSide: 'B', toSide: 'T', label: 'queued' },
      { kind: 'set_group_label', id: 'app', label: 'App Plane' },
    ] }), makeContext()))
    expect(mutated.ok).toBe(true)
    expect(mutated.source).toContain('group app[App Plane]')
    expect(mutated.source).toContain('api:B -[queued]-> T:bus')
    expect(mutated.verify.ok).toBe(true)
  })

  test('a malformed op is a prescriptive in-band error (isError), not a mangled diagram', async () => {
    const res = await handleHostedRequest(call('build', { family: 'class', ops: [{ kind: 'add_class', name: 'Duck' }] }), makeContext())
    const p = payloadOf(res)
    expect(p.isError).toBe(true)
    expect(p.ok).toBe(false)
    expect(p.opIndex).toBe(0)
    expect(p.error.message).toContain('Valid fields: id, label, generic, members, namespace')
    expect(p.error.message).not.toContain('undefined')
  })

  test('mutate requires source+ops; build requires family+ops', async () => {
    expect((await handleHostedRequest(call('mutate', { ops: [] }), makeContext()))?.error?.code).toBe(-32602)
    expect((await handleHostedRequest(call('build', { family: 'class' }), makeContext()))?.error?.code).toBe(-32602)
    expect((await handleHostedRequest(call('mutate', { source: 'classDiagram\n  class A', ops: [] }), makeContext()))?.error?.code).toBe(-32602)
    expect((await handleHostedRequest(call('build', { family: 'class', ops: [] }), makeContext()))?.error?.code).toBe(-32602)
    for (const name of ['mutate', 'build']) {
      const tool = HOSTED_TOOLS.find(candidate => candidate.name === name)!
      const args = name === 'mutate'
        ? { source: 'classDiagram\n  class A', ops: [] }
        : { family: 'class', ops: [] }
      expect(validateMcpToolArguments(tool, args).join(' ')).toContain('must contain at least 1 item')
    }
  })

  test('tool descriptions defer family schemas to describe_sdk', () => {
    const execute = HOSTED_TOOLS.find(t => t.name === 'execute')!
    const mutate = HOSTED_TOOLS.find(t => t.name === 'mutate')!
    const build = HOSTED_TOOLS.find(t => t.name === 'build')!
    // Include metrics, layout selectors, parse positions and nested op field
    // docs (OpFieldDoc) within this limit; family edit schemas stay
    // progressively loaded.
    expect(new TextEncoder().encode(execute.description).length).toBeLessThan(15_350)
    expect(mutate.description).toContain('describe_sdk')
    expect(build.description).toContain('describe_sdk')
    expect(mutate.description).not.toContain('add_class(id, label?, generic?, members?, namespace?)')
    expect(build.description).not.toContain('add_series(kind2, name?, values)')
  })

  test('describe_sdk returns compact signatures or exact family field schemas', async () => {
    const signatures = payloadOf(await handleHostedRequest(call('describe_sdk', { family: 'xychart', detail: 'signatures' }), makeContext()))
    expect(signatures).toEqual(expect.objectContaining({ ok: true, family: 'xychart', detail: 'signatures', isError: false }))
    expect(signatures.signatures).toContain('add_series(kind2, name?, values)')

    const fields = payloadOf(await handleHostedRequest(call('describe_sdk', { family: 'gantt' }), makeContext()))
    expect(fields).toEqual(expect.objectContaining({ ok: true, family: 'gantt', detail: 'fields', isError: false }))
    expect(fields.ops.add_task).toContainEqual(expect.objectContaining({ name: 'taskId', required: false, type: 'string' }))

    const badFamily = await handleHostedRequest(call('describe_sdk', { family: 'nope' }), makeContext())
    expect(badFamily?.error?.code).toBe(-32602)
    expect(badFamily?.error?.message).toContain('family must be one of')
  })
})

describe('hosted execute', () => {
  test('delegates to the injected sandbox with the default 5s budget', async () => {
    const ctx = makeContext()
    const p = payloadOf(await handleHostedRequest(call('execute', { code: '1 + 1' }), ctx))
    expect(p).toEqual({ ok: true, value: 42, logs: [], isError: false })
    expect(ctx.executeCalls).toEqual([{ code: '1 + 1', timeoutMs: 5000 }])
  })

  test('caps positive timeouts and rejects nonpositive budgets', async () => {
    const ctx = makeContext()
    await handleHostedRequest(call('execute', { code: '1', timeoutMs: 90_000 }), ctx)
    const invalid = await handleHostedRequest(call('execute', { code: '1', timeoutMs: 0 }), ctx)
    await handleHostedRequest(call('execute', { code: '1', timeoutMs: 250 }), ctx)
    expect(ctx.executeCalls.map(c => c.timeoutMs)).toEqual([30_000, 250])
    expect(invalid?.error).toEqual(expect.objectContaining({ code: -32602 }))
  })

  test('screens sync-only violations before any isolate is involved', async () => {
    const ctx = makeContext()
    const p = payloadOf(await handleHostedRequest(call('execute', { code: 'await fetch("https://x")' }), ctx))
    expect(p.ok).toBe(false)
    expect(p.error.code).toBe('EXECUTE_FAILED')
    expect(p.error.message).toContain('Code Mode is synchronous')
    expect(ctx.executeCalls).toHaveLength(0)
  })

  test('rejects non-string code and oversized code without calling the sandbox', async () => {
    const ctx = makeContext()
    const missing = await handleHostedRequest(call('execute', {}), ctx)
    expect(missing?.error?.code).toBe(-32602)
    const big = payloadOf(await handleHostedRequest(call('execute', { code: '1 + ' + '1'.repeat(MAX_CODE_BYTES) }), ctx))
    expect(big.ok).toBe(false)
    expect(big.error.code).toBe('CODE_TOO_LARGE')
    expect(big.error.message).toContain('agentic-mermaid.dev/docs/mcp')
    expect(ctx.executeCalls).toHaveLength(0)
  })

  test('sandbox failures degrade to a structured { code, message } error, not a thrown 500', async () => {
    const ctx = makeContext({ execute: async () => { throw new Error('loader unavailable') } })
    const p = payloadOf(await handleHostedRequest(call('execute', { code: '1 + 1' }), ctx))
    expect(p.ok).toBe(false)
    expect(p.isError).toBe(true)
    expect(p.error.code).toBe('EXECUTE_FAILED')
    expect(p.error.message).toContain('loader unavailable')
  })

  test('sandbox-reported failures carry the same envelope, classified by cause', async () => {
    // Every hosted tool errors as { code, message }; execute is no exception.
    // A runner-tagged budget overrun (execute-loader failure()) is
    // EXECUTE_TIMEOUT; anything else — user throw, syntax error — is
    // EXECUTE_FAILED, message verbatim.
    const timedOut = makeContext({ execute: async () => ({ ok: false, error: 'Script execution exceeded its 5000ms CPU budget', code: 'EXECUTE_TIMEOUT', logs: [] }) })
    const t = payloadOf(await handleHostedRequest(call('execute', { code: 'while (true) {}' }), timedOut))
    expect(t.error).toEqual({ code: 'EXECUTE_TIMEOUT', message: 'Script execution exceeded its 5000ms CPU budget' })
    const threw = makeContext({ execute: async () => ({ ok: false, error: 'boom', logs: ['before the throw'] }) })
    const e = payloadOf(await handleHostedRequest(call('execute', { code: 'throw new Error("boom")' }), threw))
    expect(e.error).toEqual({ code: 'EXECUTE_FAILED', message: 'boom' })
    expect(e.logs).toEqual(['before the throw']) // logs survive the re-shaping
  })
})

describe('hosted render_png', () => {
  test('threads deterministic font warnings through the complete tool payload', async () => {
    const warning = {
      code: 'PNG_FONT_COVERAGE' as const,
      script: 'CJK',
      chars: ['日', '本', '語'],
      message: 'known bundled-font coverage gap',
    }
    const ctx = makeContext({ renderPng: async () => ({ png: new Uint8Array([0x89, 0x50, 0x4e, 0x47]), warnings: [warning], receipt: TEST_PNG_RECEIPT, runtime: PNG_WASM_RUNTIME }) })
    const payload = payloadOf(await handleHostedRequest(call('render_png', { source: 'flowchart LR\n  A[日本語]' }), ctx))
    expect(payload.ok).toBe(true)
    expect(payload.png_base64).toBe('iVBORw==')
    expect(payload.warnings).toEqual([warning])
  })
  test('combines source config diagnostics with raster font warnings', async () => {
    const fontWarning = { code: 'PNG_FONT_COVERAGE' as const, script: 'CJK', chars: ['日'], message: 'font gap' }
    const ctx = makeContext({ renderPng: async () => ({ png: new Uint8Array([0x89, 0x50, 0x4e, 0x47]), warnings: [fontWarning], receipt: TEST_PNG_RECEIPT, runtime: PNG_WASM_RUNTIME }) })
    const source = '---\nconfig:\n  state:\n    titleTopMargin: 10\n---\nstateDiagram-v2\n  A[日] --> B'
    const payload = payloadOf(await handleHostedRequest(call('render_png', { source }), ctx))
    expect(payload.ok).toBe(true)
    expect(payload.warnings).toContainEqual(expect.objectContaining({ field: 'state.titleTopMargin' }))
    expect(payload.warnings).toContainEqual(fontWarning)
  })

  test('returns base64 PNG bytes from the injected rasterizer', async () => {
    const ctx = makeContext()
    const p = payloadOf(await handleHostedRequest(call('render_png', { source: FLOW, scale: 3, background: '#fff' }), ctx))
    expect(p.ok).toBe(true)
    expect(atob(p.png_base64)).toBe('\x89PNG')
    expect(p.runtime).toEqual(PNG_WASM_RUNTIME)
    expect(ctx.pngCalls).toEqual([{
      source: FLOW, scale: 3, background: '#ffffff', security: 'strict', embedFontImport: false,
    }])
  })

  test('forces strict PNG security after caller-supplied advanced options', async () => {
    const ctx = makeContext()
    const payload = payloadOf(await handleHostedRequest(call('render_png', {
      source: FLOW,
      options: { security: 'default', seed: 4 },
    }), ctx))
    expect(payload.ok).toBe(true)
    expect(ctx.pngCalls).toEqual([expect.objectContaining({ security: 'strict', seed: 4 })])
  })

  test('PNG accepts shared render fields only through the canonical options object', async () => {
    const ctx = makeContext()
    const payload = payloadOf(await handleHostedRequest(call('render_png', {
      source: FLOW,
      options: { style: 'hand-drawn', seed: 1 },
    }), ctx))
    expect(payload.ok).toBe(true)
    expect(ctx.pngCalls).toEqual([expect.objectContaining({ style: 'hand-drawn', seed: 1, security: 'strict' })])
  })

  test('a PNG larger than one base64 chunk round-trips byte-for-byte', async () => {
    // base64Encode spreads each 0x8000-byte slice through String.fromCharCode;
    // a payload spanning several chunks (plus a partial tail) exercises the
    // boundary joins. A wrong chunk stride would drop or duplicate bytes.
    const big = new Uint8Array(0x8000 * 2 + 123)
    for (let i = 0; i < big.length; i++) big[i] = i % 256
    const ctx = makeContext({ renderPng: async () => ({ png: big, warnings: [], receipt: TEST_PNG_RECEIPT, runtime: PNG_WASM_RUNTIME }) })
    const p = payloadOf(await handleHostedRequest(call('render_png', { source: FLOW }), ctx))
    expect(p.ok).toBe(true)
    const decoded = Uint8Array.from(atob(p.png_base64), c => c.charCodeAt(0))
    expect(decoded).toEqual(big)
  })

  test('rejects oversized hosted bytes before constructing a base64 response', async () => {
    const oversized = new Uint8Array(MAX_HOSTED_PNG_BYTES + 1)
    const ctx = makeContext({ renderPng: async () => ({
      png: oversized,
      warnings: [],
      receipt: TEST_PNG_RECEIPT,
      runtime: PNG_WASM_RUNTIME,
    }) })
    const payload = payloadOf(await handleHostedRequest(call('render_png', { source: FLOW }), ctx))
    expect(payload.ok).toBe(false)
    expect(payload.isError).toBe(true)
    expect(payload.error.code).toBe('PNG_OUTPUT_TOO_LARGE')
    expect(payload).not.toHaveProperty('png_base64')
  })

  test('preserves every positive finite portable scale before rasterizing', async () => {
    const ctx = makeContext()
    await handleHostedRequest(call('render_png', { source: FLOW, scale: 100 }), ctx)
    await handleHostedRequest(call('render_png', { source: FLOW, scale: 0.001 }), ctx)
    await handleHostedRequest(call('render_png', { source: FLOW, scale: 3 }), ctx)
    expect(ctx.pngCalls.map(c => c.scale)).toEqual([100, 0.001, 3])
  })

  test('file/url artifact modes are a local-server feature', async () => {
    // Hosted output takes only the in-response modes (base64, image).
    const res = await handleHostedRequest(call('render_png', { source: FLOW, output: 'file' }), makeContext())
    expect(res?.error?.code).toBe(-32602)
    expect(res?.error?.message).toContain('arguments.output')
  })

  test('output=image returns the same PNG bytes as an image content block', async () => {
    const real = renderMermaidPNGWithReceipt(FLOW)
    const ctx = makeContext({ renderPng: async () => ({ png: real.png, warnings: [], receipt: TEST_PNG_RECEIPT, runtime: PNG_WASM_RUNTIME }) })
    const base64 = payloadOf(await handleHostedRequest(call('render_png', { source: FLOW }), ctx))
    const response = await handleHostedRequest(call('render_png', { source: FLOW, output: 'image' }), ctx)
    const result = response?.result as { content: Array<{ type: string; text?: string; data?: string; mimeType?: string }>; isError: boolean }
    expect(result.isError).toBe(false)
    expect(result.content.map(block => block.type)).toEqual(['text', 'image'])
    expect(result.content[1]!.mimeType).toBe('image/png')
    expect(result.content[1]!.data).toBe(base64.png_base64)
    const decoded = Uint8Array.from(atob(result.content[1]!.data!), c => c.charCodeAt(0))
    expect(decoded).toEqual(new Uint8Array(real.png))
    const meta = JSON.parse(result.content[0]!.text!)
    expect(meta).not.toHaveProperty('png_base64')
    expect(meta).toMatchObject({ ok: true, mimeType: 'image/png', bytes: real.png.byteLength, receipt: TEST_PNG_RECEIPT, runtime: PNG_WASM_RUNTIME })
    // Dimensions are the PNG header's, independently of the helper that reports them.
    const header = new DataView(real.png.buffer, real.png.byteOffset + 16, 8)
    expect([meta.width, meta.height]).toEqual([header.getUint32(0), header.getUint32(4)])
  })

  test('reports unavailability when no rasterizer is wired', async () => {
    const ctx = makeContext()
    ctx.renderPng = undefined
    const p = payloadOf(await handleHostedRequest(call('render_png', { source: FLOW }), ctx))
    expect(p.ok).toBe(false)
    expect(p.error.code).toBe('PNG_UNAVAILABLE')
  })

  test('rasterizer and runtime failures are internal errors that keep host details out', async () => {
    const hostDetail = '/srv/worker/generated/resvg.wasm'
    for (const thrown of [
      new PngRasterizerError('loading its resources', new Error(`${hostDetail}: init failed`)),
      new TypeError(`Cannot read properties of undefined (reading '${hostDetail}')`),
      Object.assign(new Error(`ENOENT: no such file or directory, open '${hostDetail}'`), { errno: -2, syscall: 'open' }),
    ]) {
      const ctx = makeContext({ renderPng: async () => { throw thrown } })
      const p = payloadOf(await handleHostedRequest(call('render_png', { source: FLOW }), ctx))
      expect(p.ok).toBe(false)
      expect(p.error, thrown.name).toEqual({ code: 'INTERNAL_ERROR', message: expect.any(String) })
      expect(JSON.stringify(p), thrown.name).not.toContain(hostDetail)
    }
  })
})

// A 30-node, 3-subgraph flowchart: its terminal receipt repeats one connector
// limitation per edge, the case receipt:'summary' groups.
const STAGED = ['flowchart LR', ...[0, 1, 2].flatMap(stage => [
  `  subgraph S${stage}[Stage ${stage}]`,
  ...Array.from({ length: 10 }, (_, step) => `    N${stage}_${step}[Step ${stage}.${step}]`),
  ...Array.from({ length: 9 }, (_, step) => `    N${stage}_${step} --> N${stage}_${step + 1}`),
  '  end',
]), '  N0_9 --> N1_0', '  N1_9 -.-> N2_0'].join('\n')

describe('render receipt views', () => {
  type Diagnostic = { code: string; message?: string; feature?: string }
  type Receipt = Record<string, any> & { diagnostics?: Diagnostic[] }
  const cases = [
    ['render_svg', FLOW], ['render_svg', STAGED], ['render_ascii', FLOW], ['render_ascii', STAGED],
    ['render_ascii', 'sequenceDiagram\n  A->>B: hi\n  B-->>A: ok'], ['render_svg', 'pie\n  "a" : 1\n  "b" : 2'],
  ] as const
  test.each(cases)('%s summary corresponds to the full receipt of the same request (%#)', async (tool, source) => {
    const ctx = makeContext()
    const omitted = payloadOf(await handleHostedRequest(call(tool, { source }), ctx))
    const full = payloadOf(await handleHostedRequest(call(tool, { source, receipt: 'full' }), ctx))
    const summary = payloadOf(await handleHostedRequest(call(tool, { source, receipt: 'summary' }), ctx))
    expect(omitted).toEqual(full)
    const { receipt: fullReceipt, ...fullRest } = full as { receipt: Receipt }
    const { receipt: view, ...summaryRest } = summary as { receipt: Receipt }
    expect(summaryRest).toEqual(fullRest)
    expect(view).toMatchObject({
      view: 'summary',
      version: fullReceipt.version,
      output: fullReceipt.output,
      requestDigest: fullReceipt.requestDigest,
      accepted: fullReceipt.capabilityDecision.accepted,
    })
    expect(view.capabilityResolutions ?? []).toEqual(fullReceipt.capabilityDecision.resolutions.filter((r: { status: string }) => r.status !== 'selected'))
    const certification = fullReceipt.layoutCertification
    expect(view.layoutCertification).toEqual(certification === undefined ? undefined : {
      status: certification.status,
      issues: certification.issues,
      ...(certification.geometry === undefined ? {} : { geometry: certification.geometry }),
    })
    // Every full diagnostic is counted once, under an entry with its code and message.
    const fullDiagnostics = fullReceipt.diagnostics ?? []
    const groups = (view.diagnostics ?? []) as Array<Diagnostic & { count: number }>
    expect(groups.reduce((total, group) => total + group.count, 0)).toBe(fullDiagnostics.length)
    for (const diagnostic of fullDiagnostics) {
      const matching = groups.filter(group => group.code === diagnostic.code && group.message === diagnostic.message)
      expect({ code: diagnostic.code, groups: matching.length }).toEqual({ code: diagnostic.code, groups: 1 })
    }
    for (const group of groups) {
      expect({ code: group.code, count: group.count }).toEqual({
        code: group.code,
        count: fullDiagnostics.filter(diagnostic => diagnostic.code === group.code && diagnostic.message === group.message).length,
      })
    }
  })

  test('the staged terminal receipt collapses per-edge connector diagnostics', async () => {
    const ctx = makeContext()
    const full = payloadOf(await handleHostedRequest(call('render_ascii', { source: STAGED }), ctx))
    const summary = payloadOf(await handleHostedRequest(call('render_ascii', { source: STAGED, receipt: 'summary' }), ctx))
    const limitations = (full.receipt.diagnostics as Diagnostic[]).filter(d => d.code === 'TERMINAL_CONNECTOR_DECLARED_LIMITATION')
    expect(limitations.length).toBe(3 * 9 + 2) // one per edge
    expect(summary.receipt.diagnostics.length).toBeLessThan(5)
    expect(JSON.stringify(summary.receipt).length * 5).toBeLessThan(JSON.stringify(full.receipt).length)
  })

  test('summary keeps unselected capabilities, historical layout fallbacks and uncertified geometry', () => {
    const geometry = { status: 'uncertified', strategy: 'best-effort', attempts: 2, violations: [{ kind: 'edgeThroughNode', detail: 'A-B' }] }
    const fallback = { requested: 'agentic', fallback: 'elk', selected: 'elk', reason: 'unsupported', attempts: [], implementation: 'elk' }
    const summary = summarizeRenderReceipt({
      version: 2, output: 'svg', sharedRequestDigest: 's', requestDigest: 'r', appearanceDigest: 'a',
      capabilityDecision: { version: 1, accepted: false, resolutions: [
        { id: 'core:scene', range: '^1.0.0', level: 'required', status: 'selected', version: '1.0.0' },
        { id: 'backend:x', range: '^9.0.0', level: 'required', status: 'incompatible' },
      ] },
      layoutDecisions: [{ requested: 'elk', fallback: 'none', selected: 'elk', attempts: [], implementation: 'elk' }, fallback],
      layoutCertification: { status: 'failed', issues: [{ code: 'X' }], geometry } as never,
      diagnostics: [{ code: 'D', message: 'm', feature: 'a' }, { code: 'D', message: 'm', feature: 'b' }, { code: 'D', message: 'n', feature: 'c' }],
    } as never)
    expect(summary as unknown).toEqual({
      view: 'summary', version: 2, output: 'svg', requestDigest: 'r', accepted: false,
      capabilityResolutions: [{ id: 'backend:x', range: '^9.0.0', level: 'required', status: 'incompatible' }],
      layoutDecisions: [fallback],
      layoutCertification: { status: 'failed', issues: [{ code: 'X' }], geometry },
      diagnostics: [{ code: 'D', message: 'm', count: 2 }, { code: 'D', message: 'n', count: 1 }],
    })
  })
})

describe('cacheKeyFor (validated, normalized, output-affecting arguments)', () => {
  test('normalizes describe_sdk defaults and rejects invalid discovery requests', () => {
    expect(cacheKeyFor('describe_sdk', { family: 'gantt' }))
      .toEqual(cacheKeyFor('describe_sdk', { family: 'gantt', detail: 'fields' }))
    expect(cacheKeyFor('describe_sdk', { family: 'gantt', detail: 'signatures' }))
      .not.toEqual(cacheKeyFor('describe_sdk', { family: 'gantt', detail: 'fields' }))
    expect(cacheKeyFor('describe_sdk', { family: 'gantt', ignored: true })).toBeNull()
    expect(cacheKeyFor('describe_sdk', { family: 'unknown' })).toBeNull()
    expect(cacheKeyFor('describe_sdk', { family: 'gantt', detail: 'unknown' })).toBeNull()
  })

  test('describe_sdk capability requests key apart from one another', () => {
    const requests = [
      { capability: 'resolved-scene' }, { capability: 'resolved-scene', detail: 'signatures' },
      { capability: 'render-options' }, { capability: 'render-options', field: 'padding' }, { capability: 'render-options', field: 'style' },
      { capability: 'code-mode' }, { family: 'gantt' },
    ]
    const keys = requests.map(request => JSON.stringify(cacheKeyFor('describe_sdk', request)))
    expect(new Set(keys).size).toBe(requests.length)
    expect(cacheKeyFor('describe_sdk', { capability: 'resolved-scene', detail: 'fields' })).toEqual(cacheKeyFor('describe_sdk', { capability: 'resolved-scene' }))
    expect(cacheKeyFor('describe_sdk', { capability: 'render-options', field: 'nope' })).toBeNull()
    expect(cacheKeyFor('describe_sdk', { capability: 'code-mode', detail: 'fields' })).toBeNull()
  })

  test('does not cache arguments rejected by the advertised tool schema', () => {
    expect(cacheKeyFor('describe', { source: FLOW, nonce: 'x', foo: 1 })).toBeNull()
  })

  test('execute is never response-cached because it exposes time and randomness', () => {
    expect(cacheKeyFor('execute', { code: '1 + 1', timeoutMs: 100 })).toBeNull()
    expect(cacheKeyFor('execute', { code: 'Date.now()' })).toBeNull()
  })

  test('render_png keys on the exact requested portable scale', () => {
    expect(cacheKeyFor('render_png', { source: FLOW, scale: 100 }))
      .not.toEqual(cacheKeyFor('render_png', { source: FLOW, scale: 999 }))
    expect(cacheKeyFor('render_png', { source: FLOW, scale: 100 }))
      .not.toEqual(cacheKeyFor('render_png', { source: FLOW, scale: 8 }))
    expect(cacheKeyFor('render_png', { source: FLOW, scale: 2 }))
      .not.toEqual(cacheKeyFor('render_png', { source: FLOW, scale: 4 }))
  })

  test('render_png background and source both participate in the key', () => {
    expect(cacheKeyFor('render_png', { source: FLOW, background: 'white' }))
      .not.toEqual(cacheKeyFor('render_png', { source: FLOW, background: 'black' }))
    expect(cacheKeyFor('render_png', { source: FLOW }))
      .not.toEqual(cacheKeyFor('render_png', { source: 'flowchart TD\n  X --> Y' }))
    expect(cacheKeyFor('render_png', { source: FLOW, background: '#fff' }))
      .toEqual(cacheKeyFor('render_png', { source: FLOW, background: '#ffffff' }))
  })

  test('render_png omitted scale and explicit default scale collapse to one entry', () => {
    // both render at scale 2 (png-wasm applies `?? 2`), so they must share a key
    const absent = cacheKeyFor('render_png', { source: FLOW }) as Record<string, unknown>
    expect(absent).toHaveProperty('output.scale', 2)
    expect(absent).toEqual(cacheKeyFor('render_png', { source: FLOW, scale: 2 }) as Record<string, unknown>)
    // An ill-typed scale is not cacheable because dispatch rejects it.
    expect(cacheKeyFor('render_png', { source: FLOW, scale: 'big' })).toBeNull()
  })

  test('render_png cache identity canonicalizes the default label floor', () => {
    expect(cacheKeyFor('render_png', { source: FLOW }))
      .toEqual(cacheKeyFor('render_png', { source: FLOW, minLabelPx: 9 }))
    expect(cacheKeyFor('render_png', { source: FLOW, minLabelPx: 0 }))
      .not.toEqual(cacheKeyFor('render_png', { source: FLOW }))
    expect(cacheKeyFor('render_png', { source: FLOW, minLabelPx: 12 }))
      .not.toEqual(cacheKeyFor('render_png', { source: FLOW, minLabelPx: 0 }))
  })

  test('render_png cache identity follows effective fit/style precedence', () => {
    expect(cacheKeyFor('render_png', { source: FLOW, scale: 2, fitTo: { width: 64 } }))
      .toEqual(cacheKeyFor('render_png', { source: FLOW, scale: 99, fitTo: { width: 64 } }))
    expect(cacheKeyFor('render_png', {
      source: FLOW,
      style: 'crisp',
      options: { style: 'hand-drawn', seed: 1 },
    })).toBeNull()
  })

  test('the source/code payload is keyed verbatim (comment junk is NOT normalized)', () => {
    // Documented scope limit: insignificant source bytes are not normalized —
    // keying on raw source keeps a cached result provably correct
    // for that exact input. The rate limit, not the cache, bounds this.
    expect(cacheKeyFor('render_svg', { source: 'flowchart LR\n  A --> B' }))
      .not.toEqual(cacheKeyFor('render_svg', { source: 'flowchart LR\n  A --> B\n%% c' }))
  })

  test('render_svg keys canonical nested options and rejects top-level projections', () => {
    expect(cacheKeyFor('render_svg', { source: FLOW, options: { bg: '#000' } }))
      .toEqual({
        t: 'render_svg',
        source: FLOW,
        render: { bg: '#000', security: 'strict', embedFontImport: false },
      })
    expect(cacheKeyFor('render_svg', { source: FLOW, bg: '#000', junk: 1 })).toBeNull()
    expect(cacheKeyFor('render_svg', { source: FLOW, theme: 'paper' })).toBeNull()
  })

  test('render_ascii distinguishes charset and target width', () => {
    expect(cacheKeyFor('render_ascii', { source: FLOW, useAscii: true }))
      .not.toEqual(cacheKeyFor('render_ascii', { source: FLOW }))
    expect(cacheKeyFor('render_ascii', { source: FLOW, targetWidth: 40 }))
      .not.toEqual(cacheKeyFor('render_ascii', { source: FLOW, targetWidth: 60 }))
  })

  test('result-shape arguments key apart from the default, which explicit defaults share', () => {
    for (const tool of ['render_svg', 'render_ascii', 'render_png']) {
      const base = cacheKeyFor(tool, { source: FLOW })
      expect({ tool, key: cacheKeyFor(tool, { source: FLOW, receipt: 'full' }) }).toEqual({ tool, key: base })
      expect({ tool, key: cacheKeyFor(tool, { source: FLOW, receipt: 'summary' }) }).not.toEqual({ tool, key: base })
      expect({ tool, key: cacheKeyFor(tool, { source: FLOW, receipt: 'brief' }) }).toEqual({ tool, key: null })
    }
    const png = cacheKeyFor('render_png', { source: FLOW })
    expect(cacheKeyFor('render_png', { source: FLOW, output: 'base64' })).toEqual(png)
    expect(cacheKeyFor('render_png', { source: FLOW, output: 'image' })).not.toEqual(png)
    expect(cacheKeyFor('render_png', { source: FLOW, output: 'image', receipt: 'summary' }))
      .not.toEqual(cacheKeyFor('render_png', { source: FLOW, output: 'image' }))
  })

  test('returns null for uncacheable calls (unknown tool, missing arg, bad output)', () => {
    expect(cacheKeyFor('render_gif', { source: FLOW })).toBeNull()
    expect(cacheKeyFor(undefined, {})).toBeNull()
    expect(cacheKeyFor('describe', {})).toBeNull()
    expect(cacheKeyFor('execute', { code: 42 })).toBeNull()
    expect(cacheKeyFor('render_png', { source: FLOW, output: 'file' })).toBeNull()
  })

  test('distinct tools never collide on identical source', () => {
    const keys = ['render_svg', 'render_ascii', 'verify', 'describe']
      .map(t => JSON.stringify(cacheKeyFor(t, { source: FLOW })))
    expect(new Set(keys).size).toBe(keys.length)
  })

  test('describe format participates in the cache key', () => {
    expect(cacheKeyFor('describe', { source: FLOW })).toEqual(cacheKeyFor('describe', { source: FLOW, format: 'text' }))
    expect(cacheKeyFor('describe', { source: FLOW, format: 'facts' })).not.toEqual(cacheKeyFor('describe', { source: FLOW, format: 'json' }))
    expect(cacheKeyFor('describe', { source: FLOW, format: 'bad' })).toBeNull()
  })
})
