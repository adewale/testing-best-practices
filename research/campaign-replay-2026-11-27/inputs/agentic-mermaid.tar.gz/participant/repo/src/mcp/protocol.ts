// JSON-RPC 2.0 plumbing shared by every MCP transport (stdio, node HTTP/SSE,
// and the hosted Cloudflare Worker). Runtime-neutral: no node:* imports.

export interface JsonRpcRequest { jsonrpc: '2.0'; id?: number | string; method: string; params?: unknown }
export interface JsonRpcResponse { jsonrpc: '2.0'; id: number | string | null; result?: unknown; error?: { code: number; message: string; data?: unknown } }

export interface ExactJsonRpcId { sentinel: string; raw: string }

/**
 * Protect top-level numeric JSON-RPC ids that JavaScript cannot round-trip
 * lexically through JSON.parse/JSON.stringify. MCP narrows JSON-RPC Number ids
 * to integers, so integer-valued tokens are preserved for response correlation
 * while fractional values remain numbers for admission to reject.
 *
 * Only an individual request object's `id` is protected: nested `params.id`
 * values remain ordinary application data. Direct batch-item ids are included.
 */
export function preserveExactJsonRpcIds(body: string): { body: string; ids: ExactJsonRpcId[] } {
  const replacements: Array<ExactJsonRpcId & { start: number; end: number }> = []
  const stack: Array<'{' | '['> = []
  let i = 0
  const stringEnd = (start: number): number => {
    let j = start + 1
    while (j < body.length) {
      if (body[j] === '\\') { j += 2; continue }
      if (body[j] === '"') return j + 1
      j++
    }
    return j
  }
  while (i < body.length) {
    const ch = body[i]!
    if (ch === '"') {
      const end = stringEnd(i)
      let key: unknown
      try { key = JSON.parse(body.slice(i, end)) } catch { i = end; continue }
      const rpcObject = (stack.length === 1 && stack[0] === '{')
        || (stack.length === 2 && stack[0] === '[' && stack[1] === '{')
      let cursor = end
      while (/\s/.test(body[cursor] ?? '')) cursor++
      if (rpcObject && key === 'id' && body[cursor] === ':') {
        cursor++
        while (/\s/.test(body[cursor] ?? '')) cursor++
        const number = body.slice(cursor).match(/^-?(?:0|[1-9]\d*)(?:\.\d+)?(?:[eE][+-]?\d+)?/)?.[0]
        if (number && isIntegerNumberToken(number) && !isSafelyRoundTrippableInteger(number)) {
          let sentinel = `__agentic_mermaid_exact_id_${replacements.length}__`
          while (body.includes(sentinel)) sentinel += '_'
          replacements.push({ sentinel, raw: number, start: cursor, end: cursor + number.length })
        }
      }
      i = end
      continue
    }
    if (ch === '{' || ch === '[') stack.push(ch)
    else if (ch === '}' || ch === ']') stack.pop()
    i++
  }
  let protectedBody = body
  for (const replacement of replacements.slice().reverse()) {
    protectedBody = protectedBody.slice(0, replacement.start) + JSON.stringify(replacement.sentinel) + protectedBody.slice(replacement.end)
  }
  return { body: protectedBody, ids: replacements.map(({ sentinel, raw }) => ({ sentinel, raw })) }
}

function isIntegerNumberToken(token: string): boolean {
  const value = Number(token)
  return Number.isFinite(value) && Number.isInteger(value)
}

function isSafelyRoundTrippableInteger(token: string): boolean {
  if (!/^-?(?:0|[1-9]\d*)$/.test(token)) return false
  // JSON.parse preserves the IEEE-754 negative-zero value, but JSON.stringify
  // canonicalizes it to `0`; correlation requires retaining the request token.
  if (token === '-0') return false
  try {
    const value = BigInt(token)
    return value <= BigInt(Number.MAX_SAFE_INTEGER) && value >= BigInt(Number.MIN_SAFE_INTEGER)
  } catch {
    return false
  }
}

/** Accept the JSON media type with optional syntactically valid parameters,
 * but reject prefix lookalikes (`application/jsonp`) and malformed suffixes. */
export function isJsonContentType(value: string | null | undefined): boolean {
  if (!value) return false
  const token = String.raw`[!#$%&'*+.^_\x60|~0-9A-Za-z-]+`
  const quoted = String.raw`"(?:[^"\\]|\\.)*"`
  return new RegExp(String.raw`^\s*application/json\s*(?:;\s*${token}\s*=\s*(?:${token}|${quoted}))*\s*$`, 'i').test(value)
}

/** Serialize a JSON-RPC response (or response batch) while restoring exact
 * numeric ids. Sentinels can only occur in top-level response `id` positions;
 * replacement includes the `"id":` key so equal strings in result data are
 * never rewritten. */
export function stringifyJsonRpc(payload: unknown, exactIds: ExactJsonRpcId[] = []): string {
  let body = JSON.stringify(payload)
  for (const { sentinel, raw } of exactIds) {
    body = body.replace(`"id":${JSON.stringify(sentinel)}`, `"id":${raw}`)
  }
  return body
}

export function reply(id: number | string | null, result: unknown): JsonRpcResponse { return { jsonrpc: '2.0', id, result } }
export function rpcError(id: number | string | null, code: number, message: string, data?: unknown): JsonRpcResponse {
  return { jsonrpc: '2.0', id, error: data === undefined ? { code, message } : { code, message, data } }
}

/** Wrap a tool payload in the MCP tools/call content envelope. */
export function toolResult(id: number | string | null, payload: unknown, isError: boolean): JsonRpcResponse {
  return reply(id, { content: [{ type: 'text', text: JSON.stringify(payload) }], isError })
}

/** Wrap the payload of a tool linked to an MCP Apps view. The view reads the
 *  whole payload from `structuredContent`, which that spec keeps out of model
 *  context; the text block, which the model and text-only hosts read, leaves
 *  out the `viewOnly` fields (an SVG the person sees and the model never needs). */
export function viewToolResult(id: number | string | null, payload: Record<string, unknown>, viewOnly: readonly string[], isError: boolean): JsonRpcResponse {
  const forModel = Object.fromEntries(Object.entries(payload).filter(([key]) => !viewOnly.includes(key)))
  return reply(id, { content: [{ type: 'text', text: JSON.stringify(forModel) }], structuredContent: payload, isError })
}
