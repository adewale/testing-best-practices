import { reply, rpcError, toolResult, type JsonRpcRequest, type JsonRpcResponse } from './protocol.ts'
import { DESCRIBE_FORMATS } from '../agent/describe.ts'
import type { McpResourceContents, McpResourceDefinition } from './resource-surface.ts'
import {
  META_SERVER_INFO,
  isLegacyProtocolVersion,
  isModernProtocolVersion,
  mcpClientCapabilitiesProblems,
  mcpImplementationProblems,
  usesToolErrorForInvalidArguments,
  type ProtocolEra,
} from './protocol-versions.ts'
import { admitMcpMessage, type AdmittedMcpMessage } from './admission.ts'
import { PACKAGE_VERSION } from '../version.ts'
import {
  renderOptionsSchemaDefinitions,
  sharedRenderOptionsJsonSchema,
  validateSerializableRenderOptions,
  renderSchemaProblems,
  misplacedRenderOptionHint,
  type SharedRenderOptionField,
} from '../render-contract.ts'
import { MAX_HOSTED_PNG_PIXELS, MAX_PNG_PIXELS, MAX_PNG_RASTER_DIMENSION, normalizePortablePngBackground, pngOutputOptionsJsonSchema } from '../png-contract.ts'
import {
  limitJsonConfigDiagnostics,
  validateJsonConfigAdmission,
} from '../shared/json-config-admission.ts'
import type { RenderOptions } from '../types.ts'
import type { ExecuteErrorCode } from './execute-limits.ts'
import type { ExecuteResult } from './sandbox.ts'
import type { CodeModeLocation } from './facade.ts'
import { isPlainRecord } from '../shared/plain-data.ts'
import { knownStyleDescriptors } from '../scene/style-registry.ts'
import { validateJsonSchema, type SchemaPath, type JsonSchema } from '../shared/schema-validation.ts'
import { inspectPngDimensions } from '../output-color-profile.ts'
import { mcpRenderReceiptProperty } from './receipt-summary.ts'

export interface McpToolDefinition {
  name: string
  title: string
  description: string
  inputSchema: Record<string, unknown>
  annotations?: {
    readOnlyHint?: boolean
    destructiveHint?: boolean
    idempotentHint?: boolean
    openWorldHint?: boolean
  }
  /** MCP Apps linkage (extension io.modelcontextprotocol/ui): a host that
   *  supports the extension renders this tool's result with the referenced
   *  ui:// resource; every other host ignores it and uses the result as-is. */
  _meta?: {
    ui?: {
      resourceUri: string
      visibility?: readonly ('model' | 'app')[]
    }
  }
}

export const MCP_PNG_OUTPUT_MODES = Object.freeze(['base64', 'file', 'url', 'image'] as const)
export type McpPngOutputMode = typeof MCP_PNG_OUTPUT_MODES[number]
/** The hosted endpoint returns bytes in its response only; it keeps no artifacts. */
export const HOSTED_MCP_PNG_OUTPUT_MODES = Object.freeze(['base64', 'image'] as const)

export function isMcpPngOutputMode(value: unknown): value is McpPngOutputMode {
  return typeof value === 'string' && MCP_PNG_OUTPUT_MODES.includes(value as McpPngOutputMode)
}

/**
 * The annotated schema behind each compact advertised `inputSchema`, keyed by
 * the advertised object. tools/list loads every advertised schema into each
 * agent's context, while server-side validation needs the runtime annotations
 * (`x-agentic-mermaid-runtime-validator` and the expectations that word its
 * diagnostics) and the explicit role-style records its messages name.
 */
const CANONICAL_INPUT_SCHEMAS = new WeakMap<object, Record<string, unknown>>()

/** Adapt independently authored tool definitions to the closed argument
 * contract used by every first-party surface. This keeps progressive tools
 * from silently reopening the interface when they are composed into a server. */
export function withClosedMcpInputSchema(tool: McpToolDefinition): McpToolDefinition {
  const inputSchema = { ...tool.inputSchema, additionalProperties: false }
  const canonical = CANONICAL_INPUT_SCHEMAS.get(tool.inputSchema)
  if (canonical) CANONICAL_INPUT_SCHEMAS.set(inputSchema, { ...canonical, additionalProperties: false })
  return { ...tool, inputSchema }
}

/** Record that `advertised` is a projection of `canonical`, so validation of a
 * tool advertising it enforces the canonical schema. */
export function registerAdvertisedMcpInputSchema(advertised: Record<string, unknown>, canonical: Record<string, unknown>): void {
  CANONICAL_INPUT_SCHEMAS.set(advertised, canonical)
}

/** The schema `validateMcpToolArguments` enforces for a tool: the canonical
 * annotated schema when the advertised one is a compact projection of it. */
export function mcpToolValidationSchema(tool: McpToolDefinition): Record<string, unknown> {
  return CANONICAL_INPUT_SCHEMAS.get(tool.inputSchema) ?? tool.inputSchema
}

// Keywords whose value maps names to schemas, and keywords whose value is data
// rather than a schema. Annotations are stripped at schema positions only, so a
// property or definition that happens to be named `x-…` keeps its name.
const SCHEMA_MAP_KEYWORDS = new Set(['properties', 'patternProperties', '$defs', 'definitions', 'dependentSchemas'])
const SCHEMA_DATA_KEYWORDS = new Set(['enum', 'const', 'default', 'examples', 'required'])

function withoutVendorAnnotations(schema: unknown): unknown {
  if (Array.isArray(schema)) return schema.map(withoutVendorAnnotations)
  if (!isPlainRecord(schema)) return schema
  const projected: Record<string, unknown> = {}
  for (const [keyword, value] of Object.entries(schema)) {
    if (keyword.startsWith('x-')) continue
    projected[keyword] = SCHEMA_DATA_KEYWORDS.has(keyword) ? value
      : SCHEMA_MAP_KEYWORDS.has(keyword) && isPlainRecord(value)
        ? Object.fromEntries(Object.entries(value).map(([name, child]) => [name, withoutVendorAnnotations(child)]))
        : withoutVendorAnnotations(value)
  }
  return projected
}

const ROLE_STYLE_PREFIX = 'roleStyle-'
const SHARED_ROLE_STYLE = 'roleStyle-any'
const CLOSED_RECORD_KEYWORDS = new Set(['type', 'additionalProperties', 'maxProperties', 'properties'])

/** The property names of a role-style record that only restricts the shared
 * record to a subset of its properties, each with the shared property schema;
 * undefined when the record constrains anything else, so it stays explicit. */
function sharedRoleStyleRestriction(record: unknown, shared: Record<string, unknown>): string[] | undefined {
  const closed = (candidate: unknown): candidate is { properties: Record<string, unknown>; maxProperties?: unknown } =>
    isPlainRecord(candidate) && candidate.type === 'object' && candidate.additionalProperties === false
    && isPlainRecord(candidate.properties) && Object.keys(candidate).every(keyword => CLOSED_RECORD_KEYWORDS.has(keyword))
  if (!closed(record) || !closed(shared)) return undefined
  const names = Object.keys(record.properties)
  const bound = (maxProperties: unknown) => maxProperties === undefined || (typeof maxProperties === 'number' && maxProperties >= names.length)
  if (names.length === 0 || !bound(record.maxProperties) || !bound(shared.maxProperties)) return undefined
  return names.every(name => Object.hasOwn(shared.properties, name)
    && JSON.stringify(record.properties[name]) === JSON.stringify(shared.properties[name])) ? names : undefined
}

/**
 * The compact form of a canonical tool schema that tools/list and the server
 * cards advertise; the canonical schema stays the one argument validation
 * enforces. The projection accepts exactly the same argument values under any
 * JSON Schema validator: vendor annotations are not assertions, and a
 * role-style record that restricts the shared record to some of its properties
 * becomes a reference to the shared record plus the allowed property names,
 * instead of a second copy of each property schema. `allOf` around the `$ref`
 * keeps the sibling keyword meaningful to draft-07 validators, which ignore
 * keywords beside a bare `$ref`.
 */
function advertiseMcpInputSchema(canonical: Record<string, unknown>): Record<string, unknown> {
  const advertised = withoutVendorAnnotations(canonical) as Record<string, unknown>
  const definitions = advertised.$defs
  const shared = isPlainRecord(definitions) ? definitions[SHARED_ROLE_STYLE] : undefined
  if (isPlainRecord(definitions) && isPlainRecord(shared)) {
    advertised.$defs = Object.fromEntries(Object.entries(definitions).map(([name, record]) => {
      const names = name.startsWith(ROLE_STYLE_PREFIX) && name !== SHARED_ROLE_STYLE
        ? sharedRoleStyleRestriction(record, shared) : undefined
      return [name, names ? { allOf: [{ $ref: `#/$defs/${SHARED_ROLE_STYLE}` }], propertyNames: { enum: names } } : record]
    }))
  }
  CANONICAL_INPUT_SCHEMAS.set(advertised, canonical)
  return advertised
}

export interface McpServerSurface<Context> {
  protocolVersion: string | ((params: unknown) => string)
  /** initialize serverInfo.name; defaults to the local MCP_SERVER_NAME. */
  serverName?: string
  /** Every revision this surface implements, newest-relevant order preserved.
   *  Reported by server/discover and by UnsupportedProtocolVersionError.
   *  Defaults to the single pinned `protocolVersion` when it is a constant. */
  supportedVersions?: readonly string[]
  tools: McpToolDefinition[]
  /** Static resource roster. A surface without one advertises no resources
   *  capability and answers resources/* as Method not found. */
  resources?: readonly McpResourceDefinition[]
  readResource?(uri: string): McpResourceContents | null
  instructions: string
  handleToolCall(id: number | string | null, params: unknown, context: Context): JsonRpcResponse | Promise<JsonRpcResponse>
}

export interface McpDispatchOptions {
  /** The version negotiated by a stateful transport. Supplies the version for
   *  legacy requests, whose bodies carry none; never overrides modern `_meta`.
   *  HTTP passes its header through admission's distinct `headerVersion` field
   *  so only a real mirror disagreement can become HeaderMismatch. */
  protocolVersion?: string | null
  /** Connection-scoped era selected by a stateful transport. Hosted HTTP leaves
   *  this unset because its dual-era endpoint classifies each independent POST;
   *  stdio sets it after the client opens with initialize or modern metadata. */
  protocolEra?: ProtocolEra
  /**
   * Revisions THIS TRANSPORT serves, when they are narrower than the surface's.
   *
   * One dispatcher can sit behind several transports whose obligations differ:
   * the local server answers over stdio and over a 2024-11-05-era HTTP+SSE
   * transport, and a revision the dispatcher implements is not thereby served
   * over a transport that cannot carry it. `server/discover` must answer for
   * the transport the request actually arrived on, so this NARROWS the surface
   * list — it never widens it, because a transport cannot add a capability the
   * dispatcher lacks.
   */
  supportedVersions?: readonly string[]
}

// The LOCAL stdio/HTTP server identity. The hosted transport reports its own
// name (HOSTED_MCP_SERVER_NAME in hosted-server.ts): registries and clients
// cache tool lists by server identity, and the two surfaces expose different
// tool sets (see LOCAL_TOOLS and HOSTED_TOOLS), so they must not share one.
export const MCP_SERVER_NAME = 'agentic-mermaid-mcp'
// The release identity gate keeps this runtime-safe constant synchronized with
// package.json so every MCP handshake reports the published package version.
export const MCP_SERVER_VERSION = PACKAGE_VERSION
// Optional MCP features are claimed only by a surface that implements them:
// advertising an empty namespace makes clients probe methods we do not serve.
// A surface that publishes resources declares a static, version-pinned roster
// (listChanged: false is a statement, not a default) and declares
// resources/subscribe unimplemented rather than silently ignoring it.
function publishesResources<Context>(surface: McpServerSurface<Context>): surface is McpServerSurface<Context> & { resources: readonly McpResourceDefinition[] } {
  return (surface.resources?.length ?? 0) > 0
}

function hasCursor(params: unknown): boolean {
  return isPlainRecord(params) && Object.hasOwn(params, 'cursor')
}

function unknownCursor(id: number | string | null, item: string): JsonRpcResponse {
  return rpcError(id, -32602, `Invalid params: unknown cursor; this server lists every ${item} in one page and issues no cursors`)
}

function serverCapabilities<Context>(surface: McpServerSurface<Context>) {
  return publishesResources(surface)
    ? { tools: {}, resources: { subscribe: false, listChanged: false } }
    : { tools: {} }
}

export const PURE_COMPUTE_ANNOTATIONS = {
  readOnlyHint: true,
  destructiveHint: false,
  idempotentHint: true,
  openWorldHint: false,
} as const
const SANDBOX_EXECUTE_ANNOTATIONS = {
  readOnlyHint: true,
  destructiveHint: false,
  idempotentHint: false,
  openWorldHint: false,
} as const
const MANAGED_ARTIFACT_ANNOTATIONS = {
  // output=file/url creates a managed file and repeated calls can create
  // different time-addressed artifacts, so the tool as a whole is neither
  // read-only nor idempotent even though output=base64 is pure.
  readOnlyHint: false,
  destructiveHint: false,
  idempotentHint: false,
  openWorldHint: false,
} as const

export const EXECUTE_TIMEOUT_ERROR = 'execute timeoutMs must be a positive integer'

/** The execute tool payload both servers return. Success passes the runner's
 * { ok, value, logs } through; failure is { ok:false, error:{ code, message,
 * location? }, logs } with the runner's message verbatim, a stable code (see
 * ExecuteErrorCode) so an agent can branch on error.code on either channel,
 * and, when known, the failing { line, column } in the agent's own code. */
export function executeToolPayload(result: ExecuteResult):
  | ExecuteResult
  | { ok: false; error: { code: ExecuteErrorCode; message: string; location?: CodeModeLocation }; logs: string[] } {
  if (result.ok) return result
  return {
    ok: false,
    error: {
      code: result.code ?? 'EXECUTE_FAILED',
      message: result.error ?? 'sandbox returned no error message',
      ...(result.location ? { location: { line: result.location.line, column: result.location.column } } : {}),
    },
    logs: result.logs ?? [],
  }
}

/** One validation contract shared by hosted and local Code Mode. */
export function isValidExecuteTimeout(value: unknown): value is number {
  return typeof value === 'number' && Number.isSafeInteger(value) && value > 0
}

// Every render tool offers the same `options` object; its description is the
// only built-in Style menu a client sees without calling execute, so it comes
// from the style registry, once, for every render tool on every surface.
const BUILTIN_LOOK_NAMES = knownStyleDescriptors()
  .filter(descriptor => descriptor.kind === 'look')
  .map(descriptor => descriptor.inputName)
const BUILTIN_PALETTE_NAMES = knownStyleDescriptors()
  .filter(descriptor => descriptor.kind === 'palette')
  .map(descriptor => descriptor.inputName)
export const MCP_RENDER_OPTIONS_DESCRIPTION = `Shared advanced RenderOptions object. style accepts a registered Look (${BUILTIN_LOOK_NAMES.join(', ')}), Palette (${BUILTIN_PALETTE_NAMES.join(', ')}), inline StyleSpec record, or left-to-right stack.`

/**
 * The advertised input schema of a render tool: `source`, the tool's own output
 * fields, and the shared `options` object. The render options schema names its
 * StyleSpec and JSON-value records by `#/$defs/<name>`; those definitions sit
 * at this schema's root, once, so every reference resolves from the tool
 * schema itself (no embedded `$id` resource) and no record is inlined twice.
 * The result is the compact projection (advertiseMcpInputSchema); argument
 * validation enforces the annotated schema it projects, and the options
 * description links the published annotated render options schema.
 */
export function mcpRenderToolInputSchema(outputProperties: Record<string, unknown> = {}): Record<string, unknown> {
  const { $schema: _dialect, $id: published, $defs: _defs, ...options } = sharedRenderOptionsJsonSchema()
  return advertiseMcpInputSchema({
    type: 'object',
    additionalProperties: false,
    properties: {
      source: { type: 'string', description: 'Mermaid source.' },
      ...outputProperties,
      options: { ...options, description: `${MCP_RENDER_OPTIONS_DESCRIPTION} Annotated schema (field families, terminal notes): ${String(published)}` },
    },
    required: ['source'],
    $defs: renderOptionsSchemaDefinitions(),
  })
}

export function projectMcpRenderOptions(
  args: Readonly<Record<string, unknown>>,
): RenderOptions {
  const requested = args.options
  const nested = requested === undefined ? {} : requested
  if (!isPlainRecord(nested)) throw new Error('invalid render options: render options must be a plain JSON object')
  // Capture enumerable top-level values before validation. Validating the live
  // record first could read a different getter value when projecting it.
  const projected: Record<string, unknown> = { ...(nested as RenderOptions) }
  const problems = validateSerializableRenderOptions(projected)
  if (problems.length > 0) throw new Error(`invalid render options: ${problems.join('; ')}`)
  return projected as RenderOptions
}

function formatSchemaPath(path: SchemaPath): string {
  if (path.length === 0) return 'arguments'
  return path.reduce<string>((formatted, part) =>
    typeof part === 'number' ? `${formatted}[${part}]` : `${formatted}.${part}`, 'arguments')
}

/** Runtime-check one tool's arguments against the canonical schema behind the
 * one tools/list advertises: the same JSON Schema assertions, plus the runtime
 * validators its annotations name. */
export function validateMcpToolArguments(tool: McpToolDefinition, value: unknown): string[] {
  if (!isPlainRecord(value)) return ['arguments must be a plain JSON object']
  const admissionProblems = validateJsonConfigAdmission(value)
  if (admissionProblems.length > 0) {
    return limitJsonConfigDiagnostics(admissionProblems.map(problem =>
      `${formatSchemaPath(problem.path)} ${problem.message}`), 'arguments')
  }
  const canonical = mcpToolValidationSchema(tool)
  const problems = validateJsonSchema(value, canonical, canonical, [], {
    patternMismatch: schema => schema['x-agentic-mermaid-runtime-validator'] === 'portablePngBackground'
      ? 'must be a portable basic color keyword or 3, 4, 6, or 8 digit hex color' : undefined,
    validateRuntime: (value, schema, path) => {
      const validator = schema['x-agentic-mermaid-runtime-validator']
      if (validator === 'portablePngBackground') {
        return normalizePortablePngBackground(value) === undefined
          ? [{ path, message: 'must be a portable basic color keyword or 3, 4, 6, or 8 digit hex color', generic: false }] : []
      }
      // Cross-field geometry belongs to the normalized RenderOptions boundary;
      // the wire schema continues to validate its individual fields.
      return validator === 'architectureVisual' ? [] : renderSchemaProblems(value, schema, path)
    },
  })
    .map(problem => {
      const hint = problem.message === 'is not allowed' && problem.path.length === 2 && problem.path[0] === 'options'
        ? misplacedRenderOptionHint(String(problem.path[1])) : undefined
      return `${formatSchemaPath(problem.path)} ${problem.message}${hint ? `; ${hint}` : ''}`
    })
  return limitJsonConfigDiagnostics(problems, 'arguments')
}

/** The versions a surface implements: its explicit list, else its pinned constant. */
export function surfaceSupportedVersions<Context>(surface: McpServerSurface<Context>, options: McpDispatchOptions = {}): readonly string[] {
  const surfaceVersions = surface.supportedVersions
    ?? (typeof surface.protocolVersion === 'string' ? [surface.protocolVersion] : [])
  if (!options.supportedVersions) return surfaceVersions
  // Intersect rather than replace: a transport narrows what the dispatcher can
  // do, so a transport list may not introduce a revision the surface lacks.
  return surfaceVersions.filter(version => options.supportedVersions!.includes(version))
}

/** server/discover is the modern replacement for initialize. Its version list
 * reports every revision this exact surface/transport accepts, including
 * legacy revisions a dual-era client may select for its next request. */
function discoverResult<Context>(surface: McpServerSurface<Context>, supportedVersions: readonly string[]) {
  return {
    supportedVersions: [...supportedVersions],
    capabilities: serverCapabilities(surface),
    instructions: surface.instructions,
  }
}

function initializeParamsProblems(params: unknown): string[] {
  if (!isPlainRecord(params)) return ['params is required and must be an object']
  const problems: string[] = []
  if (typeof params.protocolVersion !== 'string') {
    problems.push('params.protocolVersion is required and must be a string')
  }
  problems.push(...mcpClientCapabilitiesProblems(params.capabilities, 'params.capabilities'))
  problems.push(...mcpImplementationProblems(params.clientInfo, 'params.clientInfo'))
  return problems
}

export async function dispatchMcpRequest<Context>(req: JsonRpcRequest, context: Context, surface: McpServerSurface<Context>, options: McpDispatchOptions = {}): Promise<JsonRpcResponse | null> {
  const servedVersions = surfaceSupportedVersions(surface, options)
  const admission = admitMcpMessage(req, {
    supportedVersions: servedVersions,
    negotiatedVersion: options.protocolVersion,
    protocolEra: options.protocolEra,
  })
  if (!admission.ok) return admission.response
  return dispatchAdmittedMcpRequest(admission.message, context, surface)
}

/** Execute a message that has crossed the sole raw/protocol admission boundary.
 * Cache and transport code call this form so dispatch cannot reclassify it. */
export async function dispatchAdmittedMcpRequest<Context>(message: AdmittedMcpMessage, context: Context, surface: McpServerSurface<Context>): Promise<JsonRpcResponse | null> {
  const { request: req, id, notification, protocol } = message
  const { era, version, supportedVersions: servedVersions } = protocol

  let response: JsonRpcResponse | null
  switch (req.method) {
    // initialize / notifications/initialized / ping are REMOVED in the modern
    // era. Under a modern request they are simply unknown methods; a legacy
    // request keeps the handshake it depends on.
    case 'initialize': {
      if (era === 'modern') { response = unknownMethod(id, req.method); break }
      const problems = initializeParamsProblems(req.params)
      if (problems.length > 0) {
        response = rpcError(id, -32602, `Invalid params: ${problems.join('; ')}`)
        break
      }
      // Echo the client's version when this transport serves it. Advertising a
      // revision in server/discover and then refusing to negotiate it would
      // reproduce, inside one server, the exact mismatch per-transport
      // reporting exists to remove.
      const offered = (req.params as { protocolVersion?: unknown } | undefined)?.protocolVersion
      const legacyServedVersions = servedVersions.filter(isLegacyProtocolVersion)
      const fallbackLegacyVersion = legacyServedVersions.at(-1)
        ?? (typeof surface.protocolVersion === 'function' ? surface.protocolVersion(req.params) : surface.protocolVersion)
      const protocolVersion = isLegacyProtocolVersion(offered) && legacyServedVersions.includes(offered)
        ? offered
        : fallbackLegacyVersion
      response = reply(id, {
        protocolVersion,
        serverInfo: { name: surface.serverName ?? MCP_SERVER_NAME, version: MCP_SERVER_VERSION },
        capabilities: serverCapabilities(surface),
        instructions: surface.instructions,
      })
      break
    }
    // JSON-RPC 2.0: a message with an id is a request, whatever its method is
    // called, and a request gets a response. MCP defines initialized only as
    // a notification, so the request form names no method this server has.
    case 'notifications/initialized': response = era === 'modern'
      ? unknownMethod(id, req.method)
      : notification ? null : rpcError(id, -32601, 'Method not found: notifications/initialized is a notification; send it without an id'); break
    case 'ping': response = era === 'modern' ? unknownMethod(id, req.method) : reply(id, {}); break
    case 'server/discover': response = era === 'modern'
      ? reply(id, discoverResult(surface, servedVersions))
      : unknownMethod(id, req.method); break
    // Each whole list fits one page, so this server never issues a nextCursor
    // and no cursor a client sends can name a page (MCP pagination: an invalid
    // cursor SHOULD be -32602 rather than silently restarting the listing).
    case 'tools/list': response = hasCursor(req.params)
      ? unknownCursor(id, 'tool')
      : reply(id, { tools: surface.tools }); break
    case 'resources/list': response = !publishesResources(surface)
      ? unknownMethod(id, req.method)
      : hasCursor(req.params) ? unknownCursor(id, 'resource') : reply(id, { resources: surface.resources }); break
    // No resource templates exist (per-family op discovery stays on the
    // describe_sdk tool), but a client that saw the resources capability may
    // legitimately probe: answer with the empty roster, not Method-not-found.
    case 'resources/templates/list': response = !publishesResources(surface)
      ? unknownMethod(id, req.method)
      : hasCursor(req.params) ? unknownCursor(id, 'resource template') : reply(id, { resourceTemplates: [] }); break
    case 'resources/read': {
      if (!publishesResources(surface)) {
        response = unknownMethod(id, req.method)
        break
      }
      const uri = isPlainRecord(req.params) ? req.params.uri : undefined
      if (typeof uri !== 'string') {
        response = rpcError(id, -32602, 'Invalid params: resources/read requires `uri` (string)')
        break
      }
      const contents = surface.readResource?.(uri) ?? null
      // This revision retired -32002 (ResourceNotFound); unknown URIs are
      // Invalid params per the reserved-error-code policy the static sweep
      // in mcp-reserved-error-codes.test.ts enforces.
      response = contents
        ? reply(id, contents)
        : rpcError(id, -32602, `Invalid params: resource not found: ${uri}`, { uri })
      break
    }
    case 'tools/call': {
      if (!isPlainRecord(req.params)) {
        response = rpcError(id, -32602, 'Invalid params: tools/call requires an object')
        break
      }
      const name = req.params.name
      if (typeof name !== 'string') {
        response = rpcError(id, -32602, 'Invalid params: tools/call requires `name` (string)')
        break
      }
      const tool = surface.tools.find(candidate => candidate.name === name)
      if (!tool) {
        response = rpcError(id, -32602, `Unknown tool: ${name}`)
        break
      }
      const args = req.params.arguments ?? {}
      const problems = validateMcpToolArguments(tool, args)
      if (problems.length > 0) {
        const message = `Invalid arguments for ${name}: ${problems.join('; ')}`
        // SEP-1303 (2025-11-25): an input-validation failure is a TOOL
        // execution error, not a protocol error, so the model can read it and
        // self-correct instead of seeing a transport fault. The diagnostic text
        // is identical either way — only the envelope changes.
        response = usesToolErrorForInvalidArguments(version)
          ? toolResult(id, { ok: false, error: { code: 'INVALID_ARGUMENTS', message } }, true)
          : rpcError(id, -32602, message)
        break
      }
      response = await surface.handleToolCall(id, { ...req.params, arguments: args }, context)
      break
    }
    default: response = unknownMethod(id, req.method)
  }
  return notification ? null : decorateMcpResult(response, req.method, era, surface.serverName ?? MCP_SERVER_NAME)
}

/**
 * How long a client may treat a list result as fresh. The tool surface is fixed
 * at build time and changes only when a deploy changes it, so the only staleness
 * this can cause is a client holding a previous deploy's list for up to this
 * long. Five minutes bounds that while removing essentially all repeat listing
 * traffic, and is the value the spec's own example uses.
 */
export const LIST_RESULT_TTL_MS = 300_000

/** The operations the spec requires caching hints on, intersected with ours. */
// resources/read is included because every served resource is a
// version-static constant — its content changes only with the package
// version, exactly like the list rosters (SEP-2549 requires hints on
// cacheable reads, and ours are all cacheable).
const CACHEABLE_METHODS = new Set(['server/discover', 'tools/list', 'resources/list', 'resources/templates/list', 'resources/read'])

/**
 * Result fields this revision requires, applied on the MODERN path only.
 *
 * `resultType` is a MUST — "The `result` MUST include a `resultType` field to
 * indicate the type of the result" — and legacy results must NOT grow it: "For
 * backward compatibility with servers implementing earlier protocol versions,
 * which do not include `resultType`, clients MUST treat an absent `resultType`
 * as `complete`". Every result we return is terminal, since no tool of ours asks
 * the client for more input, so `complete` is the only value we can produce.
 *
 * Caching hints are a MUST too, not the optional nicety the migration plan
 * recorded them as: "Servers MUST include caching hints on results with
 * `resultType: 'complete'` returned by the following operations: server/discover,
 * tools/list, …". Ours are identical for every caller and carry no user data, so
 * `public` is the honest scope — and the spec is explicit that a public result
 * may be shared across authorization contexts, which is true of a static tool
 * list by construction.
 *
 * Errors are left alone: caching hints and `resultType` live on results.
 */
export function decorateMcpResult(response: JsonRpcResponse | null, method: string, era: ProtocolEra, serverName: string): JsonRpcResponse | null {
  if (era !== 'modern' || !response || !isPlainRecord(response.result)) return response
  const existingMeta = isPlainRecord(response.result._meta) ? response.result._meta : {}
  const result: Record<string, unknown> = {
    resultType: 'complete',
    ...response.result,
    _meta: {
      ...existingMeta,
      [META_SERVER_INFO]: { name: serverName, version: MCP_SERVER_VERSION },
    },
  }
  if (CACHEABLE_METHODS.has(method)) {
    result.ttlMs = LIST_RESULT_TTL_MS
    result.cacheScope = 'public'
  }
  return { ...response, result }
}

/** Strip response-era fields before a deterministic tool result enters the
 * shared compute cache. Cache hits are decorated again for the current request,
 * so a legacy fill can never dictate a modern envelope (or vice versa). */
export function protocolNeutralMcpResult(result: unknown): unknown {
  if (!isPlainRecord(result)) return result
  const { resultType: _resultType, ttlMs: _ttlMs, cacheScope: _cacheScope, _meta, ...neutral } = result
  if (isPlainRecord(_meta)) {
    const { [META_SERVER_INFO]: _serverInfo, ...retainedMeta } = _meta
    if (Object.keys(retainedMeta).length > 0) neutral._meta = retainedMeta
  }
  return neutral
}

/** -32601, which the HTTP transport maps to 404 for modern requests. */
function unknownMethod(id: number | string | null, method: string): JsonRpcResponse {
  return rpcError(id, -32601, `Method not found: ${method}`)
}

export function createExecuteTool(options: { sdkDeclaration: string; hosted?: boolean }): McpToolDefinition {
  const hostedNote = options.hosted
    ? `SVG/ASCII/layout enforce
security:'strict', embedFontImport:false.

`
    : ''
  const timeoutDescription = options.hosted
    ? 'Optional CPU-time budget (default 5000ms, max 30000ms).'
    : 'Optional hard timeout (default 5000ms).'
  const runtime = options.hosted ? 'isolated' : 'node:vm'
  return {
    name: 'execute',
    title: 'Execute Mermaid SDK code',
    description: `Sync ${runtime} JS; return a value. No imports/TS.
${hostedNote}
${options.sdkDeclaration}`,
    inputSchema: {
      type: 'object',
      additionalProperties: false,
      properties: {
        code: { type: 'string', description: 'JavaScript to execute; mermaid.* SDK is global.' },
        timeoutMs: { type: 'integer', minimum: 1, description: timeoutDescription },
      },
      required: ['code'],
    },
    annotations: SANDBOX_EXECUTE_ANNOTATIONS,
  }
}

/** The compact-result paths, named in both servers' instructions. */
export const MCP_COMPACT_RESULTS_NOTE = 'For smaller results, pass receipt:"summary" to render tools and output:"image" to render_png; describe_sdk capability=render-options (field=<name>) gives each render option\'s families and terminal notes, capability=code-mode the execute declaration. Deprecation: 0.6.0 makes receipt:"summary" and output:"image" the defaults; pass receipt:"full" or output:"base64" to keep today\'s results.'

/** Render tools do not verify. Running verify's checks on every render would
 * add roughly 55-100% CPU to each uncached render (measured locally on 10-60
 * node flowcharts, xychart, sequence and class diagrams), so the warnings
 * stay partial and the tools say where the full findings come from. */
export const RENDER_WARNINGS_NOTE = `warnings lists source/config warnings only (capabilities.json codes); it is not a verification.
Layout and content-loss findings (e.g. LABELS_HIDDEN, ROUTE_SELF_LOOP_OCCUPANCY, LAYOUT_UNCERTIFIED) come from
verify: call it before trusting the drawing. receipt.layoutCertification.geometry marks a drawing that failed layout certification.`

/**
 * render_png output=image: the PNG travels as an MCP image content block, which
 * clients hand to a model as an image instead of ~1.3 tokens per base64 byte of
 * JSON text. content[0] stays the JSON payload every render tool returns, with
 * the byte count and pixel dimensions in place of png_base64.
 */
export function mcpPngImageResult(id: number | string | null, png: Uint8Array, data: string, fields: Record<string, unknown>): JsonRpcResponse {
  const { width, height } = inspectPngDimensions(png)
  const payload = { ok: true as const, mimeType: 'image/png', bytes: png.byteLength, width, height, ...fields }
  return reply(id, {
    content: [{ type: 'text', text: JSON.stringify(payload) }, { type: 'image', data, mimeType: 'image/png' }],
    isError: false,
  })
}

export function createRenderPngTool(mode: 'local' | 'hosted'): McpToolDefinition {
  const hosted = mode === 'hosted'
  const pngSchema = pngOutputOptionsJsonSchema(hosted ? 'portable' : 'native')
  const pngProperties = pngSchema.properties as Record<string, JsonSchema>
  const pixelCap = Math.ceil((hosted ? MAX_HOSTED_PNG_PIXELS : MAX_PNG_PIXELS) / 1_000_000)
  const budget = `A raster wider or taller than ${MAX_PNG_RASTER_DIMENSION}px or over ${pixelCap}MP fails with
PNG_RASTER_BUDGET_EXCEEDED; pass fitTo { width } or { height }, or a smaller scale, to fit it.
${RENDER_WARNINGS_NOTE} Raster font-coverage and legibility warnings are added.`
  return {
    name: 'render_png',
    title: 'Render Mermaid as PNG',
    description: hosted
      ? `Rasterize a Mermaid source string to PNG. Returns { ok, png_base64 }; output "image"
returns { ok, bytes, width, height } plus an MCP image content block instead.
Hosted rendering uses resvg-wasm with bundled fonts; bytes may differ from the
local napi renderer, so hosted PNG is a convenience surface, not part of the
byte-determinism contract. For file/URL artifacts use the local stdio server.
${budget}`
      : `Rasterize a Mermaid source string to PNG. By default returns base64-encoded PNG bytes;
output "image" returns { ok, bytes, width, height } plus an MCP image content block instead.
Set output to "file" or "url" to write a managed artifact instead; artifact responses include
{path?, url?, mimeType, bytes, sha256}. File/URL artifacts are generated under the MCP server's
artifact directory with safe names, size limits, and TTL cleanup.
Uses bundled resvg + Inter (DejaVu Sans fallback) for same-machine cross-runtime determinism where verified.
${budget}
Agentic Mermaid outputs SVG, PNG, ASCII, Unicode, and JSON layout. For non-PNG output, use render_svg, render_ascii (useAscii true for ASCII, false for Unicode), or verify. Code Mode execute also exposes the corresponding mermaid.* SDK functions.`,
    inputSchema: mcpRenderToolInputSchema({
      ...pngProperties,
      output: hosted
        ? { type: 'string', enum: [...HOSTED_MCP_PNG_OUTPUT_MODES], description: 'base64 (default) JSON field, or image: an MCP image content block beside the JSON.' }
        : { type: 'string', enum: [...MCP_PNG_OUTPUT_MODES], description: 'PNG return mode (default base64); image returns an MCP image content block beside the JSON.' },
      receipt: mcpRenderReceiptProperty(),
    }),
    annotations: hosted ? PURE_COMPUTE_ANNOTATIONS : MANAGED_ARTIFACT_ANNOTATIONS,
  }
}

export function createDescribeTool(): McpToolDefinition {
  return {
    name: 'describe',
    title: 'Describe Mermaid diagram',
    description: `Describe a Mermaid diagram. format=text returns { ok, text } with
one or two summary sentences; format=json returns { ok, tree } with the AX tree;
format=facts returns { ok, facts } with deterministic semantic fact lines for
machine checking (for example edge A -> B : label, member Duck +quack()).`,
    inputSchema: {
      type: 'object',
      additionalProperties: false,
      properties: {
        source: { type: 'string', description: 'Mermaid source.' },
        format: { type: 'string', enum: [...DESCRIBE_FORMATS], description: 'text (default), json AX tree, or facts semantic read-back.' },
      },
      required: ['source'],
    },
    annotations: PURE_COMPUTE_ANNOTATIONS,
  }
}
