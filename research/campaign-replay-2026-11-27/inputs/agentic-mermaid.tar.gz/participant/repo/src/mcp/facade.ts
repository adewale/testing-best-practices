import { ResolvedSceneError } from '../scene/resolved-error.ts'
// Code Mode SDK facade — runtime-neutral. Shared by the node:vm sandbox
// (sandbox.ts) and the hosted dynamic-worker harness: the hardened read-only
// mermaid.* proxy, the sync-only code screen, and the expression-first code
// wrapping. Must stay free of node:* imports so it bundles for workerd.

import type { Node as AcornNode } from 'acorn'
import { parse as parseJavaScript } from 'acorn'
import { verifyMutationResult } from '../agent/apply.ts'
import * as mermaid from '../agent/core.ts'
import { BUILTIN_FAMILY_METADATA } from '../agent/families.ts'
import type { DiagramKind } from '../agent/types.ts'
import { ParsedDiagramFamilyMismatchError, RenderCapabilityError } from '../render-contract.ts'
import { projectKnownRenderErrorDiagnostic, projectRenderErrorDiagnostic } from '../render-error-diagnostic.ts'
import type { CodeModeHostPolicy } from '../render-host-policy.ts'

export type ExecutionTraceCall =
  | { verb: 'parse'; diagram?: number; source?: string }
  | { verb: 'create'; family?: DiagramKind; diagram?: number; ops?: number; ok?: boolean }
  | { verb: 'narrow'; family: DiagramKind; input?: number; ok: boolean }
  | { verb: 'mutate'; body: DiagramKind | 'opaque'; input?: number; output?: number; opKind?: string; fingerprint?: string }
  | { verb: 'verify'; diagram?: number; ok?: boolean; inspected?: boolean; fingerprint?: string }
  | { verb: 'verify_inspect'; diagram?: number; property: 'ok' | 'warnings' | 'layout' }
  | { verb: 'analyze'; diagram?: number; source?: string; ok?: boolean; fingerprint?: string }
  | { verb: 'facts'; diagram?: number; source?: string; ok?: boolean; fingerprint?: string }
  | { verb: 'check'; diagram?: number; source?: string; ok?: boolean; fingerprint?: string }
  | { verb: 'serialize'; diagram?: number; source?: string; fingerprint?: string }

type TraceMutationBody = Extract<ExecutionTraceCall, { verb: 'mutate' }>['body']
type TraceNarrowFamily = Extract<ExecutionTraceCall, { verb: 'narrow' }>['family']

export function createTracingMermaid(trace?: ExecutionTraceCall[], makeSandboxError?: (message: string) => Error, isClosed?: () => boolean, hostPolicy?: CodeModeHostPolicy, beforeSdkCall?: () => string | undefined, onTraceCall?: (call: ExecutionTraceCall) => void): typeof mermaid {
  const diagramIds = new WeakMap<object, number>()
  const trusted = new WeakSet<object>()
  const sourceResults = new WeakSet<object>()
  const preservedSources = new WeakMap<object, { source: string; preservation?: unknown }>()
  const hardened = new WeakMap<object, unknown>()
  const raw = new WeakMap<object, object>()
  let nextId = 1

  const forbidden = (prop: string | symbol): boolean => prop === 'constructor' || prop === '__proto__' || prop === 'prototype'
  const protoFor = (target: object): object | null => (Object.isExtensible(target) ? null : Reflect.getPrototypeOf(target))
  const sandboxError = (message: string): Error => (makeSandboxError ? makeSandboxError(message) : new Error(message))
  const assertOpen = () => {
    if (isClosed?.()) throw sandboxError('Code Mode SDK calls are not allowed while returning results')
    const blocked = beforeSdkCall?.()
    if (blocked) throw sandboxError(blocked)
  }
  const readonly = () => {
    throw sandboxError('Code Mode SDK results are read-only; use mermaid.mutate(...) for structured edits')
  }
  const arrayMutators = new Set(['copyWithin', 'fill', 'pop', 'push', 'reverse', 'shift', 'sort', 'splice', 'unshift'])
  const arrayCallbackMethods = new Set(['forEach', 'map', 'filter', 'find', 'findIndex', 'findLast', 'findLastIndex', 'some', 'every', 'flatMap'])
  // Non-callback, non-mutating methods. Each runs natively over a host copy
  // of the hardened elements, so identity searches see the same element
  // proxies index reads return and new arrays hold only hardened values (the
  // function membrane hardens the result again).
  const arrayHardenedCopyMethods = new Set(['at', 'concat', 'flat', 'includes', 'indexOf', 'lastIndexOf', 'slice'])
  // String conversions run over the unwrapped data so an object element
  // prints as it would in a plain array ("[object Object]") instead of
  // throwing on a hardened proxy that hides toString; the result is a string.
  const arrayStringMethods = new Set(['join', 'toLocaleString', 'toString'])
  const rawOf = <T>(value: T): T => (value && (typeof value === 'object' || typeof value === 'function') && raw.has(value as object) ? raw.get(value as object) : value) as T
  const isMap = (value: unknown): value is Map<unknown, unknown> => value instanceof Map || Object.prototype.toString.call(value) === '[object Map]'
  const isSet = (value: unknown): value is Set<unknown> => value instanceof Set || Object.prototype.toString.call(value) === '[object Set]'
  const structuredErrorMetadata = new WeakMap<object, Record<string, unknown>>()
  /** Copy only documented structured-error data. The JSON round trip detaches
   * nested records from the host before the read-only membrane exposes them to
   * Code Mode; stacks, prototypes, accessors, and arbitrary error properties
   * never cross the boundary. */
  const structuredErrorFields = (error: unknown): Record<string, unknown> | undefined => {
    if (typeof error !== 'object' || error === null) return undefined
    const carried = structuredErrorMetadata.get(error)
    if (carried) return carried
    let fields: Record<string, unknown> | undefined
    if (error instanceof ResolvedSceneError) {
      fields = { name: error.name, code: error.code, partId: error.partId, feature: error.feature }
    } else if (error instanceof RenderCapabilityError) {
      fields = {
        name: error.name,
        code: error.code,
        output: error.output,
        family: error.family,
        decision: error.decision,
      }
    } else if (error instanceof ParsedDiagramFamilyMismatchError) {
      fields = {
        name: error.name,
        code: error.code,
        expectedFamilyId: error.expectedFamilyId,
        detectedFamilyId: error.detectedFamilyId,
      }
    } else {
      const renderDiagnostic = projectKnownRenderErrorDiagnostic(error)
      if (!renderDiagnostic) return undefined
      fields = {
        name: renderDiagnostic.code === 'ASCII_TARGET_WIDTH_IMPOSSIBLE' ? 'AsciiWidthError' : 'MermaidFamilyDetectionError',
        ...renderDiagnostic,
      }
    }
    if (!fields) return undefined
    const encoded = JSON.stringify(fields)
    return encoded === undefined ? undefined : (JSON.parse(encoded) as Record<string, unknown>)
  }
  /** A proxy may not substitute hardened child proxies for non-configurable,
   * non-writable properties on a frozen target. Move plain immutable data onto
   * an extensible envelope first so nested parsed receipts remain both
   * accessible and read-only through the Code Mode membrane. */
  const extensibleDataEnvelope = (value: object): object => {
    if (Object.isExtensible(value)) return value
    if (Array.isArray(value)) return value.slice()
    const prototype = Reflect.getPrototypeOf(value)
    return prototype === Object.prototype || prototype === null ? Object.assign(Object.create(prototype), value) : value
  }
  const hostCall = <T>(fn: () => T, renderFailure?: { source?: string }): T => {
    try {
      return fn()
    } catch (e) {
      // A syntax error in source the registered parser rejects is reported as
      // that parse failure, as on every other render surface.
      const parseFailure = renderFailure && projectKnownRenderErrorDiagnostic(e)?.code === 'MERMAID_SYNTAX_ERROR' ? projectRenderErrorDiagnostic(e, renderFailure) : undefined
      const fields = (parseFailure?.code === 'PARSE_FAILED' ? { name: 'RenderError', ...parseFailure } : undefined)
        ?? structuredErrorFields(e) ?? (renderFailure ? { name: 'RenderError', ...projectRenderErrorDiagnostic(e, renderFailure) } : undefined)
      const wrapped = sandboxError((fields?.message as string) ?? (e as Error).message)
      if (fields) {
        structuredErrorMetadata.set(wrapped, fields)
        for (const [field, value] of Object.entries(fields)) {
          Object.defineProperty(wrapped, field, {
            value: harden(value),
            enumerable: true,
            writable: false,
            configurable: false,
          })
        }
      }
      throw wrapped
    }
  }
  const jsonClone = <T>(value: T): T =>
    hostCall(() => {
      if (!value || (typeof value !== 'object' && typeof value !== 'function')) return value
      const encoded = JSON.stringify(value)
      return (encoded === undefined ? undefined : JSON.parse(encoded)) as T
    })
  const iteratorOf = (source: Iterator<unknown>, project: (value: unknown) => unknown = value => harden(value)) => {
    let proxy: object
    const next = harden(() => {
      const step = source.next()
      return step.done ? { value: undefined, done: true } : { value: project(step.value), done: false }
    })
    const iterator = harden(() => proxy)
    const target = { next, [Symbol.iterator]: iterator }
    // Only these owned methods cross the membrane. Ordinary object properties
    // still hide functions; a native iterator and its prototype never escape.
    proxy = new Proxy(target, {
      get(_target, prop) {
        return prop === 'next' ? next : prop === Symbol.iterator ? iterator : undefined
      },
      has(_target, prop) {
        return prop === 'next' || prop === Symbol.iterator
      },
      ...readonlyTraps(),
    })
    hardened.set(target, proxy)
    return rememberRaw(proxy, target)
  }
  function descriptorFor(target: object, prop: string | symbol): PropertyDescriptor | undefined {
    if (forbidden(prop)) return undefined
    const desc = Reflect.getOwnPropertyDescriptor(target, prop)
    if (!desc) return undefined
    if ('value' in desc) return { ...desc, value: harden(desc.value) }
    return { ...desc, get: desc.get ? harden(desc.get) : undefined, set: desc.set ? harden(readonly) : undefined }
  }
  /** The traps every membrane proxy shares: each write, prototype change or
   * extension lock throws the read-only error, and descriptors and prototypes
   * are reported (hardened) for `source`, the proxied target by default. */
  const readonlyTraps = <T extends object>(source?: object) => ({
    set: readonly,
    deleteProperty: readonly,
    defineProperty: readonly,
    setPrototypeOf: readonly,
    preventExtensions: readonly,
    getOwnPropertyDescriptor: (target: T, prop: string | symbol) => descriptorFor(source ?? target, prop),
    getPrototypeOf: (target: T) => protoFor(source ?? target),
  })
  const isDiagramLike = (value: unknown): value is object => Boolean(value && typeof value === 'object' && 'body' in value && 'canonicalSource' in value)
  const idOf = (value: unknown): number | undefined => {
    value = rawOf(value)
    if (!isDiagramLike(value)) return undefined
    const obj = value as object
    let id = diagramIds.get(obj)
    if (!id) {
      id = nextId++
      diagramIds.set(obj, id)
    }
    return id
  }
  const trustDiagram = (value: unknown): void => {
    value = rawOf(value)
    if (isDiagramLike(value)) trusted.add(value as object)
  }
  const requireTrustedDiagram = (value: unknown, verb: string): void => {
    value = rawOf(value)
    // A missing diagram is almost always a narrower's null (asSequence(d) on a
    // flowchart) passed straight on; say so instead of letting the engine
    // report "Cannot read properties of null".
    if (value === null || value === undefined) {
      throw sandboxError(`Code Mode ${verb} input is ${value}; it must be a diagram from mermaid.parseRegisteredMermaid(...).value or mermaid.mutate(...). A mermaid.as<Family>(d) narrower returns null when d is a different family — check d.kind before narrowing`)
    }
    if ((typeof value === 'object' || typeof value === 'function') && !trusted.has(value as object)) {
      throw sandboxError(`Code Mode ${verb} input must come from mermaid.parseRegisteredMermaid(...) or mermaid.mutate(...)`)
    }
  }
  const rememberRaw = <T extends object>(proxy: T, target: object): T => {
    raw.set(proxy, target)
    if (isDiagramLike(target)) diagramIds.set(proxy, idOf(target)!)
    return proxy
  }
  const harden = <T>(value: T): T => {
    if (!value || (typeof value !== 'object' && typeof value !== 'function')) return value
    const unwrapped = rawOf(value)
    if (unwrapped !== value) return harden(unwrapped) as T
    const obj = value as object
    const cached = hardened.get(obj)
    if (cached) return cached as T

    if (isMap(value)) {
      let proxy: Map<unknown, unknown>
      proxy = new Proxy(value, {
        get(target, prop) {
          if (forbidden(prop)) return undefined
          if (prop === 'size') return target.size
          if (prop === 'get') return harden((key: unknown) => harden(target.get(rawOf(key))))
          if (prop === 'set' || prop === 'delete' || prop === 'clear' || prop === 'getOrInsert' || prop === 'getOrInsertComputed') return harden(readonly)
          if (prop === 'has') return harden((key: unknown) => target.has(rawOf(key)))
          if (prop === Symbol.iterator || prop === 'entries') return harden(() => iteratorOf(target.entries(), entry => {
            const [key, value] = entry as [unknown, unknown]
            return [harden(key), harden(value)]
          }))
          if (prop === 'values') return harden(() => iteratorOf(target.values()))
          if (prop === 'keys') return harden(() => iteratorOf(target.keys()))
          if (prop === 'forEach')
            return harden((cb: (value: unknown, key: unknown, map: Map<unknown, unknown>) => unknown, thisArg?: unknown) => {
              for (const [k, v] of target.entries()) cb.call(thisArg, harden(v), harden(k), proxy)
            })
          const got = hostCall(() => Reflect.get(target, prop, target))
          return typeof got === 'function' ? undefined : harden(got)
        },
        ...readonlyTraps(),
      })
      hardened.set(obj, proxy)
      return rememberRaw(proxy, value) as T
    }

    if (isSet(value)) {
      let proxy: Set<unknown>
      proxy = new Proxy(value, {
        get(target, prop) {
          if (forbidden(prop)) return undefined
          if (prop === 'size') return target.size
          if (prop === 'add' || prop === 'delete' || prop === 'clear') return harden(readonly)
          if (prop === 'has') return harden((val: unknown) => target.has(rawOf(val)))
          if (prop === Symbol.iterator || prop === 'values' || prop === 'keys') return harden(() => iteratorOf(target.values()))
          if (prop === 'entries') return harden(() => iteratorOf(target.values(), value => {
            const item = harden(value)
            return [item, item]
          }))
          if (prop === 'forEach')
            return harden((cb: (value: unknown, value2: unknown, set: Set<unknown>) => unknown, thisArg?: unknown) => {
              for (const v of target.values()) cb.call(thisArg, harden(v), harden(v), proxy)
            })
          const got = hostCall(() => Reflect.get(target, prop, target))
          return typeof got === 'function' ? undefined : harden(got)
        },
        ...readonlyTraps(),
      })
      hardened.set(obj, proxy)
      return rememberRaw(proxy, value) as T
    }

    if (typeof value === 'function') {
      const original = value
      const callable = (...args: unknown[]) => harden(hostCall(() => Reflect.apply(original, undefined, args)))
      const proxy = new Proxy(callable, {
        apply(_target, thisArg, args) {
          return harden(hostCall(() => Reflect.apply(original, thisArg, args)))
        },
        get(_target, prop, receiver) {
          if (forbidden(prop)) return undefined
          if (!Reflect.getOwnPropertyDescriptor(original, prop)) return undefined
          return harden(hostCall(() => Reflect.get(original, prop, receiver)))
        },
        ...readonlyTraps(original),
      })
      hardened.set(obj, proxy)
      return rememberRaw(proxy, value) as T
    }

    const proxyTarget = extensibleDataEnvelope(value as object)
    let proxy: object
    proxy = new Proxy(proxyTarget, {
      get(target, prop, receiver) {
        if (forbidden(prop)) return undefined
        if (Array.isArray(target)) {
          if (typeof prop === 'string' && arrayMutators.has(prop)) return harden(readonly)
          if (prop === Symbol.iterator || prop === 'values') return harden(() => iteratorOf(Array.prototype.values.call(target)))
          if (prop === 'entries') return harden(() => iteratorOf(Array.prototype.entries.call(target), entry => {
            const [index, value] = entry as [number, unknown]
            return [index, harden(value)]
          }))
          if (prop === 'keys') return harden(() => iteratorOf(Array.prototype.keys.call(target)))
          if (typeof prop === 'string' && arrayHardenedCopyMethods.has(prop)) {
            const method = Reflect.get(Array.prototype, prop) as (...args: unknown[]) => unknown
            return harden((...args: unknown[]) => Reflect.apply(method, Array.prototype.map.call(target, v => harden(v)), args))
          }
          if (typeof prop === 'string' && arrayStringMethods.has(prop)) {
            const method = Reflect.get(Array.prototype, prop) as (...args: unknown[]) => unknown
            return harden((...args: unknown[]) => Reflect.apply(method, Array.prototype.map.call(target, v => rawOf(v)), args))
          }
          if (typeof prop === 'string' && arrayCallbackMethods.has(prop)) {
            return harden((cb: (value: unknown, index: number, array: unknown) => unknown, thisArg?: unknown) => {
              const call = (v: unknown, i: number) => cb.call(thisArg, harden(v), i, proxy)
              if (prop === 'forEach') {
                Array.prototype.forEach.call(target, call)
                return undefined
              }
              if (prop === 'map') return Array.prototype.map.call(target, call)
              if (prop === 'filter') return Array.prototype.filter.call(target, call)
              if (prop === 'find') return Array.prototype.find.call(target, call)
              if (prop === 'findIndex') return Array.prototype.findIndex.call(target, call)
              if (prop === 'findLast') return Array.prototype.findLast.call(target, call)
              if (prop === 'findLastIndex') return Array.prototype.findLastIndex.call(target, call)
              if (prop === 'some') return Array.prototype.some.call(target, call)
              if (prop === 'every') return Array.prototype.every.call(target, call)
              if (prop === 'flatMap') return Array.prototype.flatMap.call(target, call)
            })
          }
          if (prop === 'toSorted') {
            return harden((compare?: (a: unknown, b: unknown) => number) => {
              const values = Array.prototype.map.call(target, v => harden(v))
              return compare ? values.slice().sort((a, b) => compare(a, b)) : values.slice().sort()
            })
          }
          if (prop === 'toReversed') return harden(() => Array.prototype.map.call(target, v => harden(v)).reverse())
          if (prop === 'toSpliced')
            return harden(function (start: number, deleteCount?: number, ...items: unknown[]) {
              const values = Array.prototype.map.call(target, v => harden(v))
              const copy = values.slice()
              if (arguments.length === 1) copy.splice(start)
              else copy.splice(start, deleteCount ?? 0, ...items.map(item => harden(rawOf(item))))
              return copy
            })
          if (prop === 'with')
            return harden((index: number, item: unknown) => {
              const values = Array.prototype.map.call(target, v => harden(v))
              const normalized = index < 0 ? values.length + index : index
              if (normalized < 0 || normalized >= values.length) throw sandboxError('Invalid array index')
              const copy = values.slice()
              copy[normalized] = harden(rawOf(item))
              return copy
            })
          if (prop === 'reduce' || prop === 'reduceRight') {
            return harden(function (cb: (previous: unknown, current: unknown, index: number, array: unknown) => unknown, initial?: unknown) {
              const supplied = arguments.length >= 2
              let unwrappedSeed = !supplied
              const reducer = (previous: unknown, current: unknown, index: number) => {
                const accumulator = unwrappedSeed ? harden(previous) : previous
                unwrappedSeed = false
                return cb(accumulator, harden(current), index, proxy)
              }
              const reduce = prop === 'reduce' ? Array.prototype.reduce : Array.prototype.reduceRight
              return Reflect.apply(reduce, target, supplied ? [reducer, initial] : [reducer])
            })
          }
        }
        if (!Reflect.getOwnPropertyDescriptor(target, prop)) return undefined
        const got = hostCall(() => Reflect.get(target, prop, receiver))
        return typeof got === 'function' ? undefined : harden(got)
      },
      ...readonlyTraps(),
      has(target, prop) {
        return forbidden(prop) ? false : Reflect.has(target, prop)
      },
    })
    hardened.set(obj, proxy)
    if (proxyTarget !== obj) hardened.set(proxyTarget, proxy)
    return rememberRaw(proxy, value as object) as T
  }

  const fingerprint = (value: unknown): string | undefined => fingerprintDiagram(rawOf(value))
  const bodyKind = (value: unknown): TraceMutationBody => {
    const kind = (value as { body?: { kind?: string } } | undefined)?.body?.kind
    return kind != null && FAMILY_KINDS.has(kind as DiagramKind) ? (kind as DiagramKind) : 'opaque'
  }
  const push = (call: ExecutionTraceCall) => {
    trace?.push(call)
    onTraceCall?.(call)
  }
  const sdkTarget = {
    parseRegisteredMermaid: mermaid.parseRegisteredMermaid,
    createMermaid: mermaid.createMermaid,
    buildMermaid: mermaid.buildMermaid,
    ...SDK_NARROWERS,

    mutate: mermaid.mutate,
    mutatePreservingSource: mermaid.mutatePreservingSource,
    verifyMermaid: mermaid.verifyMermaid,
    analyzeMermaid: mermaid.analyzeMermaid,
    analyzeMermaidSource: mermaid.analyzeMermaidSource,
    describeMermaidFacts: mermaid.describeMermaidFacts,
    describeMermaidFactsSource: mermaid.describeMermaidFactsSource,
    checkMermaid: mermaid.checkMermaid,
    checkMermaidSource: mermaid.checkMermaidSource,
    serializeMermaid: mermaid.serializeMermaid,
    renderMermaidSVG: mermaid.renderMermaidSVG,
    renderMermaidSVGWithReceipt: mermaid.renderMermaidSVGWithReceipt,
    renderMermaidASCII: mermaid.renderMermaidASCII,
    renderMermaidASCIIWithReceipt: mermaid.renderMermaidASCIIWithReceipt,
    layoutMermaidWithReceipt: mermaid.layoutMermaidWithReceipt,
    renderResolvedScene: mermaid.renderResolvedScene,
    // Read-only op discovery: field shapes / enum values / constraint notes and
    // compact signatures for a family's ops, so a Code Mode script can look up
    // exact op shapes at runtime instead of guessing (or triggering INVALID_OP).
    describeOps: mermaid.describeOps,
    opSignatures: mermaid.opSignatures,
  } as unknown as typeof mermaid
  const sdkProps = new Set<string | symbol>(Reflect.ownKeys(sdkTarget))

  const sdkValues = new Map<string | symbol, unknown>()
  const sdkValue = (target: typeof sdkTarget, prop: string | symbol): unknown => {
    if (forbidden(prop) || !sdkProps.has(prop)) return undefined
    if (sdkValues.has(prop)) return sdkValues.get(prop)
    let value: unknown
    if (prop === 'parseRegisteredMermaid')
      value = harden((source: string) => {
        assertOpen()
        if (typeof source !== 'string') throw sandboxError(`Code Mode ${prop} source must be a string`)
        const r = hostCall(() => target.parseRegisteredMermaid(source))
        if (r.ok) trustDiagram(r.value)
        const diagram = r.ok ? idOf(r.value) : undefined
        push({ verb: 'parse', diagram, source: r.ok ? (r.value.body.kind === 'opaque' ? r.value.body.source : r.value.canonicalSource) : undefined })
        return harden(r)
      })
    else if (prop === 'createMermaid')
      value = harden((kind: unknown, opts?: unknown) => {
        assertOpen()
        const r = hostCall(() => target.createMermaid(kind as DiagramKind, jsonClone(opts) as Parameters<typeof target.createMermaid>[1]))
        trustDiagram(r)
        push({ verb: 'create', family: FAMILY_KINDS.has(kind as DiagramKind) ? (kind as DiagramKind) : undefined, diagram: idOf(r), ok: true })
        return harden(r)
      })
    else if (prop === 'buildMermaid')
      value = harden((kind: unknown, ops: unknown, opts?: unknown) => {
        assertOpen()
        const opsForHost = jsonClone(ops) as Parameters<typeof target.buildMermaid>[1]
        // buildChecked shape-validates each op before the mutator, so a malformed
        // op fails with a prescriptive INVALID_OP error instead of silently
        // building a mangled diagram — the same check the declarative path uses.
        const r = hostCall(() => mermaid.buildChecked(kind as DiagramKind, opsForHost as unknown[], jsonClone(opts) as Parameters<typeof target.buildMermaid>[2]))
        if (r.ok) trustDiagram(r.value)
        push({
          verb: 'create',
          family: FAMILY_KINDS.has(kind as DiagramKind) ? (kind as DiagramKind) : undefined,
          diagram: r.ok ? idOf(r.value) : undefined,
          ops: Array.isArray(ops) ? ops.length : undefined,
          ok: r.ok,
        })
        return harden(r)
      })
    else if (typeof prop === 'string' && prop.startsWith('as') && prop in target) {
      value = harden((d: any) => {
        assertOpen()
        requireTrustedDiagram(d, String(prop))
        const input = idOf(d)
        const r = hostCall(() => ((target as any)[prop] as (diagram: any) => unknown)(rawOf(d)))
        if (r) trustDiagram(r)
        push({ verb: 'narrow', family: narrowerFamily(prop), input, ok: r !== null })
        return harden(r)
      })
    } else if (prop === 'mutate' || prop === 'mutatePreservingSource')
      value = harden((d: any, op: any) => {
        assertOpen()
        requireTrustedDiagram(d, prop)
        const opForHost = jsonClone(op)
        const call: Extract<ExecutionTraceCall, { verb: 'mutate' }> = {
          verb: 'mutate',
          body: bodyKind(rawOf(d)),
          input: idOf(d),
          opKind: typeof opForHost === 'object' && opForHost && 'kind' in opForHost ? String((opForHost as { kind: unknown }).kind) : undefined,
        }
        push(call)
        // mutateChecked runs the shape validator before the mutator: the SAME
        // choke point the declarative applyOps path funnels through, so an op
        // rejected here is rejected identically there (no second validator).
        const r = hostCall(() => prop === 'mutatePreservingSource' ? mermaid.mutatePreservingSource(rawOf(d), opForHost) : mermaid.mutateChecked(rawOf(d), opForHost))
        if (r.ok) {
          const output = 'diagram' in r.value ? r.value.diagram : r.value
          trustDiagram(output)
          if ('diagram' in r.value) {
            sourceResults.add(r.value)
            preservedSources.set(output, { source: r.value.source, ...(r.value.preservation ? { preservation: r.value.preservation } : {}) })
          }
          call.output = idOf(output)
          call.fingerprint = fingerprint(output)
        }
        if (!r.ok && Array.isArray(opForHost)) {
          return harden({ ...r, error: { ...r.error, message: r.error.message.replace('applyOps({ source, family, ops }) to edit source', 'the declarative mutate tool to edit source') } })
        }
        return harden(r)
      })
    else if (prop === 'verifyMermaid')
      value = harden((input: any, opts?: any) => {
        assertOpen()
        requireTrustedDiagram(input, 'verifyMermaid')
        const r = hostCall(() => target.verifyMermaid(rawOf(input), jsonClone(opts)))
        const diagram = idOf(input)
        push({ verb: 'verify', diagram, ok: r.ok, inspected: false, fingerprint: fingerprint(input) })
        return harden(
          new Proxy(r, {
            get(verifyTarget, verifyProp, verifyReceiver) {
              if (isClosed?.()) throw sandboxError('Code Mode SDK calls are not allowed while returning results')
              if (verifyProp === 'ok' || verifyProp === 'warnings' || verifyProp === 'layout') {
                push({ verb: 'verify_inspect', diagram, property: verifyProp })
              }
              if (forbidden(verifyProp)) return undefined
              return harden(hostCall(() => Reflect.get(verifyTarget, verifyProp, verifyReceiver)))
            },
            ...readonlyTraps(),
          }),
        )
      })
    else if (prop === 'analyzeMermaid')
      value = harden((d: any) => {
        assertOpen()
        requireTrustedDiagram(d, 'analyzeMermaid')
        const r = hostCall(() => target.analyzeMermaid(rawOf(d)))
        push({ verb: 'analyze', diagram: idOf(d), ok: true, fingerprint: fingerprint(d) })
        return harden(r)
      })
    else if (prop === 'analyzeMermaidSource')
      value = harden((source: string) => {
        assertOpen()
        if (typeof source !== 'string') throw sandboxError('Code Mode analyzeMermaidSource source must be a string')
        const r = hostCall(() => target.analyzeMermaidSource(source))
        push({ verb: 'analyze', source, ok: r.ok })
        return harden(r)
      })
    else if (prop === 'describeMermaidFacts')
      value = harden((d: any) => {
        assertOpen()
        requireTrustedDiagram(d, 'describeMermaidFacts')
        const r = hostCall(() => target.describeMermaidFacts(rawOf(d)))
        push({ verb: 'facts', diagram: idOf(d), ok: true, fingerprint: fingerprint(d) })
        return harden(r)
      })
    else if (prop === 'describeMermaidFactsSource')
      value = harden((source: string) => {
        assertOpen()
        if (typeof source !== 'string') throw sandboxError('Code Mode describeMermaidFactsSource source must be a string')
        const r = hostCall(() => target.describeMermaidFactsSource(source))
        push({ verb: 'facts', source, ok: r.ok })
        return harden(r)
      })
    else if (prop === 'checkMermaid')
      value = harden((d: any, spec: any) => {
        assertOpen()
        requireTrustedDiagram(d, 'checkMermaid')
        const r = hostCall(() => target.checkMermaid(rawOf(d), jsonClone(spec) as Parameters<typeof target.checkMermaid>[1]))
        push({ verb: 'check', diagram: idOf(d), ok: r.ok, fingerprint: fingerprint(d) })
        return harden(r)
      })
    else if (prop === 'checkMermaidSource')
      value = harden((source: string, spec: any) => {
        assertOpen()
        if (typeof source !== 'string') throw sandboxError('Code Mode checkMermaidSource source must be a string')
        const r = hostCall(() => target.checkMermaidSource(source, jsonClone(spec) as Parameters<typeof target.checkMermaidSource>[1]))
        push({ verb: 'check', source, ok: r.ok ? r.value.ok : false })
        return harden(r)
      })
    else if (prop === 'serializeMermaid')
      value = harden((d: any) => {
        assertOpen()
        requireTrustedDiagram(d, 'serializeMermaid')
        const source = hostCall(() => target.serializeMermaid(rawOf(d)))
        push({ verb: 'serialize', diagram: idOf(d), source, fingerprint: fingerprint(d) })
        return source
      })
    else if (prop === 'renderMermaidSVG' || prop === 'renderMermaidSVGWithReceipt' || prop === 'renderMermaidASCII' || prop === 'renderMermaidASCIIWithReceipt' || prop === 'layoutMermaidWithReceipt' || prop === 'renderResolvedScene')
      value = harden((input: any, opts?: any) => {
        assertOpen()
        if (input == null || typeof input === 'object') requireTrustedDiagram(input, String(prop))
        const isAscii = prop === 'renderMermaidASCII' || prop === 'renderMermaidASCIIWithReceipt'
        const configCallback = opts?.onConfigDiagnostic
        const projectionCallback = isAscii ? opts?.onProjectionDiagnostic : undefined
        if (configCallback !== undefined && typeof configCallback !== 'function') {
          throw sandboxError(`Code Mode ${String(prop)} onConfigDiagnostic must be a function`)
        }
        if (projectionCallback !== undefined && typeof projectionCallback !== 'function') {
          throw sandboxError(`Code Mode ${String(prop)} onProjectionDiagnostic must be a function`)
        }
        let cloned = jsonClone(opts) as Record<string, unknown> | undefined
        // The host policy is applied after cloning caller data, so even an
        // explicit weaker value cannot cross any hosted render/layout boundary.
        // Local Code Mode supplies no policy and retains caller-selectable
        // behavior. The policy governs SVG content only; terminal text has its
        // own safety projection, so it is not reported as a caller option there.
        if (hostPolicy && !isAscii) cloned = { ...(cloned ?? {}), ...hostPolicy.render }
        const configDiagnostics: unknown[] = []
        const projectionDiagnostics: unknown[] = []
        if (configCallback || projectionCallback) cloned ??= {}
        if (configCallback) {
          cloned!.onConfigDiagnostic = (diagnostic: unknown) => configDiagnostics.push(diagnostic)
        }
        if (projectionCallback) {
          cloned!.onProjectionDiagnostic = (diagnostic: unknown) => projectionDiagnostics.push(diagnostic)
        }
        const rawInput = rawOf(input)
        const rendered = hostCall(() => ((target as any)[prop] as (diagram: any, options?: any) => unknown)(rawInput, cloned), typeof rawInput === 'string' ? { source: rawInput } : {})
        for (const diagnostic of configDiagnostics) configCallback(harden(jsonClone(diagnostic)))
        for (const diagnostic of projectionDiagnostics) projectionCallback(harden(jsonClone(diagnostic)))
        // Render artifacts/receipts are immutable host records. Clone to an
        // extensible data envelope before hardening so Proxy descriptor
        // invariants remain valid when Code Mode returns the artifact as JSON.
        return jsonClone(rendered)
      })
    else if (prop === 'describeOps' || prop === 'opSignatures')
      value = harden((family: any) => {
        assertOpen()
        if (typeof family !== 'string') throw sandboxError(`Code Mode ${String(prop)} family must be a string`)
        if (!mermaid.hasOpSchema(family)) {
          const families = mermaid.knownBuiltinFamilies().filter(mermaid.hasOpSchema)
          throw sandboxError(`Code Mode ${String(prop)} family must be one of: ${families.join(', ')}`)
        }
        // Pure lookup over static op schemas — no diagram, no trace, read-only.
        return harden(hostCall(() => ((target as any)[prop] as (f: string) => unknown)(family)))
      })
    sdkValues.set(prop, value)
    return value
  }

  // Marshal a Code Mode RETURN value at the boundary the host owns. A sandbox
  // that returns a live SDK diagram (or a Result wrapping one) can't be JSON-
  // stringified — it is a hardened provenance proxy over Maps, and the verify
  // proxy actively throws once the SDK is closed. Rather than surface the raw
  // "non-serializable" failure, marshal the ONE shape agents naturally return —
  // a trusted diagram — to the SAME canonical envelope the declarative mutate/
  // build tools emit: { ok, family, source, verify }. Everything else passes
  // through untouched (plain data already stringifies; genuinely unserializable
  // values still error, now with a prescriptive hint — see codeModeReturnHint).
  // Runs host-side on the RAW object, so it is safe after the SDK is closed.
  const marshalResult = (value: unknown): unknown => {
    try {
      const rawObj = rawOf(value)
      // Unwrap a Result<diagram> ({ ok:true, value:<diagram> }) to the diagram.
      let candidate = rawObj && typeof rawObj === 'object' && !Array.isArray(rawObj) && (rawObj as { ok?: unknown }).ok === true && 'value' in (rawObj as object) ? rawOf((rawObj as { value: unknown }).value) : rawObj
      if (candidate && typeof candidate === 'object' && sourceResults.has(candidate)) candidate = (candidate as { diagram: unknown }).diagram
      if (isDiagramLike(candidate) && trusted.has(candidate as object)) {
        const d = candidate as unknown as Parameters<typeof mermaid.serializeMermaid>[0] & { kind: DiagramKind }
        const { accepted, verification } = verifyMutationResult(d)
        const summary = mermaid.verifySummary(verification)
        if (!accepted) {
          return {
            ok: false,
            family: d.kind,
            error: {
              code: 'VERIFY_FAILED',
              message: 'returned diagram failed verify; source was not emitted',
              details: summary.warnings,
            },
          }
        }
        const exact = preservedSources.get(d)
        return { ok: true, family: d.kind, source: exact?.source ?? mermaid.serializeMermaid(d), ...(exact !== undefined ? { mode: 'source-preserving', ...(exact.preservation ? { preservation: exact.preservation } : {}) } : {}), verify: summary }
      }
    } catch {
      // A returned value whose inspection trips a post-close proxy guard (e.g. a
      // verify result) is not a plain diagram — fall through and let the normal
      // serializer produce the prescriptive non-serializable error.
    }
    return value
  }
  const proxy = new Proxy(sdkTarget, {
    get(target, prop) {
      return sdkValue(target, prop)
    },
    ...readonlyTraps(),
    getOwnPropertyDescriptor(target, prop) {
      if (!sdkProps.has(prop) || forbidden(prop)) return undefined
      const desc = Reflect.getOwnPropertyDescriptor(target, prop)
      return desc && 'value' in desc ? { ...desc, value: sdkValue(target, prop) } : undefined
    },
    has(_target, prop) {
      return sdkProps.has(prop) && !forbidden(prop)
    },
    ownKeys() {
      return Array.from(sdkProps)
    },
  }) as typeof mermaid
  resultMarshallers.set(proxy, marshalResult)
  return proxy
}

/** Per-facade result marshallers, keyed by the SDK proxy handed to a sandbox.
 *  Host-only: the sandbox never sees this map; the runner looks up the marshaller
 *  for its facade and applies it to the returned value before serialization. */
const resultMarshallers = new WeakMap<object, (value: unknown) => unknown>()

/**
 * Marshal a Code Mode return `value` produced against `sdk` (the proxy from
 * createTracingMermaid): a trusted diagram (or Result wrapping one) becomes the
 * canonical { ok, family, source, verify } envelope; anything else is returned
 * unchanged. The single boundary both runners (node:vm sandbox and the workerd
 * harness) call before serializing a result.
 */
export function marshalCodeModeResult(sdk: unknown, value: unknown): unknown {
  const fn = sdk && typeof sdk === 'object' ? resultMarshallers.get(sdk as object) : undefined
  return fn ? fn(value) : value
}

/** A one-line, prescriptive tail for a `non-serializable:` error: point the
 *  caller at the plain-data return shapes that always serialize, so a returned
 *  SDK object (verify result, narrowed view, custom nesting) is a fixable
 *  mistake rather than a dead end. */
export const CODE_MODE_RETURN_HINT = 'return plain data instead — e.g. serializeMermaid(d) for a diagram, or read the fields you need (verifyMermaid(d).ok, .warnings); the declarative mutate/build tools return a ready { ok, family, source, verify } envelope'

function fingerprintDiagram(value: unknown): string | undefined {
  if (!value || typeof value !== 'object') return undefined
  if (!('body' in value) || !('canonicalSource' in value)) return undefined
  try {
    return JSON.stringify(value, jsonReplacer)
  } catch {
    return undefined
  }
}

/** Kind/narrower lookup tables derived from the family metadata (single source of truth). */
const FAMILY_KINDS: ReadonlySet<DiagramKind> = new Set(BUILTIN_FAMILY_METADATA.map(m => m.id))
const SDK_NARROWERS = Object.fromEntries(BUILTIN_FAMILY_METADATA.map(({ narrower }) => {
  const narrow = mermaid[narrower as keyof typeof mermaid]
  if (typeof narrow !== 'function') throw new Error(`Missing public family narrower ${narrower}`)
  return [narrower, narrow]
}))
const NARROWER_TO_FAMILY: ReadonlyMap<string, DiagramKind> = new Map(BUILTIN_FAMILY_METADATA.map(m => [m.narrower, m.id]))

function narrowerFamily(prop: string | symbol): TraceNarrowFamily {
  const family = NARROWER_TO_FAMILY.get(String(prop))
  if (!family) throw new Error(`Unknown Code Mode narrower: ${String(prop)}`)
  return family
}

// ── Agent-code positions ────────────────────────────────────────────────
// Every Code Mode wrap (node:vm and hosted module, expression and statement
// form) puts the agent's code verbatim at column 1 of the wrap's line 2, so an
// engine position in the wrapped script is the agent position one line down.
// The single in-line shift is the statement form's return capture: `return (`
// is inserted where the final expression statement starts, moving the rest of
// that one line right by its length. agentCodeLocation undoes both, so
// reported locations are exact. A raw `e.stack` read by agent code is the
// engine's own value and stays unedited: its user.js/codemode.ts frames carry
// the one-line offset, and it also lists the runner's frames.

/** A position in the agent's own code: 1-based line and column (UTF-16 units). */
export interface CodeModeLocation { line: number; column: number }
export type CodeModeWrapForm = 'expression' | 'statement'

/** Lines every wrap places above the agent's first line. */
const CODE_MODE_LINE_OFFSET = 1
const RETURN_CAPTURE = 'return ('
const STATEMENT_PARSE_PREFIX = 'function __agent_code__(){"use strict";\n'
const LINE_TERMINATOR = /\r\n|[\n\r\u2028\u2029]/g
const MAX_STACK_CHARS = 16_384

/** The agent code minus one trailing semicolon: the expression-form payload. */
export function codeModeExpressionPayload(code: string): string {
  return code.replace(/;\s*$/, '')
}

/** [start, end) of the final meaningful top-level expression statement, with
 * its terminating semicolon excluded, or undefined when there is none. */
function finalExpressionStatement(code: string): { start: number; end: number } | undefined {
  try {
    // Parse in the function context we execute: new.target and return are
    // legal here, while strict-mode syntax restrictions apply in both hosts.
    const ast = parseJavaScript(`${STATEMENT_PARSE_PREFIX}${code}\n}`, { ecmaVersion: 'latest', sourceType: 'script' })
    const fn = ast.body[0]
    if (fn?.type !== 'FunctionDeclaration') return undefined
    const last = fn.body.body.findLast(statement => statement.type !== 'EmptyStatement')
    if (last?.type !== 'ExpressionStatement') return undefined
    const offset = STATEMENT_PARSE_PREFIX.length
    // The injected directive belongs to the wrapper, never to user output.
    if (last.start < offset) return undefined
    const start = last.start - offset
    const end = last.end - offset
    return { start, end: code[end - 1] === ';' ? end - 1 : end }
  } catch {
    // The execution boundary owns syntax errors; do not repair invalid code.
    return undefined
  }
}

/** Preserve statement semantics and capture the final meaningful top-level
 * expression. The capture inserts no line break before the expression, so
 * every agent line keeps its number (see agentCodeLocation). */
export function codeModeStatementBody(code: string): string {
  const capture = finalExpressionStatement(code)
  if (!capture) return code
  const rest = code.slice(capture.end).replace(/^;/, '')
  return `${code.slice(0, capture.start)}${RETURN_CAPTURE}${code.slice(capture.start, capture.end)}\n);${rest}`
}

/** 0-based line index and column of a UTF-16 offset in `code`. */
function lineColumnOf(code: string, offset: number): { line: number; column: number } {
  let line = 0
  let lineStart = 0
  for (const match of code.slice(0, offset).matchAll(LINE_TERMINATOR)) {
    line += 1
    lineStart = match.index + match[0].length
  }
  return { line, column: offset - lineStart }
}

/**
 * Map a 1-based engine position in a wrapped script back to the agent's code.
 * Undefined when the position lies outside the agent's lines (the wrapper's
 * own call frame).
 */
export function agentCodeLocation(code: string, form: CodeModeWrapForm, line: number, column: number): CodeModeLocation | undefined {
  if (!Number.isSafeInteger(line) || !Number.isSafeInteger(column) || column < 1) return undefined
  const agentLine = line - CODE_MODE_LINE_OFFSET
  const lineCount = (form === 'expression' ? codeModeExpressionPayload(code) : code).split(LINE_TERMINATOR).length
  if (agentLine < 1 || agentLine > lineCount) return undefined
  const capture = form === 'statement' ? finalExpressionStatement(code) : undefined
  if (capture) {
    const at = lineColumnOf(code, capture.start)
    const zeroBased = column - 1
    if (agentLine === at.line + 1 && zeroBased >= at.column) {
      return { line: agentLine, column: Math.max(at.column, zeroBased - RETURN_CAPTURE.length) + 1 }
    }
  }
  return { line: agentLine, column }
}

/** The first `at ... (<fileName>:line:column)` frame of an engine stack
 * string (V8 and JavaScriptCore both print this form), in wrapped-script
 * coordinates. Only frame lines are read, so message text cannot match. */
export function firstStackFrame(stack: unknown, fileName: string): { line: number; column: number } | undefined {
  if (typeof stack !== 'string') return undefined
  const escaped = fileName.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')
  const frame = new RegExp(`^\\s*at (?:.*[ (])?(?:[^\\s()]*/)?${escaped}:(\\d+):(\\d+)\\)?\\s*$`)
  for (const text of stack.slice(0, MAX_STACK_CHARS).split('\n')) {
    const match = frame.exec(text)
    if (match) return { line: Number(match[1]), column: Number(match[2]) }
  }
  return undefined
}

/** Where the pre-screen parser stopped in code that does not parse, in agent
 * coordinates. A failure past the agent's last line (an unterminated block or
 * literal) is reported at the end of the code. */
function codeModeSyntaxLocation(code: string): CodeModeLocation | undefined {
  try {
    parseJavaScript(`${STATEMENT_PARSE_PREFIX}${code}\n}`, { ecmaVersion: 'latest', sourceType: 'script', locations: true })
    return undefined
  } catch (e) {
    const loc = (e as { loc?: { line?: unknown; column?: unknown } }).loc
    if (typeof loc?.line !== 'number' || typeof loc.column !== 'number') return undefined
    const lines = code.split(LINE_TERMINATOR)
    const line = loc.line - CODE_MODE_LINE_OFFSET
    if (line < 1) return { line: 1, column: 1 }
    if (line > lines.length) return { line: lines.length, column: lines[lines.length - 1]!.length + 1 }
    return { line, column: loc.column + 1 }
  }
}

/**
 * The node:vm wrap for agent code: expression form when the code parses as a
 * bare expression (objects/arrows/templates included), otherwise statement
 * form (multi-statement bodies with `return` etc.). Code Mode is deliberately
 * synchronous: allowing Promise jobs after `vm.runInContext` lets sandbox code
 * block the host event loop outside the VM timeout.
 *
 * The statement body sits in `try { } finally { }` so no top-level
 * `return f(...)` is a tail call: JavaScriptCore (Bun) performs proper tail
 * calls in strict mode, which would drop the agent's frame from the stack of
 * an error thrown inside f and leave nothing to locate. A block changes one
 * thing about strict code: a top-level function declaration that shares its
 * name with a `var` or another function declaration is an early error there.
 * Such code keeps the plain function body (codeModeStatementWrap), where it
 * is valid; only an error inside a tail call it makes may lack a location.
 */
export function expressionFirstWraps(code: string): { source: string; form: CodeModeWrapForm } {
  const stripped = codeModeExpressionPayload(code)
  // Pick expression form only if host parsing succeeds; never retry based on
  // sandbox-thrown values, because their getters/proxy traps are
  // attacker-controlled.
  try {
    // eslint-disable-next-line no-new-func
    new Function(`"use strict"; return (\n${stripped}\n)`)
    return { source: `(function (mermaid, console) { "use strict"; try { return (\n${stripped}\n) } finally {} })(mermaid, console)`, form: 'expression' }
  } catch {
    const [open, close] = codeModeStatementWrap(code)
    return { source: `(function (mermaid, console) { "use strict"; ${open}\n${codeModeStatementBody(code)}\n${close} })(mermaid, console)`, form: 'statement' }
  }
}

/**
 * The text around a statement body: `try {` … `} finally {}` unless that block
 * would reject the code's own declarations (see expressionFirstWraps), in
 * which case the body stays at function scope. Shared by the local and hosted
 * runners so both scope agent code alike.
 */
export function codeModeStatementWrap(code: string): readonly [open: string, close: string] {
  return blockRejectsDeclarations(code) ? ['', ''] : ['try {', '} finally {}']
}

/** Whether a top-level function declaration shares its name with another
 *  function declaration or with a `var` anywhere in the function body. */
function blockRejectsDeclarations(code: string): boolean {
  let ast: AcornNode
  try { ast = parseJavaScript(`${STATEMENT_PARSE_PREFIX}${code}\n}`, { ecmaVersion: 'latest', sourceType: 'script' }) } catch { return false }
  const body = ((ast as unknown as { body: Array<{ body: { body: Array<AcornNode & Record<string, unknown>> } }> }).body[0]!.body.body)
  const functions: string[] = []
  for (const statement of body) {
    if (statement.type === 'FunctionDeclaration') functions.push((statement.id as { name: string }).name)
  }
  if (functions.length === 0) return false
  if (new Set(functions).size !== functions.length) return true
  const vars = new Set<string>()
  const bind = (pattern: unknown): void => {
    if (!isAcornNode(pattern)) return
    const node = pattern as AcornNode & Record<string, unknown>
    if (node.type === 'Identifier') vars.add(node.name as string)
    else if (node.type === 'ObjectPattern') for (const property of node.properties as unknown[]) bind((property as { value?: unknown; argument?: unknown }).value ?? (property as { argument?: unknown }).argument)
    else if (node.type === 'ArrayPattern') for (const element of node.elements as unknown[]) bind(element)
    else if (node.type === 'AssignmentPattern') bind(node.left)
    else if (node.type === 'RestElement') bind(node.argument)
  }
  const visit = (node: AcornNode & Record<string, unknown>): void => {
    if (node.type === 'VariableDeclaration' && node.kind === 'var') for (const declaration of node.declarations as Array<{ id: unknown }>) bind(declaration.id)
    for (const [key, value] of Object.entries(node)) {
      if (key === 'start' || key === 'end' || key === 'type') continue
      for (const child of Array.isArray(value) ? value : [value]) {
        // A var inside a nested function belongs to that function.
        if (isAcornNode(child) && !/Function|Class/.test(child.type)) visit(child as AcornNode & Record<string, unknown>)
      }
    }
  }
  for (const statement of body) if (statement.type !== 'FunctionDeclaration') visit(statement)
  return functions.some(name => vars.has(name))
}

const SYNTAX_REASON = 'Code Mode syntax must be a strict JavaScript expression or function body'

/** unsupportedCodeReason plus, for code that does not parse, where it stopped. */
export function codeModeScreen(code: string): { message: string; location?: CodeModeLocation } | undefined {
  const message = unsupportedCodeReason(code)
  if (message === undefined) return undefined
  const location = message === SYNTAX_REASON ? codeModeSyntaxLocation(code) : undefined
  return location ? { message, location } : { message }
}

export function unsupportedCodeReason(code: string): string | undefined {
  const ast = parseCodeModeAst(code)
  if (!ast) return SYNTAX_REASON
  let usesAsync = false
  let usesRealm = false
  walkJavaScriptAst(ast, (node, parent, parentKey) => {
    if (node.type === 'ImportExpression' || node.type === 'AwaitExpression') usesAsync = true
    if ('async' in node && node.async === true) usesAsync = true
    if (node.type !== 'Identifier' || !('name' in node) || typeof node.name !== 'string') return
    // Identifier spellings used only as object/member property names do not
    // reference the corresponding global. Preserve the explicit Array.fromAsync
    // rejection because that is the actual disabled async intrinsic.
    const propertyNameOnly = (parentKey === 'key' && parent?.computed !== true) || (parent?.type === 'MemberExpression' && parentKey === 'property' && parent.computed === false)
    if (propertyNameOnly && !(node.name === 'fromAsync' && parent?.type === 'MemberExpression' && (parent.object as { type?: unknown; name?: unknown } | undefined)?.type === 'Identifier' && (parent.object as { name?: unknown }).name === 'Array')) return
    if (SYNC_UNSUPPORTED_IDENTIFIERS.has(node.name)) usesAsync = true
    if (REALM_UNSUPPORTED_IDENTIFIERS.has(node.name)) usesRealm = true
  })
  if (usesAsync) {
    return 'Code Mode is synchronous; async/await, Promise jobs, finalizers, queueMicrotask, Array.fromAsync, and dynamic import are not supported'
  }
  if (usesRealm) {
    return 'Code Mode does not expose blocking or realm-creating globals'
  }
  return undefined
}

const SYNC_UNSUPPORTED_IDENTIFIERS = new Set(['async', 'await', 'Promise', 'AsyncDisposableStack', 'FinalizationRegistry', 'WeakRef', 'fromAsync', 'queueMicrotask'])
const REALM_UNSUPPORTED_IDENTIFIERS = new Set(['Atomics', 'SharedArrayBuffer', 'ShadowRealm', 'WebAssembly'])

/** Parse the same expression-first/statement-fallback language Code Mode runs.
 * A real ECMAScript parser is intentional here: slash heuristics cannot
 * distinguish regex literals from division safely and previously created both
 * false positives and a dynamic-import screening bypass. */
function parseCodeModeAst(code: string): AcornNode | undefined {
  const stripped = codeModeExpressionPayload(code)
  const candidates = [
    `function __agent_code__(){"use strict"; return (\n${stripped}\n)}`,
    `function __agent_code__(){"use strict";\n${code}\n}`,
    // Parse otherwise-invalid top-level await so it is rejected before an
    // isolate/CPU budget is allocated and telemetry remains truthful.
    `async function __agent_code__(){"use strict";\n${code}\n}`,
  ]
  for (const candidate of candidates) {
    try {
      return parseJavaScript(candidate, { ecmaVersion: 'latest', sourceType: 'script' })
    } catch {
      // Try the statement body after expression parsing fails. If both fail,
      // the runtime owns the syntax diagnostic.
    }
  }
  return undefined
}

function walkJavaScriptAst(node: AcornNode, visit: (node: AcornNode & Record<string, unknown>, parent?: AcornNode & Record<string, unknown>, parentKey?: string) => void, parent?: AcornNode & Record<string, unknown>, parentKey?: string): void {
  const record = node as AcornNode & Record<string, unknown>
  visit(record, parent, parentKey)
  for (const [key, value] of Object.entries(record)) {
    if (key === 'start' || key === 'end' || key === 'type') continue
    if (Array.isArray(value)) {
      for (const child of value) if (isAcornNode(child)) walkJavaScriptAst(child, visit, record, key)
    } else if (isAcornNode(value)) {
      walkJavaScriptAst(value, visit, record, key)
    }
  }
}

function isAcornNode(value: unknown): value is AcornNode {
  return Boolean(value && typeof value === 'object' && 'type' in value && typeof (value as { type?: unknown }).type === 'string')
}
function jsonReplacer(_k: string, v: unknown): unknown {
  if (v instanceof Map) return Object.fromEntries(v)
  if (v instanceof Set) return Array.from(v)
  return v
}
