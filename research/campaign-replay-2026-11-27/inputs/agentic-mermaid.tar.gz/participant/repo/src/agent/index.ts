// ============================================================================
// agentic-mermaid — public agent surface (v4)
// Re-exports the runtime-neutral core plus the Node-native PNG renderer.
// Browser/workerd consumers should import `agentic-mermaid/agent/core` so
// their bundle never resolves the native PNG dependency tree.
// ============================================================================

export * from './core.ts'
export { createMermaidPNGRenderer, renderMermaidPNG, renderMermaidPNGWithReceipt } from './png.ts'
export type {
  MermaidPNGRenderer, MermaidPNGRendererHostOptions, PngFontWarning,
  PngLegibilityWarning, PngOptions, PngRasterWarning, RenderedPng,
} from './png.ts'

import { renderMermaidPNGWithReceiptForHost } from './png.ts'
import { executeGraphicalRequest, type GraphicalLayoutConsumer } from '../graphical-render.ts'
import { assertFamilyLayoutProjection, projectResolvedFamilyLayout } from './family-layouts.ts'
import { buildRenderedRegions } from './rendered-regions.ts'
import { renderMermaidASCIIWithMeta, type AsciiRegion, type AsciiWarning } from '../ascii/meta.ts'
import { parseRegisteredMermaid as parseMermaid } from './parse.ts'
import { collectActionRecords } from './analyze.ts'
import { prepareRenderInput } from './render-input.ts'
import { toFinite } from './types.ts'
import { inspectPngDimensions } from '../output-color-profile.ts'
import { decodedSvgAttributeValue, scanSvgStartTags } from '../svg-structure.ts'
import type { AsciiRenderOptions } from '../ascii/index.ts'
import type { PngOptions } from './png.ts'
import type {
  DiagramActionRecord,
  ParsedDiagram,
  RenderedRegion,
  RenderedRegionKind,
  RenderedLayout,
} from './types.ts'
import type { RenderOptions } from '../types.ts'

export type RendererActionFormat = 'svg' | 'png' | 'ascii' | 'unicode'
export type RendererActionDisposition = 'embedded-inert' | 'sidecar-only'

export interface RendererAction extends DiagramActionRecord {
  surface: RendererActionFormat
  disposition: RendererActionDisposition
  /** Surface-coordinate hit region, absent when the target was not rendered. */
  region?: RenderedRegion
}

export interface RendererActionSurface {
  version: 1
  format: RendererActionFormat
  coordinateSpace: 'pixel' | 'cell'
  /** Only regions referenced by at least one action. */
  regions: RenderedRegion[]
  /** Callbacks remain metadata-only and `executable` is always false. */
  actions: RendererAction[]
}

export type RenderMermaidActionRequest =
  | { format: 'svg'; options?: RenderOptions }
  | { format: 'png'; options?: PngOptions }
  | { format: 'ascii' | 'unicode'; options?: AsciiRenderOptions }

export type RenderedActionArtifact =
  | { format: 'svg'; output: string; actionSurface: RendererActionSurface }
  | { format: 'png'; output: Uint8Array; actionSurface: RendererActionSurface }
  | { format: 'ascii' | 'unicode'; output: string; actionSurface: RendererActionSurface; warnings: AsciiWarning[] }

function terminalRegionId(region: Pick<AsciiRegion, 'id' | 'kind'>): string {
  if (region.kind === 'node') return `node:${region.id}`
  if (region.kind === 'edge') return `edge:${region.id}`
  if (region.kind === 'label') return `label:${region.id}`
  return `group:${region.id}`
}

function terminalRegionKind(kind: AsciiRegion['kind']): RenderedRegionKind {
  return kind === 'subgraph' ? 'cluster' : kind
}

function terminalRegion(region: AsciiRegion, identities: ReadonlySet<string>): RenderedRegion {
  const parent = region.parentId !== undefined && region.parentKind !== undefined
    ? terminalRegionId({ id: region.parentId, kind: region.parentKind })
    : undefined
  return {
    id: terminalRegionId(region),
    kind: terminalRegionKind(region.kind),
    elementId: region.id,
    ...(parent !== undefined && identities.has(parent) ? { parentId: parent } : {}),
    bounds: {
      x: toFinite(region.canvasColStart),
      y: toFinite(region.canvasRow),
      w: toFinite(Math.max(1, region.canvasColEnd - region.canvasColStart)),
      h: toFinite(Math.max(1, region.rowSpan ?? 1)),
    },
    ...(region.ownedCellSpans ? { cellSpans: region.ownedCellSpans } : {}),
    ...(region.occludedCellSpans ? { occludedCellSpans: region.occludedCellSpans } : {}),
    ...(region.sourceLine !== undefined ? { sourceLine: region.sourceLine } : {}),
  }
}

function actionSurface(
  format: RendererActionFormat,
  coordinateSpace: RendererActionSurface['coordinateSpace'],
  actions: DiagramActionRecord[],
  regions: RenderedRegion[],
  embeddedSvgActions: ReadonlySet<string> = new Set(),
): RendererActionSurface {
  const byId = new Map(regions.map(region => [region.id, region]))
  const rendererActions: RendererAction[] = actions.map(action => {
    const region = action.regionId ? byId.get(action.regionId) : undefined
    return {
      ...action,
      surface: format,
      disposition: format === 'svg' && region && action.href !== undefined
        && embeddedSvgActions.has(`${action.target}\u0000${action.href}`)
        ? 'embedded-inert'
        : 'sidecar-only',
      ...(region ? { region } : {}),
    }
  })
  const referencedIds = new Set(rendererActions.flatMap(action => action.region ? [action.region.id] : []))
  return {
    version: 1,
    format,
    coordinateSpace,
    regions: regions.filter(region => referencedIds.has(region.id)),
    actions: rendererActions,
  }
}

function embeddedSvgActionKeys(svg: string): ReadonlySet<string> {
  const result = new Set<string>()
  for (const tag of scanSvgStartTags(svg)) {
    const href = decodedSvgAttributeValue(tag, 'data-href')
    const targets = [decodedSvgAttributeValue(tag, 'data-task'), decodedSvgAttributeValue(tag, 'data-id')]
    if (href !== undefined) {
      for (const target of targets) if (target !== undefined) result.add(`${target}\u0000${href}`)
    }
    const links = decodedSvgAttributeValue(tag, 'data-links')
    const target = targets.find(candidate => candidate !== undefined)
    if (links === undefined || target === undefined) continue
    try {
      const menu = JSON.parse(links) as unknown
      if (!menu || typeof menu !== 'object' || Array.isArray(menu)) continue
      for (const value of Object.values(menu)) {
        if (typeof value === 'string') result.add(`${target}\u0000${value}`)
      }
    } catch {
      // Renderer-owned metadata should always be JSON. Ignore malformed tags
      // instead of upgrading an action to embedded without exact evidence.
    }
  }
  return result
}

function scalePixelRegions(regions: RenderedRegion[], scaleX: number, scaleY: number): RenderedRegion[] {
  return regions.map(region => ({
    ...region,
    bounds: {
      x: toFinite(region.bounds.x * scaleX),
      y: toFinite(region.bounds.y * scaleY),
      w: toFinite(region.bounds.w * scaleX),
      h: toFinite(region.bounds.h * scaleY),
    },
  }))
}

/**
 * Render SVG, PNG, ASCII, or Unicode and return one renderer-neutral inert
 * action/hit-region sidecar. The ordinary byte/string render APIs are unchanged.
 */
export function renderMermaidWithActions(
  input: ParsedDiagram | string,
  request: RenderMermaidActionRequest,
): RenderedActionArtifact {
  const prepared = prepareRenderInput(input)
  const source = prepared.source
  if (request.format === 'ascii' || request.format === 'unicode') {
    const meta = renderMermaidASCIIWithMeta(input, {
      ...(request.options ?? {}),
      useAscii: request.format === 'ascii',
    })
    const failure = meta.warnings.find(warning => warning.code === 'ASCII_RENDER_FAILED')
    if (failure) throw new Error(failure.message)
    const ids = new Set(meta.regions.map(terminalRegionId))
    const regions = meta.regions.map(region => terminalRegion(region, ids))
    return {
      format: request.format,
      output: meta.ascii,
      actionSurface: actionSurface(request.format, 'cell', meta.actions, regions),
      warnings: meta.warnings,
    }
  }

  const options = request.options ?? {}
  const parsed = parseMermaid(source)
  if (!parsed.ok) throw new Error(parsed.error.map(error => error.message).join('; '))
  const diagram = typeof input === 'string' ? parsed.value : input
  const projection: { layout?: RenderedLayout } = {}
  const consumeLayout: GraphicalLayoutConsumer = {
    validate: assertFamilyLayoutProjection,
    consume(resolved, result) {
      const layout = projectResolvedFamilyLayout(resolved, result, { debug: undefined })
      if (!layout) throw new Error(`No public layout projection registered for Mermaid family "${diagram.kind}"`)
      layout.regions = buildRenderedRegions(diagram, layout)
      projection.layout = layout
    },
  }
  const actions = collectActionRecords(parsed.value)
  if (request.format === 'svg') {
    const output = executeGraphicalRequest(source, options, 'svg', undefined, prepared.resolutionOptions, consumeLayout).svg
    return {
      format: 'svg',
      output,
      actionSurface: actionSurface('svg', 'pixel', actions, projection.layout!.regions ?? [], embeddedSvgActionKeys(output)),
    }
  }
  const output = renderMermaidPNGWithReceiptForHost(input, options, {}, { input: prepared, consumeLayout }).png
  const layout = projection.layout!
  const dimensions = inspectPngDimensions(output)
  const regions = scalePixelRegions(
    layout.regions ?? [],
    layout.bounds.w > 0 ? dimensions.width / layout.bounds.w : 1,
    layout.bounds.h > 0 ? dimensions.height / layout.bounds.h : 1,
  )
  return { format: 'png', output, actionSurface: actionSurface('png', 'pixel', actions, regions) }
}
