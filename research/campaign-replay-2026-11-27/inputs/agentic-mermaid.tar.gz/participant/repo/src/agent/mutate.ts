import type { MutationOpForDiagram } from './family-mutation-types.ts'
import type { AgentflowValidDiagram, AgentflowMutationOp, CynefinValidDiagram, CynefinMutationOp, RailroadValidDiagram, RailroadMutationOp, SwimlaneValidDiagram, SwimlaneMutationOp, TreeviewValidDiagram, TreeviewMutationOp, UsecaseValidDiagram, UsecaseMutationOp, VennValidDiagram, VennMutationOp, WardleyValidDiagram, WardleyMutationOp } from './types.ts'
import type { EventModelingValidDiagram, EventModelingMutationOp } from './types.ts'
import { rebaseBodyComments, restoreBodyComments, snapshotBodyCommentAnchors } from './body-comments.ts'
import { beginMutationDraft, type MutationDraft } from './mutation-draft.ts'
import { transferParsedRenderModel } from './owned-render-model.ts'
import type { PacketMutationOp, PacketValidDiagram, KanbanMutationOp, KanbanValidDiagram, RequirementMutationOp, RequirementValidDiagram, TreemapMutationOp, TreemapValidDiagram, IshikawaMutationOp, IshikawaValidDiagram, BlockMutationOp, BlockValidDiagram } from './types.ts'
import type { C4MutationOp, C4ValidDiagram } from './types.ts'
// ============================================================================
// mutate: typed structural edits. Overloaded by family.
// ============================================================================

import type {
  FlowchartValidDiagram,
  StateValidDiagram,
  SequenceValidDiagram,
  TimelineValidDiagram,
  ClassValidDiagram,
  ErValidDiagram,
  JourneyValidDiagram,
  ArchitectureValidDiagram,
  XyChartValidDiagram,
  PieValidDiagram,
  QuadrantValidDiagram,
  GanttValidDiagram,
  RadarValidDiagram,
  SankeyValidDiagram,
  MutableValidDiagram,
  ParsedDiagram,
  FlowchartMutationOp,
  StateMutationOp,
  SequenceMutationOp,
  TimelineMutationOp,
  ClassMutationOp,
  ErMutationOp,
  JourneyMutationOp,
  ArchitectureMutationOp,
  XyChartMutationOp,
  PieMutationOp,
  QuadrantMutationOp,
  GanttMutationOp,
  RadarMutationOp,
  SankeyMutationOp,
  AnyMutationOp,
  MutationError,
  Result,
} from './types.ts'
import { ok, err } from './types.ts'
import { serializeMermaid, wrapperPrefix } from './serialize.ts'
import { logToolInvocation } from './trace-log.ts'
import { getFamily } from './families.ts'
import { admitOpRecord, validateOp, hasOpSchema, type OpFamily } from './op-schema.ts'
import { AccessibilityTextError, accessibilityFromBody, metadataFromBody, ensureAccessibilityLines, normalizeBodyAccessibility } from './accessibility-envelope.ts'
import { parseRegisteredMermaid as parseMermaid } from './parse.ts'
import { applySourceEdits, sameSourceMeaning } from './source-mutation.ts'
import { serializationDrift } from './serialization-closure.ts'
import { authoredSourceOf } from './source-map-spans.ts'
import { projectStructuredEdit, sameProjectedDiagram, type SourceEditPreservation } from './source-projection.ts'

export function mutate(d: FlowchartValidDiagram, op: FlowchartMutationOp): Result<FlowchartValidDiagram, MutationError>
export function mutate(d: StateValidDiagram, op: StateMutationOp): Result<StateValidDiagram, MutationError>
export function mutate(d: SequenceValidDiagram, op: SequenceMutationOp): Result<SequenceValidDiagram, MutationError>
export function mutate(d: TimelineValidDiagram, op: TimelineMutationOp): Result<TimelineValidDiagram, MutationError>
export function mutate(d: ClassValidDiagram, op: ClassMutationOp): Result<ClassValidDiagram, MutationError>
export function mutate(d: ErValidDiagram, op: ErMutationOp): Result<ErValidDiagram, MutationError>
export function mutate(d: JourneyValidDiagram, op: JourneyMutationOp): Result<JourneyValidDiagram, MutationError>
export function mutate(d: ArchitectureValidDiagram, op: ArchitectureMutationOp): Result<ArchitectureValidDiagram, MutationError>
export function mutate(d: XyChartValidDiagram, op: XyChartMutationOp): Result<XyChartValidDiagram, MutationError>
export function mutate(d: PieValidDiagram, op: PieMutationOp): Result<PieValidDiagram, MutationError>
export function mutate(d: QuadrantValidDiagram, op: QuadrantMutationOp): Result<QuadrantValidDiagram, MutationError>
export function mutate(d: GanttValidDiagram, op: GanttMutationOp): Result<GanttValidDiagram, MutationError>
export function mutate(d: RadarValidDiagram, op: RadarMutationOp): Result<RadarValidDiagram, MutationError>
export function mutate(d: C4ValidDiagram, op: C4MutationOp): Result<C4ValidDiagram, MutationError>
export function mutate(d: SankeyValidDiagram, op: SankeyMutationOp): Result<SankeyValidDiagram, MutationError>
export function mutate(d: PacketValidDiagram, op: PacketMutationOp): Result<PacketValidDiagram, MutationError>
export function mutate(d: KanbanValidDiagram, op: KanbanMutationOp): Result<KanbanValidDiagram, MutationError>
export function mutate(d: RequirementValidDiagram, op: RequirementMutationOp): Result<RequirementValidDiagram, MutationError>
export function mutate(d: TreemapValidDiagram, op: TreemapMutationOp): Result<TreemapValidDiagram, MutationError>
export function mutate(d: EventModelingValidDiagram, op: EventModelingMutationOp): Result<EventModelingValidDiagram, MutationError>
export function mutate(d: IshikawaValidDiagram, op: IshikawaMutationOp): Result<IshikawaValidDiagram, MutationError>
export function mutate(d: BlockValidDiagram, op: BlockMutationOp): Result<BlockValidDiagram, MutationError>
export function mutate(d: AgentflowValidDiagram, op: AgentflowMutationOp): Result<AgentflowValidDiagram, MutationError>
export function mutate(d: CynefinValidDiagram, op: CynefinMutationOp): Result<CynefinValidDiagram, MutationError>
export function mutate(d: RailroadValidDiagram, op: RailroadMutationOp): Result<RailroadValidDiagram, MutationError>
export function mutate(d: SwimlaneValidDiagram, op: SwimlaneMutationOp): Result<SwimlaneValidDiagram, MutationError>
export function mutate(d: TreeviewValidDiagram, op: TreeviewMutationOp): Result<TreeviewValidDiagram, MutationError>
export function mutate(d: UsecaseValidDiagram, op: UsecaseMutationOp): Result<UsecaseValidDiagram, MutationError>
export function mutate(d: VennValidDiagram, op: VennMutationOp): Result<VennValidDiagram, MutationError>
export function mutate(d: WardleyValidDiagram, op: WardleyMutationOp): Result<WardleyValidDiagram, MutationError>
// General form for callers holding the union (e.g. the CLI): dispatch is by
// registry at runtime either way, so kind-agnostic call sites don't need a
// per-family narrowing cascade.
export function mutate<D extends ParsedDiagram>(d: D, op: MutationOpForDiagram<NoInfer<D>>): Result<D, MutationError>
export function mutate(d: ParsedDiagram, op: AnyMutationOp): Result<ParsedDiagram, MutationError> {
  // Log the OUTCOME (not just the call): an `{ok:false}` trace line records a
  // failed op attempt — the observable signal the agent-usage eval reads to
  // measure a run's op-error rate directly, rather than inferring retries from
  // excess mutate-call counts.
  const r = applyOneMutation(d, op)
  logToolInvocation('mutate', r.ok)
  return r
}

interface BatchDraft {
  mutator?: NonNullable<ReturnType<typeof getFamily>>['mutate']
  body?: ParsedDiagram['body']
  apply?: MutationDraft
}

function applyOneMutation(d: ParsedDiagram, op: AnyMutationOp, deferSerialization = false, draft?: BatchDraft): Result<ParsedDiagram, MutationError> {
  // Every structured family mutates through its FamilyDescriptor hook, then
  // rebuilds canonicalSource from the new body so a mutated diagram never
  // carries stale source. Lookup is by DIAGRAM kind, not body kind. State
  // diagrams (BUILD-19) own a dedicated StateBody and bind the stateDiagram-v2
  // header through their own descriptor registration.
  if (d.body.kind === 'preserved') {
    return err({
      code: d.body.diagnostic.code === 'UNKNOWN_HEADER' ? 'UNKNOWN_HEADER' : 'UNSUPPORTED_FAMILY',
      message: `${d.body.diagnostic.message}; the exact source remains preserved and cannot accept structured mutation`,
    })
  }
  if (d.body.kind === 'extension') {
    return err({
      code: 'INVALID_OP',
      message: `Registered external family "${d.kind}" has no typed mutation contract in FamilyDescriptor v2`,
    })
  }
  const plugin = getFamily(d.kind)
  if (plugin?.mutate && plugin.serialize) {
    if (draft && (draft.mutator !== plugin.mutate || draft.body !== d.body)) {
      draft.mutator = plugin.mutate
      draft.body = d.body
      draft.apply = beginMutationDraft(plugin.mutate, d.body)
    }
    const before = draft?.apply ? snapshotBodyCommentAnchors(d) : d
    const r = draft?.apply ? draft.apply(op) : plugin.mutate(d.body, op)
    if (!r.ok) return r
    try {
      r.value = normalizeBodyAccessibility(r.value, op.kind !== 'set_accessibility_title')
    } catch (error) {
      if (!(error instanceof AccessibilityTextError)) throw error
      return err({ code: 'INVALID_OP', message: error.message })
    }
    if (draft) draft.body = r.value
    d = rebaseBodyComments(before, r.value, op)
    return deferSerialization ? ok({ ...d, body: r.value } as ParsedDiagram) : commitMutation(d, r.value)
  }

  return err({ code: 'INVALID_OP', message: `Unsupported mutable diagram kind: ${d.kind}` })
}

/** Commit one private transaction: serialize, rebuild spans, and check parser closure once. */
function commitMutation(d: ParsedDiagram, body: ParsedDiagram['body']): Result<ParsedDiagram, MutationError> {
  if (body.kind === 'preserved' || body.kind === 'extension') return err({ code: 'INVALID_OP', message: 'This source has no typed mutation contract' })
  const plugin = getFamily(d.kind)!
  // 1C wrapper policy: a mutated diagram keeps its leading wrapper
  // (frontmatter/directives/comments) byte-verbatim; only the body changes.
  const bodyAccessibility = accessibilityFromBody(body)
  let meta = d.meta
  try {
    meta = metadataFromBody(body, d.meta, d.body)
  } catch (error) {
    return err({ code: 'INVALID_OP', message: error instanceof Error ? error.message : String(error) })
  }
  let bodySource: string
  try {
    bodySource = restoreBodyComments(ensureAccessibilityLines(plugin.serialize!(body, meta), meta.accessibility), d.kind, body, meta)
  } catch (error) {
    if (!(error instanceof AccessibilityTextError)) throw error
    return err({ code: 'INVALID_OP', message: error.message })
  }
  const canonicalSource = wrapperPrefix(meta, 'verbatim', bodySource, d.kind) + bodySource
  // Source locations, exact authored spans, and wrapper ownership describe a
  // particular source artifact. Rebuild all three from the mutated
  // serialization; retaining pre-mutation metadata can make wrapperSource
  // disagree with the source map after a body-authored directive is moved.
  const reparsed = parseMermaid(canonicalSource)
  if (!reparsed.ok) {
    return err({
      code: 'INVALID_OP',
      message: `Mutation produced source that could not be reparsed: ${reparsed.error.map(error => error.message).join('; ')}`,
    })
  }
  const sameFamily = reparsed.value.kind === d.kind
  const sameRepresentation = reparsed.value.body.kind === body.kind
  // Blank-slate builders deliberately admit a narrow intermediate state:
  // the typed body may remain structured while it is still below the
  // family's source grammar floor (for example, a Sankey diagram before its
  // first link, which Mermaid rejects). Keep that exception family-owned and structural. A descriptor
  // must identify the candidate as EMPTY_DIAGRAM; every non-empty mutation
  // must close back through the shared parser to the same representation.
  const verifiedEmptyScaffold = !sameRepresentation && reparsed.value.body.kind === 'opaque' && plugin.verify?.(body, {}).some(warning => warning.code === 'EMPTY_DIAGRAM') === true
  if (!sameFamily || (!sameRepresentation && !verifiedEmptyScaffold)) {
    return err({
      code: 'INVALID_OP',
      message: `Mutation changed semantic family while reparsing: expected ${d.kind}/${body.kind}, got ${reparsed.value.kind}/${reparsed.value.body.kind}`,
    })
  }
  if (plugin.bodyMeta && meta.frontmatter?.title !== reparsed.value.meta.frontmatter?.title) {
    return err({ code: 'INVALID_OP', message: 'Mutation did not retain the requested title metadata through its final source envelope' })
  }
  if (bodyAccessibility && (bodyAccessibility.title !== reparsed.value.meta.accessibility.title || bodyAccessibility.descr !== reparsed.value.meta.accessibility.descr)) {
    return err({
      code: 'INVALID_OP',
      message: 'Accessibility text cannot be serialized by this family without changing its value; remove directive openers or description block delimiters',
    })
  }
  // The same representation is not the same meaning: a value the writer
  // cannot hold (a `%%` comment, a statement separator, an id that reads as
  // shape syntax) parses back as different content. Refuse it, naming what
  // would change, instead of publishing a silently altered diagram.
  const drift = sameRepresentation ? serializationDrift({ ...d, meta, body } as ParsedDiagram, reparsed.value) : undefined
  if (drift) return err({ code: 'INVALID_OP', message: `The edit cannot be written faithfully: ${drift}` })
  // Facts trim, so they cannot see edge whitespace a grammar drops on read
  // (a class member " k", a message text U+2028). Store what the written
  // source holds, so `am format` of the published source is a byte-exact
  // fixed point; a writer that does not settle is refused.
  let committed: { body: ParsedDiagram['body']; canonicalSource: string; reread: ParsedDiagram } = { body, canonicalSource, reread: reparsed.value }
  if (sameRepresentation) {
    const formatted = serializeMermaid(reparsed.value)
    if (formatted !== canonicalSource) {
      const settled = parseMermaid(formatted)
      if (!settled.ok || settled.value.body.kind !== body.kind || serializeMermaid(settled.value) !== formatted || serializationDrift(reparsed.value, settled.value)) {
        return err({ code: 'INVALID_OP', message: 'The edit cannot be written faithfully: formatting the written Mermaid does not settle on one source' })
      }
      committed = { body: reparsed.value.body, canonicalSource: formatted, reread: settled.value }
    }
  }
  const diagram = {
    ...d,
    body: committed.body,
    meta: {
      ...committed.reread.meta,
      // This receipt describes loss from the originally parsed artifact.
      // Reparsing the already-canonical mutation output cannot rediscover a
      // comment that structured serialization intentionally omitted.
      ...(d.meta.droppedComments ? { droppedComments: d.meta.droppedComments } : {}),
    },
    canonicalSource: committed.canonicalSource,
    source: committed.reread.source,
  } as ParsedDiagram
  transferParsedRenderModel(committed.reread, diagram)
  return ok(diagram)
}

export type MutationBatchError = MutationError & { opIndex: number }

/** Intermediate bodies stay private; public source/maps are rebuilt only at commit. */
export function applyMutationBatch(d: ParsedDiagram, ops: readonly unknown[]): Result<ParsedDiagram, MutationBatchError> {
  let current = d
  const draft: BatchDraft = {}
  for (let index = 0; index < ops.length; index++) {
    const next = checkedMutation(current, ops[index], true, draft)
    if (!next.ok) return err({ ...next.error, opIndex: index })
    current = next.value
  }
  if (!ops.length) return ok(d)
  const committed = commitMutation(current, current.body)
  return committed.ok ? committed : err({ ...committed.error, opIndex: ops.length - 1 })
}

/**
 * mutate with a shape check in front — the one choke point every UNTYPED edit
 * path funnels through: the declarative applyOps/buildChecked entrypoints, the
 * Code Mode facade, and the CLI `--op`/`--ops` path. Typed callers keep using
 * `mutate` directly, where the compiler already guarantees op shape;
 * `mutateChecked` restores that guarantee at the boundaries where ops arrive as
 * raw JSON.
 *
 * `validateOp` proves the op's SHAPE (field names, primitive types, enums)
 * BEFORE the mutator runs, so a malformed op is rejected with a prescriptive
 * INVALID_OP error instead of silently mangling the diagram. Semantics — does
 * the referenced node exist, is the id a duplicate — stay in the mutator, which
 * runs second on a shape-proven op. Result shape is identical to `mutate`, so
 * this is a drop-in wherever the raw mutator was called with untyped ops.
 */
export function mutateChecked<D extends ParsedDiagram>(d: D, op: unknown): Result<D, MutationError>
export function mutateChecked(d: ParsedDiagram, op: unknown): Result<ParsedDiagram, MutationError> {
  return checkedMutation(d, op, false)
}

export interface SourceMutationResult {
  /** Save these exact bytes. Unsupported syntax remains source-preserved;
   * this artifact is not promised to be portable Mermaid. */
  readonly source: string
  readonly diagram: ParsedDiagram
  /** For a structured body: whether the edit was written as a local change
   * to the authored source or fell back to the canonical serialization. */
  readonly preservation?: SourceEditPreservation
}

/** Typed edits written as the smallest change to the source they were read
 * from. A structured body is edited canonically, then the change is projected
 * onto its authored lines and accepted only when it reads back as the same
 * diagram; otherwise the canonical source is returned and the receipt says
 * so. An opaque body uses its family's bounded source hooks and refuses
 * operations they do not own. */
export function mutatePreservingSource(d: ParsedDiagram, op: unknown): Result<SourceMutationResult, MutationError> {
  const result = editPreservedSource(d, op)
  logToolInvocation('mutate', result.ok)
  return result
}

function admittedOp(kind: OpFamily, op: unknown): Result<AnyMutationOp, MutationError> {
  const admitted = admitOpRecord(op)
  const invalid = validateOp(kind, admitted.ok ? admitted.value : op)
  return invalid ? err(invalid) : ok((admitted.ok ? admitted.value : op) as AnyMutationOp)
}

function editPreservedSource(d: ParsedDiagram, op: unknown): Result<SourceMutationResult, MutationError> {
  if (d.body.kind !== 'opaque' && d.body.kind !== 'preserved' && d.body.kind !== 'extension' && hasOpSchema(d.kind)) {
    const checked = admittedOp(d.kind, op)
    if (!checked.ok) return checked
    const edited = applyOneMutation(d, checked.value)
    return edited.ok ? ok(preserveStructuredEdit(d, edited.value)) : edited
  }
  if (d.body.kind !== 'opaque' || d.body.family !== d.kind) return err({ code: 'INVALID_OP', message: 'Source-preserving mutation requires a structured or opaque body of its parsed family' })
  const plugin = getFamily(d.kind)
  if (!plugin?.mutateSource || !hasOpSchema(d.kind)) return err({ code: 'UNSUPPORTED_FAMILY', message: `${d.kind} has no source-preserving mutation contract` })
  const checked = admittedOp(d.kind, op)
  if (!checked.ok) return checked
  // The opaque body and captured wrapper own the original bytes. The ordinary
  // serializer may normalize the final newline, so it is not this authority.
  const source = (d.meta.wrapperSource ?? '') + d.body.source
  try {
    const next = plugin.mutateSource(source, checked.value)
    if (!next.ok) return next
    const editedSource = applySourceEdits(source, next.value)
    if (editedSource === source) return ok({ source, diagram: d })
    const parsed = parseMermaid(editedSource)
    if (!parsed.ok) return err({ code: 'INVALID_OP', message: `Source-preserving mutation could not be reparsed: ${parsed.error.map(error => error.message).join('; ')}` })
    if (parsed.value.kind !== d.kind || parsed.value.body.kind !== 'opaque') return err({ code: 'INVALID_OP', message: 'Source-preserving mutation changed family or source-preserved representation' })
    // Source coordinates are rebuilt after a removal or rename. Comment text
    // and order remain meaning; their old physical row numbers do not.
    const metadata = (value: ParsedDiagram['meta']) => ({ ...value, comments: value.comments.map(comment => comment.text) })
    if (!sameSourceMeaning(metadata(d.meta), metadata(parsed.value.meta))) return err({ code: 'INVALID_OP', message: 'Source-preserving mutation changed configuration, accessibility or comment metadata' })
    return ok({ source: editedSource, diagram: parsed.value })
  } catch (error) {
    return err({ code: 'INVALID_OP', message: error instanceof Error ? error.message : String(error) })
  }
}

/** Batches up to this many ops are projected op by op when the whole batch
 * does not project; each step re-traces every authored line, so a larger
 * batch falls back to canonical output instead. */
const OP_BY_OP_PROJECTION_LIMIT = 16

/**
 * Write `after`, the committed canonical result of typed edits to `before`,
 * as a local change to the source `before` was parsed from. The whole batch
 * is projected at once; when that does not read back as `after`, a batch of
 * at most OP_BY_OP_PROJECTION_LIMIT ops is projected op by op. A diagram
 * with no authored source, or an edit no local change reproduces, is
 * written canonically with the reason.
 */
export function preserveStructuredEdit(before: ParsedDiagram, after: ParsedDiagram, ops: readonly unknown[] = []): SourceMutationResult {
  const canonical = (reason: string): SourceMutationResult => ({ source: serializeMermaid(after), diagram: after, preservation: { method: 'canonical', reason } })
  const authored = authoredSourceOf(before.source)
  if (authored === undefined) return canonical('the diagram was not parsed from source, so there are no authored lines to keep')
  const read = (source: string) => {
    const parsed = parseMermaid(source)
    return parsed.ok && parsed.value.kind === before.kind && parsed.value.body.kind === before.body.kind ? parsed.value : undefined
  }
  const original = read(authored)
  if (!original) return canonical('the authored source no longer reads as this diagram')
  const whole = projectStructuredEdit(authored, original, after)
  if (whole.ok) return { ...whole.value, preservation: { method: 'local' } }
  if (ops.length > OP_BY_OP_PROJECTION_LIMIT) return canonical(`${whole.error}; batches of more than ${OP_BY_OP_PROJECTION_LIMIT} operations are not projected one by one`)
  if (ops.length > 1) {
    let source = authored, current = original
    for (const op of ops) {
      const checked = hasOpSchema(current.kind) ? admittedOp(current.kind, op) : ok(op as AnyMutationOp)
      const next = checked.ok ? applyOneMutation(current, checked.value) : checked
      const projected = next.ok ? projectStructuredEdit(source, current, next.value) : undefined
      if (!projected?.ok) break
      ;({ source, diagram: current } = projected.value)
    }
    if (current !== original && sameProjectedDiagram(current, after)) return { source, diagram: current, preservation: { method: 'local' } }
  }
  return canonical(whole.error)
}

function checkedMutation(d: ParsedDiagram, op: unknown, deferSerialization: boolean, draft?: BatchDraft): Result<ParsedDiagram, MutationError> {
  if (hasOpSchema(d.kind)) {
    const admitted = admitOpRecord(op)
    const checkedOp = admitted.ok ? admitted.value : op
    const invalid = validateOp(d.kind, checkedOp)
    // A shape rejection short-circuits before `mutate`, so record the failed
    // attempt here — otherwise checked-path errors (e.g. the op-array slip)
    // would go uncounted in the op-error rate.
    if (invalid) {
      logToolInvocation('mutate', false)
      return err(invalid)
    }
    const result = applyOneMutation(d, checkedOp as AnyMutationOp, deferSerialization, draft)
    logToolInvocation('mutate', result.ok)
    return result
  }
  const result = applyOneMutation(d, op as AnyMutationOp, deferSerialization, draft)
  logToolInvocation('mutate', result.ok)
  return result
}

// Flowchart graph mutation + helpers live in flowchart-body.ts; edgeIdOf is
// re-exported here for existing consumers (agent/index.ts, eval harness).
export { edgeIdOf } from './flowchart-body.ts'
