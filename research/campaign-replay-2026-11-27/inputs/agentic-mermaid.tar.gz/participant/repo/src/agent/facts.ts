import { projectZenUMLSequence } from '../zenuml/native-sequence.ts'
import { eventRelations } from '../eventmodeling/parser.ts'
import { stableFamilyFacts } from './stable-family-source-hooks.ts'

// ============================================================================
// Mermaid semantic facts/checks.
//
// Deterministic, single-line read-back for agents and tests. These facts are
// intentionally semantic (nodes, edges, members, tasks, points) rather than a
// source diff or a visual metric: verify.ok can prove a diagram is structurally
// renderable while these facts prove it still says the requested thing.
// ============================================================================

import { classRelationLineStyle, classRelationMarkers } from './class-body.ts'
import { readClassMemberClassifiers } from '../class/parser.ts'
import { arrowheadDirection, directionArrow } from '../shared/relation-direction.ts'
import { extractLabelsGeneric, getFamily } from './families.ts'
import { parseRegisteredMermaid } from './parse.ts'
import { sequenceActivationEvents, sequenceActivationSpans, sequenceFragmentName, sequenceMessageActivation, sequenceMessageArrow, sequenceMessageContexts, sequenceMessageStyle, sequenceTimeline, type SequenceActivationEvent, type SequenceBranchPlace, type SequenceFragmentPlace } from './sequence-body.ts'
import { readSequenceStatements } from '../sequence/parser.ts'
import { sequenceDisplayText, sequencePayloadDisplayText } from '../sequence/text.ts'
import { journeyActorKey } from '../journey/parse-core.ts'
import { displayText } from '../multiline-utils.ts'
import { resolveLabelContent, type LabelContent } from '../shared/display-text.ts'
import type { ArchitectureBody, ClassBody, ErBody, GanttBody, GitGraphBody, JourneyBody, MindmapBody, PieBody, QuadrantBody, SequenceBody, SequenceMessage, SequenceMessageArrow, StateBody, TimelineBody, XyChartBody } from './types.ts'
import { err, ok, type ParsedDiagram, type ParseError, type Result } from './types.ts'

export type MermaidFact = string

export interface CheckMermaidObjectSpec {
  /** Required facts. Aliases: expected / require / required. */
  include?: readonly string[]
  expected?: readonly string[]
  require?: readonly string[]
  required?: readonly string[]
  /** Forbidden facts. Aliases: absent / forbid / forbidden / unexpected. */
  exclude?: readonly string[]
  absent?: readonly string[]
  forbid?: readonly string[]
  forbidden?: readonly string[]
  unexpected?: readonly string[]
  /** When true, every emitted fact must be listed in the required set. */
  exact?: boolean
}

export type CheckMermaidSpec = readonly string[] | CheckMermaidObjectSpec

export interface CheckMermaidResult {
  ok: boolean
  /** Required facts not present in the diagram. */
  missing: string[]
  /** Forbidden facts that were present, or extra facts under exact:true. */
  unexpected: string[]
  /** Full deterministic fact set used for the comparison. */
  facts: string[]
}

/** Facts for a parsed diagram. Output is sorted, de-duplicated, and single-line. */
export function describeMermaidFacts(d: ParsedDiagram): string[] {
  const out: string[] = []
  add(out, `family ${d.kind}`)
  if (d.meta.accessibility.title) add(out, `accessibility title ${clean(d.meta.accessibility.title)}`)
  if (d.meta.accessibility.descr) add(out, `accessibility descr ${clean(d.meta.accessibility.descr)}`)

  switch (d.body.kind) {
    case 'agentflow':
    case 'swimlane':
    case 'flowchart': {
      if (d.body.kind === 'agentflow') {
        for (const [id, value] of d.body.metadata) add(out, `metadata ${clean(id)} ${clean(JSON.stringify(value))}`)
        for (const [id, role] of d.body.roles) add(out, `role ${clean(id)} ${role}`)
        for (const id of d.body.connectors) add(out, `connector ${clean(id)}`)
        for (const id of d.body.globals) add(out, `global ${clean(id)}`)
      }
      const g = d.body.graph
      add(out, `direction ${g.direction}`)
      for (const n of g.nodes.values()) {
        add(out, `node ${clean(n.id)} : ${clean(n.label || n.id)}`)
        add(out, `node ${clean(n.id)} shape ${clean(n.shape)}`)
      }
      const visitGroups = (items: typeof g.subgraphs, parent?: string) => {
        for (const group of items) {
          add(out, `group ${clean(group.id)} : ${clean(group.label || group.id)}`)
          if (parent) add(out, `group ${clean(group.id)} parent ${clean(parent)}`)
          if (group.direction) add(out, `group ${clean(group.id)} direction ${group.direction}`)
          for (const nodeId of group.nodeIds) add(out, `group ${clean(group.id)} contains ${clean(nodeId)}`)
          visitGroups(group.children, group.id)
        }
      }
      visitGroups(g.subgraphs)
      g.edges.forEach((e, i) => {
        const arrow = directionArrow(arrowheadDirection(e.hasArrowStart, e.hasArrowEnd))
        const base = `edge ${clean(e.source)} ${arrow} ${clean(e.target)}`
        add(out, e.label ? `${base} : ${clean(e.label)}` : base)
        add(out, `edge#${i} ${clean(e.source)} ${arrow} ${clean(e.target)}${e.label ? ` : ${clean(e.label)}` : ''}`)
        if (e.style !== 'solid') add(out, `${base} style ${e.style}`)
      })
      break
    }
    case 'usecase':
      if (d.body.title !== undefined) add(out, `title ${clean(d.body.title)}`)
      add(out, `direction ${d.body.direction}`)
      for (const node of d.body.nodes) add(out, `${node.kind} ${clean(node.id)} ${clean(JSON.stringify(node))}`)
      for (const boundary of d.body.boundaries) add(out, `boundary ${clean(boundary.id)} ${clean(JSON.stringify(boundary))}`)
      for (const relation of d.body.relationships) add(out, `relation ${clean(JSON.stringify(relation))}`)
      for (const node of d.body.jsonNodes) add(out, `json ${clean(JSON.stringify(node))}`)
      for (const note of d.body.notes) add(out, `note ${clean(JSON.stringify(note))}`)
      for (const style of d.body.classDefs) add(out, `class ${clean(JSON.stringify(style))}`)
      break
    case 'wardley':
      if (d.body.title !== undefined) add(out, `title ${clean(d.body.title)}`)
      for (const node of d.body.nodes) add(out, `component ${clean(node.id)} visibility ${node.y} evolution ${node.x} ${clean(JSON.stringify(node))}`)
      d.body.links.forEach((link,index) => add(out, `dependency#${index} ${clean(JSON.stringify(link))}`))
      d.body.trends.forEach(trend => add(out, `evolution ${clean(JSON.stringify(trend))}`))
      d.body.pipelines.forEach(pipeline => add(out, `pipeline ${clean(JSON.stringify(pipeline))}`))
      for (const [kind, records] of [['note',d.body.notes],['annotation',d.body.annotations],['accelerator',d.body.accelerators],['deaccelerator',d.body.deaccelerators]] as const) records.forEach((value,index) => add(out, `${kind}#${index} ${clean(JSON.stringify(value))}`))
      add(out, `axes ${clean(JSON.stringify(d.body.axes))}`)
      if (d.body.size) add(out, `size ${clean(JSON.stringify(d.body.size))}`)
      if (d.body.annotationsBox) add(out, `annotationsBox ${clean(JSON.stringify(d.body.annotationsBox))}`)
      break
    case 'venn':
      if (d.body.title !== undefined) add(out, `title ${clean(d.body.title)}`)
      for (const subset of d.body.subsets) add(out, `region ${clean(JSON.stringify(subset.sets))} size ${subset.size}${subset.label === undefined ? '' : ` : ${clean(subset.label)}`}`)
      for (const node of d.body.textNodes) add(out, `text ${clean(node.id)} in ${clean(JSON.stringify(node.sets))} : ${clean(node.label ?? node.id)}`)
      for (const style of d.body.styles) add(out, `style ${clean(JSON.stringify(style))}`)
      break
    case 'cynefin':
      if (d.body.title !== undefined) add(out, `title ${clean(d.body.title)}`)
      d.body.domains.forEach(domain => domain.items.forEach((item,index) => add(out, `domain ${domain.name} item#${index} : ${clean(item.label)}`)))
      d.body.transitions.forEach((transition,index) => add(out, `transition#${index} ${transition.from} -> ${transition.to}${transition.label === undefined ? '' : ` : ${clean(transition.label)}`}`))
      break
    case 'railroad':
      if (d.body.title !== undefined) add(out, `title ${clean(d.body.title)}`)
      add(out, `notation ${d.body.notation}`)
      d.body.rules.forEach((rule, index) => add(out, `rule#${index} ${clean(rule.name)} ${clean(JSON.stringify(rule.definition))}`))
      break
    case 'treeview':
      if (d.body.title !== undefined) add(out, `title ${clean(d.body.title)}`)
      d.body.nodes.forEach((node, index) => {
        add(out, `node#${index} ${clean(node.id)} ${node.nodeType} : ${clean(node.label)}`)
        if (node.parentId) add(out, `node ${clean(node.id)} parent ${clean(node.parentId)}`)
        if (node.description !== undefined) add(out, `node ${clean(node.id)} description ${clean(node.description)}`)
        if (node.icon !== undefined) add(out, `node ${clean(node.id)} icon ${clean(node.icon)}`)
        if (node.className !== undefined) add(out, `node ${clean(node.id)} class ${clean(node.className)}`)
      })
      break
    case 'state':
      factsState(out, d.body)
      break
    case 'sequence':
      factsSequence(out, d.body)
      break
    case 'timeline':
      factsTimeline(out, d.body)
      break
    case 'class':
      factsClass(out, d.body)
      break
    case 'er':
      factsEr(out, d.body)
      break
    case 'journey':
      factsJourney(out, d.body)
      break
    case 'architecture':
      factsArchitecture(out, d.body)
      break
    case 'xychart':
      factsXyChart(out, d.body)
      break
    case 'pie':
      factsPie(out, d.body)
      break
    case 'quadrant':
      factsQuadrant(out, d.body)
      break
    case 'gantt':
      factsGantt(out, d.body)
      break
    case 'mindmap':
      factsMindmap(out, d.body)
      break
    case 'gitgraph':
      factsGitGraph(out, d.body)
      break
    case 'radar': {
      if (d.body.title !== undefined) add(out, `title ${clean(d.body.title)}`)
      d.body.axes.forEach((a, i) => add(out, `axis#${i} ${clean(a.id)} : ${clean(a.label)}`))
      d.body.curves.forEach((c, i) => add(out, `curve#${i} ${clean(c.id)} : ${clean(c.label)} {${c.values.join(',')}}`))
      add(out, `scale ${d.body.min}..${d.body.max ?? 'auto'} ticks ${d.body.ticks} graticule ${d.body.graticule}`)
      break
    }
    case 'c4': {
      const body = d.body
      // Alias whitespace is identity, even when display whitespace is folded.
      const identity = (value: string): string => (/^[A-Za-z_][A-Za-z_0-9-]*$/.test(value) ? value : JSON.stringify(value))
      add(out, `variant ${body.variant}`)
      if (body.title !== undefined) add(out, `title ${clean(body.title)}`)
      for (const boundary of body.boundaries) {
        add(out, `boundary ${identity(boundary.id)} ${boundary.kind} : ${clean(boundary.label)}`)
        if (boundary.parentId !== undefined) add(out, `boundary ${identity(boundary.id)} parent ${identity(boundary.parentId)}`)
        if (boundary.type !== undefined) add(out, `boundary ${identity(boundary.id)} type ${clean(boundary.type)}`)
        if (boundary.description !== undefined) add(out, `boundary ${identity(boundary.id)} description ${clean(boundary.description)}`)
      }
      for (const element of body.elements) {
        add(out, `element ${identity(element.id)} ${element.kind} ${element.external ? 'external' : 'internal'} ${element.shape} : ${clean(element.label)}`)
        if (element.parentId !== undefined) add(out, `element ${identity(element.id)} parent ${identity(element.parentId)}`)
        if (element.technology !== undefined) add(out, `element ${identity(element.id)} technology ${clean(element.technology)}`)
        if (element.description !== undefined) add(out, `element ${identity(element.id)} description ${clean(element.description)}`)
      }
      for (const relation of body.relationships) {
        add(out, `interaction#${relation.order} ${identity(relation.id)} ${identity(relation.source)} ${relation.bidirectional ? '<->' : '->'} ${identity(relation.target)} : ${clean(relation.label)}`)
        add(out, `interaction#${relation.order} macro ${relation.macro} authored ${identity(relation.from)} -> ${identity(relation.to)}`)
        if (relation.index !== undefined) add(out, `interaction#${relation.order} index ${clean(relation.index)}`)
        if (relation.technology !== undefined) add(out, `interaction#${relation.order} technology ${clean(relation.technology)}`)
        if (relation.description !== undefined) add(out, `interaction#${relation.order} description ${clean(relation.description)}`)
        if (relation.direction !== undefined) add(out, `interaction#${relation.order} direction ${relation.direction}`)
      }
      for (const record of [...body.elements, ...body.boundaries, ...body.relationships]) {
        if (record.tags.length) add(out, `c4 ${identity(record.id)} tags ${record.tags.map(identity).join(',')}`)
        if (record.link !== undefined) add(out, `c4 ${identity(record.id)} link ${JSON.stringify(record.link)}`)
        if (record.effectiveLink !== undefined) add(out, `c4 ${identity(record.id)} effective link ${JSON.stringify(record.effectiveLink)}`)
        if (record.sprite !== undefined) add(out, `c4 ${identity(record.id)} sprite ${JSON.stringify(record.sprite)}`)
        for (const key of Object.keys(record.style).sort()) add(out, `c4 ${identity(record.id)} style ${key} ${JSON.stringify(record.style[key])}`)
      }
      break
    }
    case 'sankey': {
      d.body.links.forEach((link, i) => add(out, `link#${i} ${clean(link.source)} -> ${clean(link.target)} : ${link.value}`))
      break
    }
    case 'zenuml': {
      if (d.body.title !== undefined) add(out, `title ${JSON.stringify(d.body.title)}`)
      const model = projectZenUMLSequence(d.body, {
        message: ({ message, kind, callAncestors, scopes }) => {
          add(out, `message#${clean(message.id!)} kind ${kind}`)
          if (callAncestors.length) add(out, `message#${clean(message.id!)} call-parent ${clean(callAncestors.at(-1)!)}`)
          for (const scope of scopes) add(out, `message#${clean(message.id!)} fragment#${clean(scope.fragmentId)} branch#${scope.branchIndex}`)
        },
        note: ({ note, callAncestors, scopes }) => {
          add(out, `note#${clean(note.id!)} ${note.position} ${note.actorIds.map(id => JSON.stringify(id)).join(',')} after-index ${note.afterIndex} : ${clean(displayText(resolveLabelContent(note.text, note.textContent)))}`)
          if (callAncestors.length) add(out, `note#${clean(note.id!)} call-parent ${clean(callAncestors.at(-1)!)}`)
          for (const scope of scopes) add(out, `note#${clean(note.id!)} fragment#${clean(scope.fragmentId)} branch#${scope.branchIndex}`)
        },
        fragment: ({ fragment, branches, callAncestors, scopes }) => {
          add(out, `fragment#${clean(fragment.id)} kind ${fragment.type}`)
          if (callAncestors.length) add(out, `fragment#${clean(fragment.id)} call-parent ${clean(callAncestors.at(-1)!)}`)
          const parent = scopes.at(-1)
          if (parent) add(out, `fragment#${clean(fragment.id)} parent ${clean(parent.fragmentId)} branch#${parent.branchIndex}`)
          branches.forEach((branch, index) => {
            const condition = index === 0 ? fragment.condition : branch.condition
            add(out, `fragment#${clean(fragment.id)} branch#${index} ${branch.kind}${condition === undefined ? '' : ` : ${clean(condition)}`}`)
          })
        },
      })
      for (const actor of model.actors) if (!actor.external) {
        add(out, `participant ${clean(actor.id)} : ${clean(actor.label)}`)
        add(out, `participant ${clean(actor.id)} type ${actor.type}`)
      }
      for (const actor of model.actors) if (actor.external) add(out, `external-endpoint ${clean(actor.id)}`)
      for (const message of model.messages) {
        add(out, `message ${clean(message.from)} -> ${clean(message.to)} : ${clean(message.label)}`)
        add(out, `message#${clean(message.id!)} ${clean(message.from)} -> ${clean(message.to)} : ${clean(message.label)}${message.lineStyle === 'dashed' ? ' reply' : ''}`)
        if (message.parentId) add(out, `message#${clean(message.id!)} parent ${clean(message.parentId)}`)
      }
      for (const block of model.blocks) add(out, `fragment ${clean(block.id!)} ${block.type} : ${clean(block.label)}`)
      break
    }
    case 'eventmodeling':
      if (d.body.title !== undefined) add(out, `title ${JSON.stringify(d.body.title)}`)
      d.body.entities.forEach(entity => add(out, `entity ${JSON.stringify(entity)}`))
      d.body.frames.forEach((frame, index) => add(out, `frame#${index} ${JSON.stringify(frame)}`))
      eventRelations(d.body).forEach(edge => add(out, `relation ${edge.from} -> ${edge.to} ${edge.explicit ? 'explicit' : 'inferred'}`))
      Object.entries(d.body.data).forEach(([id, data]) => add(out, `data ${id} ${JSON.stringify(data)}`))
      d.body.notes.forEach(note => add(out, `note ${JSON.stringify(note)}`))
      d.body.specifications.forEach(spec => add(out, `specification ${JSON.stringify(spec)}`))
      break
    case 'packet':
    case 'kanban':
    case 'requirement':
    case 'block':
    case 'treemap':
    case 'ishikawa':
      out.push(...stableFamilyFacts(d.body))
      break
    case 'opaque': {
      add(out, `opaque ${d.body.family}`)
      const plugin = getFamily(d.kind)
      const labels = (plugin?.extractLabels ?? extractLabelsGeneric)(d.body.source)
      labels.forEach((label, i) => add(out, `label#${i} ${clean(label.target || '')} : ${clean(label.text)}`))
      break
    }
    case 'extension': {
      const plugin = getFamily(d.kind)
      const labels = (plugin?.extractLabels ?? extractLabelsGeneric)(d.body.source)
      labels.forEach((label, i) => add(out, `label#${i} ${clean(label.target || '')} : ${clean(label.text)}`))
      break
    }
    case 'preserved':
      add(out, `preserved ${d.body.preservation.upstreamFamilyId ?? d.body.preservation.header}`)
      break
    default: {
      const _never: never = d.body
      void _never
    }
  }
  return Array.from(new Set(out)).sort()
}

/** Parse then emit facts. Parse failures are explicit Result errors. */
export function describeMermaidFactsSource(source: string): Result<string[], ParseError[]> {
  const parsed = parseRegisteredMermaid(source)
  return parsed.ok ? ok(describeMermaidFacts(parsed.value)) : err(parsed.error)
}

/** Check required/forbidden semantic facts against a parsed diagram. */
export function checkMermaid(d: ParsedDiagram, spec: CheckMermaidSpec): CheckMermaidResult {
  const facts = describeMermaidFacts(d)
  const have = new Set(facts)
  const required = specRequired(spec)
  const forbidden = specForbidden(spec)
  const missing = required.filter(f => !have.has(f))
  let unexpected = forbidden.filter(f => have.has(f))
  if (isObjectSpec(spec) && spec.exact) {
    const allowed = new Set(required)
    unexpected = [...unexpected, ...facts.filter(f => !allowed.has(f))]
  }
  unexpected = Array.from(new Set(unexpected)).sort()
  return { ok: missing.length === 0 && unexpected.length === 0, missing, unexpected, facts }
}

export function checkMermaidSource(source: string, spec: CheckMermaidSpec): Result<CheckMermaidResult, ParseError[]> {
  const parsed = parseRegisteredMermaid(source)
  return parsed.ok ? ok(checkMermaid(parsed.value, spec)) : err(parsed.error)
}

function factsState(out: string[], body: StateBody): void {
  if (body.direction) add(out, `direction ${body.direction}`)
  const visit = (states: StateBody['states'], transitions: StateBody['transitions'], path?: string) => {
    for (const s of states) {
      add(out, `state ${clean(s.id)}`)
      if (s.label) add(out, `state ${clean(s.id)} : ${clean(s.label)}`)
      if (s.stereotype) add(out, `state ${clean(s.id)} stereotype ${clean(s.stereotype)}`)
      if (path) add(out, `state ${clean(s.id)} parent ${clean(path)}`)
      if (s.states !== undefined || s.regions !== undefined) {
        add(out, `composite ${clean(s.id)}`)
        if (s.direction) add(out, `state ${clean(s.id)} direction ${s.direction}`)
        if (s.regions)
          s.regions.forEach((region, index) => {
            add(out, `state ${clean(s.id)} region ${index}`)
            visit(region.states, region.transitions, s.id)
          })
        else visit(s.states ?? [], s.transitions ?? [], s.id)
      }
      if (s.className) add(out, `state ${clean(s.id)} class ${clean(s.className)}`)
      if (s.style) add(out, `state ${clean(s.id)} styled`)
    }
    for (const t of transitions) add(out, edgeFact(t.from, t.to, t.label))
  }
  visit(body.states, body.transitions)
  for (const [index, note] of (body.notes ?? []).entries()) {
    add(out, `note#${index} ${note.side} of ${clean(note.target)} : ${clean(note.text)}`)
  }
  for (const note of body.floatingNotes ?? []) {
    add(out, `floating note ${clean(note.id)}${note.scope ? ` in ${clean(note.scope.parent)}${note.scope.region !== undefined ? ` region ${note.scope.region}` : ''}` : ''} : ${clean(note.text)}`)
  }
}

function factsSequence(out: string[], body: SequenceBody): void {
  // Text reads as drawn: the body keeps authored quotes and markup.
  const shown = (value: string, content?: LabelContent): string => clean(sequenceDisplayText(value, content))
  body.participants.forEach((p, i) => {
    const label = p.label ? shown(p.label, p.labelContent) : clean(p.id)
    add(out, `${p.kind} ${clean(p.id)} : ${label}`)
    add(out, `participant#${i} ${clean(p.id)} : ${label}`)
    if (p.wrap !== undefined) add(out, `participant#${i} wrap ${p.wrap}`)
  })
  sequenceMessageContexts(body).forEach((context, i) => {
    const m = context.message
    const text = shown(m.text, m.textContent)
    add(out, `message ${clean(m.from)} -> ${clean(m.to)} : ${text}`)
    const place = context.scope === 'top-level' ? undefined : { fragmentPath: context.fragmentPath ?? [], fragmentIndex: context.fragmentIndex, branchIndex: context.branchIndex }
    add(out, `message#${i} ${place ? branchName(place) : 'top-level'} ${clean(m.from)} -> ${clean(m.to)} : ${text}`)
    // message# counts every message in drawing order; the ops address a
    // top-level message by its top-level index and a fragment message by its
    // index in its branch. State the fields to pass.
    add(out, `message#${i} op ${place ? `${branchAddress(place)} ` : ''}index ${context.index}`)
    addSequenceArrow(out, `message#${i}`, m)
    if (m.wrap !== undefined) add(out, `message#${i} wrap ${m.wrap}`)
  })
  body.statements.forEach((statement, segment) => {
    if (statement.kind !== 'opaque-block') return
    readSequenceStatements(statement.lines).statements.forEach((entry, index) => {
      const syntax = entry.syntax
      if (syntax?.kind === 'message') {
        const m = syntax.message
        const text = clean(sequencePayloadDisplayText(m.label))
        add(out, `message ${clean(m.from)} -> ${clean(m.to)} : ${text}`)
        // Preserved statements are observable without becoming typed edit
        // indexes. Keep the existing message# indexes stable for callers.
        add(out, `preserved-message#${segment}.${index} ${clean(m.from)} -> ${clean(m.to)} : ${text}`)
        addSequenceArrow(out, `preserved-message#${segment}.${index}`, { style: sequenceMessageStyle(m.arrow), arrow: m.arrow as SequenceMessageArrow })
      } else if (syntax?.kind === 'note') {
        const { position, actorIds, text } = syntax.note
        const note = `${position === 'over' ? 'over' : `${position} of`} ${actorIds.map(clean).join(',')} : ${clean(sequencePayloadDisplayText(text))}`
        add(out, `note ${note}`)
        add(out, `preserved-note#${segment}.${index} ${note}`)
      } else if (syntax?.kind === 'title') add(out, `title ${clean(sequencePayloadDisplayText(syntax.text))}`)
    })
  })
  const timeline = sequenceTimeline(body)
  for (const entry of timeline) {
    if (entry.kind !== 'fragment') continue
    const { fragment } = entry.place
    const name = `fragment#${sequenceFragmentName(entry.place)}`
    add(out, `${name} ${fragment.fragmentKind}`)
    add(out, `${name} op ${fragmentAddress(entry.place)}`)
    if (fragment.wrap !== undefined) add(out, `${name} wrap ${fragment.wrap}`)
    fragment.branches.forEach((branch, branchIndex) => {
      const label = branch.label !== undefined ? shown(branch.label, branch.labelContent)
        : branchIndex === 0 && fragment.label !== undefined ? shown(fragment.label, fragment.labelContent) : ''
      add(out, `${name} branch#${branchIndex}${label ? ` : ${label}` : ''}`)
      if (branch.wrap !== undefined) add(out, `${name} branch#${branchIndex} wrap ${branch.wrap}`)
      // Preserved branch lines hold no message or note; a title still reads
      // back, as from a top-level segment.
      for (const { statement } of branch.statements ?? []) {
        if (statement.kind !== 'opaque-block') continue
        for (const { syntax } of readSequenceStatements(statement.lines).statements) if (syntax?.kind === 'title') add(out, `title ${clean(sequencePayloadDisplayText(syntax.text))}`)
      }
    })
  }
  // Lifecycle directives, notes and activate/deactivate lines, placed by the
  // message# that follows them. Activation lines kept in preserved source
  // have no address.
  let messageIndex = 0
  let noteIndex = 0
  let lineIndex = 0
  const total = sequenceMessageContexts(body).length
  // A message's `+`/`-` starts or ends an activation at that message.
  const activations: Array<SequenceActivationEvent<string>> = []
  for (const entry of timeline) {
    if (entry.kind === 'message') {
      for (const event of sequenceMessageActivation(entry.message)) activations.push({ ...event, at: `message#${messageIndex}` })
      messageIndex++
    } else if (entry.kind === 'preserved') {
      const line = `${entry.place ? `${branchName(entry.place)} ` : ''}${messageIndex < total ? `before message#${messageIndex}` : 'at-end'}`
      readSequenceStatements(entry.lines).statements.forEach(({ syntax }, index) => {
        for (const event of sequenceActivationEvents(syntax)) activations.push({ ...event, at: syntax?.kind === 'message' ? `preserved-message#${entry.segment}.${index}` : line })
      })
    } else if (entry.kind === 'activation') {
      // Activation lines are numbered in drawing order, as notes are, and
      // state the fields remove_activation takes.
      const { statement: { actorId, activate }, place, index } = entry
      activations.push({ id: actorId, activate, at: `${place ? `${branchName(place)} ` : ''}${messageIndex < total ? `before message#${messageIndex}` : 'at-end'}` })
      add(out, `activation-line#${lineIndex} ${activate ? 'activate' : 'deactivate'} ${clean(actorId)}`)
      add(out, `activation-line#${lineIndex} op ${place ? `${branchAddress(place)} ` : ''}index ${index}`)
      if (messageIndex < total) add(out, `activation-line#${lineIndex} before message#${messageIndex}`)
      lineIndex++
    } else if (entry.kind === 'lifecycle') {
      // A directive in a fragment branch also names the branch it is written in.
      const { statement, place } = entry
      const id = statement.kind === 'create' ? statement.id : statement.actorId
      const at = `${place ? ` ${branchName(place)}` : ''}${messageIndex < total ? ` before message#${messageIndex}` : ''}`
      add(out, statement.kind === 'create'
        ? `create ${statement.type ?? statement.declaration} ${clean(id)} : ${shown(statement.label, statement.labelContent)}${at}`
        : `destroy ${clean(id)}${at}`)
    } else if (entry.kind === 'note') {
      // Notes are numbered in drawing order, as messages are, and state the
      // fields the note ops take.
      const { note: statement, place, index } = entry
      const { position, actorIds } = statement
      const note = `${position === 'over' ? 'over' : `${position} of`} ${actorIds.map(clean).join(',')} : ${shown(statement.text, statement.textContent)}`
      add(out, `note ${note}`)
      add(out, `note#${noteIndex} ${note}`)
      add(out, `note#${noteIndex} op ${place ? `${branchAddress(place)} ` : ''}index ${index}`)
      if (messageIndex < total) add(out, `note#${noteIndex} before message#${messageIndex}`)
      if (statement.wrap !== undefined) add(out, `note#${noteIndex} wrap ${statement.wrap}`)
      noteIndex++
    }
  }
  // Each activation span as Mermaid pairs them: a deactivation ends its
  // participant's latest open activation.
  sequenceActivationSpans(activations).spans.forEach(({ id, start, end }, index) => {
    add(out, `activation#${index} ${clean(id)} start ${start} ${end === undefined ? 'unclosed' : `end ${end}`}`)
  })
}

/** `fragment#F branch#B`, a nested fragment named by its path. */
function branchName(place: Pick<SequenceBranchPlace, 'fragmentPath' | 'fragmentIndex' | 'branchIndex'>): string {
  return `fragment#${sequenceFragmentName(place)} branch#${place.branchIndex}`
}

/** The fields the fragment ops take for a fragment: `fragmentPath` (as
 * JSON, for a nested fragment) and its `fragmentIndex`. */
function fragmentAddress({ fragmentPath, fragmentIndex }: Pick<SequenceFragmentPlace, 'fragmentPath' | 'fragmentIndex'>): string {
  return `${fragmentPath.length ? `fragmentPath ${JSON.stringify(fragmentPath.map(({ fragmentIndex, branchIndex }) => ({ fragmentIndex, branchIndex })))} ` : ''}fragmentIndex ${fragmentIndex}`
}

function branchAddress(place: Pick<SequenceBranchPlace, 'fragmentPath' | 'fragmentIndex' | 'branchIndex'>): string {
  return `${fragmentAddress(place)} branchIndex ${place.branchIndex}`
}

/** A message's style when not the default `sync`, and its operator when the
 * style alone does not name it (a half-arrow). */
function addSequenceArrow(out: string[], subject: string, m: Pick<SequenceMessage, 'style' | 'arrow'>): void {
  if (m.style !== 'sync') add(out, `${subject} style ${m.style}`)
  const arrow = sequenceMessageArrow(m)
  if (arrow !== sequenceMessageArrow({ style: m.style })) add(out, `${subject} arrow ${arrow}`)
}

function factsTimeline(out: string[], body: TimelineBody): void {
  if (body.title) add(out, `title ${clean(body.title)}`)
  body.sections.forEach((s, si) => {
    if (s.label) add(out, `section ${clean(s.label)}`)
    s.periods.forEach((p, pi) => {
      add(out, `period ${clean(p.label)}`)
      if (s.label) add(out, `period ${clean(p.label)} section ${clean(s.label)}`)
      p.events.forEach((e, ei) => {
        add(out, `event ${clean(p.label)} : ${clean(e.text)}`)
        add(out, `event#${si}.${pi}.${ei} ${clean(p.label)} : ${clean(e.text)}`)
      })
    })
  })
}

function factsClass(out: string[], body: ClassBody): void {
  if (body.title) add(out, `title ${clean(body.title)}`)
  // Namespace declarations + membership (repo #118): both directions are
  // queryable — "what namespaces exist" and "which namespace holds class X".
  for (const ns of body.namespaces ?? []) {
    add(out, `namespace ${clean(ns.name)}${ns.label ? ` : ${clean(ns.label)}` : ''}`)
    // A dotted path names its ancestors too (`namespace A.B` nests B in A),
    // whether they were declared as their own blocks or not.
    const segments = ns.name.split('.')
    for (let depth = 1; depth < segments.length; depth++) add(out, `namespace ${clean(segments.slice(0, depth).join('.'))}`)
  }
  for (const c of body.classes) {
    if (c.isInterface) {
      add(out, `interface ${clean(c.id)} : ${clean(c.label ?? c.id)}`)
      continue
    }
    add(out, `class ${clean(c.id)}`)
    if (c.generic) add(out, `class ${clean(c.id)} generic ${clean(c.generic)}`)
    if (c.label) add(out, `class ${clean(c.id)} : ${clean(c.label)}`)
    if (c.namespace) add(out, `class ${clean(c.id)} in namespace ${clean(c.namespace)}`)
    for (const member of c.members) {
      // A `$`/`*` classifier is styling, not member text: it reads back as
      // its own fact, as the renderers draw it as underline/italic.
      const { text, isStatic, isAbstract } = readClassMemberClassifiers(member)
      add(out, `member ${clean(c.id)} ${clean(text)}`)
      if (isAbstract) add(out, `member ${clean(c.id)} ${clean(text)} abstract`)
      if (isStatic) add(out, `member ${clean(c.id)} ${clean(text)} static`)
    }
  }
  body.relations.forEach((r, i) => {
    const cards = `${r.fromCardinality ? ` ${clean(r.fromCardinality)}` : ''}${r.toCardinality ? ` ${clean(r.toCardinality)}` : ''}`
    add(out, `relation ${clean(r.from)} ${r.kind} ${clean(r.to)}${r.label ? ` : ${clean(r.label)}` : ''}`)
    add(out, `relation#${i} ${clean(r.from)} ${r.kind} ${clean(r.to)}${cards}${r.label ? ` : ${clean(r.label)}` : ''}`)
    const markers = classRelationMarkers(r)
    add(out, `relation#${i} ${clean(r.from)} ${r.kind} ${clean(r.to)} marker ${markers.at}`)
    add(out, `relation#${i} ${clean(r.from)} ${r.kind} ${clean(r.to)} line ${classRelationLineStyle(r)}`)
    if (markers.at === 'both') {
      add(out, `relation#${i} from marker ${markers.from}`)
      add(out, `relation#${i} to marker ${markers.to}`)
    }
  })
  body.notes.forEach((n, i) => add(out, `note#${i}${n.for ? ` ${clean(n.for)}` : ''} : ${clean(n.text)}`))
}

function factsEr(out: string[], body: ErBody): void {
  if (body.direction) add(out, `direction ${body.direction}`)
  for (const group of body.groups ?? []) add(out, `er group ${clean(group.id)} label ${clean(group.label)}${group.parentId ? ` parent ${clean(group.parentId)}` : ''}${group.direction ? ` direction ${group.direction}` : ''}`)
  for (const e of body.entities) {
    add(out, `entity ${clean(e.id)}${e.label ? ` label ${clean(e.label)}` : ''}${e.groupId ? ` group ${clean(e.groupId)}` : ''}`)
    if (e.className) add(out, `entity ${clean(e.id)} class ${clean(e.className)}`)
    if (e.style) add(out, `entity ${clean(e.id)} styled`)
    for (const attr of e.attributes) add(out, `attribute ${clean(e.id)} ${clean(attr.text)}`)
  }
  body.relations.forEach((r, i) => {
    const line = `relation ${clean(r.from)} ${r.leftCard} ${r.dashed ? '..' : '--'} ${r.rightCard} ${clean(r.to)}${r.label ? ` : ${clean(r.label)}` : ''}`
    add(out, line)
    add(out, `relation#${i} ${line.slice('relation '.length)}`)
  })
}

function factsJourney(out: string[], body: JourneyBody): void {
  const text = (value: string, content?: LabelContent): string => clean(displayText(resolveLabelContent(value, content)))
  if (body.title) add(out, `title ${text(body.title, body.titleContent)}`)
  body.sections.forEach((s, si) => {
    if (s.label) add(out, `section ${text(s.label, s.labelContent)}`)
    s.tasks.forEach((t, ti) => {
      const actors = t.actors.length ? ` actors ${t.actors.map((actor, index) => text(actor, t.actorContents?.[index])).join(', ')}` : ''
      add(out, `journey task ${text(t.text, t.textContent)} score ${String(t.score)}${actors}`)
      add(out, `journey task#${si}.${ti} ${text(t.text, t.textContent)} score ${String(t.score)}${actors}`)
      if (s.label) add(out, `journey task ${text(t.text, t.textContent)} section ${text(s.label, s.labelContent)}`)
    })
  })

  // Aggregates (parity spec §Describe, Facts, and Verify): score statistics
  // and participation counts make pain-point queries one checkMermaid away
  // instead of a re-parse-and-compute exercise.
  const tasks = body.sections.flatMap(s => s.tasks)
  add(out, `journey sections ${body.sections.length}`)
  add(out, `journey tasks ${tasks.length}`)
  const participation = new Map<string, { actor: string; count: number }>()
  for (const t of tasks) for (const [index, actor] of t.actors.entries()) {
    const key = journeyActorKey(actor, t.actorContents?.[index])
    participation.set(key, { actor: text(actor, t.actorContents?.[index]), count: (participation.get(key)?.count ?? 0) + 1 })
  }
  add(out, `journey actors ${participation.size}`)
  if (tasks.length > 0) {
    const scores = tasks.map(t => t.score)
    const min = Math.min(...scores)
    const max = Math.max(...scores)
    const average = Math.round((scores.reduce((sum, score) => sum + score, 0) / scores.length) * 100) / 100
    add(out, `journey score range ${min}..${max}`)
    add(out, `journey average score ${num(average)}`)
    for (const t of tasks) {
      if (t.score === min) add(out, `journey lowest task ${text(t.text, t.textContent)} score ${String(t.score)}`)
      if (t.score === max) add(out, `journey highest task ${text(t.text, t.textContent)} score ${String(t.score)}`)
    }
  }
  for (const { actor, count } of participation.values()) add(out, `journey actor ${actor} tasks ${count}`)
}

function factsArchitecture(out: string[], body: ArchitectureBody): void {
  if (body.title) add(out, `title ${clean(body.title)}`)
  if (body.accessibilityTitle) add(out, `accessibility title ${clean(body.accessibilityTitle)}`)
  if (body.accessibilityDescription) add(out, `accessibility description ${clean(body.accessibilityDescription)}`)
  for (const g of body.groups) {
    add(out, `group ${clean(g.id)} : ${clean(g.label || g.id)}`)
    if (g.icon) add(out, `group ${clean(g.id)} icon ${clean(g.icon)}`)
    if (g.parentId) add(out, `group ${clean(g.id)} parent ${clean(g.parentId)}`)
  }
  for (const s of body.services) {
    add(out, `service ${clean(s.id)} : ${clean(s.label || s.id)}`)
    if (s.icon) add(out, `service ${clean(s.id)} icon ${clean(s.icon)}`)
    if (s.iconText !== undefined) add(out, `service ${clean(s.id)} icon text ${clean(s.iconText)}`)
    if (s.parentId) add(out, `service ${clean(s.id)} parent ${clean(s.parentId)}`)
  }
  for (const j of body.junctions) {
    add(out, `junction ${clean(j.id)}`)
    if (j.parentId) add(out, `junction ${clean(j.id)} parent ${clean(j.parentId)}`)
  }
  body.edges.forEach((e, i) => {
    const source = `${clean(e.source.id)}${e.source.boundary === 'group' ? '{group}' : ''}:${e.source.side}`
    const target = `${clean(e.target.id)}${e.target.boundary === 'group' ? '{group}' : ''}:${e.target.side}`
    const arrow = directionArrow(arrowheadDirection(e.hasArrowStart, e.hasArrowEnd))
    const base = `edge ${source} ${arrow} ${target}`
    add(out, e.label ? `${base} : ${clean(e.label)}` : base)
    add(out, `edge#${i} ${source} ${arrow} ${target}${e.label ? ` : ${clean(e.label)}` : ''}`)
  })
}

function factsXyChart(out: string[], body: XyChartBody): void {
  if (body.title) add(out, `title ${clean(dequote(body.title))}`)
  if (body.horizontal) add(out, 'orientation horizontal')
  axisFacts(out, 'x-axis', body.xAxis)
  axisFacts(out, 'y-axis', body.yAxis)
  body.series.forEach((s, i) => {
    const name = s.name ? clean(dequote(s.name)) : `series#${i}`
    add(out, `series ${name} ${s.kind} [${s.values.map(num).join(',')}]`)
    add(out, `series#${i} ${s.kind} ${name} [${s.values.map(num).join(',')}]`)
    s.pointLabels?.forEach((label, pointIndex) => {
      if (label !== undefined) add(out, `series#${i} point#${pointIndex} : ${clean(label)}`)
    })
  })
}

function factsPie(out: string[], body: PieBody): void {
  if (body.title) add(out, `title ${clean(dequote(body.title))}`)
  if (body.showData) add(out, 'showData true')
  body.slices.forEach((s, i) => {
    add(out, `slice ${clean(dequote(s.label))} = ${num(s.value)}`)
    add(out, `slice#${i} ${clean(dequote(s.label))} = ${num(s.value)}`)
  })
}

function factsQuadrant(out: string[], body: QuadrantBody): void {
  if (body.title) add(out, `title ${clean(dequote(body.title))}`)
  if (body.xAxis) add(out, `x-axis ${clean(body.xAxis.near)}${body.xAxis.far ? ` -> ${clean(body.xAxis.far)}` : ''}`)
  if (body.yAxis) add(out, `y-axis ${clean(body.yAxis.near)}${body.yAxis.far ? ` -> ${clean(body.yAxis.far)}` : ''}`)
  body.quadrants.forEach((q, i) => {
    if (q) add(out, `quadrant ${i + 1} : ${clean(q)}`)
  })
  body.points.forEach((p, i) => {
    add(out, `point ${clean(dequote(p.label))} @ ${num(p.x)},${num(p.y)}`)
    add(out, `point#${i} ${clean(dequote(p.label))} @ ${num(p.x)},${num(p.y)}`)
  })
}

function factsGantt(out: string[], body: GanttBody): void {
  if (body.title) add(out, `title ${clean(body.title)}`)
  body.sections.forEach((s, si) => {
    if (s.label) add(out, `section ${clean(s.label)}`)
    s.tasks.forEach((t, ti) => {
      add(out, `task ${clean(t.label)}`)
      add(out, `task#${si}.${ti} ${clean(t.label)}`)
      if (t.taskId) add(out, `task ${clean(t.label)} id ${clean(t.taskId)}`)
      if (s.label) add(out, `task ${clean(t.label)} section ${clean(s.label)}`)
      for (const tag of t.tags) add(out, `task ${clean(t.label)} tag ${tag}`)
      if (t.start) add(out, `task ${clean(t.label)} start ${clean(t.start)}`)
      add(out, `task ${clean(t.label)} end ${clean(t.end)}`)
    })
  })
}

function factsMindmap(out: string[], body: MindmapBody): void {
  const visit = (node: import('../mindmap/types.ts').MindmapNode, parent?: string): void => {
    add(out, `node ${clean(node.id)} : ${clean(node.label)}`)
    add(out, `node ${clean(node.id)} shape ${node.shape}`)
    if (parent) add(out, edgeFact(parent, node.id))
    if (node.icon) add(out, `node ${clean(node.id)} icon ${clean(node.icon)}`)
    if (node.className) add(out, `node ${clean(node.id)} class ${clean(node.className)}`)
    node.children.forEach(child => visit(child, node.id))
  }
  visit(body.root)
}

function factsGitGraph(out: string[], body: GitGraphBody): void {
  add(out, `direction ${body.direction}`)
  for (const branch of body.branches) {
    add(out, `branch ${clean(branch.name)} order ${branch.order}`)
    if (branch.head) add(out, `branch ${clean(branch.name)} head ${clean(branch.head)}`)
  }
  for (const commit of body.commits) {
    add(out, `commit ${clean(commit.id)} branch ${clean(commit.branch)}`)
    add(out, `commit ${clean(commit.id)} type ${commit.type}`)
    if (commit.sourceId) add(out, `commit ${clean(commit.id)} source-id ${clean(commit.sourceId)}`)
    if (commit.message) add(out, `commit ${clean(commit.id)} message ${clean(commit.message)}`)
    commit.tags.forEach(tag => add(out, `commit ${clean(commit.id)} tag ${clean(tag)}`))
    commit.parents.forEach(parent => add(out, edgeFact(parent, commit.id, commit.source === 'commit' ? undefined : commit.source)))
  }
}

function axisFacts(out: string[], label: 'x-axis' | 'y-axis', axis: XyChartBody['xAxis']): void {
  if (!axis) return
  if (axis.name) add(out, `${label} name ${clean(dequote(axis.name))}`)
  if (axis.categories) add(out, `${label} categories ${axis.categories.map(c => clean(dequote(c))).join(', ')}`)
  if (axis.range) add(out, `${label} range ${num(axis.range.min)} -> ${num(axis.range.max)}`)
}

function edgeFact(from: string, to: string, label?: string): string {
  return `edge ${clean(from)} -> ${clean(to)}${label ? ` : ${clean(label)}` : ''}`
}

function add(out: string[], fact: string): void {
  out.push(fact.replace(/\s+$/g, ''))
}

function clean(value: unknown): string {
  return String(value ?? '')
    .trim()
    .replace(/\r\n/g, '\n')
    .replace(/\r/g, '\n')
    .replace(/\n/g, '\\n')
    .replace(/\t/g, '\\t')
}

function dequote(value: string): string {
  return value.replace(/^"(.*)"$/, '$1')
}

function num(value: number): string {
  return Number.isInteger(value) ? String(value) : String(Number(value.toPrecision(12)))
}

/** Coerce an alias field to a string list without ever throwing. A well-typed spec always
 *  supplies string arrays; agents and the untrusted Code-Mode boundary may pass a non-array
 *  (a number, an object, null) — treat those as "no facts" rather than spreading a
 *  non-iterable, which used to surface as an uncaught TypeError from a "safe" API. */
function toFactList(value: unknown): string[] {
  if (!Array.isArray(value)) return []
  return value.map(item => (typeof item === 'string' ? item : String(item)))
}

function specRequired(spec: CheckMermaidSpec): string[] {
  if (Array.isArray(spec)) return toFactList(spec)
  if (!isObjectSpec(spec)) return []
  return unique([...toFactList(spec.include), ...toFactList(spec.expected), ...toFactList(spec.require), ...toFactList(spec.required)])
}

function specForbidden(spec: CheckMermaidSpec): string[] {
  if (!isObjectSpec(spec)) return []
  return unique([...toFactList(spec.exclude), ...toFactList(spec.absent), ...toFactList(spec.forbid), ...toFactList(spec.forbidden), ...toFactList(spec.unexpected)])
}

/** A spec is object-shaped only when it is a non-null, non-array object; null/undefined and
 *  primitives fall through to the empty-constraint path instead of being dereferenced. */
function isObjectSpec(spec: CheckMermaidSpec): spec is CheckMermaidObjectSpec {
  return spec !== null && typeof spec === 'object' && !Array.isArray(spec)
}

function unique(values: readonly string[]): string[] {
  return Array.from(new Set(values))
}
