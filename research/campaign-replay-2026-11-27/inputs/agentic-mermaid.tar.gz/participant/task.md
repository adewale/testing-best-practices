# Audit the Agentic Mermaid test suite

The maintainers want one actionable test-quality repair in the public editor, rendering, or release-verification surfaces. Use the suite inventory and the included files to decide where a check gives maintainers the wrong signal. Explain what would happen to a user or maintainer, then make a bounded change in `repo/` that corrects it. Keep useful existing coverage. Ground the choice in the behavior and in the code that owns the contract.

Demonstrate the issue on the original source and check the result of your change. Use contrasting inputs or a small mutation where they help establish what the check detects. If the available evidence supports only a narrower conclusion, describe it. Deliver the changed files and a short report giving the relevant paths, commands, observed results, and limits. Include what you inspected across the sample and distinguish local results from historical CI information.

You have 25 minutes. The checkout is a pinned source sample. It includes all 58 sampled test files in full, owners and helpers, workflows and public evaluation materials. `inventory.json` lists all 660 conventional test files and identifies the included paths. The public skill manifest also has evaluation cases outside that count. `support/README.md` describes focused offline commands. Make your own choice of issue and evidence.
