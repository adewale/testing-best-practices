# Running the source sample

From the participant directory, run `python3 -B support/focused_baseline.py`. This executes the repository's own complete Python unittest module under `eval/benchmark/visualizations/`. It uses Python and Node 24 with the pinned Trident files. The module tests retained benchmark data and invokes the TypeScript document writer. A temporary directory holds its dependency link and test inputs.

To try a public text case on a saved answer, run `python3 -B support/grade_text.py --case CASE_ID --answer-file /path/to/answer.txt`. Read case IDs from `repo/skill-evals/shared-benchmark.json`. This calls the imported upstream case-grading function with the public case, shows gates and reports any deferred judgments. Use `--allow-scripts` for an inspected case that uses a local script oracle. This is focused grading of supplied text. The command does not invoke a model.

`repo/package.json`, `repo/scripts/ci/unit-test-files.ts`, `repo/e2e/browser-contract-files.ts` and the workflows under `repo/.github/workflows/` describe the full repository's collection and entry points. The Bun/browser dependency installation, generated outputs and large reference corpora are outside this source sample. `ci-observations.json` records selected original GitHub API observations and their revisions.
