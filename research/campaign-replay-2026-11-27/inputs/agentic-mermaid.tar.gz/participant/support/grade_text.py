"""Run the upstream case-grade function against one public case and a saved answer."""
import argparse
import json
from pathlib import Path
import sys
import tempfile


HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE / "skill-eval-harness"))
import skill_benchmark


def score(case, text, manifest, *, allow_scripts=False):
    with tempfile.TemporaryDirectory(prefix="mermaid-saved-answer-") as tmp:
        run = Path(tmp)
        out = run / "output.md"
        out.write_text(text)
        row, judge_tasks = skill_benchmark.grade_case_variant(
            case, "with_skill", text, out, {}, run_base=run, manifest_dir=manifest.parent,
            allow_scripts=allow_scripts,
        )
        return {"case": case["id"], "passed": row["objective_passed"], "total": row["objective_total"],
                "assertions": row["assertions"], "deferred": len(judge_tasks),
                "qualitative": row["qualitative_assertions"]}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--manifest", type=Path, default=HERE.parent / "repo/skill-evals/shared-benchmark.json")
    parser.add_argument("--case", required=True)
    parser.add_argument("--answer-file", type=Path, required=True)
    parser.add_argument("--allow-scripts", action="store_true")
    args = parser.parse_args()
    manifest = args.manifest.resolve()
    case = next(item for item in json.loads(manifest.read_text())["cases"] if item["id"] == args.case)
    print(json.dumps(score(case, args.answer_file.read_text(), manifest, allow_scripts=args.allow_scripts), indent=2))


if __name__ == "__main__":
    main()
