"""Run the repository's retained-data unittest module against its pinned dependency."""
import argparse
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile


HERE = Path(__file__).resolve().parent
TESTDIR = Path("eval/benchmark/visualizations")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, default=HERE.parent / "repo")
    args = parser.parse_args()
    with tempfile.TemporaryDirectory(prefix="mermaid-baseline-") as tmp:
        root = Path(tmp) / "source"
        dest = root / TESTDIR
        dest.mkdir(parents=True)
        for name in ("mermaid_baseline.py", "mermaid_baseline_test.py", "mermaid_baseline_charts.py"):
            shutil.copy2(args.repo / TESTDIR / name, dest / name)
        # This mirrors the symlink established by eval/trident/prepare.ts. Node can
        # load the source TypeScript from its real path outside node_modules.
        modules = root / "node_modules"
        modules.mkdir()
        (modules / "trident").symlink_to(HERE / "trident", target_is_directory=True)
        proc = subprocess.run([sys.executable, "-B", "-m", "unittest", "-v", "mermaid_baseline_test"],
                              cwd=dest, env={**os.environ, "PYTHONDONTWRITEBYTECODE": "1"})
        return proc.returncode


if __name__ == "__main__":
    raise SystemExit(main())
