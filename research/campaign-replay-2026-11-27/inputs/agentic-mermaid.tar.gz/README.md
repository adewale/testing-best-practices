# Agentic Mermaid larger-suite replay

Use only the `participant/` directory in subject workspaces. This experiment reconstructs a previously audited public repository. The evaluators and prior findings stay outside those workspaces. Every treatment gets the same task, source files, inventory, offline tools and 25-minute budget. The parent campaign supplies the experimental guidance.

## Source and sampling

The complete Git tree at `f49196e7f5d6d2f0970a4a76fe62644ee5e9d004` contained 660 conventional test files, including 659 JavaScript/TypeScript files and one Python file. The canonical unit collector includes 606 source files and two explicitly named eval files. The browser collector lists 12 paths and overlaps the source unit collector. The separate skill manifest contains 43 public tune cases, six private holdout stubs and two private holdback stubs. [Pinned repository](https://github.com/adewale/agentic-mermaid/tree/f49196e7f5d6d2f0970a4a76fe62644ee5e9d004)

The 58 full sampled test files comprise 23,798 lines and 1,389,078 bytes. They cover 13 disjoint sampling strata, 41 canonical units and five canonical browser files. Eleven deliberate coverage anchors retain the known audit boundaries. Within each stratum, the rest are the lowest SHA-256 values of a fixed seed, NUL and the normalized path. All 660 paths and per-stratum denominators are in `participant/inventory.json`. `hidden/sampling.json` and `prepare.py` record the recipe. This enrichment precludes a suite-wide defect-rate estimate.

| Stratum | Available | Included |
| --- | ---: | ---: |
| Source property tests | 44 | 5 |
| Source interface tests | 78 | 6 |
| Source editor and site | 26 | 5 |
| Source rendering and layout | 63 | 12 |
| Remaining source families and contracts | 395 | 11 |
| Canonical eval units | 2 | 2 |
| E2E browser | 6 | 4 |
| E2E package and CLI | 6 | 3 |
| Benchmark TypeScript | 28 | 4 |
| Benchmark Python | 1 | 1 |
| Specialist evals | 8 | 3 |
| Imported upstream specs | 2 | 1 |
| Sketch prototype | 1 | 1 |

The public package has 437 repository blobs, including all 58 tests, their available direct local imports, selected helper dependencies, editor modules, image producers, approved artifacts, configuration and workflows. Nineteen files from the pinned upstream grading and Trident dependencies support local execution. All 456 source blobs passed verification against the corresponding Git object ID. `hidden/source-receipts.json` records their individual IDs and hashes. The complete 462-file participant package has digest `de12b4afd96f2fe30e9319a29491cd47f441801bd03516d820f27cc94dba7345`.

## Executed evidence

| Check at the original revision | Observed result |
| --- | --- |
| Actual repository Python unittest file with the pinned Trident sources and Node 24 | 10/10 passed, including the TypeScript document writer and altered-payload rejection. |
| Actual repository manifest materializer and upstream validation CLI | 51 rows and four ablations validated with 32 existing warnings. No private prompt was hydrated. |
| Upstream case-grading function on nine saved answers in two public editor cases | Five of 18 accept/reject decisions agreed with independently specified behavior. Both historical correct responses scored 2/3. Both wrong direct-edit and negated-rebuild responses scored 3/3. |
| Two selected regeneration test callbacks and actual cookbook CLI decision, with fixture bytes supplied for renderer output | All three accepted the original PNG and rejected the lossless re-encode, a visible one-pixel edit and a dimension change. |
| Original cookbook and Section B approval callbacks | Both accepted the original file and rejected a lossless substitution for the file identified by the approval record. |
| Existing repository PNG decoder on the 900 × 186 approved image | Dimensions and samples matched after a 16,125-to-17,681-byte re-encode. A visible pixel change failed RGBA equality. A transpose-shaped buffer with the same sample sequence failed dimension equality. |
| Actual font prerequisite statements and shell command recorders for the workflows | The missing CI directory triggered the declared error. The present directory and optional local case passed that precondition. Canonical CI invoked the font install before its shard. Weekly coverage did not. |

The original public editor callback and PNG/CI observations concern distinct contracts. The public editor instrument can misgrade release guidance. The weekly collection failure has an actionable fixture repair. Pixel equality helps diagnose changes to an image while the pinned Section B regeneration and historical-approval rules explicitly require byte equality. An unconditional switch to pixel equality has no completed-repair credit under this task. `hidden/criteria.md` covers accepted alternatives, honest deferral, alternate findings and useful retained checks.

## Reproduction

From this directory, run the following in a Python environment with PyYAML and Pillow and a Node 24 executable:

```sh
python3 -B participant/support/focused_baseline.py
python3 -B hidden/check_case.py --assert-baseline --output /tmp/agentic-mermaid-baseline.json
```

For a subject patch, apply it to a disposable copy of `participant/repo/` and use the frozen Docker wrapper in [POSTCANDIDATE.md](POSTCANDIDATE.md). Place candidate outputs in the campaign controller's output directory. Repository-owned local script assertions need the evaluator's inspected `--allow-scripts` option. If a candidate introduces a dependency or a different callback layout outside the fixture adapter, record the adapter's unresolved status and review that contract independently.

The original audit's `source.py` cache and nontruncated tree provide the frozen project inventory. `python3 -B prepare.py --audit /path/to/current-test-audit-2026-11-26` reproduces the source selection, verifies cached content, and downloads missing individual pinned blobs. `hidden/prepare_png_decoder.py` verifies the two small NPM tarballs against the repository lockfile. No product suite installation or full repository clone was needed.

The Bun suite, renderer, browser, live model benchmarks, and hosted coverage jobs were outside the executed baseline. The Node image checks execute selected original decisions with controlled rasterizer output and a minimal assertion interface. The shell recorder observes the install invocation. The local CJK prerequisite checks directory presence rather than glyph fidelity. Earlier GitHub job evidence retains its own SHA and source in `participant/support/ci-observations.json`.
