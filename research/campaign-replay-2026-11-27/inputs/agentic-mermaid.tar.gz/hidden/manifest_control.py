"""Validate the real public manifest via the repository's own materializer and upstream CLI."""
import argparse
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile


HERE = Path(__file__).resolve().parent


def run(repo):
    with tempfile.TemporaryDirectory(prefix="mermaid-manifest-") as tmp:
        checkout = Path(tmp) / "repo"
        shutil.copytree(repo, checkout, ignore=shutil.ignore_patterns(".git", "node_modules", "__pycache__"))
        out = ".case-runner.json"
        commands = [
            ["node", "scripts/eval/materialize-skill-runner-manifest.ts", "--manifest", "skill-evals/shared-benchmark.json",
             "--repo-root", ".", "--out", out],
            [sys.executable, "-B", str(HERE.parent / "participant/support/skill-eval-harness/skill_benchmark.py"),
             "validate", out],
        ]
        rows = []
        for cmd in commands:
            proc = subprocess.run(cmd, cwd=checkout, capture_output=True, text=True, timeout=30)
            rows.append({"command": " ".join(cmd).replace(str(HERE.parent) + "/", ""), "exit": proc.returncode,
                         "stdout": proc.stdout.strip().replace(str(checkout), "<temp-repo>"),
                         "warningCount": sum(line.startswith("WARN ") for line in proc.stderr.splitlines()),
                         "stderr": proc.stderr.strip().replace(str(checkout), "<temp-repo>")})
            if proc.returncode:
                break
        return {"method": "Full public manifest validation including public stubs. No hidden prompts were hydrated and no cases were run by this validator.", "commands": rows}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, default=HERE.parent / "participant/repo")
    args = parser.parse_args()
    print(json.dumps(run(args.repo.resolve()), indent=2))
