// Register narrow fixture replacements around the original test and CLI decisions.
import { registerHooks } from 'node:module'
import { readFileSync } from 'node:fs'
import { resolve, join } from 'node:path'
import { fileURLToPath, pathToFileURL } from 'node:url'
import { isDeepStrictEqual } from 'node:util'

const repo = process.env.REPLAY_REPO
const vendor = resolve(import.meta.dirname, 'vendor/node_modules')
const variant = process.env.REPLAY_VARIANT
const catalog = JSON.parse(readFileSync(join(repo, 'examples/styles/catalog.json'), 'utf8'))
const fileByStyle = new Map(catalog.examples.map(entry => {
  const style = JSON.parse(readFileSync(join(repo, 'examples/styles', entry.style), 'utf8'))
  return [JSON.stringify(style), join(repo, 'docs/assets/style-cookbook', entry.screenshot)]
}))

globalThis.replayCases = []
globalThis.replayExpect = (actual, label) => {
  const check = (pass, operator) => {
    if (!pass) throw new Error('REPLAY_ASSERTION ' + operator + ' ' + (label ?? ''))
  }
  return {
    toBe: expected => check(Object.is(actual, expected), 'toBe'),
    toEqual: expected => check(isDeepStrictEqual(actual, expected), 'toEqual'),
    toStrictEqual: expected => check(isDeepStrictEqual(actual, expected), 'toStrictEqual'),
    toBeGreaterThan: expected => check(actual > expected, 'toBeGreaterThan'),
    toBeTrue: () => check(actual === true, 'toBeTrue'),
    toHaveLength: expected => check(actual.length === expected, 'toHaveLength'),
  }
}
globalThis.replayRaster = svg => {
  const path = fileByStyle.get(svg)
  if (!path) throw new Error('unmapped controlled cookbook renderer input')
  return readFileSync(path.endsWith('/cupertino-prototype.png') ? variant : path)
}
globalThis.Bun = { deepEquals: isDeepStrictEqual }
const mocks = {
  bun: `export const describe = (_, fn) => fn();
         export const test = (name, fn) => globalThis.replayCases.push({name, fn});
         export {test as it}; export const expect = globalThis.replayExpect;`,
  svg: `export const renderMermaidSVG = (_, opts) => JSON.stringify(opts.style);
        export const validateStyleSpec = () => []; export const knownStyleDescriptors = () => [];
        export const registerStyle = () => {}; export const renderMermaidASCII = () => '';`,
  resvg: `export class Resvg { constructor(svg) { this.svg=svg; }
            render() { return {asPng: () => globalThis.replayRaster(this.svg)}; } }`,
  theme: 'export const inlineFontVarForRaster = svg => svg;',
  agent: 'export const verifyMermaid = () => {};',
  families: 'export const knownBuiltinFamilies = () => []; export const getFamily = () => {};',
  png: 'export const renderMermaidPNG = () => { throw Error("uncontrolled renderer"); };',
  profile: 'export const inspectPngDimensions = () => {};',
  style: 'export const styleKind = () => {};',
  section: `export { GRAPHICAL_BACKEND_PROBES, runSectionBBackendProbe, sectionBVariantHeadingMarkup, sectionBVisualApproval }
            from ${JSON.stringify(pathToFileURL(join(repo, 'scripts/pr-assets/section-b-brand-evidence.ts')).href)};
            import {readFileSync} from 'node:fs';
            export const buildSectionBBrandEvidence = () => readFileSync(process.env.REPLAY_VARIANT);`,
}
const byPath = new Map([
  ['src/index.ts', 'svg'], ['src/theme.ts', 'theme'], ['src/agent/index.ts', 'agent'],
  ['src/agent/families.ts', 'families'], ['src/agent/png.ts', 'png'],
  ['src/output-color-profile.ts', 'profile'], ['src/scene/style-registry.ts', 'style'],
].map(([p, key]) => [join(repo, p), key]))
const mock = key => ({url: 'replay:' + key, shortCircuit: true})
registerHooks({
  resolve(spec, ctx, next) {
    if (spec === 'bun:test') return mock('bun')
    if (spec === '@resvg/resvg-js') return mock('resvg')
    if (spec === 'upng-js') return {url: pathToFileURL(join(vendor, 'upng-js/UPNG.js')).href, shortCircuit:true}
    if (spec.startsWith('.') && ctx.parentURL?.startsWith('file:')) {
      const absolute = fileURLToPath(new URL(spec, ctx.parentURL))
      if (absolute.endsWith('/scripts/pr-assets/section-b-brand-evidence.ts')
          && ctx.parentURL.endsWith('section-b-visual-evidence.test.ts')) return mock('section')
      if (byPath.has(absolute)) return mock(byPath.get(absolute))
    }
    return next(spec, ctx)
  },
  load(url, ctx, next) {
    if (url.startsWith('replay:')) return {format:'module', source:mocks[url.slice(7)], shortCircuit:true}
    if (url.startsWith(pathToFileURL(repo).href + '/') && url.endsWith('.ts')) {
      const source = readFileSync(fileURLToPath(url), 'utf8').replace(/import\.meta\.dir\b/g, 'import.meta.dirname')
      return {source,format:'module-typescript',shortCircuit:true}
    }
    return next(url, ctx)
  },
})
