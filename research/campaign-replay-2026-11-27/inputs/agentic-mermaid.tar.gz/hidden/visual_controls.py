"""Exercise candidate visual freshness and approval decisions against real PNGs."""
import argparse
from hashlib import sha256
import json
import os
from pathlib import Path
import shutil
import subprocess
import tempfile

from PIL import Image


HERE = Path(__file__).resolve().parent
ASSETS = {"cookbook": "docs/assets/style-cookbook/cupertino-prototype.png",
          "section": "src/__tests__/testdata/section-b-brand-evidence.png"}


def variants(asset, directory):
    directory.mkdir()
    paths = {}
    with Image.open(asset) as source:
        original = source.convert("RGBA")
    width, height = original.size
    paths["original"] = directory / "original.png"
    shutil.copy2(asset, paths["original"])
    for key in ("reencoded", "visiblePixel", "dimensions"):
        out = directory / (key + ".png")
        if key == "reencoded":
            original.save(out, compress_level=1)
        elif key == "visiblePixel":
            # Both approved images have an opaque pixel here.
            r, g, b, a = original.getpixel((0, 0))
            assert a == 255
            original.putpixel((0, 0), (r ^ 255, g, b, a))
            original.save(out, compress_level=1)
            original.putpixel((0, 0), (r, g, b, a))
        else:
            if width * height < 1_000_000:
                # Exactly the same concatenated RGBA bytes, different dimensions.
                with Image.frombytes("RGBA", (height, width), original.tobytes()) as altered:
                    altered.save(out, compress_level=1)
            else:
                with original.crop((0, 0, width, height - 1)) as altered:
                    altered.save(out, compress_level=1)
        paths[key] = out
    original_hash = sha256(original.tobytes()).hexdigest()
    original.close()
    expected_encoded = sha256(asset.read_bytes()).hexdigest()
    info = {}
    for key, out in paths.items():
        with Image.open(out) as png:
            dims = list(png.size)
            pixels = sha256(png.tobytes()).hexdigest()
        raw = out.read_bytes()
        info[key] = {"bytes": len(raw), "dimensions": dims, "encodedSHA256": sha256(raw).hexdigest(),
                     "rgbaSHA256": pixels, "samePixelSequence": pixels == original_hash,
                     "sameDimensionsAndPixels": dims == [width, height] and pixels == original_hash,
                     "sameApprovedBytes": sha256(raw).hexdigest() == expected_encoded}
    assert [x["sameDimensionsAndPixels"] for x in info.values()] == [True, True, False, False]
    assert [x["sameApprovedBytes"] for x in info.values()] == [True, False, False, False]
    return paths, info


def invoke(repo, target, variant):
    env = {**os.environ, "REPLAY_REPO": str(repo), "REPLAY_TARGET": target, "REPLAY_VARIANT": str(variant)}
    cmd = ["node", "--import", str(HERE / "visual-preload.mjs")]
    is_cli = target == "cookbook-cli"
    cmd.extend([str(repo / "scripts/docs/custom-style-cookbook.ts"), "--check"] if is_cli else [str(HERE / "run-visual-test.mjs")])
    proc = subprocess.run(cmd, cwd=repo, env=env, capture_output=True, text=True, timeout=75)
    if is_cli and not proc.returncode:
        return {"decision": "accept", "exit": 0}
    if is_cli and "is out of date" in proc.stderr:
        return {"decision": "reject", "exit": proc.returncode}
    if not proc.returncode:
        try:
            return {"exit": 0, **json.loads(proc.stdout.strip().splitlines()[-1])}
        except (IndexError, ValueError):
            pass
    return {"decision": "unresolved", "exit": proc.returncode, "diagnostic": (proc.stderr or proc.stdout)[-1200:]}


def run(repo, scope):
    result = {"method": "Actual candidate TypeScript test callbacks and cookbook --check under Node. Renderer output is controlled by injecting real fixture bytes. Native rasterization, Bun discovery and workflow jobs did not run.",
              "assets": {}}
    with tempfile.TemporaryDirectory(prefix="mermaid-visual-controls-") as tmp:
        root = Path(tmp)
        checkout = root / "repo"
        shutil.copytree(repo, checkout, ignore=shutil.ignore_patterns(".git", "node_modules", "__pycache__"))
        for name, asset in ASSETS.items():
            if scope != "all" and scope != name:
                continue
            tracked = checkout / asset
            paths, info = variants(tracked, root / name)
            if name == "cookbook":
                receipt = json.loads((checkout / "eval/style-prototype-evidence/visual-approval.json").read_text())
                approved = next(a["sha256"] for a in receipt["artifacts"] if a["path"] == asset)
            else:
                approved = json.loads((checkout / "eval/section-b-brand-evidence/visual-approval.json").read_text())["artifactSha256"]
            block = {"asset": asset, "recordedSHA256": approved, "baseMatchesReceipt": info["original"]["encodedSHA256"] == approved,
                     "inputs": info, "freshness": {}, "approvals": {}}
            if name == "cookbook":
                block["existingPixelHelper"] = {}
                for key, variant in paths.items():
                    env = {**os.environ, "REPLAY_REPO": str(checkout), "REPLAY_APPROVED": str(tracked),
                           "REPLAY_VARIANT": str(variant)}
                    proc = subprocess.run(["node", "--import", str(HERE / "visual-preload.mjs"), str(HERE / "run-pixel-helper.mjs")],
                                          cwd=checkout, env=env, text=True, capture_output=True, timeout=30)
                    block["existingPixelHelper"][key] = json.loads(proc.stdout) if not proc.returncode else {
                        "unresolved": proc.stderr[-1200:], "exit": proc.returncode}
            targets = [name + "-regeneration"] + (["cookbook-cli"] if name == "cookbook" else [])
            for mode in targets:
                block["freshness"][mode] = {key: invoke(checkout, mode, v) for key, v in paths.items()}
            for key in ("original", "reencoded"):
                # Candidate receipt and source never change. Only the committed PNG
                # is swapped in this temporary checkout for the second control.
                shutil.copy2(paths[key], tracked)
                block["approvals"][key] = invoke(checkout, name + "-approval", paths[key])
            result["assets"][name] = block
    return result


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, default=HERE.parent / "participant/repo")
    parser.add_argument("--scope", choices=["all", "cookbook", "section"], default="all")
    args = parser.parse_args()
    print(json.dumps(run(args.repo.resolve(), args.scope), indent=2))
