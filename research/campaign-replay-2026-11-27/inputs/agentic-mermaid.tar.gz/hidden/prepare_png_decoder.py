"""Stage the two small lockfile-pinned packages used by the existing pixel helper."""
import base64
import hashlib
import io
from pathlib import Path
import tarfile
from urllib.request import urlopen

HERE = Path(__file__).resolve().parent
DEPS = [
    ("upng-js", "2.1.0", "d3xzZzpMP64YkjP5pr8gNyvBt7dLk/uGI67EctzDuVp4lCZyVMo0aJO6l/VDlgbInJYDY6cnClLoBp29eKWI6g=="),
    ("pako", "1.0.11", "4hLB8Py4zZce5s4yd9XzopqwVv/yGNhV1Bl8NTmCq1763HeK2+EwVTv+leGeL13Dnh2wfbqowVPXCIO0z4taYw=="),
]
if __name__ == "__main__":
    lock = (HERE.parent / "participant/repo/bun.lock").read_text()
    for name, version, integrity in DEPS:
        assert "sha512-" + integrity in lock
        url = f"https://registry.npmjs.org/{name}/-/{name}-{version}.tgz"
        with urlopen(url, timeout=20) as response:
            body = response.read()
        if base64.b64encode(hashlib.sha512(body).digest()).decode() != integrity:
            raise ValueError(f"tar integrity differs for {name}")
        with tarfile.open(fileobj=io.BytesIO(body)) as archive:
            for entry in archive.getmembers():
                parts = Path(entry.name).parts
                if not entry.isfile() or parts[0] != "package" or ".." in parts:
                    continue
                if not (parts[-1] in {"LICENSE", "package.json", "index.js", "UPNG.js"} or parts[1] == "lib"):
                    continue
                target = HERE / "vendor" / "node_modules" / name / Path(*parts[1:])
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(archive.extractfile(entry).read())
        print(name, version, len(body), "bytes verified against bun.lock")
