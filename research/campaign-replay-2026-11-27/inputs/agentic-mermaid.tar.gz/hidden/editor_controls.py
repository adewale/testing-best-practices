"""Run genuine upstream case grading for two public cases and independent saved answers."""
import argparse
from collections import Counter
import json
from pathlib import Path
import sys


HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / "participant/support"))
from grade_text import score


def run(repo, allow_scripts=False):
    manifest = repo / "skill-evals/shared-benchmark.json"
    data = json.loads(manifest.read_text())
    cases = {c["id"]: c for c in data["cases"]}
    controls = json.loads((HERE / "editor-controls.json").read_text())
    decisions = Counter()
    results = []
    for control in controls["answers"]:
        for cid, expected in zip(controls["cases"], control["expect"], strict=True):
            if cid not in cases:
                results.append({"control": control["id"], "case": cid, "expected": expected, "decision": "row-removed"})
                decisions["row-removed"] += 1
                continue
            row = score(cases[cid], control["answer"], manifest, allow_scripts=allow_scripts)
            failed = row["passed"] != row["total"]
            if failed:
                decision = "reject"
            elif row["deferred"]:
                decision = "defer"
            elif not row["total"]:
                decision = "no-objective"
            else:
                decision = "accept"
            decisions["correct" if decision == expected else decision if decision in {"defer", "no-objective"} else "incorrect"] += 1
            results.append({"control": control["id"], "case": cid, "expected": expected, "decision": decision,
                            "passed": row["passed"], "total": row["total"], "deferred": row["deferred"],
                            "assertions": [{"name": a["name"], "passed": a["passed"], "type": a["type"]} for a in row["assertions"]]})
    return {"method": "Upstream v0.6.0 grade_case_variant on original or candidate manifest and saved text. No model or full manifest benchmark ran.",
            "scriptOraclesEnabled": allow_scripts, "cases": controls["cases"], "counts": decisions, "controls": results}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, default=HERE.parent / "participant/repo")
    parser.add_argument("--allow-scripts", action="store_true")
    args = parser.parse_args()
    print(json.dumps(run(args.repo.resolve(), args.allow_scripts), indent=2))
