"""Replay the annotated CJK prerequisite and observe fixture command ordering."""
import argparse
import json
import os
from pathlib import Path
import subprocess
import tempfile

import yaml


HERE = Path(__file__).resolve().parent
FONT = "fonts-wqy-zenhei"


def guard(repo, root):
    path = repo / "src/__tests__/png-fonts.test.ts"
    source = path.read_text()
    start, stop = source.find("const CJK_FONT_DIR"), source.find("function collectWarnings")
    if start < 0 or stop <= start:
        return {"status": "unrecognized-guard-layout", "manualReplay": True}
    # The import binding is supplied by name as in the original module. Execute
    # the actual prerequisite expression. No rendering or font discovery is run.
    code = "import {existsSync} from 'node:fs';\n" + source[start:stop]
    result = {}
    for label, location, ci in [("missingCI", root / "missing", "true"), ("presentCI", root, "true"),
                                ("missingLocal", root / "missing", "false")]:
        proc = subprocess.run(["node", "--input-type=module", "-e", code], text=True, capture_output=True,
                              env={**os.environ, "CI": ci, "AM_CJK_FONT_DIR": str(location)}, timeout=10)
        result[label] = {"exit": proc.returncode, "declaredPrerequisiteMessage": "CI requires a CJK font" in proc.stderr}
    return result


def fixture_setup(path, root, covered):
    workflow = yaml.load(path.read_text(), Loader=yaml.BaseLoader)
    jobs = workflow["jobs"]
    unit = jobs.get("unit")
    if not unit:
        return {"status": "unrecognized-unit-job", "manualReplay": True}
    key = "test:coverage" if covered else "bun run test --"
    steps = unit["steps"]
    test_index = next((i for i, s in enumerate(steps) if key in s.get("run", "")), None)
    if test_index is None:
        return {"status": "unrecognized-shard-command", "manualReplay": True}
    commands, apt = [], []
    # Provide harmless command recorders. No apt operation, sudo operation or
    # workflow installation is performed. Only inspect routine provisioning steps.
    tools = root / "bin"
    tools.mkdir(exist_ok=True)
    for name, code in {"sudo": '#!/bin/sh\nexec "$@"\n',
                       "apt-get": '#!/bin/sh\nprintf "%s\\n" "$*" >> "$MERMAID_APT_LOG"\n'}.items():
        out = tools / name
        out.write_text(code)
        out.chmod(0o700)
    log = root / (path.stem + ".log")
    for index, step in enumerate(steps):
        script = step.get("run", "")
        if FONT not in script:
            continue
        if step.get("if") or "${{" in script or "working-directory" in step:
            commands.append({"index": index, "status": "conditional-or-action-needs-manual-review"})
            continue
        known = root / (path.stem + ".sh")
        known.write_text(script)
        log.write_text("")
        env = {**os.environ, "PATH": str(tools) + ":/usr/bin:/bin", "MERMAID_APT_LOG": str(log)}
        out = subprocess.run(["bash", "-e", "-o", "pipefail", str(known)], cwd=root, env=env,
                             capture_output=True, text=True, timeout=12)
        argv = [line.split() for line in log.read_text().splitlines()]
        installs = any("install" in parts and FONT in parts and not {"--simulate", "--dry-run", "-s"} & set(parts) for parts in argv)
        if installs and not out.returncode and index < test_index:
            apt.append(index)
        commands.append({"index": index, "exit": out.returncode, "aptGetCalls": argv, "beforeShard": index < test_index})
    return {"shards": unit.get("strategy", {}).get("matrix", {}).get("shard"), "shardCommandIndex": test_index,
            "recognizedSetupBeforeShard": bool(apt), "setupCommands": commands,
            "mergeNeeds": jobs.get("merge", {}).get("needs"), "mergeCommand": [
                s["run"] for s in jobs.get("merge", {}).get("steps", []) if "merge-lcov" in s.get("run", "")],
            "sharedActions": [s["uses"] for s in steps[:test_index] if s.get("uses", "").startswith("./")]}


def run(repo):
    with tempfile.TemporaryDirectory(prefix="mermaid-font-fixture-") as tmp:
        scratch = Path(tmp)
        return {"method": "Original prerequisite statements under Node and unprivileged shell command recorders for identified YAML steps. No real font install, rendering, shard, upload or merge.",
                "prerequisite": guard(repo, scratch),
                "canonical": fixture_setup(repo / ".github/workflows/ci.yml", scratch, False),
                "coverage": fixture_setup(repo / ".github/workflows/coverage.yml", scratch, True)}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, default=HERE.parent / "participant/repo")
    args = parser.parse_args()
    print(json.dumps(run(args.repo.resolve()), indent=2))
