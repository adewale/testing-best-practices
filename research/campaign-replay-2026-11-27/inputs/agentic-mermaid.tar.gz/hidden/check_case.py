"""Validate the shipped baseline and emit comparable observations for a candidate."""
import argparse
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import sys

from editor_controls import run as editor
from manifest_control import run as manifest
from visual_controls import run as visual
from workflow_controls import run as workflow


HERE = Path(__file__).resolve().parent
PUBLIC = HERE.parent / "participant"


def fingerprint():
    actual = {p.relative_to(PUBLIC).as_posix(): sha256(p.read_bytes()).hexdigest()
              for p in sorted(PUBLIC.rglob("*")) if p.is_file()}
    expected = json.loads((HERE / "participant-fingerprint.json").read_text())
    assert actual == expected["files"], "trusted public fixture changed"
    digest = sha256("".join(f"{p}\0{h}\n" for p, h in actual.items()).encode()).hexdigest()
    assert digest == expected["sha256"], "trusted public sample digest differs"
    return digest


def assert_baseline(suite, grades, png, ci, schema):
    assert suite["exit"] == 0 and "Ran 10 tests" in suite["output"]
    assert grades["counts"] == {"incorrect": 13, "correct": 5}
    assert [s["exit"] for s in schema["commands"]] == [0, 0]
    assert [s["warningCount"] for s in schema["commands"]] == [0, 32]
    for b in png["assets"].values():
        assert b["baseMatchesReceipt"]
        assert {k: s["decision"] for k, s in b["approvals"].items()} == {"original": "accept", "reencoded": "reject"}
        for checks in b["freshness"].values():
            assert {k: s["decision"] for k, s in checks.items()} == {
                "original": "accept", "reencoded": "reject", "visiblePixel": "reject", "dimensions": "reject"}
    assert [j["equivalent"] for j in png["assets"]["cookbook"]["existingPixelHelper"].values()] == [True, True, False, False]
    assert ci["canonical"]["recognizedSetupBeforeShard"] and not ci["coverage"]["recognizedSetupBeforeShard"]
    assert ci["coverage"]["shards"] == ["1/3", "2/3", "3/3"] and ci["coverage"]["mergeNeeds"] == "unit"
    assert ci["prerequisite"]["missingCI"] == {"exit": 1, "declaredPrerequisiteMessage": True}
    assert ci["prerequisite"]["presentCI"]["exit"] == ci["prerequisite"]["missingLocal"]["exit"] == 0


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, default=PUBLIC / "repo")
    parser.add_argument("--output", type=Path)
    parser.add_argument("--assert-baseline", action="store_true")
    parser.add_argument("--allow-scripts", action="store_true",
                        help="enable inspected candidate manifest script oracles inside an isolated execution environment")
    args = parser.parse_args()
    repo = args.repo.resolve()
    digest = fingerprint()
    suite_run = subprocess.run([sys.executable, "-B", str(PUBLIC / "support/focused_baseline.py"), "--repo", str(repo)],
                               capture_output=True, text=True, timeout=60)
    suite = {"exit": suite_run.returncode, "output": suite_run.stdout + suite_run.stderr}
    grades = editor(repo, allow_scripts=args.allow_scripts)
    schema = manifest(repo)
    png = visual(repo, "all")
    ci = workflow(repo)
    if args.assert_baseline:
        assert_baseline(suite, grades, png, ci, schema)
    result = {"participantFingerprint": digest, "baselineExpectationsVerified": args.assert_baseline,
              "productUnittest": suite, "publicManifestValidation": schema, "editorGrade": grades,
              "imageDecisions": png, "workflowFixture": ci}
    if args.output:
        args.output.write_text(json.dumps(result, indent=2) + "\n")
    else:
        print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
