import { join } from 'node:path'
import { pathToFileURL } from 'node:url'

const target = process.env.REPLAY_TARGET
const cookbook = target.startsWith('cookbook')
const file = cookbook ? 'custom-style-cookbook.test.ts' : 'section-b-visual-evidence.test.ts'
await import(pathToFileURL(join(process.env.REPLAY_REPO, 'src/__tests__', file)))
const pattern = {
  'cookbook-regeneration': /buildCookbookScreenshots/,
  'cookbook-approval': /eval\/style-prototype-evidence\/visual-approval\.json/,
  'section-regeneration': /buildSectionBBrandEvidence/,
  'section-approval': /sectionBVisualApproval/,
}[target]
const found = globalThis.replayCases.filter(t => pattern.test(String(t.fn)))
if (found.length !== 1) throw new Error('adapter could not identify exactly one original callback for ' + target)
try {
  await found[0].fn()
  console.log(JSON.stringify({callback:found[0].name, decision:'accept'}))
} catch (e) {
  const error = String(e.message ?? e)
  const decision = /REPLAY_ASSERTION|Section B visual approval covers/.test(error) ? 'reject' : 'unresolved'
  console.log(JSON.stringify({callback:found[0].name, decision, error:error.slice(0, 500)}))
}
