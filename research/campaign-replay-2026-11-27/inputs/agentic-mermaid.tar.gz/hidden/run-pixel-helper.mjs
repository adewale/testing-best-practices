import {readFileSync} from 'node:fs'
import {join} from 'node:path'
import {pathToFileURL} from 'node:url'

const module = pathToFileURL(join(process.env.REPLAY_REPO, 'src/__tests__/helpers/png-pixels.ts'))
const {decodePng} = await import(module)
const approved = decodePng(readFileSync(process.env.REPLAY_APPROVED))
const trial = decodePng(readFileSync(process.env.REPLAY_VARIANT))
const dimensions = approved.width === trial.width && approved.height === trial.height
const pixels = Buffer.from(approved.rgba).equals(Buffer.from(trial.rgba))
console.log(JSON.stringify({sameDimensions: dimensions, sameRGBASequence: pixels, equivalent: dimensions && pixels}))
