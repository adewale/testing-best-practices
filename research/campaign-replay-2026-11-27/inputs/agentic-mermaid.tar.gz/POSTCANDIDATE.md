# Run a submitted repair

Apply the subject's patch to its own fresh copy of `participant/repo/`. From this case directory, pass that checkout and an output location owned by the controller.

```sh
python3 -B run-isolated.py --repo /path/to/candidate/repo --output /path/to/controller-output/arm.json
```

The wrapper writes the control observations to `arm.json` and the image, candidate and result hashes, limits and runtime proof to `arm.runtime.json`. Each call uses a fresh, isolated writable copy of the candidate. Add `--allow-scripts` when a reviewed repair changes the two public editor rows to use a local script assertion. The evaluator's interpretation and preservation criteria are in `hidden/criteria.md`.

The frozen Linux/amd64 image ID is `sha256:e89a28eddc2679c648d10c127f6d0f79d892056a55f179dfded36452a5477c46`. The wrapper executes that ID with image pulls disabled. The pinned Node base and downloaded wheel checksums are in `operator-runtime/image-pin.json`. The build uses the managed Docker socket, verifies the two wheels on the host and in the build, and performs its image build steps offline. `operator-runtime/build_image.py` and its Dockerfile reproduce the recipe.

The container runs as UID and GID 65534 with a read-only root, zero process capabilities, the no-new-privileges setting and loopback as its sole network interface. There are four narrow read-only mounts for the staged candidate, participant fixture, selected evaluator files and decoder vendor files. The process receives seven explicit environment variables. Its writable space is a 256 MiB temporary filesystem. The limits are two CPUs, 2 GiB of memory, 96 processes and 240 seconds per validation. The host controller captures the result stream. It mounts neither an output directory nor the host workspace.

The original-source smoke ran the entire control driver with `--assert-baseline`. All 10 original unittests passed. Its editor grades, image decisions, workflow probes, manifest validation messages and substantive unittest output reproduced the native baseline. Timing and the interpreter's absolute path differed. [Baseline controls](operator-runtime/baseline.isolated.json) · [Isolation receipt](operator-runtime/baseline.isolated.runtime.json)

`operator-runtime/runtime-lock.json` records all case files present at freeze, including every member of `hidden/vendor/node_modules/`. Its own contents are bound by the campaign's enclosing freeze. No subject results belong under this preparation directory.
