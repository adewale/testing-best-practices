"""Container entry point. All writable paths belong to this disposable run."""
import argparse
import json
import os
from pathlib import Path
import shutil
import stat
import subprocess
import sys
import tempfile

import PIL
import yaml


def copy_worktree(source, destination):
    shutil.copytree(source, destination, symlinks=True)
    for directory, _, files in os.walk(destination):
        Path(directory).chmod(0o700)
        for name in files:
            p = Path(directory, name)
            if not p.is_symlink():
                p.chmod(0o700 if p.stat().st_mode & 0o111 else 0o600)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--assert-baseline", action="store_true")
    parser.add_argument("--allow-scripts", action="store_true")
    args = parser.parse_args()
    mounted = ["/", "/candidate", "/case/participant", "/case/hidden", "/case/hidden/vendor"]
    ro = {p: bool(os.statvfs(p).f_flag & os.ST_RDONLY) for p in mounted}
    assert all(ro.values()) and os.getuid() == 65534
    proc_status = dict(line.split(":\t", 1) for line in Path("/proc/self/status").read_text().splitlines() if ":\t" in line)
    assert int(proc_status["CapEff"], 16) == 0 and proc_status["NoNewPrivs"].strip() == "1"
    interfaces = sorted(p.name for p in Path("/sys/class/net").iterdir())
    assert interfaces == ["lo"]
    assert not Path("/var/run/docker.sock").exists() and not Path("/workspace").exists()
    assert set(os.environ) <= {"PATH", "HOME", "TMPDIR", "LANG", "LC_ALL", "TZ", "PYTHONDONTWRITEBYTECODE"}
    proof = {"uid": os.getuid(), "gid": os.getgid(), "interfaces": interfaces, "readOnlyMounts": ro,
             "effectiveCapabilities": proc_status["CapEff"], "noNewPrivileges": True,
             "environmentKeys": sorted(os.environ), "python": sys.version.split()[0],
             "node": subprocess.check_output(["node", "--version"], text=True).strip(),
             "Pillow": PIL.__version__, "PyYAML": yaml.__version__}
    sys.stderr.write("RUNTIME_PROOF " + json.dumps(proof, sort_keys=True) + "\n")
    with tempfile.TemporaryDirectory(prefix="candidate-") as tmp:
        repo = Path(tmp) / "repo"
        copy_worktree(Path("/candidate"), repo)
        assert stat.S_IMODE(repo.stat().st_mode) == 0o700
        command = [sys.executable, "-B", "/case/hidden/check_case.py", "--repo", str(repo)]
        if args.assert_baseline:
            command.append("--assert-baseline")
        if args.allow_scripts:
            command.append("--allow-scripts")
        return subprocess.run(command, cwd=tmp).returncode


if __name__ == "__main__":
    raise SystemExit(main())
