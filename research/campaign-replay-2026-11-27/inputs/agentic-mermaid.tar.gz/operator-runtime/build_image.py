"""Build the local linux/amd64 replay runtime from a pinned base and wheels."""
from hashlib import sha256
import json
import os
from pathlib import Path
import shutil
import subprocess
import tempfile
from urllib.request import urlopen


HERE = Path(__file__).resolve().parent
BASE = "node:24.22.3-bookworm@sha256:49f7adaf9f1574bc45c20ea317139b39a59d7e758d0e93745e112fd85cb42623"
BASE_ID = "sha256:c9d0052aa914303f32f82ec87c38c1c01730affd227338ef0cb54c22d168e96a"
TAG = "agentic-mermaid-replay-evaluator:20261127-v1"
DOCKER = ["docker", "--host=unix:///var/run/docker.sock"]
PACKAGES = [
    ("pillow-13.0.0-cp311-cp311-manylinux_2_27_x86_64.manylinux_2_28_x86_64.whl",
     "https://files.pythonhosted.org/packages/36/46/f509b74787f40ce0627501089d630b2c741b63b244c1f40b640b3b01e181/",
     "a625df9a2a5597fa5e5266e01aefc82604bb85d291e3547981e863560d75da6c"),
    ("pyyaml-6.0.3-cp311-cp311-manylinux2014_x86_64.manylinux_2_17_x86_64.manylinux_2_28_x86_64.whl",
     "https://files.pythonhosted.org/packages/71/60/917329f640924b18ff085ab889a11c763e0b573da888e8404ff486657602/",
     "b8bb0864c5a28024fac8a632c443c87c5aa6f215c0b126c449ae1a150412f31d"),
]


def docker_env():
    remove = {"DOCKER_HOST", "DOCKER_CONTEXT", "DOCKER_TLS", "DOCKER_TLS_VERIFY", "DOCKER_CERT_PATH"}
    return {k: v for k, v in os.environ.items() if k not in remove}


if __name__ == "__main__":
    env = docker_env()
    ident = subprocess.check_output([*DOCKER, "image", "inspect", "--format", "{{.Id}}", BASE], text=True, env=env).strip()
    if ident != BASE_ID:
        raise SystemExit(f"local amd64 base does not match its pinned image ID: {ident}")
    with tempfile.TemporaryDirectory(prefix="mermaid-evaluator-build-") as tmp:
        ctx = Path(tmp)
        for src in ("Dockerfile", "enter.py"):
            shutil.copyfile(HERE / src, ctx / src)
        wheels = ctx / "wheels"
        wheels.mkdir()
        for file, url, expected in PACKAGES:
            with urlopen(url + file, timeout=45) as response:
                raw = response.read()
            if sha256(raw).hexdigest() != expected:
                raise SystemExit(f"wheel differs from pinned SHA-256: {file}")
            (wheels / file).write_bytes(raw)
        (wheels / "SHA256SUMS").write_text("".join(f"{h}  {n}\n" for n, _, h in PACKAGES))
        # Use the already-present, content-addressed base. RUN is offline.
        subprocess.run([*DOCKER, "build", "--network=none", "--pull=false", "--platform=linux/amd64",
                        "--tag", TAG, str(ctx)], check=True, env=env)
    image_id = subprocess.check_output([*DOCKER, "image", "inspect", "--format", "{{.Id}}", TAG],
                                       text=True, env=env).strip()
    pin = {"imageId": image_id, "tag": TAG, "base": BASE, "baseImageId": BASE_ID, "platform": "linux/amd64",
           "wheels": {n: h for n, _, h in PACKAGES},
           "sourceSHA256": {n: sha256((HERE / n).read_bytes()).hexdigest() for n in ("Dockerfile", "enter.py", "build_image.py")}}
    (HERE / "image-pin.json").write_text(json.dumps(pin, indent=2) + "\n")
    print(image_id)
