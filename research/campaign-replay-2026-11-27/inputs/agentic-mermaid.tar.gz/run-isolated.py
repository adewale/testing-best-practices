"""Run the frozen evaluator by exact local image ID with read-only scoped inputs."""
import argparse
from hashlib import sha256
import json
import os
from pathlib import Path
import shutil
import stat
import subprocess
import tempfile
import time
from uuid import uuid4


HERE = Path(__file__).resolve().parent
DOCKER = ["docker", "--host=unix:///var/run/docker.sock"]
HIDDEN_INPUTS = (
    "check_case.py", "editor_controls.py", "editor-controls.json", "manifest_control.py",
    "visual_controls.py", "workflow_controls.py", "visual-preload.mjs", "run-visual-test.mjs",
    "run-pixel-helper.mjs", "participant-fingerprint.json",
)
LIMITS = {"cpus": "2", "memory": "2g", "pids": 96, "tmpfsBytes": 268435456,
          "timeoutSeconds": 240, "maxResultBytes": 8 * 1024 * 1024}


def stage_tree(source, dest, *, ignore=frozenset(), confined_to=None):
    # Staging only regular files and confined links keeps the daemon's bind
    # mounts narrowly scoped and makes host-private modes readable by nobody.
    root = source if confined_to is None else confined_to
    dest.mkdir()
    for entry in sorted(source.iterdir(), key=lambda p: p.name):
        if entry.name in ignore:
            continue
        out = dest / entry.name
        mode = entry.lstat().st_mode
        if stat.S_ISLNK(mode):
            link = os.readlink(entry)
            if Path(link).is_absolute() or not entry.resolve().is_relative_to(root):
                raise ValueError(f"candidate link leaves the supplied input: {entry.relative_to(root)}")
            out.symlink_to(link)
        elif stat.S_ISDIR(mode):
            stage_tree(entry, out, ignore=ignore, confined_to=root)
        elif stat.S_ISREG(mode):
            shutil.copyfile(entry, out)
            out.chmod(0o555 if mode & 0o111 else 0o444)
        else:
            raise ValueError(f"unsupported non-file input: {entry.relative_to(root)}")
    dest.chmod(0o755)


def candidate_digest(staged):
    rows = []
    for p in sorted(staged.rglob("*")):
        if p.is_symlink():
            digest = "link=" + os.readlink(p)
        elif p.is_file():
            digest = sha256(p.read_bytes()).hexdigest()
        else:
            continue
        rows.append(p.relative_to(staged).as_posix() + "\0" + digest + "\n")
    return sha256("".join(rows).encode()).hexdigest(), len(rows)


def write_json(target, data):
    target.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile("w", dir=target.parent, prefix=".replay-", delete=False) as stream:
        json.dump(data, stream, indent=2)
        stream.write("\n")
    Path(stream.name).replace(target)


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--repo", type=Path, default=HERE / "participant/repo")
    ap.add_argument("--output", type=Path, required=True)
    ap.add_argument("--receipt", type=Path)
    ap.add_argument("--assert-baseline", action="store_true")
    ap.add_argument("--allow-scripts", action="store_true")
    args = ap.parse_args()
    candidate = args.repo.resolve(strict=True)
    if candidate == HERE or candidate in HERE.parents:
        raise ValueError("supply the candidate repository directory")
    if not ((candidate / "package.json").is_file() or (candidate / "skill-evals/shared-benchmark.json").is_file()):
        raise ValueError("supplied path does not contain candidate repository files")
    receipt_path = args.receipt or args.output.with_suffix(".runtime.json")
    if args.output.resolve() == receipt_path.resolve():
        raise ValueError("results and runtime receipt need separate destinations")
    pin = json.loads((HERE / "operator-runtime/image-pin.json").read_text())
    image_id = pin["imageId"]
    env = dict(os.environ)
    for name in ("DOCKER_HOST", "DOCKER_CONTEXT", "DOCKER_TLS", "DOCKER_TLS_VERIFY", "DOCKER_CERT_PATH"):
        env.pop(name, None)
    ident = subprocess.check_output([*DOCKER, "image", "inspect", "--format", "{{.Id}}", image_id], text=True, env=env).strip()
    if ident != image_id:
        raise ValueError("local runtime does not match the pinned image ID")
    run_name = "mermaid-case-" + uuid4().hex
    with tempfile.TemporaryDirectory(prefix="mermaid-readonly-inputs-") as tmp:
        stage = Path(tmp)
        public = stage / "participant"
        hidden = stage / "controls"
        vendor = stage / "vendor"
        trial = stage / "candidate"
        stage_tree(HERE / "participant", public)
        stage_tree(HERE / "hidden/vendor", vendor)
        stage_tree(candidate, trial, ignore={".git", "__pycache__", "node_modules"})
        hidden.mkdir()
        (hidden / "vendor").mkdir()
        for name in HIDDEN_INPUTS:
            shutil.copyfile(HERE / "hidden" / name, hidden / name)
            (hidden / name).chmod(0o444)
        hidden.chmod(0o755)
        (hidden / "vendor").chmod(0o755)
        mounts = [(public, "/case/participant"), (hidden, "/case/hidden"), (vendor, "/case/hidden/vendor"),
                  (trial, "/candidate")]
        command = [*DOCKER, "run", "--rm", "--name", run_name, "--pull=never", "--network=none",
                   "--read-only", "--user=65534:65534", "--cap-drop=ALL", "--security-opt=no-new-privileges",
                   "--pids-limit=" + str(LIMITS["pids"]), "--cpus=" + LIMITS["cpus"], "--memory=" + LIMITS["memory"],
                   "--memory-swap=" + LIMITS["memory"], "--ulimit=nofile=256:256",
                   "--ulimit=fsize=134217728:134217728", "--shm-size=32m", "--log-driver=none",
                   "--tmpfs", "/tmp:rw,exec,nosuid,nodev,mode=1777,size=" + str(LIMITS["tmpfsBytes"])]
        for source, target in mounts:
            command.extend(["--mount", f"type=bind,src={source},dst={target},readonly"])
        # Clear Docker client's automatic proxy injection as well as using the
        # image's POSIX env -i entry point for the actual evaluator process.
        for name in ("HTTP_PROXY", "HTTPS_PROXY", "ALL_PROXY", "NO_PROXY", "FTP_PROXY"):
            command.extend(["--env", name + "=", "--env", name.lower() + "="])
        command.append(image_id)
        if args.assert_baseline:
            command.append("--assert-baseline")
        if args.allow_scripts:
            command.append("--allow-scripts")
        digest, count = candidate_digest(trial)
        start = time.monotonic()
        receipt = {"imageId": image_id, "candidateSHA256": digest, "candidateFiles": count, "limits": LIMITS,
                   "inputMounts": [{"target": target, "readOnly": True} for _, target in mounts],
                   "assertBaseline": args.assert_baseline, "allowScripts": args.allow_scripts}
        with tempfile.TemporaryFile() as stdout, tempfile.TemporaryFile() as stderr:
            try:
                proc = subprocess.run(command, stdin=subprocess.DEVNULL, stdout=stdout, stderr=stderr,
                                      timeout=LIMITS["timeoutSeconds"], env=env)
                receipt["exit"] = proc.returncode
            except subprocess.TimeoutExpired:
                subprocess.run([*DOCKER, "rm", "--force", run_name], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                               timeout=15, env=env)
                receipt["exit"] = 124
            receipt["elapsedSeconds"] = round(time.monotonic() - start, 3)
            stderr.seek(0)
            diagnostic = stderr.read(131072).decode("utf-8", "replace")
            for line in diagnostic.splitlines():
                if line.startswith("RUNTIME_PROOF "):
                    receipt["runtimeProof"] = json.loads(line.removeprefix("RUNTIME_PROOF "))
                    break
            if receipt["exit"] or "runtimeProof" not in receipt:
                receipt["diagnostic"] = diagnostic[-3000:]
                write_json(receipt_path, receipt)
                raise SystemExit(f"isolated evaluator failed (exit {receipt['exit']}); details in {receipt_path}")
            if stdout.tell() > LIMITS["maxResultBytes"]:
                receipt["diagnostic"] = "result exceeded configured output size"
                write_json(receipt_path, receipt)
                raise SystemExit(receipt["diagnostic"])
            stdout.seek(0)
            result = json.load(stdout)
        write_json(args.output, result)
        receipt["resultSHA256"] = sha256(args.output.read_bytes()).hexdigest()
        write_json(receipt_path, receipt)
        print(f"Isolated evaluator completed in {receipt['elapsedSeconds']}s: {args.output}")


if __name__ == "__main__":
    main()
