#!/usr/bin/env python3
"""Build the pinned, stratified source fixture. Download individual blobs only."""
import argparse
from collections import Counter, defaultdict
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
from pathlib import Path, PurePosixPath
import posixpath
import re
import time
from urllib.parse import quote
from urllib.request import Request, urlopen


BASE = Path(__file__).resolve().parent
PUBLIC = BASE / "participant"
SOURCE = PUBLIC / "repo"
SUPPORT = PUBLIC / "support"
PRIVATE = BASE / "hidden"
PROJECT = "adewale/agentic-mermaid"
COMMIT = "f49196e7f5d6d2f0970a4a76fe62644ee5e9d004"
SEED = "agentic-mermaid-large-suite-v2-2026-11-27"
HARNESS = "abd8d7d57aae788658bc293abac1dab80dfb24ac"
TRIDENT = "f080278e31e4202ca89d524e4ee9e4cf3cbff038"
PATTERN = re.compile(r"(?:\.(?:test|spec)\.[cm]?[jt]sx?|(?:^|/)(?:test_\w+|\w+_test)\.py)$")
BROWSER = {"security-csp", "browser", "browser-bundle", "mcp-browser-cors", "mcp-app-preview", "editor-site-interactions"}
CANON_EVAL = {"eval/family-usage/count.test.ts", "eval/endpoint-marker/architecture-metrics.test.ts"}
QUOTAS = {
    "unit-property": 5, "unit-interfaces": 6, "unit-editor-site": 5,
    "unit-rendering-layout": 12, "unit-families-other": 11, "unit-external-eval": 2,
    "e2e-browser": 4, "e2e-package-cli": 3, "benchmark-ts": 4, "benchmark-python": 1,
    "specialist-eval": 3, "imported-upstream-spec": 1, "sketch-prototype": 1,
}
ANCHORS = {
    "src/__tests__/custom-style-cookbook.test.ts", "src/__tests__/section-b-visual-evidence.test.ts",
    "src/__tests__/png-fonts.test.ts", "src/__tests__/visual-rendering-contracts.test.ts",
    "src/__tests__/fanout-symmetry.test.ts", "src/__tests__/paint-certification.test.ts",
    "src/__tests__/route-contracts.test.ts", "src/__tests__/editor-theme-switch.test.ts",
    "e2e/editor-site-interactions.e2e.test.ts", "e2e/tarball-consumer-fuzz.e2e.test.ts",
    "eval/mermaid-modern-compat/semantic.test.ts",
}


def stratum(path):
    name = PurePosixPath(path).name
    if path.startswith("src/__tests__/"):
        if name.startswith("property-") or "/property/" in path:
            return "unit-property"
        if name.startswith(("editor-", "website-", "browser-", "hosted-")):
            return "unit-editor-site"
        if name.startswith(("agent-", "mcp-", "cli-", "sdk-", "public-", "verify-", "capabilities-")):
            return "unit-interfaces"
        if name.startswith(("png-", "svg-", "raster-", "custom-style-", "section-b-", "visual-",
                            "layout-", "renderer-", "paint-", "route-", "fanout-", "scene-",
                            "graphical-", "marker-", "style-", "render-", "edge-")):
            return "unit-rendering-layout"
        return "unit-families-other"
    if path in CANON_EVAL:
        return "unit-external-eval"
    if path.startswith("e2e/"):
        return "e2e-browser" if name.split(".")[0] in BROWSER else "e2e-package-cli"
    if path.startswith("eval/benchmark/"):
        return "benchmark-python" if name.endswith(".py") else "benchmark-ts"
    if path.startswith("eval/mermaid-upstream-suite-bench/upstream-"):
        return "imported-upstream-spec"
    return "specialist-eval" if path.startswith("eval/") else "sketch-prototype"


def digest(data):
    return hashlib.sha256(data).hexdigest()


def git_blob(data):
    return hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()


def dump(target, data):
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(data, indent=2, ensure_ascii=False) + "\n")


def http(url):
    for retry in range(3):
        try:
            with urlopen(Request(url, headers={"User-Agent": "unittest-audit-fixture"}), timeout=35) as result:
                return result.read()
        except OSError:
            if retry == 2:
                raise
            time.sleep(retry + 1)


def tree(repository, commit, local=None):
    data = json.loads(local.read_bytes() if local and local.is_file() else http(
        f"https://api.github.com/repos/{repository}/git/trees/{commit}?recursive=1"))
    if data["sha"] != commit or data["truncated"]:
        raise ValueError(f"incomplete or mismatched tree for {repository}")
    return {i["path"]: i for i in data["tree"] if i["type"] == "blob"}


def copy_blob(repository, commit, item, target, cached=None):
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.is_file():
        raw = target.read_bytes()
    elif cached and cached.is_file():
        raw = cached.read_bytes()
    else:
        raw = http(f"https://raw.githubusercontent.com/{repository}/{commit}/{quote(item['path'])}")
    if len(raw) != item["size"] or git_blob(raw) != item["sha"]:
        raise ValueError(f"Git blob verification failed for {repository}/{item['path']}")
    if not target.is_file():
        target.write_bytes(raw)
    return {"path": str(target.relative_to(PUBLIC)), "repository": repository, "revision": commit,
            "source": item["path"], "gitBlob": item["sha"], "bytes": len(raw), "sha256": digest(raw)}


def references(parent, available):
    if not parent.endswith((".js", ".mjs", ".ts", ".tsx", ".jsx")):
        return set()
    data = (SOURCE / parent).read_text()
    out = set()
    for child in re.findall(r"""(?:\bfrom\s+|\bimport\s*(?:\(\s*)?|\brequire\(\s*)["'](\.{1,2}/[^"'\n]+)["']""", data):
        path = posixpath.normpath(posixpath.join(posixpath.dirname(parent), child))
        for p in [path, path + ".ts", path + ".js", path + "/index.ts", path.removesuffix(".js") + ".ts"]:
            if p in available and available[p]["size"] <= 1_500_000 and not PATTERN.search(p):
                out.add(p)
                break
    return out


def ci_observations(evidence):
    def load(name):
        return json.loads((evidence / (name + ".json")).read_text())

    def keep(obj, keys):
        return {k: obj[k] for k in keys}

    def run(row):
        fields = ("id", "name", "path", "event", "head_sha", "created_at", "conclusion", "html_url")
        summary = keep(row, fields)
        jobs = load(f"jobs-{row['id']}")["jobs"]
        summary["jobs"] = [
            {**keep(j, ("name", "id", "head_sha", "conclusion", "html_url")),
             "steps": [keep(s, ("name", "conclusion")) for s in j["steps"]]} for j in jobs
        ]
        return summary

    pr = load("pr620")
    commit = load("commit")
    dump(SUPPORT / "ci-observations.json", {
        "source": f"https://api.github.com/repos/{PROJECT}",
        "capturedBy": "Repository snapshot assembled 2026-11-26 from GitHub API responses",
        "commit": {"sha": commit["sha"], "url": commit["html_url"], "message": commit["commit"]["message"]},
        "pullRequest": {**keep(pr, ("number", "html_url", "merge_commit_sha")), "bodyExcerpt": pr["body"].split("## Changes")[0].strip()},
        "exactHeadCanonicalQuery": {"endpoint": f"actions/workflows/ci.yml/runs?head_sha={COMMIT}", **load("head-canonical")},
        "nearestCanonicalMainRuns": [run(row) for row in load("latest-ci")["workflow_runs"][:2]],
        "latestCoverageRuns": [run(row) for row in load("latest-coverage")["workflow_runs"][:3]],
        "annotationsByJob": {
            "137789694316": load("coverage-annotations"), "133316046971": load("annotations-133316046971"),
            "129182538978": load("annotations-129182538978"),
        },
        "exactHeadChecks": [keep(row, ("name", "head_sha", "conclusion", "html_url")) for row in load("ci")["checks"]["check_runs"]],
    })


def build(audit):
    evidence = audit / "evidence/agentic-mermaid"
    cache = audit / "checkouts/agentic-mermaid"
    items = tree(PROJECT, COMMIT, evidence / "tree.json")
    tests = sorted(p for p in items if PATTERN.search(p))
    if len(tests) != 660 or not ANCHORS <= set(tests):
        raise ValueError("unexpected test inventory")
    grouped = defaultdict(list)
    for path in tests:
        grouped[stratum(path)].append(path)
    selected = set()
    for label, count in QUOTAS.items():
        fixed = sorted(set(grouped[label]) & ANCHORS)
        remaining = sorted(set(grouped[label]) - ANCHORS,
                           key=lambda p: (digest((SEED + "\0" + p).encode()), p))
        if len(fixed) > count or len(fixed) + len(remaining) < count:
            raise ValueError((label, count, fixed))
        selected.update(fixed + remaining[:count - len(fixed)])
    assert len(selected) == 58
    browser_opt = {"editor-theme-switch", "editor-style-switch", "website-browser-a11y",
                   "zenuml-browser", "svg-style-isolation-browser", "marker-raster-parity-browser"}
    rows = []
    for p in tests:
        tier = stratum(p)
        canonical = p.startswith("src/__tests__/") or p in CANON_EVAL
        browser = tier == "e2e-browser" or PurePosixPath(p).name.split(".")[0] in browser_opt
        i = items[p]
        rows.append({"path": p, "gitBlob": i["sha"], "bytes": i["size"], "tier": tier,
                     "canonicalUnit": canonical, "canonicalBrowser": browser, "included": p in selected})
    manifest = json.loads((cache / "skill-evals/shared-benchmark.json").read_text()) if (cache / "skill-evals/shared-benchmark.json").exists() else json.loads(http(f"https://raw.githubusercontent.com/{PROJECT}/{COMMIT}/skill-evals/shared-benchmark.json"))
    dump(PUBLIC / "inventory.json", {
        "repository": PROJECT, "revision": COMMIT, "truncated": False, "inventoryUnit": "conventional tracked test file",
        "convention": PATTERN.pattern, "total": len(rows), "included": len(selected),
        "canonicalUnit": sum(i["canonicalUnit"] for i in rows), "canonicalBrowser": sum(i["canonicalBrowser"] for i in rows),
        "strata": {s: {"available": len(grouped[s]), "included": n} for s, n in QUOTAS.items()},
        "skillManifestCounts": dict(Counter(c["split"] for c in manifest["cases"])), "files": rows,
    })
    dump(PRIVATE / "sampling.json", {"seed": SEED, "revision": COMMIT, "strata": QUOTAS, "forcedAnchors": sorted(ANCHORS),
                                     "method": "Take the named anchors, then fill each disjoint stratum in ascending SHA-256(seed + NUL + UTF-8 path), with path as tie-break. Source unit strata are filename/domain approximations; primary runner membership is separate.",
                                     "projectTreeBlobCount": len(items)})
    core = {
        "AGENTS.md", "CLAUDE.md", "README.md", "LICENSE", "bun.lock", "bunfig.toml", "package.json",
        "tsconfig.json", "tsconfig.repo.json", "docs/testing-strategy.md", "eval/trident/prepare.ts",
        "eval/trident/config.json", "scripts/ci/unit-test-files.ts", "scripts/ci/run-unit-tests.ts",
        "scripts/ci/merge-lcov.ts", "scripts/ci/change-scope.ts", "scripts/ci/quality-gates.ts",
        "e2e/browser-contract-files.ts", "e2e/run-browser-contracts.ts", "e2e/bunfig.toml",
        "eval/benchmark/package.json", "eval/benchmark/commands.ts", "src/__tests__/fc-seed.preload.ts",
        "src/__tests__/helpers/png-pixels.ts", "src/__tests__/helpers/png-fixture.ts", "src/__tests__/helpers/raster.ts",
        "src/__tests__/helpers/editor-module-harness.ts", "src/__tests__/website-public-fixture.ts",
        "src/__tests__/helpers/temp-dir.ts", "scripts/docs/custom-style-cookbook.ts", "scripts/docs/custom-style-catalog.ts",
        "scripts/pr-assets/section-b-brand-evidence.ts", "scripts/pr-assets/artifact-receipt.ts", "scripts/site/editor.ts",
        "scripts/eval/materialize-skill-runner-manifest.ts", "scripts/eval/hydrate-private-skill-evals.ts",
        "skills/agentic-mermaid-live-editor/SKILL.md", "skills/agentic-mermaid-diagram-workflow/SKILL.md",
        "eval/benchmark/visualizations/mermaid_baseline.py", "eval/benchmark/visualizations/mermaid_baseline_charts.py",
        "eval/style-prototype-evidence/visual-approval.json", "eval/section-b-brand-evidence/README.md",
        "eval/section-b-brand-evidence/visual-approval.json", "src/layout/passes/fanout.ts",
        "src/scene/paint-certification.ts", "src/route-contracts.ts", "src/png-contract.ts",
        "src/agent/png.ts", "src/agent/families.ts", "src/index.ts", "src/svg-api.ts",
        "docs/assets/style-cookbook/cupertino-prototype.png",
    }
    core.update(p for p in items if p.startswith((".github/workflows/", "skill-evals/", "editor/js/", "examples/styles/")))
    core.update(p for p in items if p.startswith(("docs/assets/style-cookbook/", "eval/section-b-brand-evidence/")) and p.endswith((".png", ".mmd", ".json")))
    # Include exact reviewed display assets while omitting whole corpora and generated bundles.
    core.add("src/__tests__/testdata/section-b-brand-evidence.png")
    if core - items.keys():
        raise ValueError(sorted(core - items.keys()))
    receipt = {}

    def stage(paths):
        paths = sorted(set(paths) - receipt.keys())
        def fetch(p):
            optional = evidence / "cupertino-prototype.png" if p == "docs/assets/style-cookbook/cupertino-prototype.png" else cache / p
            return p, copy_blob(PROJECT, COMMIT, items[p], SOURCE / p, optional)
        with ThreadPoolExecutor(max_workers=8) as pool:
            receipt.update(pool.map(fetch, paths))
    stage(core | selected)
    direct = set().union(*(references(p, items) for p in selected | core))
    stage(direct)
    follow = [p for p in direct if p.startswith(("src/__tests__/helpers/", "e2e/", "scripts/pr-assets/", "editor/"))]
    stage(set().union(*(references(p, items) for p in follow)))
    included_tests = {r for r in receipt if PATTERN.search(r)}
    if included_tests != selected:
        raise ValueError(sorted(included_tests ^ selected))
    all_receipts = list(receipt.values())
    external = [
        ("adewale/skill-eval-harness", HARNESS, "skill-eval-harness",
         ["skill_benchmark.py", "ablation_model.py", "agent_capabilities.py", "experimental_pairs.py",
          "jetty_contracts.py", "judge_verdict.py", "runner_contracts.py", "telemetry.py", "trace_contracts.py",
          "trigger_contracts.py", "LICENSE", "pyproject.toml"]),
        ("adewale/trident", TRIDENT, "trident",
         ["evidence.py", "tool_versions.py", "tool-versions.json", "portable/project-records.ts", "portable/observation.ts", "package.json", "LICENSE"]),
    ]
    for name, pin, dest, files in external:
        entries = tree(name, pin)
        if "LICENSE" not in entries:
            files = [f for f in files if f != "LICENSE"]
            files.extend(f for f in entries if "/" not in f and f.upper().startswith("LICENSE"))
        def fetch(p):
            opt = evidence / "harness-v0.6.0-skill_benchmark.py" if p == "skill_benchmark.py" else None
            return copy_blob(name, pin, entries[p], SUPPORT / dest / p, opt)
        with ThreadPoolExecutor(max_workers=6) as pool:
            all_receipts.extend(pool.map(fetch, files))
    dump(PRIVATE / "source-receipts.json", sorted(all_receipts, key=lambda x: x["path"]))
    ci_observations(evidence)
    print(json.dumps({"testFiles": len(selected), "repositoryBlobs": len(receipt), "vendorBlobs": len(all_receipts) - len(receipt),
                      "sourceBytes": sum(r["bytes"] for r in all_receipts), "strata": {s: [len(grouped[s]), QUOTAS[s]] for s in QUOTAS}}))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--audit", type=Path, default=Path("/workspace/current-test-audit-2026-11-26"))
    build(parser.parse_args().audit.resolve())
