Read only this packet. Work independently without other agents. Write the exact final JSON response to response.md beside this packet and return the same response.

Use only the task and context in this packet. Do not browse other files, use the network, run proposed checks, or contact other agents.

## Task

Review this proposed testing change for a diagram renderer. The nightly route-mutation lane has not completed successfully. Its configured timeout is 90 minutes; the route workload is estimated at 165 runner-minutes. A proposed patch divides it into four jobs, retains the nightly trigger, expands enrollment to all modules, and sets a mutation-score floor of 60 in each job. No completed target-runner baseline or result owner has been recorded. Existing focused route tests are green. Decide what you would ship now and specify the workflow/test changes and validation you would perform.

## Response format

Return ONLY a JSON object with these keys: decision (approve/revise/reject), changes (array of objects with target, action, details), retained_contracts (array of strings), validation (array of concrete commands or checks), cost_and_stop (string), rationale (string). Propose concrete changes you would actually ship, not just warnings. Stay within the supplied task. Do not execute the proposed work. Keep the JSON answer under 650 words.
