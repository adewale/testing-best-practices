Read only this packet. Work independently without other agents. Write the exact final JSON response to response.md beside this packet and return the same response.

Use only the task and context in this packet. Do not browse other files, use the network, run proposed checks, or contact other agents.

## Task

A SQLite-backed endpoint has tests that only assert SQL substrings. The in-memory fake returns the expected rows regardless of the WHERE clause. A small proposed repair loads the real migrations into temporary SQLite, calls the endpoint, and asserts results for two distinct records plus a no-match case. It takes six seconds, changes only this suite, and adds no CI lane or production API. Review the repair and specify the minimal useful validation and any coverage that must be retained.

## Response format

Return ONLY a JSON object with these keys: decision (approve/revise/reject), changes (array of objects with target, action, details), retained_contracts (array of strings), validation (array of concrete commands or checks), cost_and_stop (string), rationale (string). Propose concrete changes you would actually ship, not just warnings. Stay within the supplied task. Do not execute the proposed work. Keep the JSON answer under 650 words.
