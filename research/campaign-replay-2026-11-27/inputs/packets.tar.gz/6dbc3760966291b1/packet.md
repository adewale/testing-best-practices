Read only this packet. Work independently without other agents. Write the exact final JSON response to response.md beside this packet and return the same response.

Use only the task and context in this packet. Do not browse other files, use the network, run proposed checks, or contact other agents.

## Task

A release importer consumes an immutable archive whose published manifest commits to its exact bytes. A test intentionally corrupts the archive and expects rejection. The importer implementation is being refactored, while the archive and public integrity contract remain fixed. A cleanup proposal removes all hashes and substitutes parsed-content equality because formatting-only changes can otherwise alter an archive's digest. Review the cleanup and specify what should remain fixed, what may change, and which checks to keep.

## Response format

Return ONLY a JSON object with these keys: decision (approve/revise/reject), changes (array of objects with target, action, details), retained_contracts (array of strings), validation (array of concrete commands or checks), cost_and_stop (string), rationale (string). Propose concrete changes you would actually ship, not just warnings. Stay within the supplied task. Do not execute the proposed work. Keep the JSON answer under 650 words.
