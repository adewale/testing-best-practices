Read work/task.md and complete that assignment in work/repo/. Only use this cell's packet, work directory, supplied guidance and locally provisioned project runtimes. Work independently. Keep all source edits in your disposable copy. The controller starts the 25-minute clock after the workspace and dependencies are ready.

Use local offline commands. Leave network services, deployments, upstream repositories, controller and evaluator materials, other cells, prior audits, credentials, and other agents outside this assignment. The runtime notes in work/ give the applicable native commands. Dependencies are provisioned before launch. The host's installed runtime and provisioned dependencies are for local execution.

Deliver your exact final report in response.md beside this packet and return the same report. Also save an identical report under work/ if the assignment specifies that location. Leave the actual changed files in work/repo/. Include which files you inspected, which selections actually ran and their results, and limits on your claims.

Your supplied guidance begins at guidance/testing-best-practices/SKILL.md. Consult its linked files as applicable.
