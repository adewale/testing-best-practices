Read only this packet. Work independently without other agents. Write the exact final JSON response to response.md beside this packet and return the same response.

Use only the task and context in this packet. Do not browse other files, use the network, run proposed checks, or contact other agents.

## Supplied guidance: testing-best-practices/SKILL.md

---
name: testing-best-practices
description: >
  Enforce testing best practices when writing, reviewing, or improving tests.
  Covers TDD/red-green-refactor, property-based testing, real objects over
  mocks, correctness by construction, assertion quality, E2E/contract tests,
  flaky-test upgrades, mock-reality drift, mutation-style gap analysis, and
  sabotaged/skipped/weak tests. Use when writing tests, reviewing test quality,
  fixing flaky tests, improving coverage quality, or when the user mentions
  TDD, testing, coverage, mocks, invariants, types vs tests, defense in depth,
  fuzzing, generative testing, or test quality.
compatibility: Agent Skills clients including Codex, OpenCode, Pi, Gemini CLI, and Claude Code.
metadata:
  author: adewale
  version: "0.3.1"
---

# Testing Best Practices

This skill has four modes:

1. **Write** — add tests or test-first bug fixes/features.
2. **Assess** — review an existing suite for quality, not just coverage.
3. **Upgrade** — strengthen weak/flaky/over-mocked tests.
4. **Detect** — find skipped, sabotaged, fake-coverage, or gap-prone tests.

## First 90 seconds

Before writing, assessing, or changing tests:

1. **Detect language/framework** from repo files and adjacent tests.
2. **Read nearby tests** for naming, fixtures, builders, assertion style, and runner commands.
3. **Find the nearest validation command** before broad full-suite commands.
4. **Identify the risk boundary**: pure logic, internal component boundary, external API, UI/user journey, security boundary, hostile-input parser, or type/schema invariant.
5. **Classify the change and asset**: behavior change vs. structure/tidying, reusable library vs. throwaway probe, customer-facing rule vs. internal helper.
6. **Choose the smallest useful test tier** from `references/test-types.md`.
7. **Load only relevant references** from the matrix below.

If the language is unsupported by a dedicated reference, follow project conventions plus the generic principles here.

## Reference matrix

Always consider:
- Test type selection → `references/test-types.md`
- Anti-pattern detection → `references/antipatterns.md`

Language/framework references:
- Python / pytest / Hypothesis → `references/python.md`
- TypeScript/JavaScript / Vitest/Jest/fast-check/Playwright → `references/typescript.md`
- Go / testing / testing.F / Rapid → `references/go.md`
- Rust → `references/rust.md`

For property-based testing or coverage-guided fuzzing, also load the matching language reference: collection, discovery, and replay differ by engine. If the selected engine is not documented here, follow its project documentation rather than transferring another engine's behavior.

Topical references by trigger:
- Auditing, repairing, consolidating, or deleting existing tests → `references/test-audit.md`. Start with candidates; record contracts, expected-value provenance, decisions, and remaining proof before edits. Compare old and keeper tests against the same credible faults when moving contracts.
- Writing/reviewing property tests, choosing a property, generator design, stateful/model-based testing, seeds and replay → `references/property-based-testing.md`
- Coverage-guided targets or campaigns for exposed/custom parsers, native or unsafe decoders, crash-prone boundaries, or security tooling whose crash disables a check → `references/fuzzing.md`
- Legacy/refactor safety → `references/characterization-testing.md`
- Reimplementation, port, multi-language SDK, custom data structure with no reference, or approximate/probabilistic/ANN/ranking output → `references/differential-testing.md`
- Complex outputs, snapshots, transformation pipelines, save/load or migration roundtrips → `references/golden-file-testing.md`
- Time, timers, schedules, sleeps, flaky time tests, background threads/async work tests can only reach by sleeping → `references/deterministic-time.md`
- External APIs, recorded real responses, mock drift → `references/vcr-cassettes.md`
- CLI/plugin/docs registry sync, or verification claims in docs and agent instructions → `references/doc-sync-testing.md`
- Mutation testing, mutation scores/survivors, recurring mutation lanes, or high coverage but escaping bugs → `references/mutation-testing.md`. For recurrence, no completed target-CI baseline or demonstrated fault-class bite means no schedule; never copy an absolute score floor.
- Finite state spaces or expensive cross-products → `references/exhaustive-testing.md`
- Large configuration/feature/runtime matrices, pairwise replacement, or interacting factors → `references/combinatorial-testing.md`. Preserve fixed regressions and exact registry enrollment; use named variable-strength groups and shadow evidence before deletion.
- Arithmetic/domain operators/laws → `references/mathematical-properties.md`
- Fixtures/builders/assertion helpers → `references/test-data-builders.md`
- Same invariant checked across layers, type-vs-test decisions, invalid states → `references/correctness-by-construction.md`
- CI/hooks/test-config changes, gated or scheduled tiers, "is this check running and can it fail?", deploy verification → `references/gate-integrity.md`

## Core principles

### Test behavior through public contracts

Good tests describe observable behavior: outputs, state transitions, side effects, rendered UI, persisted data, API contracts, or invariants. Avoid tests that break under behavior-preserving refactors: private methods, incidental call order, exact SQL strings, or broad mock choreography.

When a user brings examples, tables, bug reports, spreadsheet rows, or support cases, treat them as communication artifacts first and assertions second. Preserve the business language, then run the examples against the narrowest honest seam: usually the domain/service/API contract, not a full UI path for every business-rule row. UI/E2E tests should prove the wiring and golden path; rule tables should exercise the domain layer directly.

### Calibrate test investment to lifetime and change kind

Do not give every artifact the same test plan. Reusable libraries, parsers, payment/auth/security boundaries, migrations, and code that will be refactored deserve stronger regression/property/contract coverage. Throwaway probes, one-off research scripts, or generated exploration may need only a smoke check or no tests if the user accepts that lifecycle.

Separate **behavior changes** from **structure changes**. Behavior changes need tests that can fail for the new/changed behavior. Pure tidying/refactoring should ride an existing green suite; if no such suite exists, add characterization tests for the behavior you need to preserve before refactoring.

For a new service with no pipeline, start with a walking skeleton: the thinnest build/deploy/test slice. Track unfinished acceptance tests as visible in-progress items tied to a story/issue, not silent skips. Keep unit tests green; do not commit failing unit tests as proof.

### Use red-green-refactor when feasible

For bug fixes and new behavior, default to:

1. **Red** — add a focused test that fails for the current bug/missing behavior.
2. **Green** — implement the smallest change that passes.
3. **Refactor** — clean up while tests stay green.

The evidence matters. Separate **red evidence** (exact command and failing output before the fix) from **green evidence** (passing command/result after the fix). Only claim completed TDD/red-green-refactor when both were observed in order. If only a passing/green run is available, say tests were added and now pass, but the red phase was not observed/unverified; do not backfill a TDD claim from a green-only log. For exploratory prototypes, generated code, or user-scoped “tests only” tasks, stay within scope and state the deviation.

When practicing TDD, keep a visible **test list**. Park new edge-case ideas there instead of chasing them mid-cycle. If stuck, downshift: write the assertion first, extract a smaller child test, use a learning test for third-party APIs, or use a crash-test-dummy fake to trigger hard error paths. Choose Fake It, Triangulate, or Obvious Implementation according to uncertainty; never leave fake constants as the final behavior.

### Quality beats coverage

Coverage shows what ran; it does not prove bugs would be caught. Prefer branch coverage over line coverage and treat coverage as a map for finding untested paths, not a quality gate by itself.

Assertion count is a heuristic, not a law; never turn it into a quota. Example-based behavior tests often need multiple meaningful assertions to verify structure, state, and negative cases. But a property test, table row, or exception test may have one excellent oracle. Flag weak sole assertions such as “not empty,” `toBeDefined()`, `toBeTruthy()`, `Assert.IsNotNull(result)`, or logging without assertions.

For sanitizers, validators, filters, auth/security checks, and transformations, verify both directions where applicable: dangerous/invalid content is rejected or removed, and safe/valid content is preserved.

Assert the fields the behavior under test is about. Full-object/whole-structure equality implicitly asserts every unrelated field, so the test breaks on unrelated changes and joins a change-detector treadmill (update the literal each time a field is added). Reserve whole-state comparison for tests where breadth is the contract — golden files and save/load roundtrips (`references/golden-file-testing.md`). Prefer assertion forms whose failure message alone can start the debugging (matchers/fluent asserts that print expected vs. actual, not bare booleans); when many tests keep breaking for innocent reasons like iteration order, fix the assertion vocabulary (order-insensitive/structural matchers), not each test. For coverage, gate new/changed code rather than one repo-wide number, and read what is *not* covered as the review signal.

Every custom oracle, linter, validator, fixer, or eval grader needs a known-good input that passes and a known-bad input that fails; keep them small, and don't rerun an expensive checker for every bad input. Goldens, approvals, or eval cases written by the same actor in the same change as the code are characterizations, not independent oracles.

### Prefer real behavior over mocks

Prefer, in order:

1. Real in-memory/local objects, temp dirs, in-memory databases, real parsers.
2. Local emulation of the real runtime (workerd/vitest-pool-workers, Pyodide in Node, `wrangler dev`, SQLite loaded from migrations).
3. Purpose-built fakes that implement the same interface and can record history.
4. Deterministic stubs for controlled edge cases.
5. Framework mocks as a last resort.

Take a double's expected values from the real service (recorded or locally emulated), never from the mock author's belief; when a real engine can run in-process, delete the mock.

Prefer visible state over call choreography: assert the saved row, emitted event, response body, file on disk, or a small logging fake's recorded effects. Do not mock values; construct them. Mock roles you own, not third-party libraries directly; wrap provider SDKs behind an owned interface and add a contract/VCR check for the real provider shape. For interaction tests, allow queries and expect commands: getters can be called freely, side-effecting commands are where expectations earn their keep.

### Use properties for broad input spaces

Use property-based testing when behavior spans a broader input or operation space than examples can cover economically. Choose a property that states meaningful behavior—roundtrip, idempotence, conservation, metamorphic relation, algebraic law, or agreement with a small model—not merely that execution did not crash.

Match the generator to the behavior being tested: arbitrary input for totality and documented errors, specification-valid input for semantic branches, stateful traces for lifecycle behavior, and corpus mutation for coverage-guided discovery. Use an oracle independent of the implementation. Property tools construct values and shrink failures; coverage-guided fuzzers mutate a corpus toward new control flow. Do not use the terms or tools interchangeably.

For small finite spaces, prefer exhaustive generation over sampling, after checking per-cell cost and whether a cheaper layer decides the property (`references/exhaustive-testing.md`). See `references/property-based-testing.md` for generator, oracle, execution, and replay guidance.

### Test error-handling paths, not just invalid input

Most critical production failures are shallow: they live in error-handling code that only runs when a dependency *already* failed — a disk-write error, a dropped connection, a timeout, a partial response. Empirical studies of catastrophic distributed-systems failures find the majority were reachable by simple tests that exercised those paths. So "sad path" means more than rejecting bad arguments: inject the downstream failure (a fake/stub that raises, an injected I/O error, a `side_effect` exception) and assert the system degrades correctly.

Assert the failure behavior the code *actually* has, not one you wish it had. Read the spec or observe the code to learn what a failure should do — propagate, retry, wrap, fall back, roll back — and test that. Do not invent a retry budget, a custom error type, or rollback semantics the contract never promised; that tests a fictional contract and is scope creep. If the intended failure behavior is unspecified, characterize what the code does today and flag the gap as a follow-up rather than designing new production behavior inside a test.

### Push internal invariants into types/schemas/contracts

Types and tests answer different questions:

- Types/schemas/contracts: “Can this invalid state exist?”
- Tests: “Does observable behavior match the spec?”

When an invariant is repeated across internal layers, consider lifting it to a boundary parser, smart constructor, schema, sealed enum, state machine, or database constraint. Before deleting checks or their tests, verify all of this:

- the context is internal and non-adversarial,
- the invariant is actually enforced by the type/schema/constructor,
- boundary tests cover hostile or malformed input,
- security/auth/external-failure layers defend different failure modes,
- production type changes are in scope or explicitly approved.

If user scope says “tests only” or “do not change production code,” add tests for the current API and list type/schema tightening as a follow-up.

### Test concurrent code under a race detector, and pin the concurrency contract

For code meant to be used by multiple goroutines/threads, sequential tests prove almost nothing. Drive the shared state from many workers released together (a start barrier maximizes contention) and run under a race detector or thread sanitizer (`go test -race`, ThreadSanitizer / `-fsanitize=thread`, repeated runs via `-count`). Treat a green concurrent test as weaker evidence than a sequential one — races are probabilistic.

Assert the invariant the API actually promises — no lost updates, a monotonic/linearizable count, compute-at-most-once — instead of logging whatever count you happened to observe and moving on. If the implementation can violate that contract (e.g. it computes outside the lock, so two callers double-compute), that is a defect to surface with a failing test or an explicit flag, not a `t.Logf` that quietly bakes the race into the expected behavior.

## Mode workflows

### Write mode

Before adding a test, name the observable contract, a credible regression it catches, and why existing proof misses it. Extend an existing test or table when it covers the same contract; another layer needs a distinct risk. If the test requires exposing internals solely for access, look for a real production boundary first.

1. Read adjacent tests/config and load the relevant language reference.
2. Choose test tier from `references/test-types.md`.
3. For bugs/new behavior, add the failing regression test first when feasible.
4. Convert user/customer examples into readable test cases without forcing every example through the UI.
5. Use builders/factories/helpers where setup noise hides intent; test custom helpers when they become a mini-DSL.
6. Prefer user-facing/public interfaces over internals.
7. Pin nondeterminism: time, randomness, network, filesystem, order.
8. Choose test values deliberately: include distinct, non-default values so at least one case would expose a dropped, defaulted, or swapped argument. Still cover zero, empty, and equal-value cases when they are boundaries or part of the contract. Derive expected results independently of the SUT: literals are clearest for simple examples, while properties or a genuinely independent reference model fit broader cases. Do not recompute the expectation with the SUT's own logic or constants, because the test can share its bug and stay green.
9. Run the nearest tests, then broader checks when practical.

For transformations or complex generated output, use golden files with explicit review discipline; see `references/golden-file-testing.md`. For external APIs, prefer recorded real fixtures/cassettes or contract checks over live CI calls; see `references/vcr-cassettes.md`.

### Assess mode

For a test-quality sweep, use `references/test-audit.md` to turn detection signals into evidence-backed retain/repair/consolidate/delete decisions. Search hits alone do not justify edits.

Report evidence by severity and include positive observations. For generative tests, load the relevant language and topical references before recommending engine-specific changes. Check:

0. **Is it running, and can it fail?** For each tier: the job that runs it, its last result on the default branch, whether gated tests are reachable, and whether each gate can go red (`|| true`, `continue-on-error`, baseline updaters, skip-green, empty targets). A dead gate is the first finding. See `references/gate-integrity.md`.
1. **Sabotage / false confidence**: skipped/focused tests, no assertions, logging-not-asserting, commented-out assertions, always-true assertions.
2. **Oracle strength**: weak sole assertions, missing negative/error/state/structural assertions, tautologies. For property tests, a bare never-crashes oracle is weak when a semantic invariant is available.
3. **Mock-reality drift**: hardcoded mocks that would not notice real API/schema changes.
4. **Tier integrity**: unit tests hitting live network, integration tests mocking every boundary they claim to exercise, E2E tests that mock the system under test or drive it through a test facade, PR suites that target production, and whether the artifact under test is the artifact deployed.
5. **Determinism**: sleeps, wall-clock time, unseeded random, order dependence, global state leaks.
6. **Coverage quality**: branch coverage; for high-coverage suites with escaping bugs, seed a fault on the critical path and see whether any test fails, cheapest first (`references/gate-integrity.md` §5). A recurring mutation lane is not a default recommendation.
7. **Invariant placement**: repeated internal validation that should be a type/schema/contract.
8. **Lifecycle fit**: throwaway probes over-tested, reusable assets under-tested, or structure-only changes getting behavior-test theater.
9. **Example quality**: business examples buried in UI scripts, unreadable fixtures, or helpers that form a DSL but have no tests of their own.
10. **Generative evidence**: the configured runner reaches the production path, the generator reaches the claimed domain, the oracle is independent, and seed replay is not mislabeled as active discovery. Verify the exact CI configuration when multiple runners, projects, filters, or duplicated target lists make reachability uncertain; add a permanent drift guard only for recurring risk.
11. **Test-code readability (DAMP)**: logic in test bodies (loops/branches/computed expectations), expectations derived from the SUT's own constants, shared fixtures mutated far from the assertions that depend on them. See `references/antipatterns.md`.
12. **Suite shape**: count tests per tier; name the inverted pyramid/ice-cream cone (mostly E2E over a thin unit base) and the hourglass (unit + E2E with an empty integration middle). Recommend the smallest-tier home for each E2E case that has one — business rules move below the UI — while keeping a small golden-path/critical-journey E2E core.

### Upgrade mode

When consolidating or deleting tests, use `references/test-audit.md`: name the keeper and preserve distinct assertions before removal. Record no-contract deletions explicitly; do not fabricate replacement tests.

Prioritize by risk:

1. **P0**: security/auth/injection/sanitizer tests with weak or missing assertions.
2. **P1**: tests that only assert not-null/not-empty/truthy.
3. **P2**: flaky tests: sleeps, live network, wall-clock, order coupling. Before patching waits, ask whether a smaller SUT can host the test — size (dependencies, processes, RAM footprint) predicts flakiness better than tool choice — and treat auto-retry/quarantine as masking debt, not a fix.
4. **P3**: mock-heavy “integration” tests and implementation-coupled mocks.
5. **P4**: fixture noise, duplication, unclear names, missing builders.

Common upgrades:
- Replace `sleep()` with virtual time, injected clocks, or condition-based waits.
- Replace live API calls with recorded cassettes or committed fixtures.
- Replace broad mocks with fakes, contract tests, or assertions on public behavior.
- Replace repeated object literals with builders that keep behavior-specific fields explicit.

Never silently downgrade a tier: list removed or replaced tests by tier, and keep real-engine tests (SQLite, workerd, browser) unless an equal or stronger tier replaces them. A lesson or postmortem counts only when a check enforces it.

### Detect mode

Use concrete search signals from `references/antipatterns.md`:

- `@skip`, `skip`, `skipif` without real condition, `test.only`, `fit`, `xit`, `xdescribe`.
- `print`, `console.log`, `t.Log`, `Debug.WriteLine` used instead of assertions.
- Assertion-free tests or only truthy/not-empty/not-null checks.
- Property tests with no independent oracle, generators filtered into one easy path, or small finite domains sampled when they can be enumerated.
- `sleep`, `waitForTimeout`, `Thread.Sleep`, `Task.Delay` for synchronization.
- Try/catch swallowing exceptions.
- Mock return values identical to assertions.
- Global state/env/registry mutations without cleanup.
- Snapshot/golden updates without diff review.
- CI steps with `|| true`, `continue-on-error`, `scan --baseline`, or `::warning::` skips; coverage or mutation thresholds that never run.
- Mutation run as a program: calendar schedules over unchanged code, round-number floors, internals exported or pinned only to kill survivors.
- Assertions only inside loops over possibly-empty results; `violations == []` with no non-empty check; tests that import nothing from the code under test.
- Source, CSS, or workflow text read and asserted as strings; helper-level retry loops; raised global timeouts or `isCI ? a : b` budgets.

## Validation loop

After writing or changing tests:

1. Run the nearest relevant test command.
2. If bug-fix TDD was intended, report red evidence separately from green evidence; if the pre-fix failing run was not observed, call the red phase unverified instead of claiming completed TDD.
3. Scan the changed tests for weak sole assertions, skips/focus markers, logging-not-asserting, sleeps, live network, and implementation-detail coupling. Also check: expected results come from an oracle independent of the SUT, at least one test value would expose dropped/defaulted/swapped inputs, relevant boundary values are still covered, and assertions are narrow to the behavior's fields.
4. For security/transformation tests, verify both rejection/removal and preservation.
5. For invariant work, verify both tactics where relevant: property/invariant proof and invalid-state reachability.
6. For property/fuzz tests, confirm the claimed input domain, independent oracle, engine-native replay, and—where configuration makes it uncertain—collection or target selection with the exact CI command.
7. Decide pass/fail from exit status, not output text. Run the exact CI entrypoint rather than a sub-mode, and compile tag-gated files you touched with their tags.
8. When repairing CI, keep "update a stale selector" separate from "weaken an assertion or raise a timeout", and justify every weakening. Call a failure pre-existing only after reproducing it on a clean checkout of the base.
9. If validation is blocked, report the exact command, failure, and next-best check. Never claim tests passed without running them; say which environment a green claim came from, and check the pushed commit's CI when there is one.

## Final report contract

End testing work with:

```md
Tests changed/assessed:
Behavior covered:
Commands run:
Results:
CI status (ran / red / not running):
TDD evidence (if claimed):
Gaps / risks:
Follow-ups:
```

Keep it concise, but make validation and remaining risk auditable.


## Supplied guidance: testing-best-practices/references/golden-file-testing.md

# Golden File and Snapshot Testing

Two closely related patterns for asserting on complex output:

- **Golden files**: input file → output file, both on disk. Auto-discovered.
  Best for transformation pipelines (HTML→Markdown, compilers, code generators).
- **Snapshot tests**: any expression → stored string. Lives in or beside the
  test file. Best when an assertion would otherwise be a long, brittle
  field-by-field comparison.

Both can use an explicit **promote workflow**: generate a candidate in authoring
mode, review it against the intended contract, then commit it. Verification is
read-only: missing or different expected output fails, and CI never creates or
updates baselines. Hand-written contract-derived expectations are also valid.

## Golden Files

### How it works

1. Put input files in `tests/fixtures/`
2. Run the transformation and save output to `tests/expected/`
3. On subsequent runs, compare output against expected files
4. If no expected file exists, fail without writing one
5. To update: use a separate authoring command to generate a candidate, review
   its behavioral changes, and explicitly accept it

### The pattern (from kepano/defuddle)

```typescript
describe('Fixtures Tests', () => {
  const fixtures = getFixtures();  // Auto-discovers all .html files

  test.each(fixtures)('should process: $name', async ({ name, path }) => {
    const input = readFileSync(path, 'utf-8');
    const result = transform(input);
    const expected = loadExpected(name);

    if (expected === undefined || expected === null) {
      throw new Error(`Missing reviewed golden: ${name}`);
    }

    expect(result.trim()).toEqual(expected.trim());
  });
});
```

### Auto-discovery helper

```typescript
function getFixtures() {
  const dir = join(__dirname, 'fixtures');
  return readdirSync(dir)
    .filter(f => f.endsWith('.html'))
    .map(f => ({ name: basename(f, '.html'), path: join(dir, f) }));
}
```

### Why golden files work

- **Zero-code test creation**: add a fixture file = add a test case
- **Human-readable expected output**: Markdown/text, not binary
- **Real-world inputs**: actual web pages, documents, source files
- **Drift detection**: any change to transformation logic is caught

### When to use
- HTML → Markdown extraction
- Code formatting / pretty-printing
- Template rendering, compiler output
- Data migration / transformation pipelines

### Naming convention

Use `category--source-description.extension`:
```
codeblocks--stripe.html
comments--news.ycombinator.com.html
```

## Snapshot Tests (the promote workflow)

Snapshot tests generalize the golden-file idea: any string-renderable output
becomes the expected value, captured on first run, asserted on subsequent
runs. The expected output lives **inside** the test file (inline) or in a
sidecar (`__snapshots__/`), not in a separate fixtures tree.

### The promote workflow

1. Write the test with an empty expected slot; ordinary verification must fail
2. Run the framework's explicit update/authoring command to generate a candidate
3. Subsequent runs: framework compares actual vs expected, fails with a diff
4. When the change is intentional: run with `--update` (or interactive review)
5. **Commit the snapshot file with the code change** — the snapshot diff in
   your PR is the record of what observable behavior changed

### Tools per language

| Language | Tool | Update command |
|----------|------|----------------|
| Python | `syrupy` | `pytest --snapshot-update` |
| JS/TS | Jest, Vitest | `jest -u`, `vitest -u`, or interactive `u` in watch mode |
| Rust | `insta` | `cargo insta review` (interactive), `cargo insta accept` |
| Go | `cupaloy` | `UPDATE_SNAPSHOTS=true go test` |
| Multi-language | `approvaltests` | `*.received.txt` → rename to `*.approved.txt` |

### Python (syrupy) example

```python
def test_render_invoice(snapshot):
    invoice = Invoice(items=[Item("Widget", 9.99, 2)], tax_rate=0.08)
    assert invoice.render() == snapshot
```

Generate and review `__snapshots__/test_invoice.ambr` with
`pytest --snapshot-update`. Ordinary runs compare and must fail if it is missing.

### Rust (insta) — the inline form

```rust
#[test]
fn test_invoice() {
    let invoice = Invoice::new(...);
    insta::assert_yaml_snapshot!(invoice, @"");
    // After first `cargo insta accept`, the macro contains the snapshot inline:
    // insta::assert_yaml_snapshot!(invoice, @r###"
    //   items:
    //     - name: Widget
    //       price: 9.99
    //       quantity: 2
    //   subtotal: 19.98
    //   tax: 1.60
    //   total: 21.58
    // "###);
}
```

The snapshot lives in the source file — you read the test and see the
assertion together. This is closer to Jane Street's `ppx_expect` than the
sidecar `__snapshots__/` style.

## When to use snapshot tests instead of field-by-field assertions

- The output has more than ~5 fields you'd otherwise assert on individually
- The output is a tree, AST, rendered DOM, log sequence, or formatted text
- The same shape is asserted on across many tests (a single change should
  cascade through the snapshots, not require editing 50 assertions)
- The structure is part of the contract, not just the values

## When NOT to use snapshot tests

- The output has one or two meaningful fields — write specific assertions
- The "contract" is a single boolean or numeric value
- The output contains unredacted timestamps, UUIDs, or other non-determinism
  you haven't normalized (you'll get noise on every run)
- The test is exercising a security property — write the explicit assertion
  so a reviewer can't miss it among unrelated output

## Failure modes to defend against

Snapshot tests fail predictably when discipline slips:

### Rubber-stamping
The most common failure. Engineers run `--update` without reading the diff.
The test becomes a change detector, not a behavior test. Mitigations:

- Make snapshot diffs mandatory reading in code review
- Require a one-line explanation in the PR description for every snapshot
  diff: "Updated 3 invoice snapshots because we now include the tax line"
- For interactive review tools (`cargo insta review`), prefer them over
  blanket-accept

### Hash-only goldens
Pinning an exact render or op-stream hash gives no reviewable diff: every art or
layout change becomes a "rebind the hashes" commit, and a backend change needs a
second hash table. Prefer structural or perceptual goldens with a visible diff
(draw-command lists, text frames, SVG structure, images reviewed as images), and
treat pin churn per change as a health metric. If you must keep hashes, re-pin
through a tool that records a written review of what changed.

### Self-approved goldens
A golden created or re-approved by the same actor in the same change as the code it
checks is a characterization, not an independent oracle. Require an approval that
did not come from the authoring agent, or review the rendered diff yourself.

### Coupling to incidental detail
Timestamps, UUIDs, map iteration order, whitespace make tests fail on noise.
Fix at write-time:

```python
# syrupy custom serializer
class StableSerializer(SnapshotSerializer):
    def serialize(self, data):
        data = redact_uuids(data)
        data = freeze_timestamps(data, to="2024-01-01T00:00:00Z")
        data = sort_keys(data)
        return super().serialize(data)
```

### Cascade updates that hide intent
One logic change updates 50 snapshots. The reviewer can't tell which were
intended. Mitigations:

- Keep snapshots small and focused (one snapshot per behavior, not per test)
- Don't snapshot the entire program state — snapshot the part this test
  exercises
- When a refactor cascades through snapshots, split into two commits:
  "refactor (no behavior change, regenerated snapshots)" + "feature
  (intentional behavior change)"

### Loss of intent
A snapshot like `"hello Bob"` doesn't tell you what's important. The test
name has to carry the intent:

```typescript
// Bad: snapshot reveals nothing about why
test('renders correctly', () => { expect(view).toMatchSnapshot(); })

// Good: name carries the intent, snapshot verifies the form
test('greeting includes the user name after first interaction', () => {
  expect(view).toMatchSnapshot();
})
```

## Design pressure: make your output tell a story

The single biggest determinant of snapshot test quality is whether the
output itself is readable. Invest in:

- Custom `__repr__` / `Display` / `toString` for domain types
- Pretty-printers that surface what matters and elide what doesn't
- Stable serialization (sorted keys, normalized whitespace, fixed precision)
- Helper functions to format multi-object state into one cohesive trace

This is the principle behind Jane Street's `ppx_expect`: when stringification
is trivial and stable, tests get written. From "The Joy of Expect Tests":
*"The real art lies in producing output that tells a concise story, capturing
the state you care about."*

## Whole-state roundtrip digests (save/load, migration)

For persistence layers — save/load, serialization formats, schema migrations —
the highest-value characterization test is an **identity check over the whole
state**, not field assertions on one record. (Pattern source: Redis's
`DEBUG RELOAD` + dataset digest: snapshot a fingerprint, reload, assert the
fingerprint is unchanged.)

1. **Generate rich state with a seeded RNG** — many keys, every supported
   value type, the awkward ones especially (empty collections, TTLs, unicode,
   nesting). Hand-picked single-record tests miss exactly the types that break.
2. **Canonicalize, then fingerprint.** Produce a canonical dump of the entire
   state — **sort anything unordered** (sets, map iteration) before comparing
   or hashing. Digesting a non-canonical dump turns legitimate passes into
   flaky failures; structural equality on canonical forms is often better than
   a hash because failures show a diff instead of two checksums.
3. **Assert save→load is the identity**, comparing full canonical state.
4. **Parameterize the reload step across every format/path** — JSON and
   binary, snapshot and incremental, migration v1→v2→v1 — same state, same
   identity assertion, one parameterized test.
5. **On mismatch, emit both canonical dumps** so the failure is a reviewable
   diff, not "digests differ."

```python
@pytest.mark.parametrize("fmt", ["json", "binary"])
def test_save_load_roundtrip_identity(tmp_path, fmt):
    store = build_seeded_store(random.Random(1234), keys=500)  # all value types
    before = canonical_dump(store)                # sorted, normalized
    save(store, tmp_path / "db", format=fmt)
    reloaded = load(tmp_path / "db", format=fmt)
    assert canonical_dump(reloaded) == before     # whole-state identity
```

Two failure modes to defend against:
- **A digest that ignores fields gives false confidence** — if `canonical_dump`
  skips TTLs, TTL persistence bugs are invisible. The dump must cover every
  field the format claims to persist.
- **A digest over nondeterministic ordering gives false failures** — hashing
  `str(a_set)` fails randomly. Canonicalize first, always.

## Multi-environment testing

```typescript
const USE_JSDOM = process.env.DOM === 'jsdom';
export const parseDocument = USE_JSDOM ? parseWithJSDOM : parseLinkedomHTML;
```

Run the same fixtures through different backends; expected output should
agree.

When rendered output legitimately differs across platforms (fonts, GPU,
antialiasing), golden the deterministic intermediate (text frames, draw-command
lists) rather than dropping to "runs without error", and render any pixel baselines
on the same image CI uses.


## Supplied guidance: testing-best-practices/references/test-audit.md

# Audit and repair existing tests

Use this workflow for a bounded test-quality sweep, consolidation, or deletion.
It complements [anti-patterns](antipatterns.md) and [gate integrity](gate-integrity.md).
The output is a set of evidence-backed decisions about tests and their owners.
Search hits, test counts, coverage percentages, and deleted lines are not quality
verdicts or targets.

## 1. Establish scope and baseline

- Read repository instructions, CI configuration, nearby tests, and relevant open
  PRs. Pin the base SHA. Choose a coherent production owner or boundary and a time
  budget; do not start with a deletion quota.
- For each in-scope tier, record the actual command, CI job/trigger, last result
  on the default branch, and whether it selects any tests and can fail. Read job
  results rather than inferring them from the workflow's overall conclusion.
- Run each relevant tier once when feasible, or record why it was unavailable.
  A passing baseline does not establish oracle strength. A failing baseline may
  expose a product bug; keep it separate from cleanup candidates.
- Read the owner, entry points, callers, fixtures, and history of candidates.
  For external-system doubles, inspect the real API/types and exercise the real
  runtime where available. SQLite can validate SQL without validating D1's
  binding semantics, `exec`, `batch`, or limits.
- Check fixtures are obtainable from a fresh checkout. An orphan Git pin, a
  developer-specific absolute path, unavailable recording, or generated state
  with no maintained recipe makes historical proof difficult to reproduce. If replacing it with
  generated scenarios, verify their observable state and label old outputs as
  historical rather than claiming the original experiment was reproduced.

## 2. Discover candidates cheaply

Start with focused searches, then read each hit in context. With ripgrep, from
the target repository root:

```sh
rg -n -g '*test*' -g '*spec*' -g '!node_modules/**' -g '!vendor/**' \
  '(readFileSync|read_text|read_to_string|toBeDefined|toBeTruthy|assertIsNotNone|waitForTimeout|Thread\.Sleep|time\.sleep|test\.only|test\.skip|pytest\.mark\.skip)' .
rg -n -g '*.yml' -g '*.yaml' -g '!node_modules/**' -g '!vendor/**' \
  '(continue-on-error|\|\| true|--passWithNoTests|--updateSnapshot)' .github
```

These commands only collect candidates; exit 1 means no regex match, not a clean
bill of health. They miss nonstandard test paths, assertion-free tests, computed
oracles, custom helpers, and semantic duplication. Adapt paths/frameworks and
inspect at least the critical boundary's tests and helpers directly. Do not turn
these patterns into a CI failure rule without calibrated good/bad examples.

For every candidate, ask:

| Signal | What to inspect | Possible improvement | Reason to retain |
|---|---|---|---|
| Source/config/SQL strings, copied counts, hashes | Does it execute the owner or only recognize its spelling? | Run the executable, renderer, parser, migration, or real engine | Independent architecture, package, protocol, prompt-byte, or published config contract |
| Mock supplies the asserted answer | Where did the expected value and fixture come from? Does the real owner produce the effect? | Real local engine; externally grounded fixture; assert persisted/emitted state | A controlled dependency failure or a separately verified external contract |
| Truthy, not-null, no-crash | Which wrong outputs would still pass? | Assert relevant values, state transitions, and error semantics | Existence or totality is itself the complete contract |
| Assertions in loops, empty result lists, negative checks | Are inputs nonempty and is the intended branch reached? | Assert enrollment/reachability and check each required item | An empty violation set is valid when inspected inputs are independently nonempty |
| Same behavior at several layers | Which suite owns the contract? What distinct failure can each layer detect? | Consolidate shared behavior into a keeper; retain wiring/lifecycle checks | Transport, security, persistence, platform, or ordering risks differ |
| Sleep, retry, timeout increase | Who produces completion? Does the original shard order reproduce a leak? | Wait for produced state; virtual time; repair resource ownership | A measured performance or timeout contract, with justified bounds |
| Test-only export, flag, wrapper, injection hook | Are there non-test callers? Is this a useful owned interface or only access to internals? | Move proof to a real entry point; remove an obsolete seam within scope | A legitimate public API or stable dependency boundary |
| Name promises more than assertions prove | Do input, execution, and oracle reach the named condition? | Correct the test/fixture or narrow its name and claim | A narrower, honest contract still matters |
| Grader/checker self-tests all pass | Can plausible wrong answers pass a scored assertion? Are valid phrasings rejected? | Calibrate each independently scored assertion with both controls | Instrument validation proves checker behavior; product or model gains need their own experiment |

Static, slow, mocked, and single-assertion tests are not automatically bad.
Retain independently specified API, security, migration, storage, release,
cross-language, default, and observable-ordering contracts. Do not remove
behavioral proof merely because a type exists; check its runtime boundary and
hostile inputs using [correctness by construction](correctness-by-construction.md).

## 3. Decide before editing

For each candidate and relevant neighbour, record one decision. Start with the
highest-risk evidence, rather than cataloguing every obviously sound test in a
large repository. Expand to a full ledger when a broad layer removal makes
coverage ownership uncertain.

```md
Base SHA / owner / scope:
Tier command / CI job / baseline result:

| Test location and name | Observable contract / credible regression | Expected-value provenance | Decision | Remaining proof / keeper | Validation |
|---|---|---|---|---|---|
```

- **Retain**: name the independent contract and the regression it catches.
- **Repair**: preserve the contract; fix a weak oracle, unreachable fixture,
  unrealistic double, or synchronization problem.
- **Consolidate**: name the keeper test and migrate every distinct assertion
  before removing the redundant suite. A similar name or coverage line is not
  evidence that the keeper catches the same bug.
- **Delete**: name the remaining proof, or explain why no independent contract
  exists. No contract needs no artificial replacement. Missing evidence means
  retain pending investigation.

Before any deletion, record the old and new tier and inspect CI routing,
parameter rows, negative/error branches, callers, and the reason the test exists.
An internal duplicate can disappear while its boundary proof remains. An
independent real-engine contract must keep equal or stronger proof.

## 4. Repair and prove preservation

Work in small owner batches. Keep production fixes distinguishable from test
cleanup; respect tests-only scope and report any required production repair.

1. Replace source recognition and self-supplied answers with execution through
   the smallest honest production boundary. Expected values come from a spec,
   reviewed recording, independent model, or explicit example, not the SUT's
   constants or the double's implementation.
   A captured result can be a deliberate compatibility characterization; label
   and review it using [golden-file guidance](golden-file-testing.md). Comparing
   the SUT with its own fresh output establishes repeatability, not independent
   correctness.
2. Check negative controls reach the intended guard. Rejecting for unrelated
   missing configuration, fixture setup, or an earlier validation is no proof of
   the claimed rejection. A loop whose assertions never run supplies no evidence
   for its per-item claim; direct emptiness assertions can be valid contracts.
3. For a retained contract moved into a keeper, choose a plausible fault from
   what the old assertion could detect. Use isolated scratch copies/worktrees;
   do not mutate a checkout while tests are running. Run old and new tests
   against the **same** fault and record:

   | Fault / contract | Old tests | Keeper | Interpretation |
   |---|---|---|---|
   | Concrete production change | Fail/pass/unrun and reason | Fail/pass/unrun and reason | Preserved, stronger, lost, or unknown |

   Old fails/new passes is a possible lost check to resolve. Old passes/new
   fails shows additional sensitivity only if the failure is for the intended
   behavior. Both pass calls for investigation; equivalent or unreachable
   mutations are not automatically missing tests. Restore mutated source
   byte-for-byte. Do not pursue a mutation-score target or schedule a new lane
   by default; see [mutation testing](mutation-testing.md).
   For suspected implementation locks or custom checkers, also exercise a
   representative allowed change that must stay green: for example, JSON
   whitespace/key reordering when only parsed meaning is promised. Keep a real
   defect control alongside it. Preserve exact bytes, item order, or integrity
   checks when those are the independent contract. Catching more faults is not
   an improvement if harmless changes now fail.
4. A product bug needs an observed failing control and passing repaired run on
   the same harness where feasible. Report unavailable red/control evidence.
   A baseline failure is not permission to delete the failing test.
5. Run keeper/owner and relevant sibling tests, then required changed checks.
   Check deleted tests did not orphan support files, imports, exports, or CI
   entries. Search documentation for their descriptions as well as names.
   Delegate broad proof to the repository's normal CI when appropriate.

Choose checks in proportion to the change. Deleting a test with no independent
contract does not require inventing a mutation. When a compiler replaces a
type-level check, demonstrate that removing the relevant member fails the
actual typecheck, rather than building a mutation-testing program around it.

## 5. Review and hand off

For substantial removal, independently compare the deleted assertions against
the keepers, with special attention to error rows, persisted fields, ordering,
and external-system fidelity. Add production-correctness review when production
code or an external-system double changes. Review is useful when it checks
specific preservation risks; a fixed number of reviewers is not a requirement.

Report decisions, contracts retained/lost/restored, commands and actual results,
control/fault evidence, CI state at the pushed SHA, and unresolved gaps. Separate
test/support changes from production changes and any product defects discovered.
Do not claim quality from a lower test count or a green-only run.

## Reusable task brief

```text
Use testing-best-practices to audit and improve existing tests for <owner/boundary>.
Scope: <paths and allowed production changes>. Budget: <time/size>.
Read the skill's references/test-audit.md and relevant language/tier references.
Establish CI liveness and a pinned baseline; discover candidates, then inspect
their production owners, fixtures, callers, and history. Record retain/repair/
consolidate/delete decisions, independent expected-value sources, and remaining
proof before edits. Repair the highest-risk false-confidence cases through real
boundaries. For moved contracts, compare old and keeper tests against the same
credible faults; explain no-contract deletions. Treat baseline product failures
as defects. Validate focused proof and required gates, review lost coverage, and
report exact evidence and gaps. No deletion, assertion, or mutation-score quota.
```


## Task

A release importer consumes an immutable archive whose published manifest commits to its exact bytes. A test intentionally corrupts the archive and expects rejection. The importer implementation is being refactored, while the archive and public integrity contract remain fixed. A cleanup proposal removes all hashes and substitutes parsed-content equality because formatting-only changes can otherwise alter an archive's digest. Review the cleanup and specify what should remain fixed, what may change, and which checks to keep.

## Response format

Return ONLY a JSON object with these keys: decision (approve/revise/reject), changes (array of objects with target, action, details), retained_contracts (array of strings), validation (array of concrete commands or checks), cost_and_stop (string), rationale (string). Propose concrete changes you would actually ship, not just warnings. Stay within the supplied task. Do not execute the proposed work. Keep the JSON answer under 650 words.
