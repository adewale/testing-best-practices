Read only this packet. Work independently without other agents. Write the exact final JSON response to response.md beside this packet and return the same response.

Use only the task and context in this packet. Do not browse other files, use the network, run proposed checks, or contact other agents.

## Supplied guidance: testing-best-practices/SKILL.md

---
name: testing-best-practices
description: >
  Enforce testing best practices when writing, reviewing, or improving tests.
  Covers TDD/red-green-refactor, property-based testing, real objects over
  mocks, correctness by construction, assertion quality, E2E/contract tests,
  flaky-test upgrades, mock-reality drift, mutation-style gap analysis, and
  sabotaged/skipped/weak tests. Use when writing tests, reviewing test quality,
  fixing flaky tests, improving coverage quality, or when the user mentions
  TDD, testing, coverage, mocks, invariants, types vs tests, defense in depth,
  fuzzing, generative testing, or test quality.
compatibility: Agent Skills clients including Codex, OpenCode, Pi, Gemini CLI, and Claude Code.
metadata:
  author: adewale
  version: "0.3.1"
---

# Testing Best Practices

This skill has four modes:

1. **Write** — add tests or test-first bug fixes/features.
2. **Assess** — review an existing suite for quality, not just coverage.
3. **Upgrade** — strengthen weak/flaky/over-mocked tests.
4. **Detect** — find skipped, sabotaged, fake-coverage, or gap-prone tests.

## First 90 seconds

Before writing, assessing, or changing tests:

1. **Detect language/framework** from repo files and adjacent tests.
2. **Read nearby tests** for naming, fixtures, builders, assertion style, and runner commands.
3. **Find the nearest validation command** before broad full-suite commands.
4. **Identify the risk boundary**: pure logic, internal component boundary, external API, UI/user journey, security boundary, hostile-input parser, or type/schema invariant.
5. **Classify the change and asset**: behavior change vs. structure/tidying, reusable library vs. throwaway probe, customer-facing rule vs. internal helper.
6. **Choose the smallest useful test tier** from `references/test-types.md`.
7. **Load only relevant references** from the matrix below.

If the language is unsupported by a dedicated reference, follow project conventions plus the generic principles here.

## Reference matrix

Always consider:
- Test type selection → `references/test-types.md`
- Anti-pattern detection → `references/antipatterns.md`

Language/framework references:
- Python / pytest / Hypothesis → `references/python.md`
- TypeScript/JavaScript / Vitest/Jest/fast-check/Playwright → `references/typescript.md`
- Go / testing / testing.F / Rapid → `references/go.md`
- Rust → `references/rust.md`

For property-based testing or coverage-guided fuzzing, also load the matching language reference: collection, discovery, and replay differ by engine. If the selected engine is not documented here, follow its project documentation rather than transferring another engine's behavior.

Topical references by trigger:
- Auditing, repairing, consolidating, or deleting existing tests → `references/test-audit.md`. Start with candidates; record contracts, expected-value provenance, decisions, and remaining proof before edits. Compare old and keeper tests against the same credible faults when moving contracts.
- Writing/reviewing property tests, choosing a property, generator design, stateful/model-based testing, seeds and replay → `references/property-based-testing.md`
- Coverage-guided targets or campaigns for exposed/custom parsers, native or unsafe decoders, crash-prone boundaries, or security tooling whose crash disables a check → `references/fuzzing.md`
- Legacy/refactor safety → `references/characterization-testing.md`
- Reimplementation, port, multi-language SDK, custom data structure with no reference, or approximate/probabilistic/ANN/ranking output → `references/differential-testing.md`
- Complex outputs, snapshots, transformation pipelines, save/load or migration roundtrips → `references/golden-file-testing.md`
- Time, timers, schedules, sleeps, flaky time tests, background threads/async work tests can only reach by sleeping → `references/deterministic-time.md`
- External APIs, recorded real responses, mock drift → `references/vcr-cassettes.md`
- CLI/plugin/docs registry sync, or verification claims in docs and agent instructions → `references/doc-sync-testing.md`
- Mutation testing, mutation scores/survivors, recurring mutation lanes, or high coverage but escaping bugs → `references/mutation-testing.md`. For recurrence, no completed target-CI baseline or demonstrated fault-class bite means no schedule; never copy an absolute score floor.
- Finite state spaces or expensive cross-products → `references/exhaustive-testing.md`
- Large configuration/feature/runtime matrices, pairwise replacement, or interacting factors → `references/combinatorial-testing.md`. Preserve fixed regressions and exact registry enrollment; use named variable-strength groups and shadow evidence before deletion.
- Arithmetic/domain operators/laws → `references/mathematical-properties.md`
- Fixtures/builders/assertion helpers → `references/test-data-builders.md`
- Same invariant checked across layers, type-vs-test decisions, invalid states → `references/correctness-by-construction.md`
- CI/hooks/test-config changes, gated or scheduled tiers, "is this check running and can it fail?", deploy verification → `references/gate-integrity.md`

## Core principles

### Test behavior through public contracts

Good tests describe observable behavior: outputs, state transitions, side effects, rendered UI, persisted data, API contracts, or invariants. Avoid tests that break under behavior-preserving refactors: private methods, incidental call order, exact SQL strings, or broad mock choreography.

When a user brings examples, tables, bug reports, spreadsheet rows, or support cases, treat them as communication artifacts first and assertions second. Preserve the business language, then run the examples against the narrowest honest seam: usually the domain/service/API contract, not a full UI path for every business-rule row. UI/E2E tests should prove the wiring and golden path; rule tables should exercise the domain layer directly.

### Calibrate test investment to lifetime and change kind

Do not give every artifact the same test plan. Reusable libraries, parsers, payment/auth/security boundaries, migrations, and code that will be refactored deserve stronger regression/property/contract coverage. Throwaway probes, one-off research scripts, or generated exploration may need only a smoke check or no tests if the user accepts that lifecycle.

Separate **behavior changes** from **structure changes**. Behavior changes need tests that can fail for the new/changed behavior. Pure tidying/refactoring should ride an existing green suite; if no such suite exists, add characterization tests for the behavior you need to preserve before refactoring.

For a new service with no pipeline, start with a walking skeleton: the thinnest build/deploy/test slice. Track unfinished acceptance tests as visible in-progress items tied to a story/issue, not silent skips. Keep unit tests green; do not commit failing unit tests as proof.

### Use red-green-refactor when feasible

For bug fixes and new behavior, default to:

1. **Red** — add a focused test that fails for the current bug/missing behavior.
2. **Green** — implement the smallest change that passes.
3. **Refactor** — clean up while tests stay green.

The evidence matters. Separate **red evidence** (exact command and failing output before the fix) from **green evidence** (passing command/result after the fix). Only claim completed TDD/red-green-refactor when both were observed in order. If only a passing/green run is available, say tests were added and now pass, but the red phase was not observed/unverified; do not backfill a TDD claim from a green-only log. For exploratory prototypes, generated code, or user-scoped “tests only” tasks, stay within scope and state the deviation.

When practicing TDD, keep a visible **test list**. Park new edge-case ideas there instead of chasing them mid-cycle. If stuck, downshift: write the assertion first, extract a smaller child test, use a learning test for third-party APIs, or use a crash-test-dummy fake to trigger hard error paths. Choose Fake It, Triangulate, or Obvious Implementation according to uncertainty; never leave fake constants as the final behavior.

### Quality beats coverage

Coverage shows what ran; it does not prove bugs would be caught. Prefer branch coverage over line coverage and treat coverage as a map for finding untested paths, not a quality gate by itself.

Assertion count is a heuristic, not a law; never turn it into a quota. Example-based behavior tests often need multiple meaningful assertions to verify structure, state, and negative cases. But a property test, table row, or exception test may have one excellent oracle. Flag weak sole assertions such as “not empty,” `toBeDefined()`, `toBeTruthy()`, `Assert.IsNotNull(result)`, or logging without assertions.

For sanitizers, validators, filters, auth/security checks, and transformations, verify both directions where applicable: dangerous/invalid content is rejected or removed, and safe/valid content is preserved.

Assert the fields the behavior under test is about. Full-object/whole-structure equality implicitly asserts every unrelated field, so the test breaks on unrelated changes and joins a change-detector treadmill (update the literal each time a field is added). Reserve whole-state comparison for tests where breadth is the contract — golden files and save/load roundtrips (`references/golden-file-testing.md`). Prefer assertion forms whose failure message alone can start the debugging (matchers/fluent asserts that print expected vs. actual, not bare booleans); when many tests keep breaking for innocent reasons like iteration order, fix the assertion vocabulary (order-insensitive/structural matchers), not each test. For coverage, gate new/changed code rather than one repo-wide number, and read what is *not* covered as the review signal.

Every custom oracle, linter, validator, fixer, or eval grader needs a known-good input that passes and a known-bad input that fails; keep them small, and don't rerun an expensive checker for every bad input. Goldens, approvals, or eval cases written by the same actor in the same change as the code are characterizations, not independent oracles.

### Prefer real behavior over mocks

Prefer, in order:

1. Real in-memory/local objects, temp dirs, in-memory databases, real parsers.
2. Local emulation of the real runtime (workerd/vitest-pool-workers, Pyodide in Node, `wrangler dev`, SQLite loaded from migrations).
3. Purpose-built fakes that implement the same interface and can record history.
4. Deterministic stubs for controlled edge cases.
5. Framework mocks as a last resort.

Take a double's expected values from the real service (recorded or locally emulated), never from the mock author's belief; when a real engine can run in-process, delete the mock.

Prefer visible state over call choreography: assert the saved row, emitted event, response body, file on disk, or a small logging fake's recorded effects. Do not mock values; construct them. Mock roles you own, not third-party libraries directly; wrap provider SDKs behind an owned interface and add a contract/VCR check for the real provider shape. For interaction tests, allow queries and expect commands: getters can be called freely, side-effecting commands are where expectations earn their keep.

### Use properties for broad input spaces

Use property-based testing when behavior spans a broader input or operation space than examples can cover economically. Choose a property that states meaningful behavior—roundtrip, idempotence, conservation, metamorphic relation, algebraic law, or agreement with a small model—not merely that execution did not crash.

Match the generator to the behavior being tested: arbitrary input for totality and documented errors, specification-valid input for semantic branches, stateful traces for lifecycle behavior, and corpus mutation for coverage-guided discovery. Use an oracle independent of the implementation. Property tools construct values and shrink failures; coverage-guided fuzzers mutate a corpus toward new control flow. Do not use the terms or tools interchangeably.

For small finite spaces, prefer exhaustive generation over sampling, after checking per-cell cost and whether a cheaper layer decides the property (`references/exhaustive-testing.md`). See `references/property-based-testing.md` for generator, oracle, execution, and replay guidance.

### Test error-handling paths, not just invalid input

Most critical production failures are shallow: they live in error-handling code that only runs when a dependency *already* failed — a disk-write error, a dropped connection, a timeout, a partial response. Empirical studies of catastrophic distributed-systems failures find the majority were reachable by simple tests that exercised those paths. So "sad path" means more than rejecting bad arguments: inject the downstream failure (a fake/stub that raises, an injected I/O error, a `side_effect` exception) and assert the system degrades correctly.

Assert the failure behavior the code *actually* has, not one you wish it had. Read the spec or observe the code to learn what a failure should do — propagate, retry, wrap, fall back, roll back — and test that. Do not invent a retry budget, a custom error type, or rollback semantics the contract never promised; that tests a fictional contract and is scope creep. If the intended failure behavior is unspecified, characterize what the code does today and flag the gap as a follow-up rather than designing new production behavior inside a test.

### Push internal invariants into types/schemas/contracts

Types and tests answer different questions:

- Types/schemas/contracts: “Can this invalid state exist?”
- Tests: “Does observable behavior match the spec?”

When an invariant is repeated across internal layers, consider lifting it to a boundary parser, smart constructor, schema, sealed enum, state machine, or database constraint. Before deleting checks or their tests, verify all of this:

- the context is internal and non-adversarial,
- the invariant is actually enforced by the type/schema/constructor,
- boundary tests cover hostile or malformed input,
- security/auth/external-failure layers defend different failure modes,
- production type changes are in scope or explicitly approved.

If user scope says “tests only” or “do not change production code,” add tests for the current API and list type/schema tightening as a follow-up.

### Test concurrent code under a race detector, and pin the concurrency contract

For code meant to be used by multiple goroutines/threads, sequential tests prove almost nothing. Drive the shared state from many workers released together (a start barrier maximizes contention) and run under a race detector or thread sanitizer (`go test -race`, ThreadSanitizer / `-fsanitize=thread`, repeated runs via `-count`). Treat a green concurrent test as weaker evidence than a sequential one — races are probabilistic.

Assert the invariant the API actually promises — no lost updates, a monotonic/linearizable count, compute-at-most-once — instead of logging whatever count you happened to observe and moving on. If the implementation can violate that contract (e.g. it computes outside the lock, so two callers double-compute), that is a defect to surface with a failing test or an explicit flag, not a `t.Logf` that quietly bakes the race into the expected behavior.

## Mode workflows

### Write mode

Before adding a test, name the observable contract, a credible regression it catches, and why existing proof misses it. Extend an existing test or table when it covers the same contract; another layer needs a distinct risk. If the test requires exposing internals solely for access, look for a real production boundary first.

1. Read adjacent tests/config and load the relevant language reference.
2. Choose test tier from `references/test-types.md`.
3. For bugs/new behavior, add the failing regression test first when feasible.
4. Convert user/customer examples into readable test cases without forcing every example through the UI.
5. Use builders/factories/helpers where setup noise hides intent; test custom helpers when they become a mini-DSL.
6. Prefer user-facing/public interfaces over internals.
7. Pin nondeterminism: time, randomness, network, filesystem, order.
8. Choose test values deliberately: include distinct, non-default values so at least one case would expose a dropped, defaulted, or swapped argument. Still cover zero, empty, and equal-value cases when they are boundaries or part of the contract. Derive expected results independently of the SUT: literals are clearest for simple examples, while properties or a genuinely independent reference model fit broader cases. Do not recompute the expectation with the SUT's own logic or constants, because the test can share its bug and stay green.
9. Run the nearest tests, then broader checks when practical.

For transformations or complex generated output, use golden files with explicit review discipline; see `references/golden-file-testing.md`. For external APIs, prefer recorded real fixtures/cassettes or contract checks over live CI calls; see `references/vcr-cassettes.md`.

### Assess mode

For a test-quality sweep, use `references/test-audit.md` to turn detection signals into evidence-backed retain/repair/consolidate/delete decisions. Search hits alone do not justify edits.

Report evidence by severity and include positive observations. For generative tests, load the relevant language and topical references before recommending engine-specific changes. Check:

0. **Is it running, and can it fail?** For each tier: the job that runs it, its last result on the default branch, whether gated tests are reachable, and whether each gate can go red (`|| true`, `continue-on-error`, baseline updaters, skip-green, empty targets). A dead gate is the first finding. See `references/gate-integrity.md`.
1. **Sabotage / false confidence**: skipped/focused tests, no assertions, logging-not-asserting, commented-out assertions, always-true assertions.
2. **Oracle strength**: weak sole assertions, missing negative/error/state/structural assertions, tautologies. For property tests, a bare never-crashes oracle is weak when a semantic invariant is available.
3. **Mock-reality drift**: hardcoded mocks that would not notice real API/schema changes.
4. **Tier integrity**: unit tests hitting live network, integration tests mocking every boundary they claim to exercise, E2E tests that mock the system under test or drive it through a test facade, PR suites that target production, and whether the artifact under test is the artifact deployed.
5. **Determinism**: sleeps, wall-clock time, unseeded random, order dependence, global state leaks.
6. **Coverage quality**: branch coverage; for high-coverage suites with escaping bugs, seed a fault on the critical path and see whether any test fails, cheapest first (`references/gate-integrity.md` §5). A recurring mutation lane is not a default recommendation.
7. **Invariant placement**: repeated internal validation that should be a type/schema/contract.
8. **Lifecycle fit**: throwaway probes over-tested, reusable assets under-tested, or structure-only changes getting behavior-test theater.
9. **Example quality**: business examples buried in UI scripts, unreadable fixtures, or helpers that form a DSL but have no tests of their own.
10. **Generative evidence**: the configured runner reaches the production path, the generator reaches the claimed domain, the oracle is independent, and seed replay is not mislabeled as active discovery. Verify the exact CI configuration when multiple runners, projects, filters, or duplicated target lists make reachability uncertain; add a permanent drift guard only for recurring risk.
11. **Test-code readability (DAMP)**: logic in test bodies (loops/branches/computed expectations), expectations derived from the SUT's own constants, shared fixtures mutated far from the assertions that depend on them. See `references/antipatterns.md`.
12. **Suite shape**: count tests per tier; name the inverted pyramid/ice-cream cone (mostly E2E over a thin unit base) and the hourglass (unit + E2E with an empty integration middle). Recommend the smallest-tier home for each E2E case that has one — business rules move below the UI — while keeping a small golden-path/critical-journey E2E core.

### Upgrade mode

When consolidating or deleting tests, use `references/test-audit.md`: name the keeper and preserve distinct assertions before removal. Record no-contract deletions explicitly; do not fabricate replacement tests.

Prioritize by risk:

1. **P0**: security/auth/injection/sanitizer tests with weak or missing assertions.
2. **P1**: tests that only assert not-null/not-empty/truthy.
3. **P2**: flaky tests: sleeps, live network, wall-clock, order coupling. Before patching waits, ask whether a smaller SUT can host the test — size (dependencies, processes, RAM footprint) predicts flakiness better than tool choice — and treat auto-retry/quarantine as masking debt, not a fix.
4. **P3**: mock-heavy “integration” tests and implementation-coupled mocks.
5. **P4**: fixture noise, duplication, unclear names, missing builders.

Common upgrades:
- Replace `sleep()` with virtual time, injected clocks, or condition-based waits.
- Replace live API calls with recorded cassettes or committed fixtures.
- Replace broad mocks with fakes, contract tests, or assertions on public behavior.
- Replace repeated object literals with builders that keep behavior-specific fields explicit.

Never silently downgrade a tier: list removed or replaced tests by tier, and keep real-engine tests (SQLite, workerd, browser) unless an equal or stronger tier replaces them. A lesson or postmortem counts only when a check enforces it.

### Detect mode

Use concrete search signals from `references/antipatterns.md`:

- `@skip`, `skip`, `skipif` without real condition, `test.only`, `fit`, `xit`, `xdescribe`.
- `print`, `console.log`, `t.Log`, `Debug.WriteLine` used instead of assertions.
- Assertion-free tests or only truthy/not-empty/not-null checks.
- Property tests with no independent oracle, generators filtered into one easy path, or small finite domains sampled when they can be enumerated.
- `sleep`, `waitForTimeout`, `Thread.Sleep`, `Task.Delay` for synchronization.
- Try/catch swallowing exceptions.
- Mock return values identical to assertions.
- Global state/env/registry mutations without cleanup.
- Snapshot/golden updates without diff review.
- CI steps with `|| true`, `continue-on-error`, `scan --baseline`, or `::warning::` skips; coverage or mutation thresholds that never run.
- Mutation run as a program: calendar schedules over unchanged code, round-number floors, internals exported or pinned only to kill survivors.
- Assertions only inside loops over possibly-empty results; `violations == []` with no non-empty check; tests that import nothing from the code under test.
- Source, CSS, or workflow text read and asserted as strings; helper-level retry loops; raised global timeouts or `isCI ? a : b` budgets.

## Validation loop

After writing or changing tests:

1. Run the nearest relevant test command.
2. If bug-fix TDD was intended, report red evidence separately from green evidence; if the pre-fix failing run was not observed, call the red phase unverified instead of claiming completed TDD.
3. Scan the changed tests for weak sole assertions, skips/focus markers, logging-not-asserting, sleeps, live network, and implementation-detail coupling. Also check: expected results come from an oracle independent of the SUT, at least one test value would expose dropped/defaulted/swapped inputs, relevant boundary values are still covered, and assertions are narrow to the behavior's fields.
4. For security/transformation tests, verify both rejection/removal and preservation.
5. For invariant work, verify both tactics where relevant: property/invariant proof and invalid-state reachability.
6. For property/fuzz tests, confirm the claimed input domain, independent oracle, engine-native replay, and—where configuration makes it uncertain—collection or target selection with the exact CI command.
7. Decide pass/fail from exit status, not output text. Run the exact CI entrypoint rather than a sub-mode, and compile tag-gated files you touched with their tags.
8. When repairing CI, keep "update a stale selector" separate from "weaken an assertion or raise a timeout", and justify every weakening. Call a failure pre-existing only after reproducing it on a clean checkout of the base.
9. If validation is blocked, report the exact command, failure, and next-best check. Never claim tests passed without running them; say which environment a green claim came from, and check the pushed commit's CI when there is one.

## Final report contract

End testing work with:

```md
Tests changed/assessed:
Behavior covered:
Commands run:
Results:
CI status (ran / red / not running):
TDD evidence (if claimed):
Gaps / risks:
Follow-ups:
```

Keep it concise, but make validation and remaining risk auditable.


## Supplied guidance: testing-best-practices/references/gate-integrity.md

# Gate Integrity: Is the Check Running, and Can It Fail?

Read this when assessing a suite, changing CI/hooks/test configuration, adding a
gated or scheduled test, asking why bugs escape a green pipeline, or before
claiming "tests pass". The most common failure in real repositories is not a
missing test. It is a check that silently stopped running, or one that cannot go
red, while everyone believes it is green.

## 1. Liveness: which job runs each tier, and when did it last pass?

For every tier (unit, integration, E2E, visual, perf/budgets, coverage, mutation,
fuzz, evals, post-deploy smoke, lint/types) record:

- the exact command, the CI job that runs it, and its trigger (PR, push, schedule,
  dispatch);
- the last run on the default branch: status, duration, and test count.

A tier with no job is presumed broken until run. A test that exists but no job
runs is documentation, not verification.

Check that runs executed, not just that they are green or red: a runner was
assigned, the duration is plausible, and counts are non-zero. CI that is red or
not starting for non-code reasons (quota, billing, missing runner, uninstalled
browser engine) is a **dead gate**: surface it before anything else. While it is
dead, local runs are the only evidence, and the report must say so.

**Collection parity.** The CI collector may not see every test: `unittest
discover` ignores pytest-style module functions; Playwright projects that no lane
invokes never run; runner `include` globs miss files. Compare counts against an
alternate collector (`pytest --collect-only -q` vs the CI runner; the JSON
reporter's per-project totals).

## 2. Gated-test reachability

For every build tag, env gate, `skipIf(resource)`, OS-suffixed baseline, optional
conformance leg, or `if:` condition, all three must hold:

1. **Compiled in CI**: `go vet -tags=network ./...` or `go test -tags=… -run '^$'`;
   a type-check that includes the file.
2. **Selected with the resource present**: some lane provides the capability and
   selects the file.
3. **Fails when it skips**: a skip ledger, a reporter contract
   (`skipped == expected`), or a `REQUIRE_*` flag that turns a skip into a failure.

Cheap detection: run the CI command verbosely in a fresh checkout and list what
was skipped or not collected. Honest gating is fine; gating that no lane
satisfies is a dead test.

## 3. Gate integrity: show every check can go red

| Signal | Why it cannot fail | Fix |
|---|---|---|
| `\|\| true`, `continue-on-error: true`, `2>/dev/null` on a test or check step | Failure is discarded | Remove; if genuinely advisory, see §6 |
| Baseline updater used as a check (`detect-secrets scan --baseline`) | Rewrites the baseline and exits 0 | Use the checking form (`detect-secrets-hook --baseline`) or fail on a diff |
| Error-swallowing shell (`if echo "$?" \| grep …`) | Every error becomes a warning | Capture stderr; tolerate only the specific benign message |
| Skip-green when secrets or tokens are missing | The owner's own repo can lose its gate silently | Fail in the owner's repo; skip explicitly only for forks |
| `::warning::` + skip that ends a deploy green | Nothing shipped, and the badge is green | Fail on the normal path; alert on live-version drift (§5) |
| Step iterating an empty set (scanner over a directory with no targets) | Zero findings from zero inputs | Scan committed canary fixtures: one that must fire, one that must not |
| Coverage threshold configured but never invoked, or its provider not installed | The number is never computed | Run it in CI, or delete the dead threshold |
| A threshold the tool silently ignores (gremlins 0.6.0 CLI `--threshold-*`) | The claimed gate never fires | Put it where the tool reads it, and show it failing when set above the score |
| Fail-open imports (`import(x).catch(() => null)` + `skipIf`) | A required lane passes when its dependency fails to load | Fail when CI is set; assert the skip count is zero |
| Warning-only expiry or review dates | Warnings nobody reads | Fail after a grace period; warn ahead of time |
| E2E against production or a deployment not built from this commit | Tests someone else's code | Target a local server or a deploy of this SHA |

Prove a gate works by planting a violation in a scratch copy (a failing test, a
fake secret, an empty target) and watching it go red, then revert.

Not every check that cannot fail is a dead gate. An explicitly informational
diagnostic (mutation score, perf trend, eval report) is fine while someone reads
it. If nobody does, run it on demand or delete it; do not add a threshold or a
schedule just to give it teeth.

## 4. Vacuous passes: the instrument measures something else

- A universal assertion can pass without exercising the intended scenario when
  its input set is empty. Assert non-empty inputs only when the scenario requires
  them, and report how many inputs were inspected. `violations == []` is a valid
  expected result; check the inspected inputs, not that violations exist.
- Zero-sample aggregates (`Math.min(...[])` is `Infinity`) must refuse n = 0.
- A test or script that reimplements the logic and imports nothing from the SUT
  tests its own copy.
- **Test linkage**: a subject with no non-test importer (dead code, or a
  reimplementation) can carry many green tests while the live path is untested.
  Check linkage at symbol level.
- Precondition failures converted to green: `test.skip()` in the failure branch,
  `page.goto(...).catch(() => {})`, an imperative `pytest.xfail()` left after the
  fix.
- **Instrument drift**: measurement tools or tests that copy constants from the
  code instead of importing them agree with the code by construction.
- **Quiescent harness**: pausing or stubbing can flip which branch the SUT takes;
  ask what the harness changed to get its quiet.

## 5. Test the tester, and trust the artifact

- **Both sides**: every custom oracle, linter, validator, auto-fixer, scanner, and
  eval grader needs at least one known-good input that passes and one known-bad
  input that fails, checked in CI. Detectors also need near-miss controls that
  must not fire. Write fixtures from the failure, not from the regex. Keep them
  cheap: reuse expensive prepared inputs, then run the checker on each focused
  negative variant. Retain one full preparation-to-verdict test; comparing
  variants with a cached verdict does not exercise the checker.
- **Seed faults cheapest first**, and stop when the question is answered:
  1. Red-green: the new or changed test fails against the code before the fix.
  2. A hand-seeded fault in a scratch copy or worktree, never the shared tree:
     neuter one central function or reintroduce one past bug, run only the tests
     that exercise the affected behavior, record which fail, revert. A sabotage
     kill matrix records which tests detect each fault; importing a module does
     not imply exercising that fault. Require detection by an appropriate
     behavior test, not failure of every importing test file.
  3. A mutation tool scoped to the changed function or file, run on demand
     (`references/mutation-testing.md`), only when 1–2 leave a real question.

  Prefer a regression test to a committed replay probe; commit probes only where
  a test cannot express the bug (gates, corpora, checkers), and run them when
  their paths change. Invariants that a no-op satisfies (determinism, count
  preservation) need a change-witness assertion that state actually changed.
- **The author is not the oracle**: goldens, approvals, and eval cases produced in
  the same change by the same actor are characterizations until independently
  reviewed. Report a trivial baseline next to any eval score.
- **Deploy truth**:
  - A smoke test touches the core dependency.
  - The live version or SHA must match the deployable default branch; alert on
    drift.
  - The artifact under test must be the artifact deployed: lockfile parity,
    installed-package or tarball tests, publishing the bytes that passed.
  - Test declared compatibility floors (`requires-python`, `engines`).

## 6. Recurring lanes and advisory gates: an operating contract

Before scheduling a nightly E2E, fuzz, perf, eval, or mutation lane:

- run the exact configuration once to completion on the target infrastructure and
  keep the report;
- set a runtime budget and name an owner;
- decide notify-or-block: a red schedule that does neither is a write-only log;
- choose a stop rule for repeated operational failures or untriaged findings:
  fix, narrow, disable, or delete before growing scope;
- state a removal criterion;
- choose the trigger from what can produce new evidence. Deterministic mutation
  reruns with unchanged code, tests, operators, and environment usually add none;
  use change filters or incremental results. Scheduled fuzz discovery can explore
  new inputs, and E2E, performance, or eval runs can expose environment,
  dependency, model, or workload changes without a source edit. Keep a calendar
  lane when that purpose, its budget, and its result consumer are explicit;
- calibrate any threshold on comparable target-runner history. For mutation
  scores, report actual kills separately from timeouts: their score treatment
  depends on the tool, and local load can inflate a timeout-inclusive score.

Gates cost minutes and attention. Before adding a lane, estimate runs × jobs ×
minutes; on private repositories those minutes are billed, and running out stops
every gate at once. Cancel superseded runs. Weigh suite shape by where CI time
goes, not just test counts, and retire gates that never fire or never change a
decision. Mutation specifics are in `references/mutation-testing.md`.

## 7. Restraint: don't over-apply

- A capability-gated test is fine when a lane provides the capability and fails
  on skip.
- An advisory job with an owner, a schedule, and a notification is not a dead
  gate.
- Post-merge or nightly lanes are legitimate if someone is notified and acts; not
  every tier must run on every PR.
- Never turn a legitimately red lane green by deleting it or weakening it.
- Do not demand network, production, or paid resources in CI to satisfy this
  checklist; say what cannot be verified instead.

## Audit record (Assess mode)

```md
| Tier | Command | CI job / trigger | Last run (status, count, date) | Can it fail? (evidence) | Gap |
```

## Starter mechanical checks for a repository

Encode recurring findings as a static test with a shrink-only allowlist. Give
each rule a teeth test: a planted violation it must catch.

- focused or unconditional skip markers; assertion-free tests; weak sole assertions
- `sleep`/`waitForTimeout` synchronization; new retries
- `|| true` or `continue-on-error` on test steps in workflows
- `readFileSync(src…)` or `read_text()` of source followed by string assertions
- assertions only inside loops over results
- test files that import nothing from the source tree
- `Math.random`/unseeded randomness inside property bodies


## Supplied guidance: testing-best-practices/references/antipatterns.md

# Testing Anti-Patterns: Detection and Fixes

## Quick Detection Reference

| Anti-Pattern | Search Signal | Severity |
|---|---|---|
| Logging not asserting | `t.Log` in `if` blocks; `console.log` in test conditionals | P0 |
| Not-empty assertions | `!= ""`, `toBeDefined()`, `toBeTruthy()` as sole assertion | P1 |
| Unconditional skips | `@skip`, `xit`, `xdescribe` without `skipif` | P1 |
| Mock-only integration | `@mock.patch` / `vi.mock` in `tests/integration/` | P2 |
| No sad path tests | All test names contain "works", "returns", "success" | P2 |
| Test pollution | `os.environ[...] =` without `monkeypatch` | P2 |
| Flaky time tests | `sleep(`, `time.time()`, `Date.now()` in tests | P2 |
| Testing the mock | Asserted value identical to mock's configured return | P3 |
| Stale snapshots | Snapshot updates with no code changes | P3 |
| Logical defense-in-depth | Same invariant checked & tested at 3+ internal layers; "this should never happen" tests | P2 |
| Asserting through fault-masking code | Output-only assertion behind a `clamp`/`max(min())`/blanket `except`→default/`recover()`→zero; test passes even if the computation is wholly broken | P1 |
| Logic in tests / over-DRY test code | Expected values built by concatenation/arithmetic or from the SUT's own constants; `for`/`if` in test bodies; fixtures mutated in `setUp*` far from the assertion | P1 |
| Always-green or dead gate | `\|\| true`, `continue-on-error`, `scan --baseline`, `::warning::` + skip, coverage/mutation configured but never run, CI not executing at all | P0 |
| Vacuous pass | Assertions only inside a loop over possibly-empty results; `violations == []` with no non-empty check; scanner run over zero targets; test imports nothing from the SUT | P1 |
| Source/config-text assertions | `readFileSync`/`read_text` of `src/`, CSS, or workflow files followed by `toContain`/`assertIn`/`match`; pinned render hashes | P2 |
| Permissive environment | Regex-dispatched SQL fakes, hand-built schemas, bindings missing from the test config, fakes that never fail | P1 |
| Hidden retries / timeout ratchet | Helper loops retrying 5xx; `retries: CI ? n : 0`; repeatedly raised global timeouts; `isCI ? a : b` budgets | P2 |
| Self-authored oracle | Goldens, approvals, or eval questions written by the same actor in the same change as the code they judge | P2 |
| Mutation program without a decision | Calendar-scheduled mutation over unchanged code; round-number or "no survivors" floors; private helpers exported, production markers added, or tie-breaks and cache internals pinned to kill a survivor | P2 |

## Anti-Pattern Details

### 1. Logging not asserting

**What**: `t.Log()` / `console.log()` / `print()` in assertion position. Test
logs failure but never fails.

**Fix**: Replace with `t.Errorf()` / `expect().toBe()` / `assert`.

### 2. Not-empty assertions

**What**: Only checks output is non-empty. `return "X"` for all inputs passes.

**Fix**: Assert specific expected content (positive) AND absence of unwanted
content (negative).

### 3. Mock-reality drift

**What**: Mocks return what the test author expects, not what the real system
returns. Real API changes go undetected.

**Fix**: When a real engine can run in-process or locally (SQLite loaded from
migrations, workerd, Pyodide in Node, node-canvas), delete the mock and use it.
For doubles you must keep, take expected values from the real service — recorded
responses, VCR cassettes, or a local emulator run — never from the mock author's
belief. A "fidelity" test whose name says one thing (`changes_0`) while asserting
another (`changes == 1`) pins fiction; question the expected value. Flag contract
tests whose target double no longer exists. Add at least one test against real
infrastructure.

### 4. Integration tests mocking everything

**What**: Tests in `tests/integration/` that mock all external dependencies.
They're unit tests in disguise.

**Fix**: Either rename to `tests/unit/` (honest labeling) or add real
component-boundary integration tests alongside. An integration test should
exercise at least one real dependency or component boundary: an in-process
controller + service + repository can be integration even without a live
external service. Do not add network/database dependencies just to satisfy a
label.

### 5. Testing the mock

**What**: Test assertion verifies the mock's return value, not the function's
behavior. Test is tautological.

**Detection**: The asserted value is identical to `mock.return_value`.

**Fix**: Assert on the function's *transformation* of mock data, not the data
itself.

### 6. Skipped tests without expiry

**What**: `@skip("broken")` with no tracking issue. Accumulates silently.

**Fix**: Use `@skipif(condition, reason="...")` for legitimate skips. Require
issue links. Delete tests that will never be re-enabled.

Related shapes: `test.skip()` called inside a failure branch (the test skips
exactly when the feature breaks); an imperative `pytest.xfail()` left in a
known-bug test after the fix (a regression reports green); a capability skip
(`skipIf(!resource)`, build tag, OS-only baseline) that no CI lane ever satisfies.
A gated test is real only if some lane provides the resource, selects the test,
and fails when it skips — see `references/gate-integrity.md`.

### 7. Tests coupled to implementation

**What**: Tests that break on refactoring even when behavior is unchanged.
Verifying internal method call counts, SQL query strings, call order.

**Fix**: Test through public interfaces. Assert on outputs and side effects,
not internal mechanics.

Agent-era shapes of the same smell:
- **Source- or config-text assertions**: reading `src/`, CSS, docs, or workflow
  YAML and asserting substrings or regexes. They break on innocent edits and pass
  on real rendering or runtime bugs. Assert computed style, rendered output, or
  parsed-structure invariants ("every step after a precondition is gated on it"),
  or extract a seam.
- **Hash-only goldens**: pinned render or op-stream hashes give no reviewable diff
  and churn on every art change; prefer structural or perceptual goldens with a
  visible diff (see `references/golden-file-testing.md`).
- **E2E through a test facade**: driving the app through `window.__test` hooks
  proves the facade works, not the user journey; keep a golden path on trusted
  input.

### 8. Flaky tests

**What**: Tests that pass sometimes and fail sometimes.

| Cause | Fix |
|-------|-----|
| Wall-clock time | Inject clock or freeze time |
| Shared state | Reset in setUp/tearDown |
| Network | VCR cassettes or committed fixtures |
| Race conditions | Proper synchronization |
| Test ordering | `autouse` fixtures for cleanup |
| Oversized SUT | Shrink the tier/SUT first — size (deps, processes, RAM) predicts flakiness better than tool choice |
| Retry/quarantine reliance | Root-cause instead; retries mask real races and erode trust in red. Required lanes run with `retries: 0` and assert zero flaky results; helper-level retry loops count too |
| Wall-clock budgets in the unit tier | `expect(elapsed).toBeLessThan(n)` fails under contention; assert bounded work or move deadline contracts to an isolated lane with headroom or an injected clock |
| Timeout ratchet | Repeatedly raising a global timeout, or `isCI ? a : b` budgets, means heavy work is in the wrong tier; move the tests, don't raise the budget |

### 9. Test pollution

**What**: Tests modify global state without cleanup.

**Fix**: Use `monkeypatch` (pytest), `afterEach` cleanup, fresh databases per
test, `try/finally` for plugin registration.

### 10. Quantity over quality

**What**: Chasing coverage percentage with weak tests. Execution coverage says
what ran, not what would be caught.

**Fix**: Judge oracle strength, not counts: a test with weak sole assertions is
weak whatever the coverage. To find the weak ones, seed a fault in the code a
test claims to cover and see whether it fails (cheapest first:
`references/gate-integrity.md` §5). Make coverage informational, not blocking, and check its denominator (thresholds only
see files the tests load unless `include` lists the source tree).

**Never turn a heuristic into a quota.** A per-file or per-test assertion minimum
(for example "at least 3 per test") gets met with `isinstance` and not-empty checks,
and the same happens to coverage and mutation score floors. Use counts only to
find tests to read.

### 11. Missing sad path

**What**: Only happy-path tests. No tests for invalid input, errors, edge cases.

**Fix**: For every feature: test valid input, invalid input, boundary values,
empty/null, error conditions, and (where applicable) concurrency.

### 12. Stale VCR cassettes / snapshots

**What**: Recorded API responses or snapshots that no longer match reality.
Developers blindly update without review.

**Fix**: Delete and re-record periodically. Require explicit reviewer approval
for snapshot changes. Filter volatile data from cassettes.

### 13. Logical defense-in-depth (shotgun validation)

**What**: Defense-in-depth applied to internal program logic in a
non-adversarial, already-typed context. Every layer defends against the
*same* failure mode in the *absence* of an adversary, instead of lifting
the invariant into a type, schema, or contract once at the boundary.

**Detection signals** (any one is enough; co-occurrence is diagnostic):
- **Repeated validation everywhere** — same `is None` / `!= ""` / `len > 0`
  guard at controller, service, and repo
- **Loose strings** flowing through the whole system instead of being
  parsed into a precise type at the boundary
- **Status enums duplicated across layers** — `OrderStatus` redeclared in
  DTO, service, repo, UI
- **Catch-all retries** — `for _ in range(3): try: ... except Exception:`
- **Silent fallback behavior** — `lookup() or default()` hiding failure
- **Post-hoc sanitizer patches** — regex stripping characters that should
  never have been representable
- **Runtime guards instead of state machines / types / schema constraints**
- **"This should never happen"** comments and assertions
- **Tests `test_X_rejects_null` / `_empty` / `_negative`** duplicated
  across many functions in one module
- **Builders that permit invalid objects** plus tests asserting the
  invalid objects are rejected

**Distinguish from**: defense-in-depth where each layer faces a
*different* failure mode or *different* adversary — hostile input, auth
boundaries, SSRF/XSS/injection, external system failure, rate limits,
retries, observability, recovery. Those layers and their tests are
not this antipattern.

**Fix**:
1. Lift the invariant into a type, schema, or sealed enum at the outermost
   trust boundary (smart constructor, branded type, `NonEmpty`,
   `EmailAddress`, newtype, state machine, schema constraint).
2. Delete every downstream check and **its test**.
3. Add the two tests that survive: (A) a property-based test that *proves*
   the invariant holds for valid inputs, and (B) a test that tries to
   construct each invalid state the type claims to forbid and asserts the
   construction fails. If (B) passes by *succeeding* in construction, the
   model has a hole — fix the model, not the test.
4. If the language cannot express the invariant in the type system, keep
   exactly one runtime check at the outermost layer and one test for it.

See `references/correctness-by-construction.md` for language-specific
patterns and the canonical lineage (Hoare → Dijkstra → Meyer →
Praxis/SPARK → seL4 → Minsky → King → LangSec).

### 14. Asserting through fault-masking code

A specialization of #2 worth naming: when the code under test silently absorbs
anomalies before they reach the output — `max(0, min(100, score))`, `except
Exception: return 0`, a Go `recover()`→zero, `value or DEFAULT`, or any
high-domain/range coercion — even a *specific* assertion on the final output
can't catch a fault. Voas & Miller's model: a fault must be **Executed**,
**Infect** the data state, and **Propagate** to output to be caught; a mask
breaks propagation, so the computation can be wholly broken and the test still
passes. (In #2 the *assertion* is weak; here the *SUT* destroys the signal.)

**Fix — surface the infection so it can propagate:**
1. Prefer a smaller public seam or explicit observable diagnostic before
   reaching into private state. If the pre-mask value is a stable, approved
   testability seam, assert it directly; asserting only the clamped/defaulted
   output still cannot see an unrelated infection that the mask absorbs.
2. If a mask hides a genuine defect, surface it (raise/return an error) rather
   than testing around the silent recovery.
3. Run focused mutation testing on masked modules. A survivor is a triage
   question—it may expose a hidden fault, but may also be equivalent, irrelevant,
   or specified masking (see `references/mutation-testing.md`).

**Restraint — when the mask is the specified behavior, don't flag it**: if
clamping volume to `[0,100]`, graceful degradation, a documented fallback, or
saturating arithmetic *is the contract*, that is correct code — test the
specified behavior directly (`set_volume(150) == 100`) and do **not** call it
fault-masking or recommend removing it. The smell is a mask hiding the
*unrelated* computation behind it, not a mask that is itself the feature.

### 15. Logic in tests / over-DRY test code

**What**: Test code optimized like production code. Signals: expected values
built by concatenation/arithmetic or from the SUT's own constants (`assert
url == BASE + "/users/" + name` — the expectation can share the SUT's bug
and stay green); `for`/`if` in a test body deciding which assertion runs; a
shared fixture mutated in `setUp*`/module scope far from the assertion that
depends on it; helpers that hide which inputs a test's outcome depends on.

**Why it matters**: Tests have no tests of their own. An abstraction that
breaks (or shares the SUT's bug) inside test code has nothing to catch it,
and a reader cannot verify an expectation without chasing helper
definitions. Cause and effect should sit together, even at the cost of
duplicated setup — test code leans DAMP (descriptive and meaningful
phrases), not DRY.

**Fix**: One behavior per test; setup local and explicit next to its
assertion, duplicated when necessary; expected results derived independently
of the SUT (often literals for simple examples); loops replaced by named
parameterized rows with no branching in the row body.

**Restraint — the sanctioned DRY**: value-construction builders/factories
with reasonable defaults are correct *when every field an assertion depends
on is set explicitly in the test* (see `references/test-data-builders.md`).
DAMP targets hidden behavior, not value helpers; do not inline a builder's
boilerplate into every test. Named-row table tests (e.g. Go's
`t.Run(tt.name, ...)`) are fine.

### 16. Always-green and dead gates

**What**: A check that cannot fail or is not running: `|| true`,
`continue-on-error`, baseline updaters used as checks (`detect-secrets scan
--baseline` exits 0 and absorbs the new secret), error-swallowing shell, deploys
that `::warning::`-skip and end green, E2E that is green when secrets are missing,
scanners run over an empty directory, coverage thresholds never invoked, CI that
stopped executing (quota, billing, missing runner) while pushes continue.

**Fix**: Make each gate fail closed and prove it by planting a violation in a
scratch copy. An advisory job needs an owner, a change-based trigger, a
notification, and an exit plan. A diagnostic nobody reads is a cost, not a dead
gate: run it on demand or delete it rather than adding a threshold. See
`references/gate-integrity.md`.

### 17. Vacuous passes

**What**: The assertion holds because nothing was checked: assertions only inside
a loop over output that can be empty; "every row satisfies P" over zero rows;
`Math.min(...[])` or other zero-sample aggregates passing a threshold; a test or
script that reimplements the logic and imports nothing from the SUT; tests of code
with no non-test importer.

**Fix**: Assert the precondition (non-empty, HTTP 200, font loaded, n > 0) before
the universal claim and print the denominator. Import the real code. Check that the
subject has a production importer.

### 18. Permissive environment (yes-man doubles)

**What**: The test environment enforces fewer constraints or runs fewer branches
than production: fake databases that ignore `WHERE` clauses or accept wrong bind
counts, hand-written schemas that drift from migrations, bindings omitted from the
test config (so `env.AI && ...` paths never run), fresh-only databases, tiny
fixtures. A variant: production code gains a branch whose only job is to keep a
test double working.

**Fix**: Load schemas from migrations, run a real local engine, add fakes for
every binding production uses, and enumerate capability-gated branches so none
hides. Remove branches that are unreachable with the real dependency.

### 19. Self-authored oracles

**What**: Goldens approved, eval questions written, or expected values chosen by the
same actor in the same change as the code they judge. The suite then measures
agreement with its author, not correctness.

**Fix**: Treat such goldens as characterizations until independently reviewed;
write eval cases before the change or from users' own words; report a trivial
baseline (e.g. title-keyword matching for a retrieval eval) next to the real score
so a non-discriminating eval is visible.

### 20. Silent tier downgrade

**What**: A cleanup or "improve test quality" change replaces a real-engine test
(SQLite, workerd, browser) with a mock or string assertion, or deletes it, without
saying so. Lessons written down the week before are undone.

**Fix**: When removing or replacing tests, list them by tier and keep the tier or
stronger. A lesson or postmortem counts only when a check enforces it.

### 21. Mutation program without a decision

**What**: Mutation testing run as a standing program rather than to answer a
question about specific tests. Signals:
- scheduled runs over unchanged code that repeat the same score;
- floors copied from round numbers, set above the measured score, or taken
  from a loaded local run;
- "no surviving mutants" as a definition of done, or every survivor treated as
  a release blocker;
- private helpers exported, production code marked, or implementation details
  (tie-breaks, epsilons, cache internals) pinned only to kill a survivor;
- tests that enforce enrollment in the mutation lane;
- a mutation tool kept as a dependency that nothing runs;
- source-text "sabotage proofs" for regex change-detectors, which only test the
  regex.

**Why it hurts**: The recurring lanes cost runner-hours and, more lastingly,
couple tests to implementation. The survivors they surface are often
equivalent. Real findings come from cheap one-off checks.

**Fix**: Seed faults cheapest first (`references/gate-integrity.md` §5), then
use a tool scoped to changed code, on demand. Classify a survivor that is
equivalent, unreachable through the public interface, or performance-only; do
not chase it. Delete lanes that have never changed a decision.


## Supplied guidance: testing-best-practices/references/test-audit.md

# Audit and repair existing tests

Use this workflow for a bounded test-quality sweep, consolidation, or deletion.
It complements [anti-patterns](antipatterns.md) and [gate integrity](gate-integrity.md).
The output is a set of evidence-backed decisions about tests and their owners.
Search hits, test counts, coverage percentages, and deleted lines are not quality
verdicts or targets.

## 1. Establish scope and baseline

- Read repository instructions, CI configuration, nearby tests, and relevant open
  PRs. Pin the base SHA. Choose a coherent production owner or boundary and a time
  budget; do not start with a deletion quota.
- For each in-scope tier, record the actual command, CI job/trigger, last result
  on the default branch, and whether it selects any tests and can fail. Read job
  results rather than inferring them from the workflow's overall conclusion.
- Run each relevant tier once when feasible, or record why it was unavailable.
  A passing baseline does not establish oracle strength. A failing baseline may
  expose a product bug; keep it separate from cleanup candidates.
- Read the owner, entry points, callers, fixtures, and history of candidates.
  For external-system doubles, inspect the real API/types and exercise the real
  runtime where available. SQLite can validate SQL without validating D1's
  binding semantics, `exec`, `batch`, or limits.
- Check fixtures are obtainable from a fresh checkout. An orphan Git pin, a
  developer-specific absolute path, unavailable recording, or generated state
  with no maintained recipe makes historical proof difficult to reproduce. If replacing it with
  generated scenarios, verify their observable state and label old outputs as
  historical rather than claiming the original experiment was reproduced.

## 2. Discover candidates cheaply

Start with focused searches, then read each hit in context. With ripgrep, from
the target repository root:

```sh
rg -n -g '*test*' -g '*spec*' -g '!node_modules/**' -g '!vendor/**' \
  '(readFileSync|read_text|read_to_string|toBeDefined|toBeTruthy|assertIsNotNone|waitForTimeout|Thread\.Sleep|time\.sleep|test\.only|test\.skip|pytest\.mark\.skip)' .
rg -n -g '*.yml' -g '*.yaml' -g '!node_modules/**' -g '!vendor/**' \
  '(continue-on-error|\|\| true|--passWithNoTests|--updateSnapshot)' .github
```

These commands only collect candidates; exit 1 means no regex match, not a clean
bill of health. They miss nonstandard test paths, assertion-free tests, computed
oracles, custom helpers, and semantic duplication. Adapt paths/frameworks and
inspect at least the critical boundary's tests and helpers directly. Do not turn
these patterns into a CI failure rule without calibrated good/bad examples.

For every candidate, ask:

| Signal | What to inspect | Possible improvement | Reason to retain |
|---|---|---|---|
| Source/config/SQL strings, copied counts, hashes | Does it execute the owner or only recognize its spelling? | Run the executable, renderer, parser, migration, or real engine | Independent architecture, package, protocol, prompt-byte, or published config contract |
| Mock supplies the asserted answer | Where did the expected value and fixture come from? Does the real owner produce the effect? | Real local engine; externally grounded fixture; assert persisted/emitted state | A controlled dependency failure or a separately verified external contract |
| Truthy, not-null, no-crash | Which wrong outputs would still pass? | Assert relevant values, state transitions, and error semantics | Existence or totality is itself the complete contract |
| Assertions in loops, empty result lists, negative checks | Are inputs nonempty and is the intended branch reached? | Assert enrollment/reachability and check each required item | An empty violation set is valid when inspected inputs are independently nonempty |
| Same behavior at several layers | Which suite owns the contract? What distinct failure can each layer detect? | Consolidate shared behavior into a keeper; retain wiring/lifecycle checks | Transport, security, persistence, platform, or ordering risks differ |
| Sleep, retry, timeout increase | Who produces completion? Does the original shard order reproduce a leak? | Wait for produced state; virtual time; repair resource ownership | A measured performance or timeout contract, with justified bounds |
| Test-only export, flag, wrapper, injection hook | Are there non-test callers? Is this a useful owned interface or only access to internals? | Move proof to a real entry point; remove an obsolete seam within scope | A legitimate public API or stable dependency boundary |
| Name promises more than assertions prove | Do input, execution, and oracle reach the named condition? | Correct the test/fixture or narrow its name and claim | A narrower, honest contract still matters |
| Grader/checker self-tests all pass | Can plausible wrong answers pass a scored assertion? Are valid phrasings rejected? | Calibrate each independently scored assertion with both controls | Instrument validation proves checker behavior; product or model gains need their own experiment |

Static, slow, mocked, and single-assertion tests are not automatically bad.
Retain independently specified API, security, migration, storage, release,
cross-language, default, and observable-ordering contracts. Do not remove
behavioral proof merely because a type exists; check its runtime boundary and
hostile inputs using [correctness by construction](correctness-by-construction.md).

## 3. Decide before editing

For each candidate and relevant neighbour, record one decision. Start with the
highest-risk evidence, rather than cataloguing every obviously sound test in a
large repository. Expand to a full ledger when a broad layer removal makes
coverage ownership uncertain.

```md
Base SHA / owner / scope:
Tier command / CI job / baseline result:

| Test location and name | Observable contract / credible regression | Expected-value provenance | Decision | Remaining proof / keeper | Validation |
|---|---|---|---|---|---|
```

- **Retain**: name the independent contract and the regression it catches.
- **Repair**: preserve the contract; fix a weak oracle, unreachable fixture,
  unrealistic double, or synchronization problem.
- **Consolidate**: name the keeper test and migrate every distinct assertion
  before removing the redundant suite. A similar name or coverage line is not
  evidence that the keeper catches the same bug.
- **Delete**: name the remaining proof, or explain why no independent contract
  exists. No contract needs no artificial replacement. Missing evidence means
  retain pending investigation.

Before any deletion, record the old and new tier and inspect CI routing,
parameter rows, negative/error branches, callers, and the reason the test exists.
An internal duplicate can disappear while its boundary proof remains. An
independent real-engine contract must keep equal or stronger proof.

## 4. Repair and prove preservation

Work in small owner batches. Keep production fixes distinguishable from test
cleanup; respect tests-only scope and report any required production repair.

1. Replace source recognition and self-supplied answers with execution through
   the smallest honest production boundary. Expected values come from a spec,
   reviewed recording, independent model, or explicit example, not the SUT's
   constants or the double's implementation.
   A captured result can be a deliberate compatibility characterization; label
   and review it using [golden-file guidance](golden-file-testing.md). Comparing
   the SUT with its own fresh output establishes repeatability, not independent
   correctness.
2. Check negative controls reach the intended guard. Rejecting for unrelated
   missing configuration, fixture setup, or an earlier validation is no proof of
   the claimed rejection. A loop whose assertions never run supplies no evidence
   for its per-item claim; direct emptiness assertions can be valid contracts.
3. For a retained contract moved into a keeper, choose a plausible fault from
   what the old assertion could detect. Use isolated scratch copies/worktrees;
   do not mutate a checkout while tests are running. Run old and new tests
   against the **same** fault and record:

   | Fault / contract | Old tests | Keeper | Interpretation |
   |---|---|---|---|
   | Concrete production change | Fail/pass/unrun and reason | Fail/pass/unrun and reason | Preserved, stronger, lost, or unknown |

   Old fails/new passes is a possible lost check to resolve. Old passes/new
   fails shows additional sensitivity only if the failure is for the intended
   behavior. Both pass calls for investigation; equivalent or unreachable
   mutations are not automatically missing tests. Restore mutated source
   byte-for-byte. Do not pursue a mutation-score target or schedule a new lane
   by default; see [mutation testing](mutation-testing.md).
   For suspected implementation locks or custom checkers, also exercise a
   representative allowed change that must stay green: for example, JSON
   whitespace/key reordering when only parsed meaning is promised. Keep a real
   defect control alongside it. Preserve exact bytes, item order, or integrity
   checks when those are the independent contract. Catching more faults is not
   an improvement if harmless changes now fail.
4. A product bug needs an observed failing control and passing repaired run on
   the same harness where feasible. Report unavailable red/control evidence.
   A baseline failure is not permission to delete the failing test.
5. Run keeper/owner and relevant sibling tests, then required changed checks.
   Check deleted tests did not orphan support files, imports, exports, or CI
   entries. Search documentation for their descriptions as well as names.
   Delegate broad proof to the repository's normal CI when appropriate.

Choose checks in proportion to the change. Deleting a test with no independent
contract does not require inventing a mutation. When a compiler replaces a
type-level check, demonstrate that removing the relevant member fails the
actual typecheck, rather than building a mutation-testing program around it.

## 5. Review and hand off

For substantial removal, independently compare the deleted assertions against
the keepers, with special attention to error rows, persisted fields, ordering,
and external-system fidelity. Add production-correctness review when production
code or an external-system double changes. Review is useful when it checks
specific preservation risks; a fixed number of reviewers is not a requirement.

Report decisions, contracts retained/lost/restored, commands and actual results,
control/fault evidence, CI state at the pushed SHA, and unresolved gaps. Separate
test/support changes from production changes and any product defects discovered.
Do not claim quality from a lower test count or a green-only run.

## Reusable task brief

```text
Use testing-best-practices to audit and improve existing tests for <owner/boundary>.
Scope: <paths and allowed production changes>. Budget: <time/size>.
Read the skill's references/test-audit.md and relevant language/tier references.
Establish CI liveness and a pinned baseline; discover candidates, then inspect
their production owners, fixtures, callers, and history. Record retain/repair/
consolidate/delete decisions, independent expected-value sources, and remaining
proof before edits. Repair the highest-risk false-confidence cases through real
boundaries. For moved contracts, compare old and keeper tests against the same
credible faults; explain no-contract deletions. Treat baseline product failures
as defects. Validate focused proof and required gates, review lost coverage, and
report exact evidence and gaps. No deletion, assertion, or mutation-score quota.
```


## Task

A verifier's tamper tests now account for 32% of unit-suite time. Each negative variant reruns expensive preparation and the complete oracle pipeline. The next audit proposes adding more variants, repeating the whole pipeline for each, and increasing the global test timeout. The checker must still reject each bad variant: reusing the final verdict would not test those variants. Review the change and give a concrete way to preserve the verification while controlling its cost.

## Response format

Return ONLY a JSON object with these keys: decision (approve/revise/reject), changes (array of objects with target, action, details), retained_contracts (array of strings), validation (array of concrete commands or checks), cost_and_stop (string), rationale (string). Propose concrete changes you would actually ship, not just warnings. Stay within the supplied task. Do not execute the proposed work. Keep the JSON answer under 650 words.
