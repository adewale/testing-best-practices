Read only this packet. Work independently without other agents. Write the exact final JSON response to response.md beside this packet and return the same response.

Use only the task and context in this packet. Do not browse other files, use the network, run proposed checks, or contact other agents.

## Supplied guidance: testing-best-practices/SKILL.md

---
name: testing-best-practices
description: >
  Enforce testing best practices when writing, reviewing, or improving tests.
  Covers TDD/red-green-refactor, property-based testing, real objects over
  mocks, correctness by construction, assertion quality, E2E/contract tests,
  flaky-test upgrades, mock-reality drift, mutation-style gap analysis, and
  sabotaged/skipped/weak tests. Use when writing tests, reviewing test quality,
  fixing flaky tests, improving coverage quality, or when the user mentions
  TDD, testing, coverage, mocks, invariants, types vs tests, defense in depth,
  fuzzing, generative testing, or test quality.
compatibility: Agent Skills clients including Codex, OpenCode, Pi, Gemini CLI, and Claude Code.
metadata:
  author: adewale
  version: "0.3.2"
---

# Testing Best Practices

This skill has four modes:

1. **Write** — add tests or test-first bug fixes/features.
2. **Assess** — review an existing suite for quality, not just coverage.
3. **Upgrade** — strengthen weak/flaky/over-mocked tests.
4. **Detect** — find skipped, sabotaged, fake-coverage, or gap-prone tests.

## First 90 seconds

Before writing, assessing, or changing tests:

1. **Detect language/framework** from repo files and adjacent tests.
2. **Read nearby tests** for naming, fixtures, builders, assertion style, and runner commands.
3. **Find the nearest validation command** before broad full-suite commands.
4. **Identify the risk boundary**: pure logic, internal component boundary, external API, UI/user journey, security boundary, hostile-input parser, or type/schema invariant.
5. **Classify the change and asset**: behavior change vs. structure/tidying, reusable library vs. throwaway probe, customer-facing rule vs. internal helper.
6. **Choose the smallest useful test tier** from `references/test-types.md`.
7. **Load only relevant references** from the matrix below.

If the language is unsupported by a dedicated reference, follow project conventions plus the generic principles here.

## Reference matrix

Always consider:
- Test type selection → `references/test-types.md`
- Anti-pattern detection → `references/antipatterns.md`

Language/framework references:
- Python / pytest / Hypothesis → `references/python.md`
- TypeScript/JavaScript / Vitest/Jest/fast-check/Playwright → `references/typescript.md`
- Go / testing / testing.F / Rapid → `references/go.md`
- Rust → `references/rust.md`

For property-based testing or coverage-guided fuzzing, also load the matching language reference: collection, discovery, and replay differ by engine. If the selected engine is not documented here, follow its project documentation rather than transferring another engine's behavior.

Topical references by trigger:
- Auditing, repairing, consolidating, or deleting existing tests → `references/test-audit.md`. Start with candidates; record contracts, expected-value provenance, decisions, and remaining proof before edits. Compare old and keeper tests against the same credible faults when moving contracts.
- Sampling a larger suite or choosing a failure/recovery witness → `references/test-audit-patterns.md`. Report inventory, selected strata, files actually read and unrun tiers; a sample cannot justify retiring an unexamined layer.
- Custom checkers, graders, evaluation scores, or claims of model/skill improvement → `references/checker-calibration.md`. Exercise the public scoring route, preserve process failures and compare compatible measurements.
- Writing/reviewing property tests, choosing a property, generator design, stateful/model-based testing, seeds and replay → `references/property-based-testing.md`
- Coverage-guided targets or campaigns for exposed/custom parsers, native or unsafe decoders, crash-prone boundaries, or security tooling whose crash disables a check → `references/fuzzing.md`
- Legacy/refactor safety → `references/characterization-testing.md`
- Reimplementation, port, multi-language SDK, custom data structure with no reference, or approximate/probabilistic/ANN/ranking output → `references/differential-testing.md`
- Complex outputs, snapshots, transformation pipelines, save/load or migration roundtrips → `references/golden-file-testing.md`
- Time, timers, schedules, sleeps, flaky time tests, background threads/async work tests can only reach by sleeping → `references/deterministic-time.md`
- External APIs, recorded real responses, mock drift → `references/vcr-cassettes.md`
- CLI/plugin/docs registry sync, or verification claims in docs and agent instructions → `references/doc-sync-testing.md`
- Mutation testing, mutation scores/survivors, recurring mutation lanes, or high coverage but escaping bugs → `references/mutation-testing.md`. For recurrence, no completed target-CI baseline or demonstrated fault-class bite means no schedule; never copy an absolute score floor.
- Finite state spaces or expensive cross-products → `references/exhaustive-testing.md`
- Large configuration/feature/runtime matrices, pairwise replacement, or interacting factors → `references/combinatorial-testing.md`. Preserve fixed regressions and exact registry enrollment; use named variable-strength groups and shadow evidence before deletion.
- Arithmetic/domain operators/laws → `references/mathematical-properties.md`
- Fixtures/builders/assertion helpers → `references/test-data-builders.md`
- Same invariant checked across layers, type-vs-test decisions, invalid states → `references/correctness-by-construction.md`
- CI/hooks/test-config changes, gated or scheduled tiers, "is this check running and can it fail?", deploy verification → `references/gate-integrity.md`

## Core principles

### Test behavior through public contracts

Good tests describe observable behavior: outputs, state transitions, side effects, rendered UI, persisted data, API contracts, or invariants. Avoid tests that break under behavior-preserving refactors: private methods, incidental call order, exact SQL strings, or broad mock choreography.

When a user brings examples, tables, bug reports, spreadsheet rows, or support cases, treat them as communication artifacts first and assertions second. Preserve the business language, then run the examples against the narrowest honest seam: usually the domain/service/API contract, not a full UI path for every business-rule row. UI/E2E tests should prove the wiring and golden path; rule tables should exercise the domain layer directly.

### Calibrate test investment to lifetime and change kind

Do not give every artifact the same test plan. Reusable libraries, parsers, payment/auth/security boundaries, migrations, and code that will be refactored deserve stronger regression/property/contract coverage. Throwaway probes, one-off research scripts, or generated exploration may need only a smoke check or no tests if the user accepts that lifecycle.

Separate **behavior changes** from **structure changes**. Behavior changes need tests that can fail for the new/changed behavior. Pure tidying/refactoring should ride an existing green suite; if no such suite exists, add characterization tests for the behavior you need to preserve before refactoring.

For a new service with no pipeline, start with a walking skeleton: the thinnest build/deploy/test slice. Track unfinished acceptance tests as visible in-progress items tied to a story/issue, not silent skips. Keep unit tests green; do not commit failing unit tests as proof.

### Use red-green-refactor when feasible

For bug fixes and new behavior, default to:

1. **Red** — add a focused test that fails for the current bug/missing behavior.
2. **Green** — implement the smallest change that passes.
3. **Refactor** — clean up while tests stay green.

The evidence matters. Separate **red evidence** (exact command and failing output before the fix) from **green evidence** (passing command/result after the fix). Only claim completed TDD/red-green-refactor when both were observed in order. If only a passing/green run is available, say tests were added and now pass, but the red phase was not observed/unverified; do not backfill a TDD claim from a green-only log. For exploratory prototypes, generated code, or user-scoped “tests only” tasks, stay within scope and state the deviation.

When practicing TDD, keep a visible **test list**. Park new edge-case ideas there instead of chasing them mid-cycle. If stuck, downshift: write the assertion first, extract a smaller child test, use a learning test for third-party APIs, or use a crash-test-dummy fake to trigger hard error paths. Choose Fake It, Triangulate, or Obvious Implementation according to uncertainty; never leave fake constants as the final behavior.

### Quality beats coverage

Coverage shows what ran; it does not prove bugs would be caught. Prefer branch coverage over line coverage and treat coverage as a map for finding untested paths, not a quality gate by itself.

Assertion count is a heuristic, not a law; never turn it into a quota. Example-based behavior tests often need multiple meaningful assertions to verify structure, state, and negative cases. But a property test, table row, or exception test may have one excellent oracle. Flag weak sole assertions such as “not empty,” `toBeDefined()`, `toBeTruthy()`, `Assert.IsNotNull(result)`, or logging without assertions.

For sanitizers, validators, filters, auth/security checks, and transformations, verify both directions where applicable: dangerous/invalid content is rejected or removed, and safe/valid content is preserved.

Assert the fields the behavior under test is about. Full-object/whole-structure equality implicitly asserts every unrelated field, so the test breaks on unrelated changes and joins a change-detector treadmill (update the literal each time a field is added). Reserve whole-state comparison for tests where breadth is the contract — golden files and save/load roundtrips (`references/golden-file-testing.md`). Prefer assertion forms whose failure message alone can start the debugging (matchers/fluent asserts that print expected vs. actual, not bare booleans); when many tests keep breaking for innocent reasons like iteration order, fix the assertion vocabulary (order-insensitive/structural matchers), not each test. For coverage, gate new/changed code rather than one repo-wide number, and read what is *not* covered as the review signal.

Every custom oracle, linter, validator, fixer, or eval grader needs a known-good input that passes and a known-bad input that fails; keep them small, and don't rerun an expensive checker for every bad input. Goldens, approvals, or eval cases written by the same actor in the same change as the code are characterizations, not independent oracles.

### Prefer real behavior over mocks

Prefer, in order:

1. Real in-memory/local objects, temp dirs, in-memory databases, real parsers.
2. Local emulation of the real runtime (workerd/vitest-pool-workers, Pyodide in Node, `wrangler dev`, SQLite loaded from migrations).
3. Purpose-built fakes that implement the same interface and can record history.
4. Deterministic stubs for controlled edge cases.
5. Framework mocks as a last resort.

Ground an external double's shapes and semantics in the real API, types, recordings or runtime. A distinctive literal response is valid input for an owned forwarding or error-handling contract; it is not proof that the real provider produces it. Use an affordable real engine for claims about that engine. Retain controlled doubles for distinct dependency-failure and wiring contracts rather than deleting them merely because an engine exists.

Prefer visible state over call choreography: assert the saved row, emitted event, response body, file on disk, or a small logging fake's recorded effects. Do not mock values; construct them. Mock roles you own, not third-party libraries directly; wrap provider SDKs behind an owned interface and add a contract/VCR check for the real provider shape. For interaction tests, allow queries and expect commands: getters can be called freely, side-effecting commands are where expectations earn their keep.

### Use properties for broad input spaces

Use property-based testing when behavior spans a broader input or operation space than examples can cover economically. Choose a property that states meaningful behavior—roundtrip, idempotence, conservation, metamorphic relation, algebraic law, or agreement with a small model—not merely that execution did not crash.

Match the generator to the behavior being tested: arbitrary input for totality and documented errors, specification-valid input for semantic branches, stateful traces for lifecycle behavior, and corpus mutation for coverage-guided discovery. Use an oracle independent of the implementation. Property tools construct values and shrink failures; coverage-guided fuzzers mutate a corpus toward new control flow. Do not use the terms or tools interchangeably.

For small finite spaces, prefer exhaustive generation over sampling, after checking per-cell cost and whether a cheaper layer decides the property (`references/exhaustive-testing.md`). See `references/property-based-testing.md` for generator, oracle, execution, and replay guidance.

### Test error-handling paths, not just invalid input

Most critical production failures are shallow: they live in error-handling code that only runs when a dependency *already* failed — a disk-write error, a dropped connection, a timeout, a partial response. Empirical studies of catastrophic distributed-systems failures find the majority were reachable by simple tests that exercised those paths. So "sad path" means more than rejecting bad arguments: inject the downstream failure (a fake/stub that raises, an injected I/O error, a `side_effect` exception) and assert the system degrades correctly.

Assert the failure behavior the code *actually* has, not one you wish it had. Read the spec or observe the code to learn what a failure should do — propagate, retry, wrap, fall back, roll back — and test that. Do not invent a retry budget, a custom error type, or rollback semantics the contract never promised; that tests a fictional contract and is scope creep. If the intended failure behavior is unspecified, characterize what the code does today and flag the gap as a follow-up rather than designing new production behavior inside a test.

### Push internal invariants into types/schemas/contracts

Types and tests answer different questions:

- Types/schemas/contracts: “Can this invalid state exist?”
- Tests: “Does observable behavior match the spec?”

When an invariant is repeated across internal layers, consider lifting it to a boundary parser, smart constructor, schema, sealed enum, state machine, or database constraint. Before deleting checks or their tests, verify all of this:

- the context is internal and non-adversarial,
- the invariant is actually enforced by the type/schema/constructor,
- boundary tests cover hostile or malformed input,
- security/auth/external-failure layers defend different failure modes,
- production type changes are in scope or explicitly approved.

If user scope says “tests only” or “do not change production code,” add tests for the current API and list type/schema tightening as a follow-up.

### Test concurrent code under a race detector, and pin the concurrency contract

For code meant to be used by multiple goroutines/threads, sequential tests prove almost nothing. Drive the shared state from many workers released together (a start barrier maximizes contention) and run under a race detector or thread sanitizer (`go test -race`, ThreadSanitizer / `-fsanitize=thread`, repeated runs via `-count`). Treat a green concurrent test as weaker evidence than a sequential one — races are probabilistic.

Assert the invariant the API actually promises — no lost updates, a monotonic/linearizable count, compute-at-most-once — instead of logging whatever count you happened to observe and moving on. If the implementation can violate that contract (e.g. it computes outside the lock, so two callers double-compute), that is a defect to surface with a failing test or an explicit flag, not a `t.Logf` that quietly bakes the race into the expected behavior.

## Mode workflows

### Write mode

Before adding a test, name the observable contract, a credible regression it catches, and why existing proof misses it. Extend an existing test or table when it covers the same contract; another layer needs a distinct risk. If the test requires exposing internals solely for access, look for a real production boundary first.

1. Read adjacent tests/config and load the relevant language reference.
2. Choose test tier from `references/test-types.md`.
3. For bugs/new behavior, add the failing regression test first when feasible.
4. Convert user/customer examples into readable test cases without forcing every example through the UI.
5. Use builders/factories/helpers where setup noise hides intent; test custom helpers when they become a mini-DSL.
6. Prefer user-facing/public interfaces over internals.
7. Pin nondeterminism: time, randomness, network, filesystem, order.
8. Choose test values deliberately: include distinct, non-default values so at least one case would expose a dropped, defaulted, or swapped argument. Still cover zero, empty, and equal-value cases when they are boundaries or part of the contract. Derive expected results independently of the SUT: literals are clearest for simple examples, while properties or a genuinely independent reference model fit broader cases. Do not recompute the expectation with the SUT's own logic or constants, because the test can share its bug and stay green.
9. Run the nearest tests, then broader checks when practical.

For transformations or complex generated output, use golden files with explicit review discipline; see `references/golden-file-testing.md`. For external APIs, prefer recorded real fixtures/cassettes or contract checks over live CI calls; see `references/vcr-cassettes.md`.

### Assess mode

For a test-quality sweep, use `references/test-audit.md` to turn detection signals into evidence-backed retain/repair/consolidate/delete decisions. Search hits alone do not justify edits.

Report evidence by severity and include positive observations. For generative tests, load the relevant language and topical references before recommending engine-specific changes. Check:

0. **Is it running, and can it fail?** For each tier: the job that runs it, its last result on the default branch, whether gated tests are reachable, and whether each gate can go red (`|| true`, `continue-on-error`, baseline updaters, skip-green, empty targets). A dead gate is the first finding. See `references/gate-integrity.md`.
1. **Sabotage / false confidence**: skipped/focused tests, no assertions, logging-not-asserting, commented-out assertions, always-true assertions.
2. **Oracle strength**: weak sole assertions, missing negative/error/state/structural assertions, tautologies. For property tests, a bare never-crashes oracle is weak when a semantic invariant is available.
3. **Mock-reality drift**: hardcoded mocks that would not notice real API/schema changes.
4. **Tier integrity**: unit tests hitting live network, integration tests mocking every boundary they claim to exercise, E2E tests that mock the system under test or drive it through a test facade, PR suites that target production, and whether the artifact under test is the artifact deployed.
5. **Determinism**: sleeps, wall-clock time, unseeded random, order dependence, global state leaks.
6. **Coverage quality**: branch coverage; for high-coverage suites with escaping bugs, seed a fault on the critical path and see whether any test fails, cheapest first (`references/gate-integrity.md` §5). A recurring mutation lane is not a default recommendation.
7. **Invariant placement**: repeated internal validation that should be a type/schema/contract.
8. **Lifecycle fit**: throwaway probes over-tested, reusable assets under-tested, or structure-only changes getting behavior-test theater.
9. **Example quality**: business examples buried in UI scripts, unreadable fixtures, or helpers that form a DSL but have no tests of their own.
10. **Generative evidence**: the configured runner reaches the production path, the generator reaches the claimed domain, the oracle is independent, and seed replay is not mislabeled as active discovery. Verify the exact CI configuration when multiple runners, projects, filters, or duplicated target lists make reachability uncertain; add a permanent drift guard only for recurring risk.
11. **Test-code readability (DAMP)**: logic in test bodies (loops/branches/computed expectations), expectations derived from the SUT's own constants, shared fixtures mutated far from the assertions that depend on them. See `references/antipatterns.md`.
12. **Suite shape**: count tests per tier; name the inverted pyramid/ice-cream cone (mostly E2E over a thin unit base) and the hourglass (unit + E2E with an empty integration middle). Recommend the smallest-tier home for each E2E case that has one — business rules move below the UI — while keeping a small golden-path/critical-journey E2E core.

### Upgrade mode

When consolidating or deleting tests, use `references/test-audit.md`: name the keeper and preserve distinct assertions before removal. Record no-contract deletions explicitly; do not fabricate replacement tests.

Prioritize by risk:

1. **P0**: security/auth/injection/sanitizer tests with weak or missing assertions.
2. **P1**: tests that only assert not-null/not-empty/truthy.
3. **P2**: flaky tests: sleeps, live network, wall-clock, order coupling. Before patching waits, ask whether a smaller SUT can host the test — size (dependencies, processes, RAM footprint) predicts flakiness better than tool choice — and treat auto-retry/quarantine as masking debt, not a fix.
4. **P3**: mock-heavy “integration” tests and implementation-coupled mocks.
5. **P4**: fixture noise, duplication, unclear names, missing builders.

Common upgrades:
- Replace `sleep()` with virtual time, injected clocks, or condition-based waits.
- Replace live API calls with recorded cassettes or committed fixtures.
- Replace broad mocks with fakes, contract tests, or assertions on public behavior.
- Replace repeated object literals with builders that keep behavior-specific fields explicit.

Never silently downgrade a tier: list removed or replaced tests by tier, and keep real-engine tests (SQLite, workerd, browser) unless an equal or stronger tier replaces them. A lesson or postmortem counts only when a check enforces it.

### Detect mode

Use concrete search signals from `references/antipatterns.md`:

- `@skip`, `skip`, `skipif` without real condition, `test.only`, `fit`, `xit`, `xdescribe`.
- `print`, `console.log`, `t.Log`, `Debug.WriteLine` used instead of assertions.
- Assertion-free tests or only truthy/not-empty/not-null checks.
- Property tests with no independent oracle, generators filtered into one easy path, or small finite domains sampled when they can be enumerated.
- `sleep`, `waitForTimeout`, `Thread.Sleep`, `Task.Delay` for synchronization.
- Try/catch swallowing exceptions.
- Mock return values identical to assertions.
- Global state/env/registry mutations without cleanup.
- Snapshot/golden updates without diff review.
- CI steps with `|| true`, `continue-on-error`, `scan --baseline`, or `::warning::` skips; coverage or mutation thresholds that never run.
- Mutation run as a program: calendar schedules over unchanged code, round-number floors, internals exported or pinned only to kill survivors.
- Assertions only inside loops over possibly-empty results; `violations == []` with no non-empty check; tests that import nothing from the code under test.
- Source, CSS, or workflow text read and asserted as strings; helper-level retry loops; raised global timeouts or `isCI ? a : b` budgets.

## Validation loop

After writing or changing tests:

1. Run the nearest relevant test command.
2. If bug-fix TDD was intended, report red evidence separately from green evidence; if the pre-fix failing run was not observed, call the red phase unverified instead of claiming completed TDD.
3. Scan the changed tests for weak sole assertions, skips/focus markers, logging-not-asserting, sleeps, live network, and implementation-detail coupling. Also check: expected results come from an oracle independent of the SUT, at least one test value would expose dropped/defaulted/swapped inputs, relevant boundary values are still covered, and assertions are narrow to the behavior's fields.
4. For security/transformation tests, verify both rejection/removal and preservation.
5. For invariant work, verify both tactics where relevant: property/invariant proof and invalid-state reachability.
6. For property/fuzz tests, confirm the claimed input domain, independent oracle, engine-native replay, and—where configuration makes it uncertain—collection or target selection with the exact CI command.
7. Decide pass/fail from exit status, not output text. Run the exact CI entrypoint rather than a sub-mode, and compile tag-gated files you touched with their tags.
8. When repairing CI, keep "update a stale selector" separate from "weaken an assertion or raise a timeout", and justify every weakening. Call a failure pre-existing only after reproducing it on a clean checkout of the base.
9. If validation is blocked, report the exact command, failure, and next-best check. Never claim tests passed without running them; say which environment a green claim came from, and check the pushed commit's CI when there is one.

## Final report contract

End testing work with:

```md
Tests changed/assessed:
Behavior covered:
Commands run:
Results:
CI status (ran / red / not running):
TDD evidence (if claimed):
Gaps / risks:
Follow-ups:
```

Keep it concise, but make validation and remaining risk auditable.


## Supplied guidance: testing-best-practices/references/golden-file-testing.md

# Golden File and Snapshot Testing

Two closely related patterns for asserting on complex output:

- **Golden files**: input file → output file, both on disk. Auto-discovered.
  Best for transformation pipelines (HTML→Markdown, compilers, code generators).
- **Snapshot tests**: any expression → stored string. Lives in or beside the
  test file. Best when an assertion would otherwise be a long, brittle
  field-by-field comparison.

Both can use an explicit **promote workflow**: generate a candidate in authoring
mode, review it against the intended contract, then commit it. Verification is
read-only: missing or different expected output fails, and CI never creates or
updates baselines. Hand-written contract-derived expectations are also valid.

## Golden Files

### How it works

1. Put input files in `tests/fixtures/`
2. Run the transformation and save output to `tests/expected/`
3. On subsequent runs, compare output against expected files
4. If no expected file exists, fail without writing one
5. To update: use a separate authoring command to generate a candidate, review
   its behavioral changes, and explicitly accept it

### The pattern (from kepano/defuddle)

```typescript
describe('Fixtures Tests', () => {
  const fixtures = getFixtures();  // Auto-discovers all .html files

  test.each(fixtures)('should process: $name', async ({ name, path }) => {
    const input = readFileSync(path, 'utf-8');
    const result = transform(input);
    const expected = loadExpected(name);

    if (expected === undefined || expected === null) {
      throw new Error(`Missing reviewed golden: ${name}`);
    }

    expect(result.trim()).toEqual(expected.trim());
  });
});
```

### Auto-discovery helper

```typescript
function getFixtures() {
  const dir = join(__dirname, 'fixtures');
  return readdirSync(dir)
    .filter(f => f.endsWith('.html'))
    .map(f => ({ name: basename(f, '.html'), path: join(dir, f) }));
}
```

### Why golden files work

- **Zero-code test creation**: add a fixture file = add a test case
- **Human-readable expected output**: Markdown/text, not binary
- **Real-world inputs**: actual web pages, documents, source files
- **Drift detection**: any change to transformation logic is caught

### When to use
- HTML → Markdown extraction
- Code formatting / pretty-printing
- Template rendering, compiler output
- Data migration / transformation pipelines

### Naming convention

Use `category--source-description.extension`:
```
codeblocks--stripe.html
comments--news.ycombinator.com.html
```

## Snapshot Tests (the promote workflow)

Snapshot tests generalize the golden-file idea: any string-renderable output
becomes the expected value, captured on first run, asserted on subsequent
runs. The expected output lives **inside** the test file (inline) or in a
sidecar (`__snapshots__/`), not in a separate fixtures tree.

### The promote workflow

1. Write the test with an empty expected slot; ordinary verification must fail
2. Run the framework's explicit update/authoring command to generate a candidate
3. Subsequent runs: framework compares actual vs expected, fails with a diff
4. When the change is intentional: run with `--update` (or interactive review)
5. **Commit the snapshot file with the code change** — the snapshot diff in
   your PR is the record of what observable behavior changed

### Tools per language

| Language | Tool | Update command |
|----------|------|----------------|
| Python | `syrupy` | `pytest --snapshot-update` |
| JS/TS | Jest, Vitest | `jest -u`, `vitest -u`, or interactive `u` in watch mode |
| Rust | `insta` | `cargo insta review` (interactive), `cargo insta accept` |
| Go | `cupaloy` | `UPDATE_SNAPSHOTS=true go test` |
| Multi-language | `approvaltests` | `*.received.txt` → rename to `*.approved.txt` |

### Python (syrupy) example

```python
def test_render_invoice(snapshot):
    invoice = Invoice(items=[Item("Widget", 9.99, 2)], tax_rate=0.08)
    assert invoice.render() == snapshot
```

Generate and review `__snapshots__/test_invoice.ambr` with
`pytest --snapshot-update`. Ordinary runs compare and must fail if it is missing.

### Rust (insta) — the inline form

```rust
#[test]
fn test_invoice() {
    let invoice = Invoice::new(...);
    insta::assert_yaml_snapshot!(invoice, @"");
    // After first `cargo insta accept`, the macro contains the snapshot inline:
    // insta::assert_yaml_snapshot!(invoice, @r###"
    //   items:
    //     - name: Widget
    //       price: 9.99
    //       quantity: 2
    //   subtotal: 19.98
    //   tax: 1.60
    //   total: 21.58
    // "###);
}
```

The snapshot lives in the source file — you read the test and see the
assertion together. This is closer to Jane Street's `ppx_expect` than the
sidecar `__snapshots__/` style.

## When to use snapshot tests instead of field-by-field assertions

- The output has more than ~5 fields you'd otherwise assert on individually
- The output is a tree, AST, rendered DOM, log sequence, or formatted text
- The same shape is asserted on across many tests (a single change should
  cascade through the snapshots, not require editing 50 assertions)
- The structure is part of the contract, not just the values

## When NOT to use snapshot tests

- The output has one or two meaningful fields — write specific assertions
- The "contract" is a single boolean or numeric value
- The output contains unredacted timestamps, UUIDs, or other non-determinism
  you haven't normalized (you'll get noise on every run)
- The test is exercising a security property — write the explicit assertion
  so a reviewer can't miss it among unrelated output

## Failure modes to defend against

Snapshot tests fail predictably when discipline slips:

### Rubber-stamping
The most common failure. Engineers run `--update` without reading the diff.
The test becomes a change detector, not a behavior test. Mitigations:

- Make snapshot diffs mandatory reading in code review
- Require a one-line explanation in the PR description for every snapshot
  diff: "Updated 3 invoice snapshots because we now include the tax line"
- For interactive review tools (`cargo insta review`), prefer them over
  blanket-accept

### Hash-only goldens
Pinning an exact render or op-stream hash gives no reviewable diff: every art or
layout change becomes a "rebind the hashes" commit, and a backend change needs a
second hash table. Prefer structural or perceptual goldens with a visible diff
(draw-command lists, text frames, SVG structure, images reviewed as images), and
treat pin churn per change as a health metric. If you must keep hashes, re-pin
through a tool that records a written review of what changed.

### Self-approved goldens
A golden created or re-approved by the same actor in the same change as the code it
checks is a characterization, not an independent oracle. Require an approval that
did not come from the authoring agent, or review the rendered diff yourself.

### Coupling to incidental detail
Timestamps, UUIDs, map iteration order, whitespace make tests fail on noise.
Fix at write-time:

```python
# syrupy custom serializer
class StableSerializer(SnapshotSerializer):
    def serialize(self, data):
        data = redact_uuids(data)
        data = freeze_timestamps(data, to="2024-01-01T00:00:00Z")
        data = sort_keys(data)
        return super().serialize(data)
```

### Cascade updates that hide intent
One logic change updates 50 snapshots. The reviewer can't tell which were
intended. Mitigations:

- Keep snapshots small and focused (one snapshot per behavior, not per test)
- Don't snapshot the entire program state — snapshot the part this test
  exercises
- When a refactor cascades through snapshots, split into two commits:
  "refactor (no behavior change, regenerated snapshots)" + "feature
  (intentional behavior change)"

### Loss of intent
A snapshot like `"hello Bob"` doesn't tell you what's important. The test
name has to carry the intent:

```typescript
// Bad: snapshot reveals nothing about why
test('renders correctly', () => { expect(view).toMatchSnapshot(); })

// Good: name carries the intent, snapshot verifies the form
test('greeting includes the user name after first interaction', () => {
  expect(view).toMatchSnapshot();
})
```

## Design pressure: make your output tell a story

The single biggest determinant of snapshot test quality is whether the
output itself is readable. Invest in:

- Custom `__repr__` / `Display` / `toString` for domain types
- Pretty-printers that surface what matters and elide what doesn't
- Stable serialization (sorted keys, normalized whitespace, fixed precision)
- Helper functions to format multi-object state into one cohesive trace

This is the principle behind Jane Street's `ppx_expect`: when stringification
is trivial and stable, tests get written. From "The Joy of Expect Tests":
*"The real art lies in producing output that tells a concise story, capturing
the state you care about."*

## Whole-state roundtrip digests (save/load, migration)

For persistence layers — save/load, serialization formats, schema migrations —
the highest-value characterization test is an **identity check over the whole
state**, not field assertions on one record. (Pattern source: Redis's
`DEBUG RELOAD` + dataset digest: snapshot a fingerprint, reload, assert the
fingerprint is unchanged.)

1. **Generate rich state with a seeded RNG** — many keys, every supported
   value type, the awkward ones especially (empty collections, TTLs, unicode,
   nesting). Hand-picked single-record tests miss exactly the types that break.
2. **Canonicalize, then fingerprint.** Produce a canonical dump of the entire
   state — **sort anything unordered** (sets, map iteration) before comparing
   or hashing. Digesting a non-canonical dump turns legitimate passes into
   flaky failures; structural equality on canonical forms is often better than
   a hash because failures show a diff instead of two checksums.
3. **Assert save→load is the identity**, comparing full canonical state.
4. **Parameterize the reload step across every format/path** — JSON and
   binary, snapshot and incremental, migration v1→v2→v1 — same state, same
   identity assertion, one parameterized test.
5. **On mismatch, emit both canonical dumps** so the failure is a reviewable
   diff, not "digests differ."

```python
@pytest.mark.parametrize("fmt", ["json", "binary"])
def test_save_load_roundtrip_identity(tmp_path, fmt):
    store = build_seeded_store(random.Random(1234), keys=500)  # all value types
    before = canonical_dump(store)                # sorted, normalized
    save(store, tmp_path / "db", format=fmt)
    reloaded = load(tmp_path / "db", format=fmt)
    assert canonical_dump(reloaded) == before     # whole-state identity
```

Two failure modes to defend against:
- **A digest that ignores fields gives false confidence** — if `canonical_dump`
  skips TTLs, TTL persistence bugs are invisible. The dump must cover every
  field the format claims to persist.
- **A digest over nondeterministic ordering gives false failures** — hashing
  `str(a_set)` fails randomly. Canonicalize first, always.

## Multi-environment testing

```typescript
const USE_JSDOM = process.env.DOM === 'jsdom';
export const parseDocument = USE_JSDOM ? parseWithJSDOM : parseLinkedomHTML;
```

Run the same fixtures through different backends; expected output should
agree.

When rendered output legitimately differs across platforms (fonts, GPU,
antialiasing), golden the deterministic intermediate (text frames, draw-command
lists) rather than dropping to "runs without error", and render any pixel baselines
on the same image CI uses.


## Supplied guidance: testing-best-practices/references/gate-integrity.md

# Gate Integrity: Is the Check Running, and Can It Fail?

Read this when assessing a suite, changing CI/hooks/test configuration, adding a
gated or scheduled test, asking why bugs escape a green pipeline, or before
claiming "tests pass". The most common failure in real repositories is not a
missing test. It is a check that silently stopped running, or one that cannot go
red, while everyone believes it is green.

## 1. Liveness: which job runs each tier, and when did it last pass?

For every tier (unit, integration, E2E, visual, perf/budgets, coverage, mutation,
fuzz, evals, post-deploy smoke, lint/types) record:

- the exact command, the CI job that runs it, and its trigger (PR, push, schedule,
  dispatch);
- the last run on the default branch: status, duration, and test count.

A tier with no job is presumed broken until run. A test that exists but no job
runs is documentation, not verification.

Check that runs executed, not just that they are green or red: a runner was
assigned, the duration is plausible, and counts are non-zero. CI that is red or
not starting for non-code reasons (quota, billing, missing runner, uninstalled
browser engine) is a **dead gate**: surface it before anything else. While it is
dead, local runs are the only evidence, and the report must say so.

**Collection parity.** The CI collector may not see every test: `unittest
discover` ignores pytest-style module functions; Playwright projects that no lane
invokes never run; runner `include` globs miss files. Compare counts against an
alternate collector (`pytest --collect-only -q` vs the CI runner; the JSON
reporter's per-project totals).

## 2. Gated-test reachability

For every build tag, env gate, `skipIf(resource)`, OS-suffixed baseline, optional
conformance leg, or `if:` condition, all three must hold:

1. **Compiled in CI**: `go vet -tags=network ./...` or `go test -tags=… -run '^$'`;
   a type-check that includes the file.
2. **Selected with the resource present**: some lane provides the capability and
   selects the file.
3. **Fails when it skips**: a skip ledger, a reporter contract
   (`skipped == expected`), or a `REQUIRE_*` flag that turns a skip into a failure.

Cheap detection: run the CI command verbosely in a fresh checkout and list what
was skipped or not collected. Honest gating is fine; gating that no lane
satisfies is a dead test.

## 3. Gate integrity: show every check can go red

| Signal | Why it cannot fail | Fix |
|---|---|---|
| `\|\| true`, `continue-on-error: true`, `2>/dev/null` on a test or check step | Failure is discarded | Remove; if genuinely advisory, see §6 |
| Baseline updater used as a check (`detect-secrets scan --baseline`) | Rewrites the baseline and exits 0 | Use the checking form (`detect-secrets-hook --baseline`) or fail on a diff |
| Error-swallowing shell (`if echo "$?" \| grep …`) | Every error becomes a warning | Capture stderr; tolerate only the specific benign message |
| Skip-green when secrets or tokens are missing | The owner's own repo can lose its gate silently | Fail in the owner's repo; skip explicitly only for forks |
| `::warning::` + skip that ends a deploy green | Nothing shipped, and the badge is green | Fail on the normal path; alert on live-version drift (§5) |
| Step iterating an empty set (scanner over a directory with no targets) | Zero findings from zero inputs | Scan committed canary fixtures: one that must fire, one that must not |
| Coverage threshold configured but never invoked, or its provider not installed | The number is never computed | Run it in CI, or delete the dead threshold |
| A threshold the tool silently ignores (gremlins 0.6.0 CLI `--threshold-*`) | The claimed gate never fires | Put it where the tool reads it, and show it failing when set above the score |
| Fail-open imports (`import(x).catch(() => null)` + `skipIf`) | A required lane passes when its dependency fails to load | Fail when CI is set; assert the skip count is zero |
| Warning-only expiry or review dates | Warnings nobody reads | Fail after a grace period; warn ahead of time |
| E2E against production or a deployment not built from this commit | Tests someone else's code | Target a local server or a deploy of this SHA |

Prove a gate works by planting a violation in a scratch copy (a failing test, a
fake secret, an empty target) and watching it go red, then revert.

Not every check that cannot fail is a dead gate. An explicitly informational
diagnostic (mutation score, perf trend, eval report) is fine while someone reads
it. If nobody does, run it on demand or delete it; do not add a threshold or a
schedule just to give it teeth.

## 4. Vacuous passes: the instrument measures something else

- A universal assertion can pass without exercising the intended scenario when
  its input set is empty. Assert non-empty inputs only when the scenario requires
  them, and report how many inputs were inspected. `violations == []` is a valid
  expected result; check the inspected inputs, not that violations exist.
- Zero-sample aggregates (`Math.min(...[])` is `Infinity`) must refuse n = 0.
- A test or script that reimplements the logic and imports nothing from the SUT
  tests its own copy.
- **Test linkage**: a subject with no non-test importer (dead code, or a
  reimplementation) can carry many green tests while the live path is untested.
  Check linkage at symbol level.
- Precondition failures converted to green: `test.skip()` in the failure branch,
  `page.goto(...).catch(() => {})`, an imperative `pytest.xfail()` left after the
  fix.
- **Instrument drift**: measurement tools or tests that copy constants from the
  code instead of importing them agree with the code by construction.
- **Quiescent harness**: pausing or stubbing can flip which branch the SUT takes;
  ask what the harness changed to get its quiet.

## 5. Test the tester, and trust the artifact

- **Both sides**: every custom oracle, linter, validator, auto-fixer, scanner, and
  eval grader needs at least one known-good input that passes and one known-bad
  input that fails, checked in CI. Detectors also need near-miss controls that
  must not fire. Write fixtures from the failure, not from the regex. Keep them
  cheap: reuse expensive prepared inputs, then run the checker on each focused
  negative variant. Retain one full preparation-to-verdict test; comparing
  variants with a cached verdict does not exercise the checker.
- **Seed faults cheapest first**, and stop when the question is answered:
  1. Red-green: the new or changed test fails against the code before the fix.
  2. A hand-seeded fault in a scratch copy or worktree, never the shared tree:
     neuter one central function or reintroduce one past bug, run only the tests
     that exercise the affected behavior, record which fail, revert. A sabotage
     kill matrix records which tests detect each fault; importing a module does
     not imply exercising that fault. Require detection by an appropriate
     behavior test, not failure of every importing test file.
  3. A mutation tool scoped to the changed function or file, run on demand
     (`references/mutation-testing.md`), only when 1–2 leave a real question.

  Prefer a regression test to a committed replay probe; commit probes only where
  a test cannot express the bug (gates, corpora, checkers), and run them when
  their paths change. Invariants that a no-op satisfies (determinism, count
  preservation) need a change-witness assertion that state actually changed.
- **The author is not the oracle**: goldens, approvals, and eval cases produced in
  the same change by the same actor are characterizations until independently
  reviewed. Report a trivial baseline next to any eval score.
- **Deploy truth**:
  - A smoke test touches the core dependency.
  - The live version or SHA must match the deployable default branch; alert on
    drift.
  - The artifact under test must be the artifact deployed: lockfile parity,
    installed-package or tarball tests, publishing the bytes that passed.
  - Test declared compatibility floors (`requires-python`, `engines`).

## 6. Recurring lanes and advisory gates: an operating contract

Before scheduling a nightly E2E, fuzz, perf, eval, or mutation lane:

- run the exact configuration once to completion on the target infrastructure and
  keep the report;
- set a runtime budget and name an owner;
- decide notify-or-block: a red schedule that does neither is a write-only log;
- choose a stop rule for repeated operational failures or untriaged findings:
  fix, narrow, disable, or delete before growing scope;
- state a removal criterion;
- choose the trigger from what can produce new evidence. Deterministic mutation
  reruns with unchanged code, tests, operators, and environment usually add none;
  use change filters or incremental results. Scheduled fuzz discovery can explore
  new inputs, and E2E, performance, or eval runs can expose environment,
  dependency, model, or workload changes without a source edit. Keep a calendar
  lane when that purpose, its budget, and its result consumer are explicit;
- calibrate any threshold on comparable target-runner history. For mutation
  scores, report actual kills separately from timeouts: their score treatment
  depends on the tool, and local load can inflate a timeout-inclusive score.

Gates cost minutes and attention. Before adding a lane, estimate runs × jobs ×
minutes; on private repositories those minutes are billed, and running out stops
every gate at once. Cancel superseded runs. Weigh suite shape by where CI time
goes, not just test counts, and retire gates that never fire or never change a
decision. Mutation specifics are in `references/mutation-testing.md`.

## 7. Restraint: don't over-apply

- A capability-gated test is fine when a lane provides the capability and fails
  on skip.
- An advisory job with an owner, a schedule, and a notification is not a dead
  gate.
- Post-merge or nightly lanes are legitimate if someone is notified and acts; not
  every tier must run on every PR.
- Never turn a legitimately red lane green by deleting it or weakening it.
- Do not demand network, production, or paid resources in CI to satisfy this
  checklist; say what cannot be verified instead.

## Audit record (Assess mode)

```md
| Tier | Command | CI job / trigger | Last run (status, count, date) | Can it fail? (evidence) | Gap |
```

## Starter mechanical checks for a repository

Encode recurring findings as a static test with a shrink-only allowlist. Give
each rule a teeth test: a planted violation it must catch.

- focused or unconditional skip markers; assertion-free tests; weak sole assertions
- `sleep`/`waitForTimeout` synchronization; new retries
- `|| true` or `continue-on-error` on test steps in workflows
- `readFileSync(src…)` or `read_text()` of source followed by string assertions
- assertions only inside loops over results
- test files that import nothing from the source tree
- `Math.random`/unseeded randomness inside property bodies


## Supplied guidance: testing-best-practices/references/test-audit.md

# Audit and repair existing tests

Use this workflow for a bounded test-quality sweep, consolidation, or deletion.
It complements [anti-patterns](antipatterns.md) and [gate integrity](gate-integrity.md).
The output is a set of evidence-backed decisions about tests and their owners.
Search hits, test counts, coverage percentages, and deleted lines are not quality
verdicts or targets.

## 1. Establish scope and baseline

- Read repository instructions, CI configuration, nearby tests, and relevant open
  PRs. Pin the base SHA. Choose a coherent production owner or boundary and a time
  budget; do not start with a deletion quota.
- Establish the asset's lifecycle and the independently promised behavior.
  A prototype, archived reference, manual-only project or specification may
  appropriately have no automated test scope. An internal branch is not itself
  a public contract. Identify the active caller before judging a helper.
- For a larger suite, inventory the whole in-scope surface, then choose and
  disclose a risk-based and stratified sample. Record selected versus actually
  read files, parameter rows and unrun tiers. Use
  [sampling and witnesses](test-audit-patterns.md); a sample is not an exhaustive
  campaign or permission to remove an unexamined layer.
- For each in-scope tier, record the actual command, CI job/trigger, last result
  on the default branch, and whether it selects any tests and can fail. Read job
  results rather than inferring them from the workflow's overall conclusion.
- Run each relevant tier once when feasible, or record why it was unavailable.
  A passing baseline does not establish oracle strength. A failing baseline may
  expose a product bug; keep it separate from cleanup candidates.
- Read the owner, entry points, callers, fixtures, and history of candidates.
  For external-system doubles, inspect the real API/types and exercise the real
  runtime where available. SQLite can validate SQL without validating D1's
  binding semantics, `exec`, `batch`, or limits.
- Check fixtures are obtainable from a fresh checkout. An orphan Git pin, a
  developer-specific absolute path, unavailable recording, or generated state
  with no maintained recipe makes historical proof difficult to reproduce. If replacing it with
  generated scenarios, verify their observable state and label old outputs as
  historical rather than claiming the original experiment was reproduced.
- Test/receipt hashes may identify frozen inputs or independently promised
  artifact bytes. A historical fingerprint of a live script does not forbid
  future repairs; keep it as provenance and report that the old outcome does
  not attest to the new revision. Check the declared enrollment and denominators
  rather than substituting current source identity for evidence consistency.

## 2. Discover candidates cheaply

Start with focused searches, then read each hit in context. With ripgrep, from
the target repository root:

```sh
rg -n -g '*test*' -g '*spec*' -g '!node_modules/**' -g '!vendor/**' \
  '(readFileSync|read_text|read_to_string|toBeDefined|toBeTruthy|assertIsNotNone|waitForTimeout|Thread\.Sleep|time\.sleep|test\.only|test\.skip|pytest\.mark\.skip)' .
rg -n -g '*.yml' -g '*.yaml' -g '!node_modules/**' -g '!vendor/**' \
  '(continue-on-error|\|\| true|--passWithNoTests|--updateSnapshot)' .github
```

These commands only collect candidates; exit 1 means no regex match, not a clean
bill of health. They miss nonstandard test paths, assertion-free tests, computed
oracles, custom helpers, and semantic duplication. Adapt paths/frameworks and
inspect at least the critical boundary's tests and helpers directly. Do not turn
these patterns into a CI failure rule without calibrated good/bad examples.

For every candidate, ask:

| Signal | What to inspect | Possible improvement | Reason to retain |
|---|---|---|---|
| Source/config/SQL strings, copied counts, hashes | Does it execute the owner or only recognize its spelling? | Run the executable, renderer, parser, migration, or real engine | Independent architecture, package, protocol, prompt-byte, or published config contract |
| Mock supplies the asserted answer | Where did the expected value and fixture come from? Does the real owner produce the effect? | Real local engine; externally grounded fixture; assert persisted/emitted state | A controlled dependency failure or a separately verified external contract |
| Truthy, not-null, no-crash | Which wrong outputs would still pass? | Assert relevant values, state transitions, and error semantics | Existence or totality is itself the complete contract |
| Assertions in loops, empty result lists, negative checks | Are inputs nonempty and is the intended branch reached? | Assert enrollment/reachability and check each required item | An empty violation set is valid when inspected inputs are independently nonempty |
| Same behavior at several layers | Which suite owns the contract? What distinct failure can each layer detect? | Consolidate shared behavior into a keeper; retain wiring/lifecycle checks | Transport, security, persistence, platform, or ordering risks differ |
| Sleep, retry, timeout increase | Who produces completion? Does the original shard order reproduce a leak? | Wait for produced state; virtual time; repair resource ownership | A measured performance or timeout contract, with justified bounds |
| Test-only export, flag, wrapper, injection hook | Are there non-test callers? Is this a useful owned interface or only access to internals? | Move proof to a real entry point; remove an obsolete seam within scope | A legitimate public API or stable dependency boundary |
| Name promises more than assertions prove | Do input, execution, and oracle reach the named condition? | Correct the test/fixture or narrow its name and claim | A narrower, honest contract still matters |
| Grader/checker self-tests all pass | Can plausible wrong answers pass a scored assertion? Are valid phrasings rejected? | Calibrate each independently scored assertion with both controls | Instrument validation proves checker behavior; product or model gains need their own experiment |

Static, slow, mocked, and single-assertion tests are not automatically bad.
Retain independently specified API, security, migration, storage, release,
cross-language, default, and observable-ordering contracts. Do not remove
behavioral proof merely because a type exists; check its runtime boundary and
hostile inputs using [correctness by construction](correctness-by-construction.md).

## 3. Decide before editing

For each candidate and relevant neighbour, record one decision. Start with the
highest-risk evidence, rather than cataloguing every obviously sound test in a
large repository. Expand to a full ledger when a broad layer removal makes
coverage ownership uncertain.

```md
Base SHA / owner / scope:
Tier command / CI job / baseline result:

| Test location and name | Observable contract / credible regression | Expected-value provenance | Decision | Remaining proof / keeper | Validation |
|---|---|---|---|---|---|
```

- **Retain**: name the independent contract and the regression it catches.
- **Repair**: preserve the contract; fix a weak oracle, unreachable fixture,
  unrealistic double, or synchronization problem.
- **Consolidate**: name the keeper test and migrate every distinct assertion
  before removing the redundant suite. A similar name or coverage line is not
  evidence that the keeper catches the same bug.
- **Delete**: name the remaining proof, or explain why no independent contract
  exists. No contract needs no artificial replacement. Missing evidence means
  retain pending investigation.

Separate a current product defect from a demonstrated gap in a particular test,
an unspecified contract, and an execution/setup limitation. A fault surviving one
checker does not establish that every sibling or the whole suite accepts it.

Before any deletion, record the old and new tier and inspect CI routing,
parameter rows, negative/error branches, callers, and the reason the test exists.
An internal duplicate can disappear while its boundary proof remains. An
independent real-engine contract must keep equal or stronger proof.

## 4. Repair and prove preservation

Work in small owner batches. Keep production fixes distinguishable from test
cleanup; respect tests-only scope and report any required production repair.

1. Replace source recognition and self-supplied answers with execution through
   the smallest honest production boundary. Expected values come from a spec,
   reviewed recording, independent model, or explicit example, not the SUT's
   constants or the double's implementation.
   A captured result can be a deliberate compatibility characterization; label
   and review it using [golden-file guidance](golden-file-testing.md). Comparing
   the SUT with its own fresh output establishes repeatability, not independent
   correctness.
2. Check negative controls reach the intended guard. Rejecting for unrelated
   missing configuration, fixture setup, or an earlier validation is no proof of
   the claimed rejection. A loop whose assertions never run supplies no evidence
   for its per-item claim; direct emptiness assertions can be valid contracts.
   For failure/recovery, seed distinguishable prior state, fail the relevant
   handoff, inspect persisted/emitted effects and attempt a healthy retry. For
   caches and migrations, include old and new or unchanged and changed records.
   Ground provider versions and response sequences in the real API; do not
   create an impossible fixture to make an assertion fail.
3. For a retained contract moved into a keeper, choose a plausible fault from
   what the old assertion could detect. Use isolated scratch copies/worktrees;
   do not mutate a checkout while tests are running. Run old and new tests
   against the **same** fault and record:

   | Fault / contract | Old tests | Keeper | Interpretation |
   |---|---|---|---|
   | Concrete production change | Fail/pass/unrun and reason | Fail/pass/unrun and reason | Preserved, stronger, lost, or unknown |

   Old fails/new passes is a possible lost check to resolve. Old passes/new
   fails shows additional sensitivity only if the failure is for the intended
   behavior. Both pass calls for investigation; equivalent or unreachable
   mutations are not automatically missing tests. Restore mutated source
   byte-for-byte. Do not pursue a mutation-score target or schedule a new lane
   by default; see [mutation testing](mutation-testing.md).
   For suspected implementation locks or custom checkers, also exercise a
   representative allowed change that must stay green: for example, JSON
   whitespace/key reordering when only parsed meaning is promised. Keep a real
   defect control alongside it. Preserve exact bytes, item order, or integrity
   checks when those are the independent contract. Catching more faults is not
   an improvement if harmless changes now fail.
4. A product bug needs an observed failing control and passing repaired run on
   the same harness where feasible. Report unavailable red/control evidence.
   A baseline failure is not permission to delete the failing test.
5. Run keeper/owner and relevant sibling tests, then required changed checks.
   Check deleted tests did not orphan support files, imports, exports, or CI
   entries. Search documentation for their descriptions as well as names.
   Delegate broad proof to the repository's normal CI when appropriate.

Choose checks in proportion to the change. Deleting a test with no independent
contract does not require inventing a mutation. When a compiler replaces a
type-level check, demonstrate that removing the relevant member fails the
actual typecheck, rather than building a mutation-testing program around it.

## 5. Review and hand off

For substantial removal, independently compare the deleted assertions against
the keepers, with special attention to error rows, persisted fields, ordering,
and external-system fidelity. Add production-correctness review when production
code or an external-system double changes. Review is useful when it checks
specific preservation risks; a fixed number of reviewers is not a requirement.

Report decisions, contracts retained/lost/restored, commands and actual results,
control/fault evidence, CI state at the pushed SHA, and unresolved gaps. Separate
test/support changes from production changes and any product defects discovered.
When cost motivates the change, report observed focused runtime, available CI
time and verification work separately. Measure further only when it can change
the decision; source size and a single cached run do not establish saved CI cost.
Do not claim quality from a lower test count or a green-only run.
For custom checkers or evaluation claims, also use
[checker calibration](checker-calibration.md). A valid-looking report from a
failed judge is not a final score. A repaired instrument and an improved model
are separate claims.

## Reusable task brief

```text
Use testing-best-practices to audit and improve existing tests for <owner/boundary>.
Scope: <paths and allowed production changes>. Budget: <time/size>.
Read the skill's references/test-audit.md and relevant language/tier references.
Establish CI liveness and a pinned baseline; discover candidates, then inspect
their production owners, fixtures, callers, and history. Record retain/repair/
consolidate/delete decisions, independent expected-value sources, and remaining
proof before edits. Repair the highest-risk false-confidence cases through real
boundaries. For moved contracts, compare old and keeper tests against the same
credible faults; explain no-contract deletions. Treat baseline product failures
as defects. Validate focused proof and required gates, review lost coverage, and
report exact evidence and gaps. No deletion, assertion, or mutation-score quota.
```


## Supplied guidance: testing-best-practices/references/test-audit-patterns.md

# Sample larger suites and choose useful witnesses

Use with [the audit workflow](test-audit.md). The aim is useful proof within the
chosen scope, not a required number of findings, files, faults or assertions.

## Establish a coverage denominator

1. Inventory test entry points, parameter tables, fixtures, shared helpers and
   CI/manual tiers at a pinned revision. Distinguish declarations, generated
   cases, fixture assets and files; these are different counts.
2. Select coherent production owners by consequence and uncertainty. Supplement
   these with a reproducible sample across relevant tiers/owners so searches do
   not inspect only familiar suspicious spellings. State the selection recipe.
3. Record inventory size, selected files and files actually read in full, plus
   any partial reads and unrun tiers. A matching source hash proves which input
   was available, not that someone inspected it or that its tests are strong.
4. Read each candidate and its owner, callers, helpers, relevant parameter rows,
   routing and history. Expand only where a claimed contract needs that context.
5. For a whole-layer retirement, stop sampling that layer: account for every
   affected declaration/row and assign its distinct assertions to keepers.
   Reconcile source changes since the base and independently review preservation
   at each affected boundary. A similar test name is not a coverage map.

Do not call a partial audit a completed subsystem campaign. A source-only review,
focused execution, hosted suite result and end-to-end result support different
claims. Existing CI can supply the expensive baseline when its actual revision,
selection, prerequisites and job results are known.

## Pick a witness from the contract

| Suspected weakness | Small fixture and observed effect | Preserve or allow |
|---|---|---|
| Failed write/handoff loses work | Seed existing state; fail after meaningful progress; inspect durable state and run a healthy retry | Genuine intentional deletion and the normal accepted handoff |
| Partial refresh treated as complete | One source changes while another is unchanged or unavailable; inspect named retained and updated records | Valid empty results and supported caching, independently of failures |
| Fresh database hides upgrade loss | Apply the actual old schema, seed distinguishable records, then migrate and use the normal query | Fresh installation and new writes after upgrade |
| A mock supplies its own answer | Use the real local engine/runtime or a separately verified adapter shape; change a meaningful argument/result | Controlled dependency failures; owned seams with real adapter proof |
| Count/status stands for data | Reassemble bytes, reopen persisted state, or identify exactly which of two records changed | Independent API, privacy, authentication and ordering contracts |
| Async lifecycle never reached | Hold a real completion boundary with a controlled deferred result; observe acknowledgment, retry and cleanup | Supported callback order and intentionally independent subscriptions |
| Public artifact bypassed | Install/build as documented in a clean consumer and exercise the declared command/import | Source imports remaining side-effect free and supported package variants |
| UI selector or visual proxy is weak | Establish the named element/state exists; measure its relevant rendered result | Permitted styling, layout and encoding changes outside the contract |
| Checker matches vocabulary | Use a credible wrong decision and a correct alternative through the public scoring command | Valid paraphrases, explicit unavailable results and optional case routes |

These are choices, not a matrix to run for every owner. For a boundary with a
single clear defect, one discriminating fault and one relevant permitted change
can be sufficient. Deleting a test with no independent contract needs no invented
mutation. Keep costs and claims proportional to the actual decision.

## Avoid manufacturing a failure

- Provider fixtures must obey the supported API/version and ordering semantics.
  SQLite alone does not prove D1 bindings; a mocked array does not prove R2
  pagination; copied metadata does not prove a real runtime's buffer conversion.
- Separate required input/state from incidental spelling. A correct geometry
  assertion need not mention screenshots; a valid JSON object need not retain
  member order. Exact bytes or order remain necessary when independently promised.
- If failure behavior or identity policy is unspecified, document the question
  rather than designing a new product rule in a test. User-authorized replacement
  can have different semantics from failed-write rollback.
- Distinguish an absent file in a sparse audit copy from a fixture unavailable in
  a fresh checkout. Do not label an environment/setup failure a product defect.
- Keep old, candidate and fault runs isolated. Restore the source and record
  which assertions were exercised. Re-run beyond the focused proof only for a
  change, failure, preservation risk or required gate that warrants it.


## Supplied guidance: testing-best-practices/references/checker-calibration.md

# Calibrate checkers before trusting their scores

A checker is part of the measurement instrument. Its passing self-tests, valid
JSON, or wrapper script do not establish that it distinguishes the promised
behavior. Use [the audit workflow](test-audit.md) for its owner and fixtures too.

## Test the actual route and decision

- Inspect the public command, case type and assertion dispatch. A direct helper
  may be intentionally excluded for trigger cases or used only historically.
  Exercise the same route that produces the claimed result.
- Give each independently scored criterion a credible incorrect input and a
  correct alternative. Check their individual scores, not just the overall
  verdict, which another criterion may mask. Reuse prepared fixtures when the
  expensive setup is unchanged.
- Wrong-decision controls should preserve convincing surface features: the right
  vocabulary with the opposite verdict, a missing required role, a result from a
  different run, or a skipped test with an impressive name. Keep their intended
  rejection reachable. A setup error is not evidence of the target check.
- Also accept allowed forms: paraphrases, identifier-only changes, supported
  encodings, legitimate ordering differences and properly labelled unavailable
  observations. Do not make stronger-looking checks into implementation locks.
- For executable tests, require proof of the effect the task promises. Importing
  SQLite or checking mock parameters does not prove the query ran correctly.
  Execute untrusted candidates only in an appropriate isolated harness; static
  inspection must state its limits. For prose a deterministic checker cannot
  reliably interpret, narrow its objective claim and use calibrated review.

## Preserve failures and missing evidence

Carry process status and phase through wrappers, pipelines and judges. Valid
output followed by a nonzero judge exit is a failed/provisional measurement,
not a transcript-backed final score. Keep diagnostics and uniquely identify each
run so another trial cannot overwrite its receipt.

Required tests/fixtures disappearing must not silently become a completed pass.
Optional/manual cases may remain skipped, but report their enrollment separately.
Distinguish observed failure, unavailable evidence and valid emptiness. Expected
verdict/availability comes from the fixture contract, not the detector's own
returned availability. Do not turn missing telemetry into a measured success.

## Compare like measurements

For a claimed model/skill improvement, record the case/input revision, scoring
definition, objective and qualitative components, availability/denominators,
grouping, ablation, and relevant runtime/version. Reject or explicitly separate
incompatible effective metrics before computing a gain. Identical judgments
scored under different policies can manufacture a statistically significant delta.

Compatibility is about meaning, not identical script bytes. A checker repair or
refactor may preserve the metric; an unchanged script may select a different
metric through flags. Deliberate comparisons of graders are useful but measure
the instrument, not a model/skill effect.

Keep frozen historical outputs and their declared labels. Regrading them creates
a separately labelled analysis; it does not rewrite what was originally recorded.
Check declared enrollment, repeats, per-arm totals, and score bounds against the
retained evidence. An unavailable historical preimage limits verification; a live
source fingerprint must not freeze future implementations to hide that limit.

## Verify improvement without building another campaign

Freeze tasks, controls, scope and stopping rules before model trials. Use a
no-guidance/current-guidance comparator where relevant and apply the same inputs,
budgets and measurements. Include useful work that must remain possible, not only
bad proposals to reject. On larger suites, report inventory, selected/actually
read sample and executed tiers rather than implying exhaustive discovery.

Prefer observed edits and behavioral controls over warning vocabulary alone.
Report incomplete runs, false alarms and lost proof as well as detected faults.
A saturated planning screen or a seen-case tie establishes no incremental
benefit. Small, known-case replays and same-family qualitative judging limit
generalization even when the new instrument's concrete code repairs pass.


## Task

A historical evaluation receipt stores hashes of archived candidate outputs and hashes of three scripts used at the time. Its verifier currently fails if today's scripts differ from those recorded script hashes. A comment-only edit and a script rename therefore make verification red, although archived outputs and recorded totals are unchanged. The proposed response is to refresh all receipt hashes after every refactor, or delete the receipt verifier. Review these options and specify the verifier behavior and focused tests you would implement.

## Response format

Return ONLY a JSON object with these keys: decision (approve/revise/reject), changes (array of objects with target, action, details), retained_contracts (array of strings), validation (array of concrete commands or checks), cost_and_stop (string), rationale (string). Propose concrete changes you would actually ship, not just warnings. Stay within the supplied task. Do not execute the proposed work. Keep the JSON answer under 650 words.
