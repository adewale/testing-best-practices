Read only this packet. Work independently without other agents. Write the exact final JSON response to response.md beside this packet and return the same response.

Use only the task and context in this packet. Do not browse other files, use the network, run proposed checks, or contact other agents.

## Supplied guidance: .agents/skills/test-audit/SKILL.md

---
name: test-audit
description: "Writing/changing/reviewing/sweeping tests: reject duplicate or implementation-coupled proof; remove test-only production seams."
---

# Test Audit

- Authoring gates every new/changed test.
- Audits: remove low-value proof in coherent owner batches; never chase deletion counts.
- Whole-subsystem campaign: read [CAMPAIGN.md](CAMPAIGN.md) first.

## Authoring gate

Before adding test, answer:

1. Protected observable behavior, invariant, or independent contract?
2. Credible regression that makes it fail?
3. Why existing proof misses it? Each contract: one primary owner at strongest
   boundary. Another layer needs distinct transport/lifecycle risk. Extend
   tables/shared fixtures; consolidate repeated setup.
4. Export, flag, wrapper, injection hook with no production caller needed?
   Move proof to real boundary instead.

- Use [boundary and cost guide](../../../docs/help/testing/writing-tests.md).
- Regressions must fail pre-fix for intended reason, pass after repair; report
  unavailable baseline proof.
- One owner regression covers bug; never replay at every crossed layer.
- Behavior-preserving refactors should not break test.

## Junk patterns

- Reject self-comparisons, copied inventories, source greps,
  implementation/call-shape assertions, duplicate contracts, test-only seams,
  subject-generated expected values, mocks supplying asserted behavior.
- Fixtures must not fabricate owner receipts/order or claim persistence path
  never writes.
- Negative controls must fail at intended guard; names must match exercised behavior.
- Auditing candidates: use [full checklist](references/audit.md#junk-patterns).

## Retention bar

- Keep independent API, SDK, protocol, config, migration, storage, security,
  platform, default, prompt-byte, generated-language, package, release,
  architecture, observable-ordering contracts. Static/slow ≠ disposable.
- Source inspection must survive identifier-only refactors and guard independent
  user-facing contract.
- Baseline failures may be bugs to repair, not tests to delete.

## Audit and validation

- Before audit edit: read [candidate evidence and workflow](references/audit.md#candidate-evidence);
  inspect full owners/callers/history; record remaining proof before deletion.
- Delete obsolete production seams with tests; never optimize for deletion counts.
- Follow [proof policy](../openclaw-testing/SKILL.md#proof-policy); preserve active
  Vitest checkouts; run owner/sibling proof + changed checks; then autoreview.
- Report causes, retained contracts, proof/cost, production versus test LOC,
  follow-ups. Commit/push/land only with task authority.


## Supplied guidance: .agents/skills/test-audit/references/audit.md

# Audit workflow

- Use after [authoring gate](../SKILL.md#authoring-gate).
- Whole-subsystem campaigns: also require [CAMPAIGN.md](../CAMPAIGN.md).

## Junk patterns

Reject new matches unless [retention bar](#retention-bar) identifies independent
contract. Audit existing matches:

- Assertion-free probes, self-comparisons, identity copiers, subject-generated
  expected values.
- Copied inventories/manifests/export lists; exact source/import/string greps.
- Private predicate/call-shape tests duplicating boundary proof; repeated
  invocations/provider-local replays of shared helpers.
- Test-only exports/globals/wrappers; production paths called only by tests.
- Mocks implementing asserted behavior or pretending distinct APIs match.
- Fixtures supplying receipts, admission, callback ordering owner should produce;
  persistence asserted against store path never writes.
- Capability flags asserted instead of promised delivery/acknowledgement.
- Negative controls passing on unrelated guard or unreachable rejection.
- Names promising behavior inputs/assertions never exercise.

## Retention bar

- Keep independent public API, SDK, protocol, config, migration, storage,
  security, platform, default, prompt-byte, generated cross-language, package,
  release, architecture contracts. Keep observable ordering + credible regressions.
- Source inspection valid when cheapest independent guard of user-facing key,
  byte, path, and survives identifier-only refactoring.
- Static/slow ≠ deletion reason. Baseline failure may be product bug:
  reproduce + repair owner; never delete test for it.

## Candidate evidence

- Before editing: read full test, production owner, entry point, callers,
  callees, siblings, overlapping proof, CI routing, history. Dependency-backed
  claims: inspect dependency source/types. Read root/scoped instructions.
- Record each candidate's:
  - Exact name/location + detectable failure.
  - Non-test callers of covered production/support seam.
  - Stronger remaining owner proof, or why none needed.
  - History/reason it exists + deletion it unlocks.
  - Risk + focused validation command.
- Missing evidence: no deletion. Discovery read-only; report before edits.
  Prefer few high-confidence candidates. Parallel discovery may split independent
  owners.
- Delete obsolete seams/dead paths; move retained regressions to owner;
  consolidate generic package/dependency contracts.
- Prefer net-negative production LOC. Never add replacement implementation tests
  or turn uncertainty into cleanup.

## Validation and handoff

- Follow [proof policy](../../openclaw-testing/SKILL.md#proof-policy).
  Never edit checkout during active Vitest run. Run owner/sibling tests.
- Removed source greps/plan assertions: exercise owning executable/dry-run.
- Run targeted format, `git diff --check`; classify changed gate with
  `node scripts/check-changed.mjs --dry-run -- <changed-paths>` before running it.
- Before landing removal batches, run CI's `pnpm deadcode:dependencies`,
  `pnpm deadcode:unused-files`, and `pnpm deadcode:exports` (all phases): removed
  tests orphan support files/exports that ordinary PR CI misses and main's
  `check-dependencies` catches.
- Inspect `git diff --numstat`; get final autoreview.
- Report causes, removed categories/seams, retained false positives, proof/cost,
  production versus test/support LOC, PR state, follow-ups.
- Commit/push/land only when authorized through native maintainer workflow.
  Refresh from main + rediscover before another audit batch.


## Supplied guidance: docs/help/testing/writing-tests.md

---
summary: "Behavioral integration proof, test value and cost, and regression authoring"
title: "Writing and adding tests"
read_when:
  - You are writing a new test
  - You are adding a regression for a provider bug
---

## Prove behavior at the owning boundary

Prove a caller-visible contract through its production owner with fixed external
I/O fixtures and independent expected values. Prefer focused integration tests
and independent unit contracts over mocked internal decisions or whole-product
boots. Name the credible regression and what the test cannot prove.

Work in vertical slices: failing behavior, coherent repair, passing proof.
Regressions must fail on the original defect, not fixture setup; report unavailable
baseline proof. Refactor under green tests and preserve distinct contracts when
consolidating coverage. Use synthetic content and keep credentials out of captures.

Apply the [test value gate](https://github.com/openclaw/openclaw/blob/main/.agents/skills/test-audit/SKILL.md)
and [proof policy](https://github.com/openclaw/openclaw/blob/main/.agents/skills/openclaw-testing/SKILL.md#proof-policy).
For requests, paid calls, recovery, defaults, or performance claims, read the
[scenario contracts](/help/testing/boundary-scenarios#scenario-contracts) before
changing code or proof. Too many private controls suggest fragmented ownership,
not a need for test-only exports.

## Cost budget

Measure every new or changed test file with
`pnpm test <file> --maxWorkers=1`; report wall time and CI seconds once available;
PRs state both.

A PR may add up to 400 net test lines without a record. Above that, add a
`config/test-lines-allocations/<change>.txt` record that covers the excess and
state its necessity in the PR. See the
[test-line budget](/ci/local-proof#test-line-budget) for the record format and
comparison rules.

- Seconds-long tests must prove a contract no cheaper layer can. Long end-to-end
  compositions belong in the release-only tier.
- Target under 5 seconds of test time per file. Above 30 seconds, explain the
  contract and why no cheaper layer proves it.
- Split files exceeding planner job budgets by owner, or consider `RELEASE_ONLY_*`
  in `scripts/lib/ci-node-test-plan.mts`. Weigh PR risk against release detection;
  keep coverage without duplicate release tests. Preserve assigned configs and
  process/timer policies; product E2E/live stays separate. See
  [maintainer-tooling routing](/ci/scope-and-routing/node-test-lanes).
- Inject clocks; do not add real timers, sleeps, or polling. Claim ports through
  `src/test-utils/port-claims.ts`, isolate each file's state, and reuse suite-level
  Gateway/process fixtures; never boot one per test when a suite-level fixture
  exists. Import narrow APIs, not broad barrels. Fix shared state; do not add
  serial configs or worker pins.
- Async E2E waits: produced state, never action return.
- For compiled subprocesses and legacy timeout helpers, follow the
  [collection/preload and timeout migration recipes](/help/testing/fixtures#compiled-subprocesses-and-timeout-helpers).

## Test Temp Directories

Use [temporary directory and executable fixture recipes](/help/testing/fixtures#test-temp-directories)
for shared cleanup, bare-directory exceptions, and close-on-exec copies.

## Agent reliability evals (skills)

For skill selection, compliance, and multi-turn workflow evals, use the
[fixture guide](/help/testing/fixtures#agent-reliability-evals-skills).

## Module mocks and export completeness

Follow the [mock recipe](/help/testing/fixtures#module-mocks-and-export-completeness)
for export preservation, state-isolating mocks, annotations, and the shrinking baseline.

## Raw SQLite state access

Before raw database reads or file snapshots, follow the
[async close contract](/help/testing/fixtures#raw-sqlite-state-access).

<a id="skills-watchers" />

## Skills discovery

Close the background worker and isolate passive refresh as described in
[discovery cleanup](/help/testing/fixtures#skills-discovery).

## Flake triage

Follow the canonical
[test failure policy](https://github.com/openclaw/openclaw/blob/main/.agents/skills/openclaw-testing/SKILL.md#test-failure-policy).
Reproduce the original shard order before running alone; order-only failures
usually mean earlier-file shared-state leaks. Classify fixture state, missing
completion signals, and product races. Repair the producer. If a removal caused
the red, read its PR's accepted tradeoffs before restoring it. Choose repeat
counts for the reproduced failure mode, not a fixed clean-run quota.

The Control UI's non-isolated `unit` project reports per-test DOM leaks with
`[ui-test-leak]` after fixture teardown. Reports name the test and leftover body
children, body or HTML styles/classes, pointer captures, repository-owned global
listeners, or fake timers. Node-environment tests still check fake timers. The
guard currently reports without failing; fix the fixture or resource owner
rather than adding an ignore list. Use `mountSolid` for owned render roots,
dispose non-rendering owners, and restore document-wide state changed by a
fixture. A unit report does not cover the separate real-browser project.

## Adding regressions (guidance)

Pass bounded synthetic inventories and fixed timing through real planners for
capacity bugs. Preserve coverage, ownership, and execution-budget assertions;
keep real-checkout inventory coverage in its existing integration tests.

For live provider bugs, prefer a CI-safe regression at the smallest production
composition reaching the defect: real adapters with captured requests, Gateway
integration for session/history/tool pipelines, or independent parser unit
contracts. Keep inherently live-only checks narrow and opt-in.

New `includeInPlan` SecretRef families in `src/secrets/target-registry-data.ts`
need classification in `src/secrets/exec-secret-ref-id-parity.test.ts` so sampled
traversal-segment rejection cannot silently skip them.


## Supplied guidance: .agents/skills/openclaw-testing/SKILL.md

---
name: openclaw-testing
description: Choose proportional OpenClaw tests/checks, diagnose failures, route environment-sensitive or release proof to its owner.
---

# OpenClaw Testing

## Proof policy

- **PR CI = default broad proof.** Change builds + focused tests pass → open
  ready PR. CI runs broad suites; never delay PR for pre-PR suite runs.
- **Build unavailable before publication:** when publication is already authorized,
  remote capacity is unavailable, and local execution is unqualified, push/open a
  draft PR with the exact missing build and capacity gap recorded. Defer that build
  to exact-head CI. Require its success before marking ready or merging. This
  changes proof timing only, not publication authority, source trust, credentials,
  owner approval, or merge gates.
  Automatic CI skips drafts. For a trusted canonical PR targeting `main`, use
  `scripts/pr ci-dispatch <PR>`. This maintainer-only route binds the pushed head
  and selects PR-shaped CI through the existing workflow qualification.
  Verify the selected checkout SHA and successful `build-artifacts` job cover the
  required build. CI's `build:ci-artifacts` omits full declaration emission. Keep
  uncovered proof pending. A skipped job or workflow-ref SHA is not build proof.
  Link the run in the PR, then use normal ready-PR CI and landing gates.
  Untrusted source keeps its secretless route.
- **Before PR, prove narrowly:** touched tests with
  `pnpm test <file> --maxWorkers=1`, targeted typecheck, lint, format.
  Prefer local proof for trusted, bounded work when dependencies and current
  host capacity are qualified. Local execution is optional: a focused command
  can still load a large compiler graph or expand to broad lanes.
- **Choose remote proof deliberately.** Use PR CI for broad proof; Crabbox/Testbox
  may cover expensive checks, a busy or unqualified local host, another OS/device,
  live providers/channels, long E2E, or heavy benchmarks. Acquire only when the
  command is ready and capacity is granted promptly. If queued, stop only the
  task-owned allocation; use PR CI or a safe local scope. Keep uncovered
  platform-specific proof pending. Never force heavy work onto a busy machine
  or chain providers. Use the smallest profile proven for the selected workload.
- **Never rerun or re-push just for green.** Fix real failures; read available
  CI failure classification before attributing red.

- Prove changed contract, complete required gates, finish. Broaden/repeat only for
  changed inputs, failures, or named unresolved risk.
- Follow scoped `AGENTS.md`; authoring/reviewing tests: use
  [boundary guide](../../../docs/help/testing/writing-tests.md#prove-behavior-at-the-owning-boundary)
  and [test-audit](../test-audit/SKILL.md).

## Select the proof

- Select proof for touched contract; reuse valid proof (rerun for changed inputs or missing coverage); finish workflow's required gates within user/host limits; report unrun checks and gaps. Prove user-visible behavior through real flow when feasible; external APIs need live contract proof; isolated mock-Gateway harness = valid channel boundary proof. Docs-only: docs sanity and `git diff --check`.

- Runtime defect: reproduce real entry point; rerun it + relevant siblings.
- Trusted source: `pnpm changed:lanes --json`, focused tests + targeted typecheck/lint/format; `pnpm check:changed` = optional smart local check.
- Public SDK/plugin contract: representative consumers, not all-plugin sweep.
- Build output, lazy imports, package boundaries: include `pnpm build` or the
  repository CI build that covers the changed contract. Record uncovered
  packaging/platform/declaration requirements. Required full package or release
  builds still need their matching proof.
- Workflow: `git diff --check` + `pnpm check:workflows`.
- Docs only: relevant docs/link/format checks + `git diff --check`; no runtime tests.

- Read on demand: [local commands](../../../docs/reference/test.md),
  [Crabbox](../crabbox/SKILL.md), [OpenClaw remote setup](../../../docs/reference/test/remote-proof.md),
  [package/Docker proof](references/package-and-docker.md),
  [release CI](../release-openclaw-ci/SKILL.md),
  [plugin release matrix](../release-openclaw-plugin-testing/SKILL.md),
  [Docker authoring](../openclaw-docker-e2e-authoring/SKILL.md), channel skill/
  [Control UI E2E](../control-ui-e2e/SKILL.md)/[iOS E2E](../ios-e2e/SKILL.md).
- An isolated mock-Gateway harness is valid channel boundary proof; state live
  gaps. Prove user-visible behavior through the real flow when feasible;
  external APIs require live contract proof. Read the scoped channel/platform
  guide for live-channel or native-app work. Telegram claims require
  [Test Server userbot proof with Convex-leased credentials](../telegram-e2e-userbot/SKILL.md).
  Platform claims require real-device evidence; macOS permission proof requires
  a stable [signed app](../../../docs/platforms/mac/signing.md#permission-evidence).
- Release proof: preserve candidate/Tooling SHAs; never grants publication authority.

## Source and state boundaries

- Never execute untrusted contributor/fork code, wrappers, config locally.
  Use secretless fork CI or sanitized direct AWS through Crabbox; never
  credential-hydrated Testbox. Credentialed execution: maintainer approval after
  review required; never hydrate untrusted lease.
- Isolated state + free port. Never restart, edit, or test operator Gateway/real
  data without explicit per-task approval. Preserve unrelated processes and
  shared dependency installs.
- Concurrent test/check commands: separate `OPENCLAW_VITEST_FS_MODULE_CACHE_PATH`
  values or run serially; checks can run Vitest too. Repository wrappers only,
  never raw Vitest. Prepared linked worktrees: `node scripts/run-vitest.mjs <file>
  --maxWorkers=1` avoids pnpm reconciliation; PR CI runs the broad checks.

## CI failures

- PR CI fails → `pnpm test:ci-failed <pr>`; read pre-existing/new/unknown classification.
- Fix new failures; investigate unknown → `pnpm test:ci-failed <pr> --run` until selected tests pass locally → push once.
- `--run` enables `OPENCLAW_NODE_TEST_PLAN_CONTINUE_ON_FAILURE=1`: collect ordinary failures across selected configs, while infrastructure failures still stop; use the same opt-in for manual focused reruns.
- Pre-existing failures: [failure-table landing rule](../openclaw-pr-maintainer/references/landing.md#red-main-and-inherited-failures). Matching signatures ≠ job-name-only attribution.
- Never `gh run rerun` to chase green; never local full suite for CI repair.
- Bind diagnosis to exact SHA + job. Fetch failed logs once; prefer exact run/job
  state over stale PR rollups.
- Distinguish product, harness, infrastructure, credentials, superseded-run
  cancellation. Snapshots pass macOS/fail CI: reproduce Linux/Node bytes before
  regenerating.

### Baseline and expected-failure exceptions

Narrow baseline, snapshot, ignore, and expected-failure exceptions are implementer
decisions only when each entry is verified against source and the PR records its
reason (for example, tool-owned metadata in an upgrade snapshot while user data
stays exact). Never mask a real regression or user-data change. Blanket or
unverified exceptions need approval. Exact shrink-only ratchet updates are
maintenance. A PR may add up to 400 net test lines without a record. Above
that, add a `config/test-lines-allocations/<change>.txt` record that covers the
excess and state the reason in the squash body. Required regression tests no
longer need ledger records
([#197519](https://github.com/openclaw/openclaw/pull/197519),
[#197602](https://github.com/openclaw/openclaw/pull/197602)). See the
[cost budget](../../../docs/help/testing/writing-tests.md#cost-budget).

For module mocks, follow the
[fixture contract](../../../docs/help/testing/fixtures.md#module-mocks-and-export-completeness).
When an isolation annotation retires an existing baseline entry, commit the annotation and corresponding baseline removal together.
Inspect the full baseline diff because `--prune` scans the whole checkout.
Verify the updated baseline with a guard run without `--prune`.

### Test failure policy

- Failures = defects. Bounded reproduction attempt (same shard order first);
  identify owner; fix product, fixture, shared-state, ordering bugs.
- Proven repair: add regression; cite another owner's fix when applicable.
- Safe fix cannot be established/completed: record original failure, attempts,
  evidence, uncertainty in PR; continue under normal CI/review gates.
- Unresolved failure alone neither blocks landing nor requires extra approval.
  Passing replay ≠ proven fix.
- Never hide failures with retries, longer timeouts, weaker assertions, broader
  mocks, altered baselines.


## Supplied guidance: docs/help/testing/boundary-scenarios.md

---
summary: "Request, paid-work, recovery, default, and measurement proof contracts"
title: "Behavioral proof scenarios"
read_when:
  - You are changing provider requests, paid work, recovery, or defaults
  - You are making cache, billing, or performance claims
---

## Scenario contracts

Use focused integration tests through production owners with fixed external I/O
fixtures. Keep independent unit contracts. Apply the
[test value gate](https://github.com/openclaw/openclaw/blob/main/.agents/skills/test-audit/SKILL.md)
and [proof policy](https://github.com/openclaw/openclaw/blob/main/.agents/skills/openclaw-testing/SKILL.md#proof-policy).

- Name the caller-visible contract, credible regression, and proof limits. Use
  independent expected values and the caller's interface. Exact bytes, storage,
  call counts, and ordering belong when they protect storage, billing, delivery,
  or protocol contracts.
- Work in vertical slices: failing behavior, coherent repair, passing proof.
  A regression must fail on the original defect, not fixture setup; report
  unavailable baseline proof. Refactor under green tests; check distinct
  contracts before replacing redundant tests.
- Capture final serialized requests and resolved routing after real assembly:
  instructions, tools/order, input prefix, parameters, cache identity, endpoint,
  and auth mode. Warm-prefix reuse shares one preparation owner; document
  permitted differences. Standalone summaries need an intentional contract.
- Keep a paid provider result or never request it. Preflight predictable failures
  before calling. Distinguish not sent, uncertain, completed, and persisted;
  reconcile uncertainty. Exactly-once claims need proof retries cannot duplicate
  effects. Inject relevant failures and assert physical requests/usage, including
  rejected results. Local processing errors must not silently buy another call;
  preserve valid results without bypassing redaction, cancellation, or authority.
- Prove recovery through its diagnostic consumer with a sanitized reason/outcome.
  Warn on unexpected degradation; expected recovery may use a documented
  structured outcome. Persist replay decisions, reconstruct, and exercise the
  next request. Cover relevant compaction, switching, and concurrent edits;
  transient errors must not become permanent bans.
- Exercise defaults across affected routes, auth modes, capabilities, and stored
  states through execution's eligibility owner. Cover supported and unsupported
  cases, not copied capability tables or precomputed flags.
- Support cost/performance claims with comparable request counts, input/cached/
  output tokens, and latency; name model, route, and conditions. Live cache or
  billing claims need live evidence; label estimates. Unrelated edits do not
  require paid benchmarks.

Use synthetic content; keep credentials out of captures. Select failure cases
from the changed contract. Many private controls suggest fragmented ownership,
not a need for more test-only exports.

## SecretRef registry regression contract

When extending SecretRef registry coverage, preserve this authoring requirement:

- `src/secrets/exec-secret-ref-id-parity.test.ts` should derive one sampled target
  per SecretRef class from registry metadata (`listSecretTargetRegistryEntries()`),
  then assert traversal-segment exec ids are rejected.
- If you add a new `includeInPlan` SecretRef target family in
  `src/secrets/target-registry-data.ts`, update `classifyTargetClass` in that test.
  The guardrail must fail on unclassified target ids so new classes cannot be
  skipped silently.

The current parity test covers shared exec-id vectors but no longer contains the
registry sampler or `classifyTargetClass`; restore that coverage when extending
registry families rather than assuming the vector checks cover registry traversal.


## Supplied guidance: docs/help/testing/fixtures.md

---
summary: "Temporary directories, module mocks, database cleanup, watchers, and skill eval fixtures"
title: "Test fixture recipes"
read_when:
  - You need temporary files, module mocks, database teardown, or skill watchers in a test
  - You are building skill reliability evals
---

Use these recipes for the fixture you are changing. Follow the
[test authoring contract](/help/testing/writing-tests) for behavior and cost.

## Test Temp Directories

Use the shared helpers in `test/helpers/temp-dir.ts` for test-owned temporary
directories so ownership is explicit and cleanup stays in the test lifecycle:

```ts
import { afterEach } from "vitest";
import { useAutoCleanupTempDirTracker } from "../helpers/temp-dir.js";

const tempDirs = useAutoCleanupTempDirTracker(afterEach);

it("uses a temp workspace", () => {
  const workspace = tempDirs.make("openclaw-example-");
  // use workspace
});
```

On POSIX, the Vitest process owner keeps its temporary namespace short enough
for native tools' Unix sockets. If the inherited temp root is too deep, it creates
the namespace under `/tmp` while retaining the inherited owner's cleanup claim.
Keep disposable workspace outputs separate from `TMPDIR`, `TMP`, and `TEMP`.

`useAutoCleanupTempDirTracker(afterEach)` intentionally exposes no manual
cleanup method - Vitest owns cleanup after each test. Older lower-level
helpers (`makeTempDir`, `cleanupTempDirs`, `createTempDirTracker`) still exist
for tests that have not migrated; avoid new usage of them and avoid new bare
`fs.mkdtemp*` calls unless a test is explicitly verifying raw temp-dir
behavior. When a bare temp dir is genuinely needed, add an auditable allow
comment with a reason:

```ts
// openclaw-temp-dir: allow verifies raw fs cleanup behavior
const workspace = fs.mkdtempSync(prefix);
```

`node scripts/report-test-temp-creations.mjs` reports new bare temp-dir
creation and new manual shared-helper usage in added diff lines, without
blocking existing cleanup styles. It follows the same test-path classification
as `scripts/changed-lanes.mjs` and skips the shared helper implementation
itself. `check:changed` runs this report for changed test paths as a
warning-only CI signal (GitHub warning annotations, not failures).

Copy fixture trees whose files a test later executes directly (stubs on `PATH`,
shebang wrappers, native binaries) with `copyTreeCloseOnExec` from
`test/helpers/close-on-exec-copy.ts`, not a recursive `fs.cpSync` without a
`filter`. On Node 24 that copy path opens files without close-on-exec, so a
child forked by another Vitest thread mid-copy keeps the file writable and a
later `execve` fails with `ETXTBSY`.

## Agent reliability evals (skills)

We already have a few CI-safe tests that behave like "agent reliability evals":

- Agent admission, run-ID responses, and abort requests through the real Gateway with a mock OpenAI provider (`src/gateway/gateway.test.ts`).
- End-to-end wizard flows that validate session wiring and config effects (`src/gateway/gateway.test.ts`).

What's still missing for skills (see [Skills](/tools/skills)):

- **Decisioning:** when skills are listed in the prompt, does the agent pick the right skill (or avoid irrelevant ones)?
- **Compliance:** does the agent read `SKILL.md` before use and follow required steps/args?
- **Workflow contracts:** multi-turn scenarios that assert tool order, session history carryover, and sandbox boundaries.

Start future evals with fixed inputs and mock providers:

- A scenario runner using mock providers to assert tool calls + order, skill file reads, and session wiring.
- A small suite of skill-focused scenarios (use vs avoid, gating, prompt injection).
- Optional live evals (opt-in, env-gated) only after the CI-safe suite is in place.

## Module mocks and export completeness

New first-party `vi.mock` and `vi.doMock` factories should preserve the real
module's exports when the fixture only needs to override a few functions:

```ts
vi.mock("./runtime.js", async (importOriginal) => ({
  ...(await importOriginal<typeof import("./runtime.js")>()),
  start: vi.fn(),
}));
```

Use pass-through for **export completeness** only. `importOriginal` and
`vi.importActual` can return a separate module instance for stateful singletons;
they do not guarantee shared state or lifecycle identity. Keep a closed mock when
isolating real state or initialization is the fixture's purpose, and explain that
contract on the line immediately above the mock call:

```ts
// mock-isolation: Keep the database and process-wide cache outside this fixture.
vi.mock("./runtime.js", () => ({ start: vi.fn() }));
```

`pnpm check:test-mock-exports` checks literal first-party module registrations,
including relative, workspace-package, and TypeScript-path aliases. Factories
without a recognizable real-module return/spread need the annotation, including
indirect factories the syntax check cannot prove. Existing unannotated factories
have an exact source-target and token-fingerprint baseline; new or changed factories cannot borrow
another site's allowance. After removing or annotating existing factories, run
`pnpm check:test-mock-exports --prune` to shrink that baseline. This guard runs
with the existing CI ratchets and `check:changed`; it does not rewrite tests.

## Raw SQLite state access

`closeOpenClawStateDatabaseForTest()` closes native handles synchronously, but
worker-backed state writes (plugin state, deferred plugin migrations, and other
worker stores) keep a worker connection whose retirement only starts at that
call. Its final close checkpoints and deletes the WAL under an exclusive lock at
an arbitrary later time. Before opening the database with a raw `DatabaseSync`,
or copying, hashing, or snapshotting its files, `await
closeOpenClawStateDatabaseAsync()` (or `closeStateDatabaseForTest()` from
`src/test-utils/database-cleanup.ts`, which also clears failure latches).
Otherwise the raw connection can fail with `SQLITE_BUSY`, or the snapshot can
change underneath the test. `PRAGMA locking_mode=EXCLUSIVE; BEGIN EXCLUSIVE` on
a raw connection proves that no other connection remains.

<a id="skills-watchers" />

## Skills discovery

`skills.status` and skill snapshot preparation share a background discovery
worker. Close it in `afterEach` with `await closeSkillsWatchers(true)` before
removing its temporary roots or restoring fake timers. Shared-worker lanes
also drain this owner through the generic singleton lifecycle between files.

Set `skills.load.watch: false` when a test does not exercise passive refresh.
This disables periodic scans; initial discovery and explicit skill changes still
use the worker and must finish before cleanup.

## Compiled subprocesses and timeout helpers

`createOpenClawTestInstance` waits for both `/readyz` and `/startupz` on its
isolated Gateway. Failed probes back off from 10 ms to at most 500 ms within
the original startup deadline. This also bounds refusal traffic when an
agent-launched test inherits the secret egress proxy environment; it does not
bypass the proxy's loopback traffic policy.

- Load compiled-subprocess declarations (`scripts/lib/vitest-worker-declarations.mts`)
  at collection. The first such load in a Vitest invocation prepares the whole
  compiled worker generation (tens of seconds warm, minutes cold), so an
  `await import()` in a test or hook whose graph reaches a declaration spends
  that preparation inside the test or hook deadline. Import the subject
  statically; suites that re-import it per test add a side-effect import of
  `src/test-utils/prepare-compiled-subprocesses.ts` in core. Extension tests use
  `import "openclaw/plugin-sdk/compiled-subprocess-testing";` instead. Add the
  preload only to suites that already load a declaration.
- Nested shutdown fixtures prepare one generation during collection, then borrow it
  through the supervisor and `run-vitest.mjs` forwarding shim. Keep the descriptor
  on the existing bootstrap/IPC contract so each owner joins its child before
  returning the loan; do not put cold compilation inside a shutdown deadline.

Replace grandfathered `withTestTimeout`/`raceWithTimeoutResult` races with
`awaitGateBeforeSettlement(gate, operation, message)` or `withinTest(work, signal)`
from `test/helpers/promise.ts`, or use `vi.useFakeTimers()` through the owner's
injected clock.
After removals run `pnpm check:test-timeout-race-ratchet --prune`; the per-file
baseline in `config/test-timeout-race-baseline.txt` only shrinks.


## Supplied guidance: .agents/skills/test-audit/CAMPAIGN.md

# Test-pruning campaign

Campaign mode prunes one subsystem's whole test surface in one PR: a plugin
such as `extensions/telegram`, or one core area. The value bar, retention bar,
candidate evidence, and validation in [SKILL.md](SKILL.md) apply to every
lane. This file adds the order of work and the lessons of a full campaign.
Each step ends on its completion criterion; do not start the next step early.

## 1. Baseline

Record the subsystem's test and support line counts and every test file's
pass/fail state at a pinned `main` SHA. Keep baseline failures in their own
list: in the Telegram campaign, all three were real delivery bugs, not stale
tests.

Done when every in-scope test file has a recorded baseline result.

## 2. Lanes and inventory

Split the surface into **lanes** along production owner boundaries, not file
prefixes. For Telegram these were accounts, commands, context, dispatch,
inbound, outbound, persistence, transport, shared, harness, and live/QA
scenarios. Include the subsystem's cases at shared core boundaries and its QA
and live-proof harness tests.

Done when every test file and QA scenario the subsystem owns belongs to exactly
one lane.

## 3. Read-only ledger per lane

Give each lane to its own read-only agent. The agent reads every assigned test
in full, including parameter tables. It also reads the production owners and
their entry points, callers, history, and CI routing. Each test declaration
goes into a written **ledger** with one mark. An `it.each` is one declaration
unless its rows need different marks; then mark each row.

- `R`: retain, naming the contract and the bug it catches; a retained test that
  only moves to a better-named file stays `R` with the move noted;
- `F`: retain the contract but repair the assertion, such as a vacuous negative
  that passes when only one of several items is missing;
- `C`: consolidate, naming the owner that absorbs the assertion first: a sibling
  table case, a stronger boundary suite, or the shared owner in another package;
- `D`: delete, naming the proof that remains, or why no contract exists.

Judge a test by its assertions, not its name. One Telegram test named for
retiring a progress window asserted the window was _not_ cleared.

Done when every declaration in the lane has a mark and an evidence line.

## 4. Layer plan per lane

Treat the per-test ledger as input, not as the edit list. A second read-only
pass, starting from the ledger, looks for the redundant **layer**. In Telegram,
several dispatch suites replayed the same shared compositor through one mocked
preview, around stronger real-stream and HTTP-fixture suites. Name the
**keeper** suite for each contract. Prefer the real transport boundary with a
fake network over a mocked collaborator. Correct any ledger errors this pass
finds.

Done when each lane plan names its retired files, its keeper per contract, the
assertions to carry into keepers, and the test-only production seams unlocked.

## 5. Cutover

Edit lane by lane. Serialize changes to shared harnesses and support files
through one owner. With each lane, remove the test-only production seams it
unlocks: injection parameters, getters, reset exports, and indirection layers.
Register moved suites in CI routing and test inventories. Update shrink-only
line-cap baselines. Put durable test-ownership rules in the subsystem's
`AGENTS.md`, drawn from mistakes this campaign actually found.

Done when every lane plan is applied and each lane's keepers pass.

## 6. Preservation review

Before claiming completion, have independent reviewers compare deleted
coverage against the keepers, one reviewer per boundary group. They look for
contracts that lost their only proof. They also look for new assertions that
cannot fail, such as a rejection row the production code never reaches. The
Telegram review found nine real gaps and one unreachable assertion.

For each restored contract, make one deliberate **mutation** of the production
owner and confirm the keeper goes red. Then restore the source byte for byte.

Done when every reported gap is restored or rejected with source evidence, and
every restored contract has a caught mutation.

## 7. Product defects

A baseline failure that survives into a keeper is a bug report. Fix it at its
owner as a separate commit, and prove it through the real user flow, with a
**control** run that reverts the fix and shows the old behavior. Record
unrelated product discrepancies you find as follow-ups instead of fixing them
in the campaign.

Done when each repaired defect has a failing control and a passing candidate
on the same harness.

## 8. Reconcile and hand off

Campaigns outlive many `main` commits. Merge `main` rather than rebasing a
long, many-commit campaign. When `main` modified a file the campaign
deleted, keep the deletion. Port the new contract into the keeper instead, and
confirm every new regression `main` added still has a home. PR CI reruns broad
subsystem suite on merged head. Locally rerun only tests touched by merge or
failed in CI; repeat live proof when merged inputs affect live contract.

Expect review tooling to see a truncated file list on a diff this large.
Record maintainer decisions for generic compatibility flags in the PR evidence
rather than editing gates.

Hand off with the [SKILL.md](SKILL.md) report, plus:

- baseline and final test/support line counts, with production counted separately;
- lanes, retired layers, and keepers;
- preservation gaps found and their mutations;
- product defects with control and candidate proof.


## Task

The renderer suite has a 4,500-render Cartesian style matrix. It repeats 360 renders and holds source complexity and output format constant, despite claiming interaction coverage. An audit proposes adding more seeds and browser versions to the full product. There is also a fixed regression that requires a particular three-factor combination. Review the plan and specify a smaller or larger portfolio, its obligations, and the evidence needed before removing old cases.

## Response format

Return ONLY a JSON object with these keys: decision (approve/revise/reject), changes (array of objects with target, action, details), retained_contracts (array of strings), validation (array of concrete commands or checks), cost_and_stop (string), rationale (string). Propose concrete changes you would actually ship, not just warnings. Stay within the supplied task. Do not execute the proposed work. Keep the JSON answer under 650 words.
