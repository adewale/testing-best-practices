Read only this packet. Work independently without other agents. Write the exact final JSON response to response.md beside this packet and return the same response.

Use only the task and context in this packet. Do not browse other files, use the network, run proposed checks, or contact other agents.

## Task

A verifier's tamper tests now account for 32% of unit-suite time. Each negative variant reruns expensive preparation and the complete oracle pipeline. The next audit proposes adding more variants, repeating the whole pipeline for each, and increasing the global test timeout. The checker must still reject each bad variant: reusing the final verdict would not test those variants. Review the change and give a concrete way to preserve the verification while controlling its cost.

## Response format

Return ONLY a JSON object with these keys: decision (approve/revise/reject), changes (array of objects with target, action, details), retained_contracts (array of strings), validation (array of concrete commands or checks), cost_and_stop (string), rationale (string). Propose concrete changes you would actually ship, not just warnings. Stay within the supplied task. Do not execute the proposed work. Keep the JSON answer under 650 words.
