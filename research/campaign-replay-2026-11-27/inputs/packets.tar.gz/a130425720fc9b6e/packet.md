Read only this packet. Work independently without other agents. Write the exact final JSON response to response.md beside this packet and return the same response.

Use only the task and context in this packet. Do not browse other files, use the network, run proposed checks, or contact other agents.

## Task

The renderer suite has a 4,500-render Cartesian style matrix. It repeats 360 renders and holds source complexity and output format constant, despite claiming interaction coverage. An audit proposes adding more seeds and browser versions to the full product. There is also a fixed regression that requires a particular three-factor combination. Review the plan and specify a smaller or larger portfolio, its obligations, and the evidence needed before removing old cases.

## Response format

Return ONLY a JSON object with these keys: decision (approve/revise/reject), changes (array of objects with target, action, details), retained_contracts (array of strings), validation (array of concrete commands or checks), cost_and_stop (string), rationale (string). Propose concrete changes you would actually ship, not just warnings. Stay within the supplied task. Do not execute the proposed work. Keep the JSON answer under 650 words.
