Read only this packet. Work independently without other agents. Write the exact final JSON response to response.md beside this packet and return the same response.

Use only the task and context in this packet. Do not browse other files, use the network, run proposed checks, or contact other agents.

## Task

An audit proposes bringing every test file to an assertion density of at least 3.0. Its draft adds isinstance/not-null checks and source-text substring assertions until each file meets the ratio. Some existing one-assertion tests exactly check a promised exception or a complete property. Other sanitizer tests assert only that output is nonempty and do not check whether unsafe content was removed or safe content retained. Review the proposed upgrade and specify the changes you would actually make and how to verify them.

## Response format

Return ONLY a JSON object with these keys: decision (approve/revise/reject), changes (array of objects with target, action, details), retained_contracts (array of strings), validation (array of concrete commands or checks), cost_and_stop (string), rationale (string). Propose concrete changes you would actually ship, not just warnings. Stay within the supplied task. Do not execute the proposed work. Keep the JSON answer under 650 words.
