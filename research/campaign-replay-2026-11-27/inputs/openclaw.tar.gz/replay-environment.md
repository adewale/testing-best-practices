# Running the same audit in another repository

Mount one pinned repository snapshot and give each comparison arm the same target facts. Keep the original skill entrypoints and their relative reference paths. The OpenClaw treatment starts at `source/.agents/skills/test-audit/SKILL.md`. Its ordinary workflow links `references/audit.md`, the boundary and cost guide, and the OpenClaw Testing proof policy. A whole-subsystem task adds `CAMPAIGN.md` first. The scenario and fixture recipes are available when their stated topics apply. [Source manifest](source-manifest.json)

## Map the host operations

Populate these facts from the target's actual CI, manifest, runner and scoped instructions. Give each arm access to the same evidence. If the task measures discovery of missing coverage or dead CI routes, supply the raw configuration, history and runner commands. Keep the reviewer's interpretation of those sources in the grading material.

| Operation named by OpenClaw | Equivalent target evidence |
|---|---|
| `pnpm test <file> --maxWorkers=1`, owner and sibling proof | Exact focused runner invocation and selection mechanism, sibling selection, and working directory. Record selected test count, result and elapsed time. Preserve file-level results when the task spans a whole subsystem. |
| Broad proof delegated to PR CI and changed-path classification through `node scripts/check-changed.mjs --dry-run -- <changed-paths>` | Actual CI workflow, job, trigger, base/head and path filters, or the target's native planner. Report which jobs would select which files and which jobs actually ran. A planner preview proves selection only. |
| `pnpm deadcode:dependencies`, `pnpm deadcode:unused-files`, `pnpm deadcode:exports` before landing removal batches | The target's dependency, orphan-file and unused-export checks. If a phase has no target equivalent, document that gap. Manual searches can support specific caller claims. Check registry, package exports, discovery and routing when relevant. |
| Targeted formatting, `git diff --check`, `git diff --numstat`, timing and shrink-only budgets | Use the target's formatter and available Git checks. Use its own line allocation and timing gates when present. Keep separate production and test/support deltas and report actual run time. |
| Read-only lane authors, independent preservation reviewers, maintainer autoreview and live-provider/PR proof | Record worker count, reviewer independence, capabilities, CI access and allowed writes. Where a stage cannot run, label the result as partial and identify the unproved contract. Keep any upstream publication or CI operation within the task's authority. |

The three native dead-code phases cover different evidence. OpenClaw's dependency command expands to two Knip passes. Its unused-file and unused-export phases use repository scripts. The saved native entrypoints and scripts are provenance for these mappings. Executing them requires OpenClaw's workspace, configurations and dependencies. Cross-repository replay needs the target's tools and runner. [Native command definitions](source-manifest.json) · [OpenClaw proof policy](https://github.com/openclaw/openclaw/blob/9fd0b7de19b70c97a285d5ff4c852d66f952190e/.agents/skills/openclaw-testing/SKILL.md#proof-policy)

Give every arm the same time, access, permitted actions and available reviewer capacity. Time-boxed discovery, a comparison of proposed repairs, an applied test patch, and a completed subsystem campaign each establish different results. Preserve measured work, skipped stages and unavailable verification in the run record.
