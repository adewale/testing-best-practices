# Keyboardia replay preparation

This case reconstructs findings from an earlier audit of adewale/keyboardia. The source was pinned before this replay at `aa67598560f8eaf2509a3ad4bc73edee2f8bea8a`, whose Git tree is `c2021aeb2b9fdfee548398bebe956da9854ff742`. The 58-file assignment deliberately mixes known audit cases and independently ranked files. The case measures audit and repair performance on this source under shared conditions. It gives no estimate of novel discovery frequency.

## Package

Distribute only `participant/` and the common runtime chosen for all arms. It contains the neutral assignment, complete conventional test inventory, 58-file sample, exact source and per-file hashes, two public hosted CI job inventories and neutral local test commands. Keep `evaluator/`, `evidence/`, the assembly scripts, this file and the historical audit outside participant workspaces. The subject receives the assigned guidance through the experiment runner.

The conventional inventory matches `.(spec|test).[mc]?[jt]sx?` at the end of a blob path across the entire pinned Git tree. Its 370 test files comprise 313 app Vitest files (including the separate audio-render and verification-tooling projects), 11 Worker integration files, 42 Playwright files under e2e and four Playwright identity files. The additional `app/src/audio/audio-hot-paths.bench.ts` is included in the text snapshot and excluded from the conventional test count. Declarative benchmark definitions and opt-in scripts have separate execution models.

The snapshot exports two small Worker fixture blobs into `participant/runtime/worker-assets/` and 985 UTF-8 blobs totaling 9,907,943 bytes out of 2,531 upstream blobs. It includes every conventional test, all actual TypeScript production owners under app/src, test helpers, public benchmark code, the package locks, CI and the testing guide. It omits the large application audio and screenshot corpora, the sample-curation corpus, upstream audit/history documents, generated results and Git object history. `participant/source-manifest.tsv` enumerates the included Git paths and SHA-256 hashes. The upstream product contains public modules named `evals/oracles/hidden-*`; these are part of Keyboardia's distributed source. The external evaluator controls for this replay remain in `evaluator/`.

## Reproduction and sampling

Use `python3 prepare.py /path/to/keyboardia.git --out /tmp/keyboardia-export` with a bare repository that contains the pinned commit. The retained local source at preparation time was `/tmp/keyboardia-history.git`. The exporter checks the commit's tree object, reads exactly the selected Git blobs and recomputes each Git object ID. No fetch, checkout, installation, repository mutation or build of the upstream project is required for export. Re-run `snapshot-ci.py` against the previous audit's saved GitHub API JSON to reconstruct the two all-job receipts. Each receipt also lists its original API endpoint.

The private reconstruction recipe has 18 named anchors from the prior audit and supporting examples. For every remaining place, rank eligible paths by SHA-256 of UTF-8 `keyboardia-suite-replay-2026-11-v2`, NUL, the stratum name, NUL, and the exact path. Take the smallest binary digests within each stratum, breaking ties by path. Sort the resulting path list lexicographically. `prepare.py` fixes the exact strata, quotas and anchors. The public sample presents paths and strata without the anchor designations.

| Architectural stratum | Inventory | Sample |
| --- | ---: | ---: |
| App testing, verification and tooling | 62 | 7 |
| Audio | 130 | 8 |
| Browser E2E | 42 | 11 |
| Identity browser | 4 | 2 |
| Other product code | 26 | 4 |
| Shared protocol and Worker unit | 36 | 6 |
| Sync | 16 | 6 |
| UI including hooks | 43 | 6 |
| Worker integration | 11 | 8 |
| **Total** | **370** | **58** |

The 23-file default unit run and eight-file default workerd run have narrower scope than the reading sample. The focused runs use the repository's real configuration. Audio, browser and Darwin evidence remains source or hosted history as specifically identified. The historical hosted CI results have their original run dates and URLs in the public input.

## Runtime and resource budget

Use the same prewarmed runtime, 25-minute time budget, model, reasoning effort and tool protocol across arms. Subject processes share the host and use case-local writable caches. Token usage is unavailable for matching or comparison. The separate Docker baseline used two CPUs and 2 GiB of memory. Its limits describe that baseline execution. The shared runtime needs about 0.5 GiB of package data plus working copies and scratch space. The timings in `evidence/` are single observations.

The app subset uses 17 roots from the upstream lock. The Worker uses its complete upstream lock for Linux x64 glibc. The dependency setup reused integrity-matched, already-installed native packages including workerd. The remaining platform package downloaded about 8 MB compressed. No lifecycle script ran. `prepare-worker-native.py` materializes the native portion of an `npm ci --omit=optional --ignore-scripts` setup. Standard `npm ci --ignore-scripts` with both locks also provisions the packages. The portable attachment command and reconstruction steps appear in `participant/runtime/README.md`.

The local provisioned module directories are `/tmp/keyboardia-v2-app-deps/node_modules` and `/tmp/keyboardia-v2-worker-deps/node_modules`. For shared-host subjects, expose only those dependency directories under the runner's path protocol, set `KEYBOARDIA_APP_MODULES` and `KEYBOARDIA_WORKER_MODULES` to the respective paths, and run `python3 runtime/attach.py` in a writable public copy. The case contains only participant material. Vitest keeps writable caches outside the reusable package trees. Shared-host path restrictions are procedural. The operator's offline checks use separate container mounts.

## Earlier audit evidence

The source evidence that motivated the case is in `/workspace/current-test-audit-2026-11-26/reports/keyboardia.json` and `/workspace/current-test-audit-2026-11-26/evidence/keyboardia/`. The earlier audit ran the validator and public grader but did not run the app or workerd locally. This case's new source-grounded runtime observations and paired controls are in `evidence/`. No subject or model comparison was run during this preparation.

## Executed baseline and frozen artifacts

The final local app selection passed 343 tests in 23 files. The eight-file Worker sample passed 84 tests, and the full upstream Worker suite passed 131 tests in all 11 files. The public named sync CLI counted 38 message types. The full Worker suite and sample overlap. The single-run commands, dependency versions, scopes and timing observations are in `baseline.json`. The initial broader selection exposed a missing MCP client and missing image/font fixtures in the preliminary test environment. The final runtime uses the upstream locked client and original 59,097 bytes of static font and fallback PNG inputs. Its broader run then passed. The API tests use the pinned HTML and these local assets without a production bundle.

`keyboardia-participant.tar.gz` contains all 1,001 participant files under one directory. `seal.py` creates the deterministic tarball and proves its membership and extracted bytes. `freeze-manifest.json` gives its SHA-256 and separate per-file hashes of the hidden scoring specification and runner. Two consecutive seals produced identical bytes. `evidence/integrity.json` records a byte-identical independent re-export and comparison with the saved untruncated Git tree.

A separate Docker confirmation used a fresh extract of the preceding public runtime revision, both runtime mounts read-only, no external network, two CPUs, 2 GiB of memory and UID 1000. It passed all 343 focused unit tests in 29.73 seconds and all 131 Worker tests in 48.44 seconds. The seven sync variants were also recalibrated against the final provisioned runtime. The logs are in `evidence/docker-offline.log` and `evidence/final-sync-controls/`.

The final common-host archive is identified by `freeze-manifest.json`. A fresh extract at `/workspace/test-audit-replay-v2/runtime-smoke/keyboardia` used the environment-based attachment and passed 343 unit tests and 84 Worker tests. `POSTCANDIDATE.md` gives exact isolated scoring commands for submitted files, including new tests. The immutable scoring inputs and the c1b763f7 participant archive remain independent of that transport.
