# Isolated post-submission checks

Run these commands from the Keyboardia preparation directory after the participant has finished. Give `--repo` the complete submitted repository directory, including added tests and helper files. The driver copies regular files directly and ignores generated module/cache directories. When the participant delivered a patch, first apply it to a fresh copy of `participant/repo` and include every documented new file. Record a missing file or a patch that fails to apply.

1. Record the participant's exact claimed boundary, test names, paths, lane registration and expected outcomes before opening hidden verdicts. Point the JSON command file at the check they supplied. The example below assumes a new hook test at the sample path. Substitute the actual submitted path and command.

   ```sh
   cat > /tmp/keyboardia-submission-command.json <<'JSON'
   {"cwd":"app","args":["node","node_modules/vitest/vitest.mjs","run","--project","unit","src/hooks/useMultiplayerSync.test.ts"]}
   JSON
   python3 postcandidate.py \
     --repo /absolute/path/to/submitted/repo \
     --scenario sync --case original --case inverted_hook --case early_return --case stale_hook \
     --command-json /tmp/keyboardia-submission-command.json \
     --out /absolute/path/to/evaluator-records/submitted-hook
   ```

2. For a Worker repair, replace the command JSON with the actual submitted test, for example `{"cwd":".","args":["/case/runtime/run-worker.sh","new-contract.test.ts"]}`. Select `--scenario sync --case original --case private_rename --case no_dispatch --case author_only`. Run the named production gate as a separate check by omitting `--command-json` with the same scenario and cases. Separate results show where a new check detected a regression and where a static gate retained its prior behavior. Use the complete seven-row matrix by omitting all `--case` options.

3. For the two alternative contracts, run their registered checks. Use a distinct new output directory for each invocation.

   ```sh
   python3 postcandidate.py --repo /absolute/path/to/submitted/repo --scenario discovery --out /absolute/path/to/evaluator-records/discovery
   python3 postcandidate.py --repo /absolute/path/to/submitted/repo --scenario seed --out /absolute/path/to/evaluator-records/worker-seed
   ```

4. For a different scoped proposal, `--scenario clean --command-json /absolute/path/to/command.json` verifies baseline collection and execution in the same container. Record an independently grounded allowed-change and fault check with its own adjudication. Preserve the frozen matrix as a distinct result.

The host applies one frozen stimulus or mutation per scratch copy. Each container receives only that mutable copy, published runtime helpers, both read-only dependency trees and any single required input fixture. It has no external network, carries no host credentials and has no mount containing prior audits, other arms or the hidden criteria. The runtime bootstrap precedes the submitted command. The driver serializes invocations and sets a 180-second limit per case, configurable using `--timeout`. The caller can also serialize submissions. These Docker limits apply to post-submission checks.

A mismatch with a frozen mutation anchor is recorded for review. A process exit is a measurement. Read the associated log, verify test collection, the relevant assertion and the clean baseline, and report infrastructure failures separately. An absent test on the original tree is an absent check. Compare the original registered behavior with the submitted repair, and avoid attributing an independent private witness's sensitivity or a pre-existing keeper to the submission. The immutable control specification, independent ground truth and calibrated outcomes are in `evaluator/hidden-controls.md`, `evaluator/hidden-controls.json` and `evidence/final-sync-controls/results.json`.
