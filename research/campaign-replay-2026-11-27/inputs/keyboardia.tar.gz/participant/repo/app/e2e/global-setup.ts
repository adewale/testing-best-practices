/**
 * Global E2E Test Setup
 *
 * Configures test environment for CI vs local development.
 * Tests always use the configured HTTP backend. CI normally starts Vite's
 * offline backend; full-stack runs use the real Worker.
 *
 * @see specs/research/PLAYWRIGHT-TESTING.md
 */

/* eslint-disable react-hooks/rules-of-hooks */
import { test as base, expect, Page, Locator, devices } from '@playwright/test';
import { API_BASE, createSessionWithRetry } from './test-utils';
import type { SessionState } from './test-utils';
import { configureE2EPage } from './browser-context';

/**
 * Whether we're running in CI environment
 */
export const isCI = !!process.env.CI;

/**
 * Whether Vite's mock API is active
 * When true, Vite handles all API mocking at the server level
 * and Playwright-level mocking should be disabled to avoid conflicts
 */
export const useMockAPI = process.env.USE_MOCK_API === '1';

/**
 * Input type for creating sessions - partial session state
 */
export interface CreateSessionInput {
  tracks?: SessionState['tracks'];
  tempo?: number;
  swing?: number;
  version?: number;
}

async function settleWithin<T>(promise: Promise<T>, timeoutMs: number): Promise<void> {
  let timer: ReturnType<typeof setTimeout> | undefined;
  await Promise.race([
    promise.then(() => undefined),
    new Promise<void>((resolve) => {
      timer = setTimeout(resolve, timeoutMs);
    }),
  ]);
  if (timer) clearTimeout(timer);
}

/**
 * Test base for HTTP-backed session creation and isolated browser storage.
 */
export const test = base.extend<{
  createSession: (data: CreateSessionInput) => Promise<{ id: string }>;
  isolatedPage: Page;
  releasePageAudio: void;
}>({
  /**
   * Every E2E document owns its AudioContext. Close it before Playwright reuses
   * the browser process so one test cannot starve the next test's page.
   */
  releasePageAudio: [async ({ page, browserName }, use) => {
    await configureE2EPage(page, browserName);
    await use();
    if (page.isClosed()) return;
    const shutdown = page.evaluate(() => {
      const engine = (window as unknown as {
        __audioEngine__?: { shutdown?: () => Promise<void> };
      }).__audioEngine__;
      return engine?.shutdown?.();
    }).catch(() => {
      // A test may intentionally navigate or close the page during teardown.
      // The pagehide lifecycle handler owns cleanup in that case.
    });
    // Normally wait for close() so WebKit does not accumulate live contexts
    // across a serial worker. A wedged media process can leave close() pending
    // forever, so bound the wait and let page destruction be the fallback.
    await settleWithin(shutdown, 2_000);
  }, { auto: true }],

  /**
   * Create a session through the configured HTTP backend. With USE_MOCK_API=1,
   * Vite handles the request; otherwise this exercises the real Worker.
   */
  createSession: async ({ request }, use) => {
    await use(async (data: CreateSessionInput) => {
      return createSessionWithRetry(request, data);
    });
  },

  /**
   * Isolated page fixture with clean state
   */
  isolatedPage: async ({ page }, use) => {
    // Clear storage before test
    await page.evaluate(() => {
      localStorage.clear();
      sessionStorage.clear();
    });
    await use(page);
    // Clean up after test
    await page.evaluate(() => {
      localStorage.clear();
      sessionStorage.clear();
    });
  },
});

/**
 * Base URL helper
 */
export function getBaseUrl(): string {
  return process.env.BASE_URL || process.env.PLAYWRIGHT_BASE_URL || API_BASE;
}

/**
 * Wait until edits cannot be overwritten by a late multiplayer snapshot.
 *
 * The offline Vite backend deliberately has no WebSocket server, so there is
 * no collaboration connection to await in that test mode.
 */
export async function waitForCollaborationReady(
  page: Page,
  timeout = 10000,
): Promise<void> {
  if (useMockAPI) return;

  await page.locator('.connection-status--connected').waitFor({
    state: 'visible',
    timeout,
  });
}

/**
 * Timing tolerance multiplier for CI
 * CI environments have more variable timing, so we increase tolerances
 */
export const TIMING_TOLERANCE = isCI ? 2 : 1;

/**
 * Traverse the browser's full keyboard focus order.
 *
 * Playwright WebKit on macOS mirrors Safari's default keyboard preference:
 * Tab visits text fields while Option+Tab visits every interactive control.
 * Chromium uses Tab for the same full-control traversal. Keeping that engine
 * distinction here prevents keyboard contracts from accidentally testing a
 * host preference instead of the application's tab order.
 */
export async function pressKeyboardTab(
  page: Page,
  browserName: string,
  backwards = false,
): Promise<void> {
  const modifiers = [
    ...(browserName === 'webkit' ? ['Alt'] : []),
    ...(backwards ? ['Shift'] : []),
  ];
  await page.keyboard.press([...modifiers, 'Tab'].join('+'));
}

// ============================================================================
// SMART WAIT UTILITIES
// These replace the anti-pattern of waitForTimeout with proper Playwright waits
// ============================================================================

/**
 * Wait for the app to be ready for interaction.
 * Uses proper Playwright waits instead of fixed timeouts.
 *
 * Handles two app states:
 * 1. Landing page at `/` - clicks "Start" to create session and enter sequencer
 * 2. Sequencer at `/s/{id}` - waits for track rows or sample picker
 *
 * In CI, includes additional error detection and longer timeouts.
 */
export async function waitForAppReady(page: Page): Promise<void> {
  const timeout = isCI ? 30000 : 15000;

  // First, wait for the page to complete initial load
  await page.waitForLoadState('domcontentloaded');

  // Check for any JavaScript errors that might prevent rendering
  const errors: string[] = [];
  page.on('pageerror', (err) => errors.push(err.message));

  // Check if we're on the landing page
  const landingPage = page.locator('.landing');
  const isLanding = await landingPage.isVisible().catch(() => false);

  if (isLanding) {
    // Enter the ordinary blank-session path explicitly. Exact matching keeps
    // this helper resilient if another landing-page action later uses "Start".
    const startButton = page.getByRole('button', { name: 'Start Session', exact: true });
    await startButton.waitFor({ state: 'visible', timeout: 5000 });
    await startButton.click();

    // Wait for URL to change to /s/{sessionId}
    await page.waitForURL(/\/s\/[a-zA-Z0-9_-]+/, {
      timeout,
      waitUntil: 'domcontentloaded',
    });
  }

  // Wait for app to be ready. Accept multiple indicators of readiness:
  // 1. Track rows visible (session with tracks)
  // 2. Sample picker visible (empty session ready to add tracks)
  // 3. App container with header visible (empty session - no tracks yet)
  try {
    // First try to wait for track rows or sample picker (normal cases)
    await page.locator('.track-row, .sample-picker').first().waitFor({
      state: 'visible',
      timeout: 3000 // Short timeout for this check
    });
  } catch {
    // If no tracks or sample picker, check if app container is ready
    // This handles empty sessions correctly
    try {
      await page.locator('.app, .App').first().waitFor({
        state: 'visible',
        timeout: timeout - 3000
      });
      // App container is visible, check for header to confirm app loaded
      // In portrait mode, .app-header is hidden and .portrait-header is shown instead
      // Check each header type separately since .first() picks DOM order not visibility
      const appHeaderVisible = await page.locator('.app-header').isVisible().catch(() => false);
      const portraitHeaderVisible = await page.locator('.portrait-header').isVisible().catch(() => false);
      const genericHeaderVisible = await page.locator('header').first().isVisible().catch(() => false);
      const hasHeader = appHeaderVisible || portraitHeaderVisible || genericHeaderVisible;
      if (!hasHeader) {
        throw new Error('App container visible but no header found');
      }
      // App is ready (empty session with no tracks)
      return;
    } catch (innerErr) {
      // On timeout, gather diagnostic info
      const html = await page.content();
      const hasRoot = html.includes('id="root"');
      const hasApp = html.includes('class="app"') || html.includes('class="App"');
      // More specific error detection - look for actual error indicators, not CSS classes
      const hasErrorMessage = html.includes('Something went wrong') ||
                              html.includes('Failed to load') ||
                              html.includes('Error:') ||
                              html.includes('error-boundary');
      const currentUrl = page.url();

      // Check what elements ARE visible
      const visibleElements = await page.evaluate(() => {
        const root = document.getElementById('root');
        if (!root) return 'No #root element';
        if (!root.children.length) return '#root is empty';
        return Array.from(root.querySelectorAll('*'))
          .slice(0, 10)
          .map(el => `${el.tagName.toLowerCase()}.${el.className}`)
          .join(', ');
      });

      const diagnostics = [
        `Timeout waiting for app to be ready (${timeout}ms)`,
        `Current URL: ${currentUrl}`,
        `Has #root: ${hasRoot}`,
        `Has app class: ${hasApp}`,
        `Has error message: ${hasErrorMessage}`,
        `JS errors: ${errors.length ? errors.join('; ') : 'none'}`,
        `Visible elements: ${visibleElements}`,
        `Inner error: ${innerErr instanceof Error ? innerErr.message : String(innerErr)}`,
      ].join('\n');

      throw new Error(diagnostics);
    }
  }

  // CRITICAL: Wait for WebSocket connection before any track operations.
  // Without this wait, tracks added before the initial snapshot arrives
  // will be lost when LOAD_STATE overwrites local state.
  // Only wait if we're on a session page (URL contains /s/)
  if (page.url().includes('/s/')) {
    await waitForCollaborationReady(page).catch(() => {
      // Connection status might not be visible in all cases (e.g., single player mode)
      // This is acceptable as long as the app is ready
    });
  }

  // Wait for network to settle (with timeout to prevent hanging)
  await page.waitForLoadState('networkidle').catch(() => {
    // networkidle can timeout if there are ongoing WebSocket connections
    // This is acceptable for app readiness
  });
}

/**
 * Wait for an element to be stable (no animations).
 * Useful after UI interactions that trigger animations.
 */
export async function waitForStable(locator: Locator): Promise<void> {
  // Wait for element to be visible and enabled
  await locator.waitFor({ state: 'visible' });
  // Playwright auto-waits for actionability, but we can also check stability
  await expect(locator).toBeVisible();
}

/**
 * Wait for a state change after an action.
 * Replaces arbitrary timeouts with assertion-based waiting.
 */
export async function waitForStateChange(
  page: Page,
  checkFn: () => Promise<boolean>,
  options: { timeout?: number; interval?: number } = {}
): Promise<void> {
  const { timeout = 5000, interval = 100 } = options;
  const startTime = Date.now();

  while (Date.now() - startTime < timeout) {
    if (await checkFn()) {
      return;
    }
    await page.waitForTimeout(interval);
  }
  throw new Error(`State change not detected within ${timeout}ms`);
}

/**
 * Wait for animation to complete.
 * Only use this for genuine CSS animations where no other wait is possible.
 * This is the ONLY acceptable use of waitForTimeout.
 */
export async function waitForAnimation(page: Page): Promise<void> {
  // 300ms is the typical CSS transition duration
  // This is acceptable per Playwright docs for animations outside our control
  await page.waitForTimeout(isCI ? 450 : 300);
}

/**
 * Wait for drag operation to complete.
 * Drag operations may need a brief pause for the browser to process.
 */
export async function waitForDragComplete(page: Page): Promise<void> {
  // Small wait for drag event propagation
  await page.waitForTimeout(isCI ? 75 : 50);
}

/**
 * @deprecated Use waitForAppReady, waitForStable, or web-first assertions instead.
 * This function exists only for backwards compatibility during migration.
 */
export async function waitWithTolerance(page: Page, _ms: number): Promise<void> {
  // Log deprecation warning in development
  if (!isCI) {
    console.warn(
      'DEPRECATED: waitWithTolerance() is an anti-pattern. ' +
      'Use waitForAppReady(), waitForStable(), or expect().toBeVisible() instead.'
    );
  }
  // For now, just wait for network idle as a reasonable default
  await page.waitForLoadState('networkidle').catch(() => {
    // Fallback if networkidle times out
  });
}

export { expect, devices };
export type { Page, Locator };
