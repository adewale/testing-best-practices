/**
 * Mobile Orientation E2E Tests
 *
 * Tests for the mobile interface simplification feature:
 * - Portrait mode: consumption-only interface
 * - Landscape mode: creation with inline drawer pattern
 * - Orientation transitions: smooth and correct visibility
 *
 * Run with: npx playwright test e2e/mobile-orientation.spec.ts
 */

import { test, expect, waitForAppReady, Page } from './global-setup';
import { createPopulatedSessionWithRetry } from './test-utils';

// Device configurations
const PORTRAIT_VIEWPORT = { width: 375, height: 667 }; // iPhone SE portrait
const LANDSCAPE_VIEWPORT = { width: 667, height: 375 }; // iPhone SE landscape
const DESKTOP_VIEWPORT = { width: 1280, height: 800 }; // Desktop

// Modern device landscape viewports (width > 768px, which broke the old CSS media queries)
const IPHONE_14_LANDSCAPE = { width: 844, height: 390 }; // iPhone 14
const IPHONE_15_PRO_MAX_LANDSCAPE = { width: 932, height: 430 }; // iPhone 15 Pro Max
const GALAXY_S24_LANDSCAPE = { width: 915, height: 412 }; // Samsung Galaxy S24

/**
 * Helper to add a track by clicking a sample button
 */
async function addTrack(page: Page) {
  // Click a drum sample to add a track
  const sampleBtn = page.locator('.instrument-btn, .sample-button').first();
  if (await sampleBtn.isVisible({ timeout: 2000 }).catch(() => false)) {
    await sampleBtn.click();
    // Wait for track to appear
    await page.locator('.track-row, .portrait-track-row').first().waitFor({ state: 'visible', timeout: 5000 }).catch(() => {});
  }
}

test.describe('Mobile Orientation - Portrait Mode', () => {
  test.beforeEach(async ({ page }) => {
    await page.setViewportSize(PORTRAIT_VIEWPORT);
    await page.goto('/');
    await waitForAppReady(page);
  });

  test('should show portrait header with play button, title, and BPM', async ({ page }) => {
    const header = page.locator('.portrait-header');
    await expect(header).toBeVisible();

    // Play button
    const playBtn = header.locator('.portrait-play-btn');
    await expect(playBtn).toBeVisible();

    // App name
    const appName = header.locator('.portrait-app-name');
    await expect(appName).toContainText('Keyboardia');

    // BPM display
    const bpm = header.locator('.portrait-bpm');
    await expect(bpm).toBeVisible();
  });

  test('should show portrait grid with abbreviated track labels', async ({ page, request }) => {
    const { id } = await createPopulatedSessionWithRetry(request);
    await page.goto(`/s/${id}`);
    await waitForAppReady(page);
    const grid = page.locator('.portrait-grid');
    await expect(grid).toBeVisible();

    const trackRows = grid.locator('.portrait-track-row');
    await expect(trackRows).toHaveCount(10);
    await expect(trackRows.first().locator('.portrait-track-label')).not.toBeEmpty();
    await expect(trackRows.first().locator('.portrait-step-cell').first()).toBeVisible();
  });

  test('should hide all editing UI in portrait', async ({ page }) => {
    // Transport should be hidden
    await expect(page.locator('.transport')).not.toBeVisible();
    await expect(page.locator('.transport-bar')).not.toBeVisible();

    // Mixer panel should be hidden
    await expect(page.locator('.mixer-panel-container')).not.toBeVisible();

    // Track controls should be hidden
    await expect(page.locator('.sequencer-content')).not.toBeVisible();
  });

  test('tap-anywhere-to-play-pause should toggle playback @blocking', async ({ page, request, browserName }) => {
    test.skip(browserName === 'webkit', 'Real audio playback is owned by Chromium; headless WebKit can wedge on AudioContext.resume()');
    // Use an owned populated session so browser hit-testing covers header,
    // track-label, and cell coordinates rather than only an empty grid.
    const { id } = await createPopulatedSessionWithRetry(request);
    await page.goto(`/s/${id}`);
    await waitForAppReady(page);
    await expect(page.locator('.portrait-track-row')).toHaveCount(10);
    const playBtn = page.locator('.portrait-play-btn');

    const tapAtCenter = async (selector: string) => {
      const box = await page.locator(selector).first().boundingBox();
      expect(box, `${selector} should have a layout box`).not.toBeNull();
      await page.mouse.click(box!.x + box!.width / 2, box!.y + box!.height / 2);
    };

    await expect(playBtn).not.toHaveClass(/playing/);

    // Exercise real browser hit-testing across representative parts of the
    // advertised surface rather than dispatching directly to the overlay.
    await tapAtCenter('.portrait-step-number');
    await expect(playBtn).toHaveClass(/playing/);

    await tapAtCenter('.portrait-track-label');
    await expect(playBtn).not.toHaveClass(/playing/);

    await tapAtCenter('.portrait-step-cell');
    await expect(playBtn).toHaveClass(/playing/);

    const indicator = await page.locator('.portrait-page-indicator').boundingBox();
    expect(indicator).not.toBeNull();
    await page.mouse.click(indicator!.x + 4, indicator!.y + indicator!.height / 2);
    await expect(playBtn).not.toHaveClass(/playing/);
  });

  test('should show orientation hint suggesting rotation', async ({ page }) => {
    const hint = page.locator('.orientation-hint');
    await expect(hint).toBeVisible();
    await expect(hint).toContainText('Rotate to edit');
  });

  test('orientation hint should be dismissible', async ({ page }) => {
    const hint = page.locator('.orientation-hint');
    await expect(hint).toBeVisible();

    // Dismiss
    await hint.locator('.orientation-hint-dismiss').click();

    // Should be hidden
    await expect(hint).not.toBeVisible();

    // Reload and check persistence
    await page.reload();
    await expect(hint).not.toBeVisible();
  });

  test('portrait header should show share and QR buttons', async ({ page }) => {
    const header = page.locator('.portrait-header');

    // Share and QR buttons should be visible in header
    const shareBtn = header.locator('.portrait-share-btn');
    const qrBtn = header.locator('.portrait-qr-btn');

    await expect(shareBtn).toBeVisible();
    await expect(qrBtn).toBeVisible();

    // QR button should trigger QR mode
    await qrBtn.click();
    // QR mode adds ?qr=1 to URL
    await expect(page).toHaveURL(/qr=1/);
  });

  test('page indicator dots should switch between step pages', async ({ page }) => {
    const dots = page.locator('.portrait-page-dot');

    // First dot should be active
    await expect(dots.first()).toHaveClass(/active/);
    await expect(dots.nth(1)).not.toHaveClass(/active/);

    // Click second dot
    await dots.nth(1).click();

    // Second dot should now be active
    await expect(dots.nth(1)).toHaveClass(/active/);
    await expect(dots.first()).not.toHaveClass(/active/);
  });
});

test.describe('Mobile Orientation - Landscape Mode', () => {
  test.beforeEach(async ({ page }) => {
    await page.setViewportSize(LANDSCAPE_VIEWPORT);
    await page.goto('/');
    await waitForAppReady(page);
  });

  test('partial portrait pages do not expose nonexistent steps @blocking', async ({ page, request }) => {
    await page.setViewportSize(PORTRAIT_VIEWPORT);
    const { id } = await createPopulatedSessionWithRetry(request);
    await page.goto(`/s/${id}`);
    await waitForAppReady(page);
    await expect(page.locator('.portrait-track-row')).toHaveCount(10);

    const finalPage = page.getByRole('button', { name: 'View steps 25-27' });
    await finalPage.click();
    await expect(page.locator('.portrait-step-number:not(.empty)')).toHaveText(['25', '26', '27']);
    await expect(page.locator('.portrait-track-row').first().locator('[data-step]')).toHaveCount(3);
  });

  test('should show transport with play, BPM, and swing only', async ({ page }) => {
    const transport = page.locator('.transport');
    await expect(transport).toBeVisible();

    // Play button visible
    const playBtn = transport.locator('.play-button');
    await expect(playBtn).toBeVisible();

    // BPM visible
    const bpm = transport.locator('.tempo-control');
    await expect(bpm).toBeVisible();

    // Swing visible
    const swing = transport.locator('.swing-control');
    await expect(swing).toBeVisible();
  });

  test('should hide complex transport elements in landscape', async ({ page }) => {
    // Scale selector hidden
    await expect(page.locator('.scale-selector')).not.toBeVisible();

    // Control group (FX, Mixer, Pitch, Unmute) hidden
    await expect(page.locator('.transport-control-group')).not.toBeVisible();
  });

  test('should show compact track rows with M/S and name', async ({ page }) => {
    // Add a track first since sessions start empty
    await addTrack(page);

    // Track row should be visible
    const trackRow = page.locator('.track-row').first();
    await expect(trackRow).toBeVisible();

    // M/S buttons should be visible
    await expect(trackRow.locator('.mute-button')).toBeVisible();
    await expect(trackRow.locator('.solo-button')).toBeVisible();

    // Track name should be visible
    await expect(trackRow.locator('.track-name')).toBeVisible();
  });

  test('M/S buttons should toggle instantly without drawer', async ({ page }) => {
    // Add a track first since sessions start empty
    await addTrack(page);

    const trackRow = page.locator('.track-row').first();
    const muteBtn = trackRow.locator('.mute-button');

    // Initially not muted
    await expect(muteBtn).not.toHaveClass(/active/);

    // Click mute
    await muteBtn.click();

    // Should be muted
    await expect(muteBtn).toHaveClass(/active/);
  });

  test('tapping track name should open drawer with Copy/Clear/Delete', async ({ page }) => {
    // Add a track first since sessions start empty
    await addTrack(page);

    const trackName = page.locator('.track-name').first();
    await expect(trackName).toBeVisible();

    // Tap track name to open drawer
    await trackName.click();

    // Wait for the 200ms click delay + drawer to appear
    const drawer = page.locator('.track-drawer').first();
    await expect(drawer).toBeVisible({ timeout: 3000 });

    // Drawer should contain Copy, Clear, and Delete buttons
    await expect(drawer.locator('.drawer-action-btn-compact', { hasText: 'Copy' })).toBeVisible();
    await expect(drawer.locator('.drawer-action-btn-compact', { hasText: 'Clear' })).toBeVisible();
    await expect(drawer.locator('.drawer-action-btn-compact.destructive')).toBeVisible();
  });

  test('landscape drawer supports keyboard disclosure and Escape focus restoration @blocking', async ({ page }) => {
    await addTrack(page);

    const trigger = page.locator('.track-name').first();
    await trigger.focus();
    await trigger.press('Enter');

    const drawer = page.locator('.track-drawer').first();
    await expect(drawer).toBeVisible({ timeout: 3000 });
    await expect(trigger).toHaveAttribute('aria-expanded', 'true');
    // aria-controls may only reference an element that exists, and the drawer
    // is unmounted while closed.
    await expect(trigger).toHaveAttribute('aria-controls', await drawer.getAttribute('id') ?? '');

    await page.keyboard.press('Escape');
    await expect(drawer).not.toBeVisible({ timeout: 3000 });
    await expect(trigger).toBeFocused();
    await expect(trigger).toHaveAttribute('aria-expanded', 'false');
    await expect(trigger).not.toHaveAttribute('aria-controls', /./);
  });

  test('landscape drawer keeps the destructive action distinguishable without hover @blocking', async ({ page }) => {
    await addTrack(page);

    await page.locator('.track-name').first().click();
    const drawer = page.locator('.track-drawer').first();
    await expect(drawer).toBeVisible({ timeout: 3000 });

    // This drawer is the touch surface: neither :hover nor :focus-visible ever
    // fires there, so Delete must differ from its neighbours at rest.
    const deleteBtn = drawer.locator('.drawer-action-btn-compact.destructive');
    const clearBtn = drawer.locator('.drawer-action-btn-compact', { hasText: 'Clear' });
    await expect(deleteBtn).toHaveText('Delete');

    const deleteBorder = await deleteBtn.evaluate((el) => getComputedStyle(el).borderTopColor);
    const clearBorder = await clearBtn.evaluate((el) => getComputedStyle(el).borderTopColor);
    expect(deleteBorder).not.toBe(clearBorder);
  });

  test('landscape drawer uses non-overlapping 44px control targets @blocking', async ({ page }) => {
    await addTrack(page);

    await page.locator('.track-name').first().click();
    const drawer = page.locator('.track-drawer').first();
    await expect(drawer).toBeVisible({ timeout: 3000 });

    const controls = drawer.locator('button, select');
    const controlCount = await controls.count();
    expect(controlCount).toBeGreaterThan(0);

    const boxes = [];
    for (let index = 0; index < controlCount; index += 1) {
      const box = await controls.nth(index).boundingBox();
      expect(box, `control ${index} should have a layout box`).not.toBeNull();
      expect(box!.width, `control ${index} width`).toBeGreaterThanOrEqual(44);
      expect(box!.height, `control ${index} height`).toBeGreaterThanOrEqual(44);
      boxes.push(box!);
    }

    for (let index = 1; index < boxes.length; index += 1) {
      expect(
        boxes[index].x,
        `control ${index} should not overlap control ${index - 1}`,
      ).toBeGreaterThanOrEqual(boxes[index - 1].x + boxes[index - 1].width);
    }
  });

  test('narrow landscape drawer scrolls every control into view and disables reduced motion @blocking', async ({ page, request }) => {
    await page.emulateMedia({ reducedMotion: 'reduce' });
    await page.setViewportSize({ width: 480, height: 320 });
    const { id } = await createPopulatedSessionWithRetry(request);
    await page.goto(`/s/${id}`);
    await waitForAppReady(page);

    const trackName = page.locator('.track-name').first();
    await trackName.focus();
    await page.keyboard.press('Enter');
    const drawer = page.locator('.track-drawer').first();
    await expect(drawer).toBeVisible();

    const overflow = await drawer.evaluate((element) => {
      const style = getComputedStyle(element);
      return {
        overflowX: style.overflowX,
        scrollWidth: element.scrollWidth,
        clientWidth: element.clientWidth,
        animationName: style.animationName,
      };
    });
    expect(overflow.overflowX).toBe('auto');
    expect(overflow.scrollWidth).toBeGreaterThan(overflow.clientWidth);
    expect(overflow.animationName).toBe('none');

    await drawer.evaluate(element => { element.scrollLeft = element.scrollWidth; });
    const drawerBox = await drawer.boundingBox();
    const deleteBox = await drawer.getByRole('button', { name: 'Delete' }).boundingBox();
    expect(drawerBox).not.toBeNull();
    expect(deleteBox).not.toBeNull();
    expect(deleteBox!.x).toBeGreaterThanOrEqual(drawerBox!.x);
    expect(deleteBox!.x + deleteBox!.width).toBeLessThanOrEqual(drawerBox!.x + drawerBox!.width + 1);

    const transitionDuration = await drawer.getByRole('button', { name: 'Delete' })
      .evaluate(element => getComputedStyle(element).transitionDuration);
    expect(transitionDuration).toBe('0s');
  });

  test('activating another track name should close first drawer (accordion)', async ({ page, request }) => {
    const { id } = await createPopulatedSessionWithRetry(request);
    await page.goto(`/s/${id}`);
    await waitForAppReady(page);

    const trackNames = page.locator('.track-name');
    await expect(trackNames).toHaveCount(10);

    // Open the first drawer and then activate the second disclosure. Keyboard
    // activation avoids conflating accordion ownership with horizontal-grid
    // hit testing (covered separately above).
    await trackNames.first().focus();
    await page.keyboard.press('Enter');
    const firstDrawer = page.locator('.track-drawer').first();
    await expect(firstDrawer).toBeVisible({ timeout: 3000 });

    await trackNames.nth(1).focus();
    await page.keyboard.press('Enter');

    // Only one drawer should be visible (accordion behavior)
    const visibleDrawers = page.locator('.track-drawer');
    await expect(visibleDrawers).toHaveCount(1);
  });

  test('tapping same track name again should close drawer', async ({ page }) => {
    // Add a track first since sessions start empty
    await addTrack(page);

    const trackName = page.locator('.track-name').first();

    // Open drawer
    await trackName.click();
    const drawer = page.locator('.track-drawer').first();
    await expect(drawer).toBeVisible({ timeout: 3000 });

    // Close drawer by tapping same name again
    await trackName.click();
    await expect(drawer).not.toBeVisible({ timeout: 3000 });
  });

  test('step grid should show more cells than old mobile', async ({ page }) => {
    // Add a track first since sessions start empty
    await addTrack(page);

    const steps = page.locator('.track-row').first().locator('.step-cell');

    // Count visible cells (should be at least 12-16 vs old 5-6)
    const count = await steps.count();
    expect(count).toBeGreaterThanOrEqual(10);
  });

  test('step editing should work - tap to toggle', async ({ page }) => {
    // Add a track first since sessions start empty
    await addTrack(page);

    const firstCell = page.locator('.track-row').first().locator('.step-cell').first();

    // Initially not active
    const wasActive = await firstCell.evaluate(el => el.classList.contains('active'));

    // Click to toggle
    await firstCell.click();

    // State should change
    const isActive = await firstCell.evaluate(el => el.classList.contains('active'));
    expect(isActive).not.toBe(wasActive);
  });
});

test.describe('Orientation Changes', () => {
  test('should transition smoothly from portrait to landscape', async ({ page }) => {
    // Start in portrait
    await page.setViewportSize(PORTRAIT_VIEWPORT);
    await page.goto('/');
    await waitForAppReady(page);

    // Verify portrait mode
    await expect(page.locator('.portrait-header')).toBeVisible();
    await expect(page.locator('[data-orientation="portrait"]')).toBeVisible();

    // Change to landscape
    await page.setViewportSize(LANDSCAPE_VIEWPORT);

    // Wait for transition (debounced at 100ms)
    await page.waitForTimeout(150);

    // Verify landscape mode
    await expect(page.locator('.portrait-header')).not.toBeVisible();
    await expect(page.locator('.transport')).toBeVisible();
    await expect(page.locator('[data-orientation="landscape"]')).toBeVisible();
  });

  test('should transition smoothly from landscape to portrait', async ({ page }) => {
    // Start in landscape
    await page.setViewportSize(LANDSCAPE_VIEWPORT);
    await page.goto('/');
    await waitForAppReady(page);

    // Verify landscape mode
    await expect(page.locator('.transport')).toBeVisible();

    // Change to portrait
    await page.setViewportSize(PORTRAIT_VIEWPORT);

    // Wait for transition
    await page.waitForTimeout(150);

    // Verify portrait mode
    await expect(page.locator('.portrait-header')).toBeVisible();
    await expect(page.locator('.portrait-grid')).toBeVisible();
  });

  test('should show desktop interface at 768px+ width', async ({ page }) => {
    await page.setViewportSize(DESKTOP_VIEWPORT);
    await page.goto('/');
    await waitForAppReady(page);

    // Full desktop UI visible
    await expect(page.locator('.transport')).toBeVisible();
    await expect(page.locator('.scale-selector')).toBeVisible();
    await expect(page.locator('.transport-control-group')).toBeVisible();

    // Portrait UI hidden
    await expect(page.locator('.portrait-header')).not.toBeVisible();
    await expect(page.locator('.portrait-grid')).not.toBeVisible();
  });

  test('round-trip: portrait → landscape → portrait should restore identical UI', async ({ page }) => {
    // Start in portrait
    await page.setViewportSize(PORTRAIT_VIEWPORT);
    await page.goto('/');
    await waitForAppReady(page);

    // Capture initial portrait state
    const initialPortraitHeader = await page.locator('.portrait-header').isVisible();
    const initialPortraitGrid = await page.locator('.portrait-grid').isVisible();
    const initialTransport = await page.locator('.transport').isVisible();
    const initialSequencerContent = await page.locator('.sequencer-content').isVisible();
    const initialOrientation = await page.locator('[data-orientation]').getAttribute('data-orientation');

    // Verify we're in portrait mode
    expect(initialPortraitHeader).toBe(true);
    expect(initialPortraitGrid).toBe(true);
    expect(initialTransport).toBe(false);
    expect(initialSequencerContent).toBe(false);
    expect(initialOrientation).toBe('portrait');

    // Rotate to landscape
    await page.setViewportSize(LANDSCAPE_VIEWPORT);
    await page.waitForTimeout(150); // Wait for debounced orientation change

    // Verify landscape mode
    await expect(page.locator('.portrait-header')).not.toBeVisible();
    await expect(page.locator('.portrait-grid')).not.toBeVisible();
    await expect(page.locator('.transport')).toBeVisible();
    await expect(page.locator('[data-orientation="landscape"]')).toBeVisible();

    // Rotate back to portrait
    await page.setViewportSize(PORTRAIT_VIEWPORT);
    // Wait for portrait UI to be visible (more reliable than fixed timeout)
    await page.locator('.portrait-header').waitFor({ state: 'visible', timeout: 5000 });
    await page.locator('[data-orientation="portrait"]').waitFor({ state: 'visible', timeout: 5000 });

    // Verify portrait state is restored identically
    const finalPortraitHeader = await page.locator('.portrait-header').isVisible();
    const finalPortraitGrid = await page.locator('.portrait-grid').isVisible();
    const finalTransport = await page.locator('.transport').isVisible();
    const finalSequencerContent = await page.locator('.sequencer-content').isVisible();
    const finalOrientation = await page.locator('[data-orientation]').getAttribute('data-orientation');

    expect(finalPortraitHeader).toBe(initialPortraitHeader);
    expect(finalPortraitGrid).toBe(initialPortraitGrid);
    expect(finalTransport).toBe(initialTransport);
    expect(finalSequencerContent).toBe(initialSequencerContent);
    expect(finalOrientation).toBe(initialOrientation);

    // Verify key UI elements are properly displayed
    await expect(page.locator('.portrait-header')).toBeVisible();
    await expect(page.locator('.portrait-app-name')).toContainText('Keyboardia');
    await expect(page.locator('.portrait-bpm')).toBeVisible();
    await expect(page.locator('.portrait-grid')).toBeVisible();
  });

  test('multiple rapid orientation changes should not break layout', async ({ page }) => {
    await page.setViewportSize(PORTRAIT_VIEWPORT);
    await page.goto('/');
    await waitForAppReady(page);

    // Rapid orientation changes (simulating user rotating device back and forth)
    for (let i = 0; i < 3; i++) {
      await page.setViewportSize(LANDSCAPE_VIEWPORT);
      await page.waitForTimeout(50); // Quick change
      await page.setViewportSize(PORTRAIT_VIEWPORT);
      await page.waitForTimeout(50);
    }

    // Wait for final debounce to settle
    await page.waitForTimeout(200);

    // Verify portrait mode is stable and correct
    await expect(page.locator('.portrait-header')).toBeVisible();
    await expect(page.locator('.portrait-grid')).toBeVisible();
    await expect(page.locator('[data-orientation="portrait"]')).toBeVisible();

    // Verify no broken elements or duplicates
    const headerCount = await page.locator('.portrait-header').count();
    const gridCount = await page.locator('.portrait-grid').count();
    expect(headerCount).toBe(1);
    expect(gridCount).toBe(1);
  });
});

test.describe('Modern Device Landscape Compatibility', () => {
  // These devices have landscape widths > 768px, which previously caused
  // CSS media queries to miss them while JS correctly detected landscape mode.
  // The fix uses data-orientation attribute selectors driven by JS, ensuring
  // a single source of truth for orientation detection.

  const modernDevices = [
    { name: 'iPhone 14', viewport: IPHONE_14_LANDSCAPE },
    { name: 'iPhone 15 Pro Max', viewport: IPHONE_15_PRO_MAX_LANDSCAPE },
    { name: 'Samsung Galaxy S24', viewport: GALAXY_S24_LANDSCAPE },
  ];

  for (const device of modernDevices) {
    test(`${device.name} landscape should show landscape UI, not desktop`, async ({ page }) => {
      await page.setViewportSize(device.viewport);
      await page.goto('/');
      await waitForAppReady(page);

      // JS should detect landscape mode via data-orientation attribute
      await expect(page.locator('[data-orientation="landscape"]')).toBeVisible();

      // Transport should be visible (landscape editing mode)
      await expect(page.locator('.transport')).toBeVisible();

      // Portrait UI should be hidden
      await expect(page.locator('.portrait-header')).not.toBeVisible();
      await expect(page.locator('.portrait-grid')).not.toBeVisible();

      // Complex transport elements should be hidden (landscape simplification)
      await expect(page.locator('.scale-selector')).not.toBeVisible();
      await expect(page.locator('.transport-control-group')).not.toBeVisible();
    });

    test(`${device.name} landscape should show compact track layout`, async ({ page }) => {
      await page.setViewportSize(device.viewport);
      await page.goto('/');
      await waitForAppReady(page);

      // Add a track
      await addTrack(page);

      const trackRow = page.locator('.track-row').first();
      await expect(trackRow).toBeVisible();

      // M/S buttons should be visible (landscape compact layout)
      await expect(trackRow.locator('.mute-button')).toBeVisible();
      await expect(trackRow.locator('.solo-button')).toBeVisible();

      // Track name should be visible
      await expect(trackRow.locator('.track-name')).toBeVisible();

      // Step grid should show many cells (not old mobile 5-6)
      const stepCount = await trackRow.locator('.step-cell').count();
      expect(stepCount).toBeGreaterThanOrEqual(10);
    });
  }
});

test.describe('Accessibility', () => {
  test('portrait header should have proper ARIA labels', async ({ page }) => {
    await page.setViewportSize(PORTRAIT_VIEWPORT);
    await page.goto('/');
    await waitForAppReady(page);

    const header = page.locator('.portrait-header');
    await expect(header).toHaveAttribute('role', 'banner');

    const playBtn = header.locator('.portrait-play-btn');
    await expect(playBtn).toHaveAttribute('aria-label', /Play|Stop/);

    const bpm = header.locator('.portrait-bpm');
    await expect(bpm).toHaveAttribute('aria-label', /Tempo/);
  });

  test('portrait grid exposes accessible playback and 44px page controls @blocking', async ({ page }) => {
    await page.setViewportSize(PORTRAIT_VIEWPORT);
    await page.goto('/');
    await waitForAppReady(page);

    const grid = page.locator('.portrait-grid');
    await expect(grid).not.toHaveAttribute('role', 'button');
    await expect(grid).not.toHaveAttribute('tabindex', '0');

    const pageDots = page.locator('.portrait-page-dot');
    await expect(pageDots).toHaveCount(2);
    for (let index = 0; index < 2; index += 1) {
      const box = await pageDots.nth(index).boundingBox();
      expect(box?.width).toBeGreaterThanOrEqual(44);
      expect(box?.height).toBeGreaterThanOrEqual(44);
    }
    await expect(pageDots.first()).toHaveAttribute('aria-pressed', 'true');
    await expect(pageDots.last()).toHaveAttribute('aria-pressed', 'false');

    // The tap-to-play affordance is a full-bleed accessible button layered
    // above presentational content. Page controls remain independently usable.
    await pageDots.last().click();
    await expect(pageDots.last()).toHaveAttribute('aria-pressed', 'true');
    await expect(pageDots.first()).toHaveAttribute('aria-pressed', 'false');

    const tapLayer = page.locator('.portrait-grid-tap-layer');
    await expect(tapLayer).toHaveAttribute('aria-label', 'Play');
    await expect(tapLayer).not.toHaveAttribute('aria-hidden', 'true');
    await expect(tapLayer).not.toHaveAttribute('tabindex', '-1');
    await expect(page.getByRole('button', { name: /^(Play|Stop)$/ })).toHaveCount(2);

    const dismissHint = page.getByRole('button', { name: 'Dismiss orientation hint' });
    await expect(dismissHint).toBeVisible();
    const dismissBox = await dismissHint.boundingBox();
    expect(dismissBox?.width).toBeGreaterThanOrEqual(44);
    expect(dismissBox?.height).toBeGreaterThanOrEqual(44);
  });

  test('collapsed track panels are inert during sequential keyboard navigation @blocking', async ({ page, request }) => {
    await page.setViewportSize(DESKTOP_VIEWPORT);
    const { id } = await createPopulatedSessionWithRetry(request);
    await page.goto(`/s/${id}`);
    await waitForAppReady(page);
    await expect(page.locator('.track-row')).toHaveCount(10);

    const collapsedPanels = page.locator('.panel-animation-container:not(.expanded)');
    expect(await collapsedPanels.count()).toBeGreaterThan(0);
    for (let index = 0; index < await collapsedPanels.count(); index += 1) {
      await expect(collapsedPanels.nth(index)).toHaveAttribute('aria-hidden', 'true');
      await expect(collapsedPanels.nth(index)).toHaveAttribute('inert', '');
    }

    for (let index = 0; index < 60; index += 1) {
      await page.keyboard.press('Tab');
      expect(await page.evaluate(() => document.activeElement?.closest('[inert]') === null)).toBe(true);
    }
  });

  test('should respect prefers-reduced-motion @blocking', async ({ page }) => {
    await page.emulateMedia({ reducedMotion: 'reduce' });
    await page.setViewportSize(PORTRAIT_VIEWPORT);
    await page.goto('/');
    await waitForAppReady(page);

    // Check that animations are disabled via CSS
    // Note: This test verifies the CSS media query is respected
    const hint = page.locator('.orientation-hint').first();
    const animation = await hint.evaluate(el =>
      window.getComputedStyle(el).animationName
    );
    expect(animation).toBe('none');
  });
});

test.describe('Performance', () => {
  test('playback should maintain smooth animation', async ({ page, request, browserName }) => {
    test.skip(browserName === 'webkit', 'Real audio playback is owned by Chromium; headless WebKit can wedge on AudioContext.resume()');
    await page.setViewportSize(PORTRAIT_VIEWPORT);
    const { id } = await createPopulatedSessionWithRetry(request);
    await page.goto(`/s/${id}`);
    await waitForAppReady(page);
    await expect(page.locator('.portrait-track-row')).toHaveCount(10);

    await page.locator('.portrait-grid-tap-layer').click();

    const playingCell = page.locator('.portrait-step-cell.playing').first();
    await expect(playingCell).toBeVisible();
    const hasGPUHint = await playingCell.evaluate(el =>
      window.getComputedStyle(el).willChange !== 'auto'
    );
    expect(hasGPUHint).toBe(true);

    await page.locator('.portrait-grid-tap-layer').click();
    await expect(page.locator('.portrait-play-btn')).not.toHaveClass(/playing/);
  });
});
