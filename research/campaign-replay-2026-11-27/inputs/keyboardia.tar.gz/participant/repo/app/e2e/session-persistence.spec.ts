import { test, expect, waitForAppReady, getBaseUrl, useMockAPI } from './global-setup';
import { createSessionWithRetry } from './test-utils';

const API_BASE = getBaseUrl();

/**
 * Session persistence tests - Phase 6 Observability
 *
 * These tests verify that sessions created via API are correctly
 * loaded and displayed in the browser without data loss.
 * Uses Playwright best practices with proper waits.
 *
 * Note: Debug/observability endpoints require real backend.
 */

// Skip debug endpoint tests when using mock API
test.describe('Session persistence integrity', () => {
  test('session created via API should load with correct tracks', async ({ page, request }) => {
    test.skip(useMockAPI, 'Test uses debug endpoints which require real backend');
    // Step 1: Create a session via API with known data
    const testTracks = [
      {
        id: 'test-track-1',
        name: 'Kick',
        sampleId: 'kick',
        steps: [true, false, false, false, true, false, false, false, true, false, false, false, true, false, false, false, ...Array(112).fill(false)],
        parameterLocks: Array(128).fill(null),
        volume: 1,
        muted: false,
        transpose: 0,
        stepCount: 16,
      },
      {
        id: 'test-track-2',
        name: 'Snare',
        sampleId: 'snare',
        steps: [false, false, false, false, true, false, false, false, false, false, false, false, true, false, false, false, ...Array(112).fill(false)],
        parameterLocks: Array(128).fill(null),
        volume: 0.8,
        muted: false,
        transpose: 0,
        stepCount: 16,
      },
    ];

    console.log('[TEST] Creating session with', testTracks.length, 'tracks');

    const { id } = await createSessionWithRetry(request, {
      tracks: testTracks,
      tempo: 108,
      swing: 15,
      version: 1,
    });
    console.log('[TEST] Created session:', id);

    // Step 2: Immediately verify via debug endpoint
    const debugRes = await request.get(`${API_BASE}/api/debug/session/${id}`);
    expect(debugRes.ok()).toBe(true);
    const debugInfo = await debugRes.json();
    console.log('[TEST] Debug info after create:', JSON.stringify(debugInfo, null, 2));

    expect(debugInfo.exists).toBe(true);
    expect(debugInfo.state.trackCount).toBe(2);
    expect(debugInfo.state.tempo).toBe(108);

    // Step 3: Load the session in the browser
    console.log('[TEST] Loading session in browser:', `${API_BASE}/s/${id}`);
    await page.goto(`${API_BASE}/s/${id}`);

    // Wait for tracks to render using proper waits
    await waitForAppReady(page);

    // Step 4: Check what the browser rendered
    const trackRows = page.locator('.track-row');
    const trackCount = await trackRows.count();
    console.log('[TEST] Browser rendered track count:', trackCount);

    // Step 5: Check debug endpoint again to see if session was overwritten
    const debugRes2 = await request.get(`${API_BASE}/api/debug/session/${id}`);
    const debugInfo2 = await debugRes2.json();
    console.log('[TEST] Debug info after browser load:', JSON.stringify(debugInfo2, null, 2));

    // The critical assertion: tracks should still exist
    expect(debugInfo2.state.trackCount).toBe(2);
    expect(trackCount).toBe(2);
  });

  test('debug endpoint returns correct session info', async ({ request }) => {
    test.skip(useMockAPI, 'Debug endpoints require real backend');
    // Create a simple session
    const { id } = await createSessionWithRetry(request, {
      tracks: [
        {
          id: 'debug-track',
          name: 'Test',
          sampleId: 'kick',
          steps: Array(128).fill(false),
          parameterLocks: Array(128).fill(null),
          volume: 1,
          muted: false,
          transpose: 0,
          stepCount: 16,
        },
      ],
      tempo: 120,
      swing: 0,
      version: 1,
    });

    // Use debug endpoint
    const debugRes = await request.get(`${API_BASE}/api/debug/session/${id}`);
    expect(debugRes.ok()).toBe(true);

    const debug = await debugRes.json();
    expect(debug.exists).toBe(true);
    expect(debug.state.trackCount).toBe(1);
    expect(debug.state.tracks[0].name).toBe('Test');
    expect(debug.sizeBytes).toBeGreaterThan(0);
  });

  test('non-existent session returns 404 with debug info', async ({ request }) => {
    test.skip(useMockAPI, 'Debug endpoints require real backend');
    const fakeId = '00000000-0000-0000-0000-000000000000';
    const res = await request.get(`${API_BASE}/api/debug/session/${fakeId}`);

    expect(res.status()).toBe(404);
    const debug = await res.json();
    expect(debug.exists).toBe(false);
    expect(debug.error).toBe('Session not found');
  });
});

test.describe('Observability endpoints', () => {
  // Skip all observability tests when using mock API - these require real backend
  test.skip(useMockAPI, 'Observability endpoints require real backend');

  // NOTE: /api/metrics endpoint was removed. Metrics are now derived from
  // Workers Logs wide events (Observability 2.0). See: specs/OBSERVABILITY-2-0-IMPLEMENTATION.md

  test('debug logs endpoint returns logs array', async ({ request }) => {
    // First, make some API calls to generate logs
    await createSessionWithRetry(request, { tracks: [], tempo: 120, swing: 0, version: 1 });

    // Then check logs
    const res = await request.get(`${API_BASE}/api/debug/logs?last=10`);
    expect(res.ok()).toBe(true);

    const data = await res.json();
    expect(data).toHaveProperty('logs');
    expect(Array.isArray(data.logs)).toBe(true);

    // Should have at least one log from our create call
    if (data.logs.length > 0) {
      const log = data.logs[0];
      expect(log).toHaveProperty('timestamp');
      expect(log).toHaveProperty('requestId');
      expect(log).toHaveProperty('method');
      expect(log).toHaveProperty('path');
      expect(log).toHaveProperty('status');
    }

    console.log('[TEST] Recent logs:', JSON.stringify(data.logs.slice(-3), null, 2));
  });

  test('debug logs can filter by session ID', async ({ request }) => {
    // Create a session
    const { id } = await createSessionWithRetry(request, {
      tracks: [],
      tempo: 120,
      swing: 0,
      version: 1,
    });

    // Load it to generate a read log
    await request.get(`${API_BASE}/api/sessions/${id}`);

    // Update it to generate an update log
    await request.put(`${API_BASE}/api/sessions/${id}`, {
      data: {
        state: { tracks: [], tempo: 130, swing: 10, version: 1 },
      },
    });

    // Get logs filtered by session ID
    const res = await request.get(`${API_BASE}/api/debug/logs?sessionId=${id}&last=10`);
    expect(res.ok()).toBe(true);

    const data = await res.json();
    expect(data).toHaveProperty('logs');

    // All logs should be for our session
    for (const log of data.logs) {
      if (log.sessionId) {
        expect(log.sessionId).toBe(id);
      }
    }

    console.log(`[TEST] Logs for session ${id}:`, data.logs.length, 'entries');
  });
});

test.describe('Debug mode UI', () => {
  test('debug overlay appears with ?debug=1', async ({ page, request }) => {
    // Skip in mock mode - debug overlay requires the full app
    test.skip(useMockAPI, 'Debug overlay only appears in sequencer view, not landing page');

    // Create a session first - debug overlay only appears in sequencer view
    const { id } = await createSessionWithRetry(request, {
      tracks: [],
      tempo: 120,
      swing: 0,
      version: 1,
    });

    // Navigate to the session with debug mode enabled
    await page.goto(`${API_BASE}/s/${id}?debug=1`);
    await page.waitForLoadState('networkidle');

    // Look for debug toggle button
    const debugToggle = page.locator('.debug-toggle');
    await expect(debugToggle).toBeVisible({ timeout: 5000 });

    // Click to expand
    await debugToggle.click();

    // Check for debug content
    const debugContent = page.locator('.debug-content');
    await expect(debugContent).toBeVisible();

    // Should show session info
    const sessionSection = page.locator('.debug-section h4:has-text("Session")');
    await expect(sessionSection).toBeVisible();
  });

  test('debug overlay is hidden without ?debug=1', async ({ page }) => {
    await page.goto(API_BASE);
    await page.waitForLoadState('networkidle');

    // Debug overlay should not exist
    const debugToggle = page.locator('.debug-toggle');
    await expect(debugToggle).not.toBeVisible();
  });
});

test.describe('Session state transitions', () => {
  // Skip in mock mode - uses debug endpoints
  test.skip(useMockAPI, 'State transition tests require real backend debug endpoints');

  test('create -> load -> update cycle maintains data integrity', async ({ page, request }) => {
    // Step 1: Create a session with initial data
    const initialTracks = [
      {
        id: 'integrity-test-1',
        name: 'Bass',
        sampleId: 'bass',
        steps: [true, false, false, false, false, false, false, false, true, false, false, false, false, false, false, false, ...Array(112).fill(false)],
        parameterLocks: Array(128).fill(null),
        volume: 0.9,
        muted: false,
        transpose: 0,
        stepCount: 16,
      },
    ];

    const { id } = await createSessionWithRetry(request, {
      tracks: initialTracks,
      tempo: 100,
      swing: 25,
      version: 1,
    });
    console.log('[TEST] Created session:', id);

    // Step 2: Verify via debug endpoint
    const debugRes1 = await request.get(`${API_BASE}/api/debug/session/${id}`);
    const debug1 = await debugRes1.json();
    expect(debug1.state.trackCount).toBe(1);
    expect(debug1.state.tempo).toBe(100);
    expect(debug1.state.swing).toBe(25);

    // Step 3: Load in browser
    await page.goto(`${API_BASE}/s/${id}`);
    await waitForAppReady(page);

    // Step 4: Verify tracks loaded
    const trackRows = page.locator('.track-row');
    const loadedTrackCount = await trackRows.count();
    expect(loadedTrackCount).toBe(1);

    // Step 5: Check debug endpoint again - data should still be there
    const debugRes2 = await request.get(`${API_BASE}/api/debug/session/${id}`);
    const debug2 = await debugRes2.json();
    expect(debug2.state.trackCount).toBe(1);
    expect(debug2.state.tempo).toBe(100);

    console.log('[TEST] Session integrity verified across create/load cycle');
  });
});
