import { useCallback, useState, useRef, useEffect, lazy, Suspense } from 'react'
import { GridProvider, useGrid } from './state/grid'
// Phase 34: Lazy load StepSequencer - heaviest component, enables chunk splitting
const StepSequencer = lazy(() => import('./components/StepSequencer').then(m => ({ default: m.StepSequencer })))
// Phase 34: Lazy load SamplePicker - not needed until session is loaded
const SamplePicker = lazy(() => import('./components/SamplePicker').then(m => ({ default: m.SamplePicker })))
import { Recorder } from './components/Recorder'
// Phase 34: Lazy load EffectsPanel - mobile-only, not critical for initial load
const EffectsPanel = lazy(() => import('./components/EffectsPanel').then(m => ({ default: m.EffectsPanel })))
import { LandingPage } from './components/LandingPage'
import { RemixButton } from './components/RemixButton'
import type { ExampleRemixTarget } from './data/example-sessions'
import type { EffectsState } from './types'
import { Close, CopyLink, Qr } from './icons'
import { AvatarStack } from './components/AvatarStack'
import { ToastNotification, type Toast } from './components/ToastNotification'
import { ConnectionStatus } from './components/ConnectionStatus'
import { SessionName } from './components/SessionName'
import { ErrorBoundary } from './components/ErrorBoundary'
import { FeatureErrorBoundary } from './components/FeatureErrorBoundary'
import { SamplePickerSkeleton, EffectsPanelSkeleton, StepSequencerSkeleton } from './components/SuspenseSkeletons'
// Phase 34: Lazy load QROverlay - only needed when user activates QR mode
const QROverlay = lazy(() => import('./components/QROverlay').then(m => ({ default: m.QROverlay })))
import { useSession } from './hooks/useSession'
import { useMultiplayer, useMultiplayerDispatch, useMultiplayerSync } from './hooks/useMultiplayer'
import { useQRMode } from './hooks/useQRMode'
import { useDisplayMode, useOrientationMode } from './hooks/useDisplayMode'
import { DebugProvider } from './debug/DebugContext'
import { DebugOverlay } from './debug/DebugOverlay'
// Audio debugging - dynamically loaded, exposes window.audioDebug for console debugging
if (import.meta.env.DEV) {
  import('./debug/audio-debug');
}
import { MultiplayerContext, useMultiplayerContext, type MultiplayerContextValue } from './context/MultiplayerContext'
import { RemoteChangeProvider, useRemoteChanges } from './context/RemoteChangeContext'
import type { PlayerInfo } from './sync/multiplayer'
import { MAX_TRACKS } from './types'
import type { LoadedSessionState } from './types'
import { logger } from './utils/logger'
import { copyToClipboard } from './utils/clipboard'
import { AsyncActionLatch } from './utils/AsyncActionLatch'
import { createSession, remixSession, updateUrlWithSession } from './sync/session'
import './App.css'

// Feature flags - recording is hidden (Shared Sample Recording archived)
// Enable with ?recording=1 in URL for testing
const ENABLE_RECORDING = new URLSearchParams(window.location.search).get('recording') === '1';

interface SessionControlsProps {
  children: React.ReactNode;
  focusHeadingOnMount?: boolean;
}

export function SessionControls({ children, focusHeadingOnMount = false }: SessionControlsProps) {
  const { state, dispatch } = useGrid();
  const [copied, setCopied] = useState(false);
  const [activeSessionAction, setActiveSessionAction] = useState<'share' | 'publish' | 'remix' | 'new' | null>(null);
  const sessionActionLatchRef = useRef(new AsyncActionLatch());
  const [orphanDismissed, setOrphanDismissed] = useState(false);
  const [toasts, setToasts] = useState<Toast[]>([]);
  const [shareDropdownOpen, setShareDropdownOpen] = useState(false);
  const headingRef = useRef<HTMLHeadingElement>(null);

  // Give keyboard and assistive-technology users a stable destination after
  // the landing page is replaced by a newly created or remixed session.
  useEffect(() => {
    if (focusHeadingOnMount) headingRef.current?.focus();
  }, [focusHeadingOnMount]);

  // QR Mode
  const { isActive: qrModeActive, targetURL: qrTargetURL, activate: activateQR, deactivate: deactivateQR } = useQRMode();
  const displayMode = useDisplayMode();

  // Auto-reset copied state after 2 seconds (prevents memory leak from setTimeout in callback)
  useEffect(() => {
    if (!copied) return;
    const timer = setTimeout(() => setCopied(false), 2000);
    return () => clearTimeout(timer);
  }, [copied]);

  // BUG4-FIX: Listen for custom toast events from anywhere in the app
  useEffect(() => {
    const handleToastEvent = (e: CustomEvent<{ message: string; type: Toast['type'] }>) => {
      const { message, type } = e.detail;
      const toast: Toast = {
        id: `${type}-${Date.now()}`,
        message,
        type,
      };
      setToasts(prev => [...prev, toast]);
    };
    window.addEventListener('show-toast', handleToastEvent as EventListener);
    return () => {
      window.removeEventListener('show-toast', handleToastEvent as EventListener);
    };
  }, []);

  const loadState = useCallback((loaded: LoadedSessionState) => {
    dispatch({ type: 'LOAD_STATE', ...loaded });
  }, [dispatch]);

  const resetState = useCallback(() => {
    dispatch({ type: 'RESET_STATE' });
  }, [dispatch]);

  const {
    status,
    sessionId,
    sessionName,
    renameSession,
    share,
    publish,
    remix,
    createNew,
    remixedFrom,
    remixedFromName,
    remixCount,
    isOrphaned,
    isPublished,
    setIsPublished,
  } = useSession(state, loadState, resetState);
  const previousSessionIdRef = useRef(sessionId);

  useEffect(() => {
    if (previousSessionIdRef.current === sessionId) return;
    previousSessionIdRef.current = sessionId;
    sessionActionLatchRef.current.cancel();
    // Keep controls disabled until the obsolete request actually settles. The
    // latch still owns that request and must not expose enabled no-op buttons.
    setShareDropdownOpen(false);
    setCopied(false);
    setToasts(current => current.filter(toast => toast.type !== 'url'));
    if (qrModeActive) deactivateQR();
  }, [deactivateQR, qrModeActive, sessionId]);

  useEffect(() => () => sessionActionLatchRef.current.cancel(), []);

  // Phase 11: Remote change attribution
  const remoteChanges = useRemoteChanges();

  // Phase 11: Player join/leave notification handler
  const handlePlayerEvent = useCallback((player: PlayerInfo, event: 'join' | 'leave') => {
    const toast: Toast = {
      id: `${player.id}-${event}-${Date.now()}`,
      message: `${player.name} ${event === 'join' ? 'joined' : 'left'}`,
      color: player.color,
      type: event,
    };
    setToasts(prev => [...prev, toast]);
  }, []);

  // Dismiss toast handler
  const handleDismissToast = useCallback((id: string) => {
    setToasts(prev => prev.filter(t => t.id !== id));
  }, []);

  // Show URL fallback toast when clipboard copy fails
  const showUrlFallbackToast = useCallback((url: string, message: string) => {
    const toast: Toast = {
      id: `url-${Date.now()}`,
      message,
      type: 'url',
      url,
    };
    setToasts(prev => [...prev, toast]);
  }, []);

  // Phase 12 Polish: State getter for hash verification.
  // Keep the whole grid state in the ref and let canonicalizeForHash select the
  // shared fields. A hand-written projection can silently omit a newly synced
  // field, which would make divergence in that field invisible to hash checks.
  //
  // IMPORTANT: Uses ref pattern to maintain stable callback reference.
  // Without this, the callback changes on every state update, causing the useMultiplayer
  // useEffect to re-run and disconnect/reconnect the WebSocket (connection storm bug).
  const stateForHashRef = useRef(state);
  stateForHashRef.current = state;

  const getStateForHash = useCallback(() => stateForHashRef.current, []);

  // Multiplayer connection
  const {
    isConnected,
    supportsEnvelopeV2 = true,
    players,
    playerId,
    playerCount,
    status: connectionStatus,
    reconnectAttempts,
    queueSize,
    cursors,
    sendCursor,
    retryConnection,
    playingPlayerIds,
  } = useMultiplayer(sessionId, dispatch, status === 'ready', remoteChanges?.recordChange, handlePlayerEvent, getStateForHash, setIsPublished);

  // Wrap dispatch to send actions over WebSocket
  const multiplayerDispatch = useMultiplayerDispatch(dispatch, isConnected);

  // Mute/solo/track sync handlers
  const {
    handleMuteChange,
    handleSoloChange,
    handleTrackAdded,
    handleBatchClearSteps,
    handleBatchSetParameterLocks,
    handleTrackReorder,
  } = useMultiplayerSync(isConnected);

  // Multiplayer context value
  // Phase 34: Map session status to context for skeleton screens
  const sessionStatus = status === 'loading' ? 'loading'
    : status === 'ready' ? 'ready'
    : status === 'not_found' ? 'not_found'
    : 'error';

  const multiplayerContextValue: MultiplayerContextValue = {
    isConnected,
    supportsEnvelopeV2,
    playerCount,
    dispatch: multiplayerDispatch,
    handleMuteChange,
    handleSoloChange,
    handleTrackAdded,
    handleBatchClearSteps,
    handleBatchSetParameterLocks,
    handleTrackReorder,
    // Phase 11: Cursors
    cursors,
    sendCursor,
    // Phase 21: Published sessions are read-only
    isPublished,
    // Phase 22: Per-player playback tracking
    playingPlayerIds,
    // Phase 34: Session loading status for skeleton screens
    sessionStatus,
    // Session info for portrait mode display
    sessionId,
    sessionName,
  };

  const runSessionAction = useCallback(async (
    kind: 'share' | 'publish' | 'remix' | 'new',
    action: (isCurrent: () => boolean) => Promise<void>,
  ): Promise<boolean> => sessionActionLatchRef.current.run(async isCurrent => {
    setActiveSessionAction(kind);
    try {
      await action(isCurrent);
    } finally {
      // A canceled action still owns the latch until its promise settles.
      // Release the visible disabled state at that same boundary.
      setActiveSessionAction(null);
    }
  }), []);

  const handleShare = useCallback(async () => {
    await runSessionAction('share', async isCurrent => {
      try {
        const url = await share();
        if (!isCurrent()) return;
        const success = await copyToClipboard(url);
        if (!isCurrent()) return;
        if (success) {
          setCopied(true);
        } else {
          showUrlFallbackToast(url, 'Could not copy automatically');
        }
      } catch (error) {
        logger.error('Failed to share:', error);
      }
    });
  }, [runSessionAction, share, showUrlFallbackToast]);

  const handleShowQR = useCallback(async () => {
    await runSessionAction('share', async isCurrent => {
      try {
        await share();
        if (isCurrent()) activateQR();
      } catch (error) {
        logger.error('Failed to prepare QR sharing:', error);
      }
    });
  }, [activateQR, runSessionAction, share]);

  // Phase 21: Publish session handler
  const handlePublish = useCallback(async () => {
    await runSessionAction('publish', async isCurrent => {
      try {
        const url = await publish();
        if (!isCurrent()) return;
        const success = await copyToClipboard(url);
        if (!isCurrent()) return;
        if (success) {
          const toast: Toast = {
            id: `publish-${Date.now()}`,
            message: 'Session published! Link copied.',
            type: 'join',
          };
          setToasts(prev => [...prev, toast]);
        } else {
          showUrlFallbackToast(url, 'Published! Copy link:');
        }
      } catch (error) {
        logger.error('Failed to publish:', error);
      }
    });
  }, [publish, runSessionAction, showUrlFallbackToast]);

  const handleRemix = useCallback(async () => {
    await runSessionAction('remix', async () => {
      try {
        await remix();
      } catch (error) {
        logger.error('Failed to remix:', error);
      }
    });
  }, [remix, runSessionAction]);

  const handleNew = useCallback(async () => {
    await runSessionAction('new', createNew);
  }, [createNew, runSessionAction]);

  const handleDownloadMidi = useCallback(async () => {
    try {
      const { downloadMidi } = await import('./audio/midiExport');
      await downloadMidi(state, sessionName);
    } catch (error) {
      logger.error('Failed to export MIDI:', error);
    }
  }, [sessionName, state]);

  // Session controls UI component
  const sessionControlsUI = (
    <>
      {status === 'loading' && (
        <div className="session-controls session-loading">Loading...</div>
      )}

      {status === 'not_found' && (
        <div className="session-controls session-not-found">
          <span className="not-found-text">Session not found</span>
          <button
            className="session-btn new-btn"
            onClick={handleNew}
            title="Create a new session"
          >
            Create New
          </button>
        </div>
      )}

      {status === 'error' && (
        <div className="session-controls session-error">Session error</div>
      )}

      {status === 'ready' && (
        <div className="session-controls">
            {/* Phase 34: Multiplayer error boundary - isolates connection/presence issues */}
            <FeatureErrorBoundary feature="multiplayer">
              {/* Phase 12: Connection status indicator */}
              <ConnectionStatus
                status={connectionStatus}
                reconnectAttempts={reconnectAttempts}
                queueSize={queueSize}
                onRetry={retryConnection}
              />
              {/* Multiplayer avatars */}
              {playerCount > 0 && (
                <AvatarStack
                  players={players}
                  currentPlayerId={playerId}
                  maxVisible={5}
                  playingPlayerIds={playingPlayerIds}
                />
              )}
            </FeatureErrorBoundary>
            {/* Published badge */}
            {isPublished && (
              <span className="published-badge" title="This session is published and read-only">
                Published
              </span>
            )}
            {/* Remix lineage - text only, no links (spec lines 472-479) */}
            {remixedFrom && (
              <span className="remix-lineage">
                <span className="lineage-arrow">↳</span>
                <span className="lineage-text">
                  Remixed from {remixedFromName || 'another session'}
                </span>
                {remixCount > 0 && (
                  <span className="remix-count" title={`${remixCount} remix${remixCount > 1 ? 'es' : ''}`}>
                    • {remixCount} remix{remixCount > 1 ? 'es' : ''}
                  </span>
                )}
              </span>
            )}
            {/* Show remix count even if not a remix */}
            {!remixedFrom && remixCount > 0 && (
              <span className="remix-count-standalone" title={`${remixCount} remix${remixCount > 1 ? 'es' : ''}`}>
                {remixCount} remix{remixCount > 1 ? 'es' : ''}
              </span>
            )}
            {/* Phase 21: Button order - [Publish] [Remix] [New] ··· [Invite ▾] */}
            {!isPublished && (
              <button
                className="session-btn publish-btn"
                onClick={handlePublish}
                disabled={activeSessionAction !== null}
                title="Publish this session — freeze it forever for sharing"
              >
                {activeSessionAction === 'publish' ? 'Publishing...' : 'Publish'}
              </button>
            )}
            <RemixButton
              onClick={handleRemix}
              disabled={activeSessionAction !== null}
              isRemixing={activeSessionAction === 'remix'}
              primary={isPublished}
              title={isPublished ? 'Create your own editable copy' : 'Create a copy for yourself'}
            />
            <button
              className="session-btn new-btn"
              onClick={handleNew}
              disabled={activeSessionAction !== null}
              title="Start fresh"
            >
              {activeSessionAction === 'new' ? 'Starting...' : 'New'}
            </button>
            <button
              className="session-btn download-btn"
              onClick={handleDownloadMidi}
              title="Export session as MIDI file"
            >
              Export MIDI
            </button>
            {/* Phase 21: No Invite button on published sessions (spec line 298) */}
            {!isPublished && (
              <div className="share-dropdown-container">
                <button
                  className="session-btn invite-btn"
                  onClick={() => setShareDropdownOpen(!shareDropdownOpen)}
                  disabled={activeSessionAction !== null}
                  title="Invite others to collaborate"
                  aria-expanded={shareDropdownOpen}
                  aria-haspopup="true"
                >
                  {copied ? 'Copied!' : 'Invite'} ▾
                </button>
                {shareDropdownOpen && (
                  <div className="share-dropdown">
                    <button
                      className="share-dropdown-item"
                      onClick={() => {
                        handleShare();
                        setShareDropdownOpen(false);
                      }}
                    >
                      <CopyLink size={14} aria-hidden="true" /> Copy Link
                    </button>
                    <button
                      className="share-dropdown-item"
                      onClick={() => {
                        void handleShowQR();
                        setShareDropdownOpen(false);
                      }}
                    >
                      <Qr size={14} aria-hidden="true" /> Show QR Code
                    </button>
                  </div>
                )}
              </div>
            )}
          </div>
      )}
    </>
  );

  // Close dropdown when clicking outside
  useEffect(() => {
    if (!shareDropdownOpen) return;

    const handleClickOutside = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      if (!target.closest('.share-dropdown-container')) {
        setShareDropdownOpen(false);
      }
    };

    document.addEventListener('click', handleClickOutside);
    return () => document.removeEventListener('click', handleClickOutside);
  }, [shareDropdownOpen]);

  // CSS class for QR large mode layout adjustment
  const appClassName = `app${qrModeActive && displayMode === 'large' ? ' qr-mode-large' : ''}`;

  return (
    <MultiplayerContext.Provider value={multiplayerContextValue}>
      <div className={appClassName}>
        <header className="app-header">
          {/* Orphan banner above header */}
          {status === 'ready' && isOrphaned && !orphanDismissed && (
            <div className="orphan-banner">
              <span>This session hasn't been used in over 90 days. It's still here! Editing will mark it as active again.</span>
              <button
                className="orphan-dismiss"
                onClick={() => setOrphanDismissed(true)}
                title="Dismiss inactive session notice"
                aria-label="Dismiss inactive session notice"
              >
                <Close size={14} aria-hidden="true" />
              </button>
            </div>
          )}
          <div className="header-top">
            <div className="header-title-group">
              <h1
                ref={headingRef}
                tabIndex={focusHeadingOnMount ? -1 : undefined}
              >
                Keyboardia
              </h1>
              {status === 'ready' && (
                <>
                  <span className="title-separator">/</span>
                  <SessionName
                    name={sessionName}
                    sessionId={sessionId ?? undefined}
                    onRename={renameSession}
                    disabled={isPublished}
                  />
                </>
              )}
            </div>
            {sessionControlsUI}
          </div>
          <p className={`subtitle${isPublished ? ' published' : ''}`}>
            {isPublished
              ? 'Published • Press play to listen, then remix to make it yours'
              : 'Add an instrument, toggle cells and press play.'}
          </p>
        </header>
        {children}
        {/* Phase 11: Player join/leave notifications */}
        <ToastNotification toasts={toasts} onDismiss={handleDismissToast} />

        {/* QR Code Overlay - Phase 34: Lazy loaded with Suspense */}
        {qrModeActive && status === 'ready' && (
          <Suspense fallback={<div className="qr-loading">Loading QR...</div>}>
            <QROverlay
              targetURL={qrTargetURL}
              sessionName={sessionName}
              playerCount={playerCount}
              onClose={deactivateQR}
            />
          </Suspense>
        )}

        {/* Cloudflare footer */}
        <footer className="cloudflare-footer">
          Built on <a href="https://developers.cloudflare.com/" target="_blank" rel="noopener noreferrer">the Cloudflare Developer Platform</a>
        </footer>
      </div>
    </MultiplayerContext.Provider>
  );
}

function MainContent() {
  const { state, dispatch } = useGrid();
  const multiplayer = useMultiplayerContext();
  const orientationMode = useOrientationMode();
  const isPortraitMode = orientationMode === 'portrait';
  const canAddTrack = state.tracks.length < MAX_TRACKS;
  const isPublished = multiplayer?.isPublished ?? false;

  // Track IDs we've already sent to the server to avoid duplicates
  const sentTrackIdsRef = useRef<Set<string>>(new Set());

  // Track whether we've seen the first "connected" state
  // This is used to avoid sending tracks from the initial snapshot back to the server
  const wasConnectedRef = useRef(false);

  // When tracks change, send any new ones to the server
  // This handles the case where we added a track locally
  useEffect(() => {
    if (!multiplayer?.isConnected) {
      // Reset when disconnected so we properly handle reconnection
      wasConnectedRef.current = false;
      return;
    }

    // On first connect, mark all existing tracks as "already sent"
    // These came from the initial snapshot and should NOT be sent back
    if (!wasConnectedRef.current) {
      wasConnectedRef.current = true;
      for (const track of state.tracks) {
        sentTrackIdsRef.current.add(track.id);
      }
      return; // Don't send anything on initial connect
    }

    // After initial connect, only send truly new tracks
    for (const track of state.tracks) {
      if (!sentTrackIdsRef.current.has(track.id)) {
        sentTrackIdsRef.current.add(track.id);
        // Send the new track to the server
        multiplayer.handleTrackAdded(track);
      }
    }
  }, [state.tracks, multiplayer]);

  const handleAddTrack = useCallback((sampleId: string, name: string) => {
    // Use multiplayer dispatch if connected, otherwise regular dispatch
    const dispatchFn = multiplayer?.dispatch ?? dispatch;
    dispatchFn({ type: 'ADD_TRACK', sampleId, name });
  }, [multiplayer, dispatch]);

  // Handle effects changes
  const handleEffectsChange = useCallback((effects: EffectsState) => {
    const dispatchFn = multiplayer?.dispatch ?? dispatch;
    dispatchFn({ type: 'SET_EFFECTS', effects });
  }, [multiplayer, dispatch]);

  return (
    <main>
      {/* Phase 34: Feature-level error boundary for sequencer */}
      <FeatureErrorBoundary feature="sequencer">
        <Suspense fallback={<StepSequencerSkeleton />}>
          <StepSequencer />
        </Suspense>
      </FeatureErrorBoundary>
      {/* Effects and sample picker row - hidden in portrait mode */}
      {!isPortraitMode && (
        <div className="controls-row">
          {/* Hide sample picker for published sessions - they can only listen */}
          {!isPublished && (
            <Suspense fallback={<SamplePickerSkeleton />}>
              <SamplePicker
                onSelectSample={handleAddTrack}
                disabled={!canAddTrack}
                previewsDisabled={isPublished}
              />
            </Suspense>
          )}
          {/* Effects panel - mobile only (desktop uses Transport bar FX) */}
          <div className="mobile-effects-wrapper">
            {/* Phase 34: Feature-level error boundary for audio controls */}
            <FeatureErrorBoundary feature="audio">
              <Suspense fallback={<EffectsPanelSkeleton />}>
                <EffectsPanel
                  initialState={state.effects}
                  onEffectsChange={handleEffectsChange}
                  disabled={isPublished}
                />
              </Suspense>
            </FeatureErrorBoundary>
          </div>
        </div>
      )}
      {ENABLE_RECORDING && !isPublished && (
        <Recorder
          onSampleRecorded={handleAddTrack}
          disabled={!canAddTrack}
          trackCount={state.tracks.length}
          maxTracks={MAX_TRACKS}
        />
      )}
    </main>
  );
}

function AppContent({ focusHeadingOnMount }: { focusHeadingOnMount: boolean }) {
  return (
    <SessionControls focusHeadingOnMount={focusHeadingOnMount}>
      <MainContent />
    </SessionControls>
  );
}

// Check if URL has a session ID (matches /s/{id} pattern)
function hasSessionInUrl(): boolean {
  const path = window.location.pathname;
  return /^\/s\/[a-zA-Z0-9_-]+/.test(path);
}

function App() {
  const [showLanding, setShowLanding] = useState(() => !hasSessionInUrl());
  const [focusSessionHeading, setFocusSessionHeading] = useState(false);

  // Warm the lazily-loaded session chunks while the landing page idles, so
  // starting a session mounts the real UI directly instead of flashing
  // mismatched Suspense skeletons for a few hundred ms.
  useEffect(() => {
    if (!showLanding) return;
    void import('./components/StepSequencer');
    void import('./components/SamplePicker');
  }, [showLanding]);

  const handleStartSession = useCallback(async () => {
    // Create empty session
    const session = await createSession({
      tracks: [],
      tempo: 120,
      swing: 0,
      version: 1,
    });
    updateUrlWithSession(session.id);
    setFocusSessionHeading(true);
    setShowLanding(false);
  }, []);

  const handleRemixExample = useCallback(async (target: ExampleRemixTarget) => {
    const session = await remixSession(target.sourceId, target.apiBase);
    if (target.destinationOrigin) {
      window.location.assign(`${target.destinationOrigin}/s/${session.id}`);
      return;
    }
    updateUrlWithSession(session.id);
    setFocusSessionHeading(true);
    setShowLanding(false);
  }, []);

  if (showLanding) {
    return (
      <LandingPage
        onStartSession={handleStartSession}
        onRemixExample={handleRemixExample}
      />
    );
  }

  return (
    <ErrorBoundary>
      <DebugProvider>
        <GridProvider>
          <RemoteChangeProvider>
            <AppContent focusHeadingOnMount={focusSessionHeading} />
          </RemoteChangeProvider>
          <DebugOverlay />
        </GridProvider>
      </DebugProvider>
    </ErrorBoundary>
  );
}

export default App
