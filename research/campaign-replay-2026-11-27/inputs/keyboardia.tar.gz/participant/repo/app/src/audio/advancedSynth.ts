/**
 * Advanced Synthesis Engine
 *
 * Implements advanced synthesis features from specs/SYNTHESIS-ENGINE.md:
 * - Dual oscillator architecture with detuning
 * - Filter envelope (separate from amplitude envelope)
 * - LFO system for modulation (vibrato, tremolo, filter sweeps)
 *
 * Uses Tone.js components for high-quality audio processing.
 */

import * as Tone from 'tone';
import { logger } from '../utils/logger';
import { NOTE_DURATIONS_120BPM, semitoneToFrequency, slewAudioParam } from './constants';
import { parseInstrumentId } from './instrument-types';
import type { WaveformType, LFODestination, ADSREnvelope as BaseADSREnvelope, FilterType } from './synth-types';
import {
  clamp,
  DEFAULT_MIDI_VELOCITY,
  DEFAULT_TEMPO,
  MAX_TEMPO,
  MIDI_VELOCITY_MAX,
  MIN_TEMPO,
} from '../shared/constants';
import { ADVANCED_SOURCE_GAIN_DB, dbToGain } from './source-calibration';
import {
  normalizeSynthAttackSeconds,
  normalizeSynthReleaseSeconds,
  peakSafeOscillatorMix,
  SYNTH_PRESETS,
  type SynthParams,
} from './synth';
import { absoluteToneStartTime } from './tone-schedule';
import { audioTime, type AudioTime } from './audio-time';
import type { TrackEnvelope } from '../shared/sync-types';

const MIN_ADVANCED_FILTER_FREQUENCY = 20;
const MAX_ADVANCED_FILTER_FREQUENCY = 20_000;
const VOICE_TAIL_GUARD_SECONDS = 0.05;

function noteDurationSeconds(duration: number | string, tempo: number): number {
  if (typeof duration === 'number') {
    return Number.isFinite(duration) ? Math.max(0, duration) : 0.25;
  }
  const durationAt120 = NOTE_DURATIONS_120BPM[duration] ?? 0.25;
  return durationAt120 * (DEFAULT_TEMPO / clamp(tempo, MIN_TEMPO, MAX_TEMPO));
}

/**
 * Open the advanced-voice filter with MIDI velocity, independently of note
 * amplitude. The canonical sequencer velocity (90) retains 88.9% of the
 * authored cutoff, so the richer timbre does not make defaults suddenly dull.
 */
export function advancedVelocityFilterFrequency(
  baseCutoff: number,
  midiVelocity: number,
): number {
  const velocity = Number.isFinite(midiVelocity) ? midiVelocity : DEFAULT_MIDI_VELOCITY;
  const normalized = Math.max(0, Math.min(MIDI_VELOCITY_MAX, velocity)) / MIDI_VELOCITY_MAX;
  const multiplier = 0.3 + 0.7 * Math.sqrt(normalized);
  return Math.max(
    MIN_ADVANCED_FILTER_FREQUENCY,
    Math.min(MAX_ADVANCED_FILTER_FREQUENCY, baseCutoff * multiplier),
  );
}

/**
 * Oscillator configuration (from spec Section 2.1.1)
 */
export interface OscillatorConfig {
  waveform: WaveformType;
  level: number;           // 0 to 1 (mix level)
  detune: number;          // Cents (-100 to +100)
  coarseDetune: number;    // Semitones (-24 to +24)
}

/**
 * ADSR envelope configuration
 * Re-exports the base type with additional documentation for this engine.
 */
export type ADSREnvelope = BaseADSREnvelope;

/**
 * Filter configuration (from spec Section 2.1.2)
 */
export interface FilterConfig {
  frequency: number;       // 20 to 20000 Hz
  resonance: number;       // 0 to 30 (Q factor)
  type: FilterType;
  envelopeAmount: number;  // -1 to 1 (envelope → cutoff)
}

/**
 * LFO configuration (from spec Section 2.1.3)
 */
export interface LFOConfig {
  frequency: number;       // 0.1 to 20 Hz
  waveform: WaveformType;
  destination: LFODestination;
  amount: number;          // 0 to 1
  sync: boolean;           // Sync to transport tempo
}

/**
 * Complete advanced synth preset (from spec Section 2.1.4)
 */
export interface AdvancedSynthPreset {
  name: string;
  /** Fixed source trim retained when a native preset is structurally migrated. */
  outputGainDb?: number;
  oscillator1: OscillatorConfig;
  oscillator2: OscillatorConfig;
  amplitudeEnvelope: ADSREnvelope;
  filter: FilterConfig;
  filterEnvelope: ADSREnvelope;
  lfo: LFOConfig;
  noiseLevel: number;      // 0 to 1
}

/**
 * Advanced synth presets demonstrating dual oscillator, filter envelope, and LFO
 */
export const ADVANCED_SYNTH_PRESETS: Record<string, AdvancedSynthPreset> = {
  // Detuned supersaw (trance/EDM leads)
  'supersaw': {
    name: 'Supersaw',
    oscillator1: { waveform: 'sawtooth', level: 0.5, detune: -15, coarseDetune: 0 },
    oscillator2: { waveform: 'sawtooth', level: 0.5, detune: 15, coarseDetune: 0 },
    amplitudeEnvelope: { attack: 0.01, decay: 0.2, sustain: 0.7, release: 0.5 },
    filter: { frequency: 4000, resonance: 2, type: 'lowpass', envelopeAmount: 0.3 },
    filterEnvelope: { attack: 0.01, decay: 0.3, sustain: 0.6, release: 0.5 },
    lfo: { frequency: 0.5, waveform: 'sine', destination: 'filter', amount: 0.2, sync: false },
    noiseLevel: 0,
  },

  // Sub bass with octave layer
  'sub-bass': {
    name: 'Sub Bass',
    oscillator1: { waveform: 'sine', level: 0.7, detune: 0, coarseDetune: 0 },
    oscillator2: { waveform: 'square', level: 0.3, detune: 0, coarseDetune: -12 },
    amplitudeEnvelope: { attack: 0.01, decay: 0.1, sustain: 0.9, release: 0.3 },
    filter: { frequency: 300, resonance: 1, type: 'lowpass', envelopeAmount: 0 },
    filterEnvelope: { attack: 0.01, decay: 0.1, sustain: 1, release: 0.3 },
    lfo: { frequency: 0, waveform: 'sine', destination: 'pitch', amount: 0, sync: false },
    noiseLevel: 0,
  },

  // Wobble bass (dubstep-style)
  'wobble-bass': {
    name: 'Wobble Bass',
    oscillator1: { waveform: 'sawtooth', level: 0.6, detune: 0, coarseDetune: 0 },
    oscillator2: { waveform: 'square', level: 0.4, detune: 5, coarseDetune: 0 },
    amplitudeEnvelope: { attack: 0.01, decay: 0.1, sustain: 0.9, release: 0.2 },
    filter: { frequency: 800, resonance: 8, type: 'lowpass', envelopeAmount: 0.2 },
    filterEnvelope: { attack: 0.01, decay: 0.2, sustain: 0.5, release: 0.3 },
    lfo: { frequency: 2, waveform: 'sine', destination: 'filter', amount: 0.8, sync: true },
    noiseLevel: 0,
  },

  // Warm pad with slow filter
  'warm-pad': {
    name: 'Warm Pad',
    oscillator1: { waveform: 'sawtooth', level: 0.4, detune: -10, coarseDetune: 0 },
    oscillator2: { waveform: 'triangle', level: 0.6, detune: 10, coarseDetune: 12 },
    amplitudeEnvelope: { attack: 0.5, decay: 0.15, sustain: 0.8, release: 1.5 },
    filter: { frequency: 1500, resonance: 1, type: 'lowpass', envelopeAmount: 0.4 },
    filterEnvelope: { attack: 0.8, decay: 0.5, sustain: 0.6, release: 1.0 },
    lfo: { frequency: 0.3, waveform: 'triangle', destination: 'filter', amount: 0.15, sync: false },
    noiseLevel: 0.02,
  },

  // Vibrato lead
  'vibrato-lead': {
    name: 'Vibrato Lead',
    oscillator1: { waveform: 'square', level: 0.6, detune: 0, coarseDetune: 0 },
    oscillator2: { waveform: 'sawtooth', level: 0.4, detune: -7, coarseDetune: 0 },
    amplitudeEnvelope: { attack: 0.05, decay: 0.2, sustain: 0.7, release: 0.4 },
    filter: { frequency: 3000, resonance: 2, type: 'lowpass', envelopeAmount: 0.5 },
    filterEnvelope: { attack: 0.02, decay: 0.3, sustain: 0.5, release: 0.4 },
    lfo: { frequency: 6, waveform: 'sine', destination: 'pitch', amount: 0.3, sync: false },
    noiseLevel: 0,
  },

  // Tremolo strings
  'tremolo-strings': {
    name: 'Tremolo Strings',
    oscillator1: { waveform: 'sawtooth', level: 0.5, detune: -5, coarseDetune: 0 },
    oscillator2: { waveform: 'sawtooth', level: 0.5, detune: 5, coarseDetune: 0 },
    amplitudeEnvelope: { attack: 0.3, decay: 0.12, sustain: 0.8, release: 0.8 },
    filter: { frequency: 2500, resonance: 0.5, type: 'lowpass', envelopeAmount: 0.2 },
    filterEnvelope: { attack: 0.4, decay: 0.3, sustain: 0.7, release: 0.6 },
    lfo: { frequency: 5, waveform: 'sine', destination: 'amplitude', amount: 0.25, sync: false },
    noiseLevel: 0.01,
  },

  // Acid bass (TB-303 style)
  'acid-bass': {
    name: 'Acid Bass',
    oscillator1: { waveform: 'sawtooth', level: 1.0, detune: 0, coarseDetune: 0 },
    oscillator2: { waveform: 'square', level: 0, detune: 0, coarseDetune: 0 },
    amplitudeEnvelope: { attack: 0.01, decay: 0.3, sustain: 0.4, release: 0.2 },
    filter: { frequency: 500, resonance: 15, type: 'lowpass', envelopeAmount: 0.9 },
    filterEnvelope: { attack: 0.01, decay: 0.15, sustain: 0.1, release: 0.2 },
    lfo: { frequency: 0, waveform: 'sine', destination: 'filter', amount: 0, sync: false },
    noiseLevel: 0,
  },

  // PWM-style thick lead
  'thick-lead': {
    name: 'Thick Lead',
    oscillator1: { waveform: 'square', level: 0.5, detune: -25, coarseDetune: 0 },
    oscillator2: { waveform: 'square', level: 0.5, detune: 25, coarseDetune: 0 },
    amplitudeEnvelope: { attack: 0.02, decay: 0.2, sustain: 0.6, release: 0.4 },
    filter: { frequency: 2500, resonance: 3, type: 'lowpass', envelopeAmount: 0.4 },
    filterEnvelope: { attack: 0.01, decay: 0.25, sustain: 0.4, release: 0.3 },
    lfo: { frequency: 4, waveform: 'triangle', destination: 'pitch', amount: 0.1, sync: false },
    noiseLevel: 0,
  },
};

/**
 * Lossless structural migration of the legacy `synth:*` catalogue into the
 * Tone voice graph. IDs are namespaced so similarly named advanced patches
 * cannot collide with published session IDs.
 */
export function migrateNativeSynthPreset(id: string, preset: SynthParams): AdvancedSynthPreset {
  const mix = preset.osc2?.mix ?? 0;
  return {
    name: id,
    outputGainDb: preset.outputGainDb,
    oscillator1: {
      waveform: preset.waveform,
      level: preset.osc2 ? 1 - mix : 1,
      detune: 0,
      coarseDetune: 0,
    },
    oscillator2: {
      waveform: preset.osc2?.waveform ?? preset.waveform,
      level: preset.osc2 ? mix : 0,
      detune: preset.osc2?.detune ?? 0,
      coarseDetune: preset.osc2?.coarse ?? 0,
    },
    amplitudeEnvelope: {
      attack: preset.attack,
      decay: preset.decay,
      sustain: preset.sustain,
      release: preset.release,
    },
    filter: {
      frequency: preset.filterCutoff,
      resonance: preset.filterResonance,
      type: 'lowpass',
      envelopeAmount: preset.filterEnv?.amount ?? 0,
    },
    filterEnvelope: {
      attack: preset.filterEnv?.attack ?? preset.attack,
      decay: preset.filterEnv?.decay ?? preset.decay,
      sustain: preset.filterEnv?.sustain ?? 1,
      release: preset.release,
    },
    lfo: {
      frequency: preset.lfo?.rate ?? 0,
      waveform: preset.lfo?.waveform ?? 'sine',
      destination: preset.lfo?.destination ?? 'filter',
      amount: preset.lfo?.depth ?? 0,
      sync: false,
    },
    noiseLevel: 0,
  };
}

export const NATIVE_ADVANCED_SYNTH_PRESETS: Record<string, AdvancedSynthPreset> =
  Object.fromEntries(Object.entries(SYNTH_PRESETS).map(([id, preset]) => [
    `native:${id}`,
    migrateNativeSynthPreset(id, preset),
  ]));

export function getUnifiedAdvancedSynthPreset(presetId: string): AdvancedSynthPreset | undefined {
  return ADVANCED_SYNTH_PRESETS[presetId] ?? NATIVE_ADVANCED_SYNTH_PRESETS[presetId];
}

/**
 * Advanced synth preset type
 */
export type AdvancedSynthPresetId = keyof typeof ADVANCED_SYNTH_PRESETS;

/**
 * Convert filter type to Tone.js BiquadFilterType
 */
function toToneFilterType(type: FilterConfig['type']): BiquadFilterType {
  return type;
}

/**
 * AdvancedSynthVoice - Single voice with dual oscillators, filter envelope, and LFO
 *
 * Signal flow:
 * OSC1 → Gain1 ─┐
 *               ├→ Filter → Amp Envelope → Output
 * OSC2 → Gain2 ─┘
 * Noise → Gain ─┘
 *
 * Modulation:
 * Filter Envelope → Filter Frequency
 * LFO → (Filter/Pitch/Amplitude based on config)
 */
export class AdvancedSynthVoice {
  private osc1: Tone.Oscillator | null = null;
  private osc2: Tone.Oscillator | null = null;
  private noise: Tone.Noise | null = null;
  private osc1Gain: Tone.Gain | null = null;
  private osc2Gain: Tone.Gain | null = null;
  private noiseGain: Tone.Gain | null = null;
  private filter: Tone.Filter | null = null;
  private ampEnvelope: Tone.AmplitudeEnvelope | null = null;
  private filterEnvelope: Tone.Envelope | null = null;
  private lfo: Tone.LFO | null = null;
  private output: Tone.Gain | null = null;

  private preset: AdvancedSynthPreset | null = null;
  private tempo = 120;
  private active = false;
  private sourcesStarted = false;
  private noiseStarted = false;
  private filterEnvScaler: Tone.Multiply | null = null;
  private filterEnvAdder: Tone.Add | null = null;
  private activeUntilAudioTime = Number.NEGATIVE_INFINITY;
  private noteStartTime = 0; // Tone audio time, used for voice stealing priority

  /**
   * Initialize the voice with audio nodes
   */
  initialize(): void {
    if (this.output) return; // Already initialized

    // Create oscillators
    this.osc1 = new Tone.Oscillator({ type: 'sawtooth', frequency: 440 });
    this.osc2 = new Tone.Oscillator({ type: 'sawtooth', frequency: 440 });
    this.noise = new Tone.Noise('white');

    // Create gain nodes for mixing
    this.osc1Gain = new Tone.Gain(0.5);
    this.osc2Gain = new Tone.Gain(0.5);
    this.noiseGain = new Tone.Gain(0);

    // Create filter
    this.filter = new Tone.Filter({
      type: 'lowpass',
      frequency: 2000,
      Q: 1,
    });

    // Create amplitude envelope
    this.ampEnvelope = new Tone.AmplitudeEnvelope({
      attack: 0.01,
      decay: 0.2,
      sustain: 0.5,
      release: 0.5,
    });

    // Create filter envelope
    this.filterEnvelope = new Tone.Envelope({
      attack: 0.01,
      decay: 0.2,
      sustain: 0.4,
      release: 0.5,
    });

    // Create filter envelope scaler/adder. The adder preserves the preset's
    // base cutoff; connecting the envelope directly to filter.frequency drives
    // the cutoff to 0 when envelopeAmount is 0 (silencing sub-bass presets).
    this.filterEnvScaler = new Tone.Multiply(1000);
    this.filterEnvAdder = new Tone.Add(2000);

    // Create LFO
    this.lfo = new Tone.LFO({
      frequency: 5,
      type: 'sine',
      min: -1,
      max: 1,
    });

    // Per-preset calibration lives on the engine output; voices stay at unity.
    this.output = new Tone.Gain(1);

    // Connect signal flow
    // Oscillators → Gains → Filter → Amp Envelope → Output
    this.osc1.connect(this.osc1Gain);
    this.osc2.connect(this.osc2Gain);
    this.noise.connect(this.noiseGain);

    this.osc1Gain.connect(this.filter);
    this.osc2Gain.connect(this.filter);
    this.noiseGain.connect(this.filter);

    this.filter.connect(this.ampEnvelope);
    this.ampEnvelope.connect(this.output);

    // Connect filter envelope to filter frequency as: cutoff = base + envelope.
    this.filterEnvelope.connect(this.filterEnvScaler);
    this.filterEnvScaler.connect(this.filterEnvAdder);
    this.filterEnvAdder.connect(this.filter.frequency);

    logger.audio.log('AdvancedSynthVoice initialized');
  }

  /**
   * Get the output node
   */
  getOutput(): Tone.Gain | null {
    return this.output;
  }

  /**
   * Set the audible base filter cutoff.
   *
   * Keep the raw Tone.Filter param and additive modulation base in sync so
   * every cutoff change preserves the invariant:
   *   effectiveCutoff = baseCutoff + filterEnvelope + filterLFO
   */
  setFilterFrequency(hz: number, eventTime?: AudioTime): void {
    const now = eventTime ?? audioTime(Tone.immediate());
    if (this.filter) {
      if (eventTime === undefined) slewAudioParam(this.filter.frequency, hz, now);
      else this.filter.frequency.setValueAtTime(hz, eventTime);
    }
    if (this.filterEnvAdder) {
      if (eventTime === undefined) slewAudioParam(this.filterEnvAdder.addend, hz, now);
      else this.filterEnvAdder.addend.setValueAtTime(hz, eventTime);
    }
  }

  setLfoRate(hz: number, effectiveAt?: AudioTime): void {
    if (this.lfo) {
      slewAudioParam(this.lfo.frequency, hz, effectiveAt ?? audioTime(Tone.immediate()));
    }
  }

  setTempo(bpm: number): void {
    this.tempo = clamp(bpm, MIN_TEMPO, MAX_TEMPO);
    if (this.preset?.lfo.sync) {
      this.setLfoRate(this.preset.lfo.frequency * (this.tempo / DEFAULT_TEMPO));
    }
  }

  /**
   * Apply a preset to this voice
   */
  applyPreset(preset: AdvancedSynthPreset): void {
    this.preset = preset;

    if (!this.osc1 || !this.osc2 || !this.filter || !this.ampEnvelope || !this.filterEnvelope || !this.lfo) {
      logger.audio.warn('Voice not initialized');
      return;
    }

    // Apply oscillator 1 settings
    this.osc1.type = preset.oscillator1.waveform;
    this.osc1.detune.value = preset.oscillator1.detune + (preset.oscillator1.coarseDetune * 100);
    if (this.osc1Gain) {
      this.osc1Gain.gain.value = preset.oscillator1.level;
    }

    // Apply oscillator 2 settings
    this.osc2.type = preset.oscillator2.waveform;
    this.osc2.detune.value = preset.oscillator2.detune + (preset.oscillator2.coarseDetune * 100);
    if (this.osc2Gain) {
      this.osc2Gain.gain.value = preset.oscillator2.level;
    }

    // Apply noise level
    if (this.noiseGain) {
      this.noiseGain.gain.value = preset.noiseLevel;
    }

    // Apply filter settings through setFilterFrequency() so the base cutoff
    // and additive modulation base cannot drift apart.
    this.filter.type = toToneFilterType(preset.filter.type);
    this.setFilterFrequency(preset.filter.frequency);
    this.filter.Q.value = preset.filter.resonance;

    // Apply amplitude envelope
    this.ampEnvelope.attack = normalizeSynthAttackSeconds(preset.amplitudeEnvelope.attack);
    this.ampEnvelope.decay = preset.amplitudeEnvelope.decay;
    this.ampEnvelope.sustain = preset.amplitudeEnvelope.sustain;
    this.ampEnvelope.release = normalizeSynthReleaseSeconds(preset.amplitudeEnvelope.release);

    // Apply filter envelope
    this.filterEnvelope.attack = normalizeSynthAttackSeconds(preset.filterEnvelope.attack);
    this.filterEnvelope.decay = preset.filterEnvelope.decay;
    this.filterEnvelope.sustain = preset.filterEnvelope.sustain;
    this.filterEnvelope.release = normalizeSynthReleaseSeconds(preset.filterEnvelope.release);

    // Apply filter envelope amount (scale in Hz)
    if (this.filterEnvScaler) {
      this.filterEnvScaler.value = preset.filter.envelopeAmount * 5000; // Scale to Hz range
    }

    // Apply LFO settings. Sync-enabled rates are authored at 120 BPM and
    // scale with Keyboardia's scheduler tempo.
    this.lfo.frequency.value = preset.lfo.sync
      ? preset.lfo.frequency * (this.tempo / 120)
      : preset.lfo.frequency;
    this.lfo.type = preset.lfo.waveform;

    // Disconnect and reconnect LFO based on destination
    this.lfo.disconnect();

    // IMPORTANT: WebAudio disconnect() does NOT restore AudioParam values!
    // The param retains its last value. We must explicitly reset any params
    // that could have been modulated by the previous preset's LFO.
    // See docs/AUDIO-ENGINEERING-PATTERNS.md for full explanation.

    // Reset the voice-local gain to unity (source trim lives on engine output).
    if (this.output) {
      this.output.gain.value = 1;
    }

    // Reset oscillator detune to preset values (in case previous preset used pitch LFO)
    this.osc1.detune.value = preset.oscillator1.detune + (preset.oscillator1.coarseDetune * 100);
    this.osc2.detune.value = preset.oscillator2.detune + (preset.oscillator2.coarseDetune * 100);

    if (preset.lfo.amount > 0) {
      const lfoAmount = preset.lfo.amount;

      switch (preset.lfo.destination) {
        case 'filter':
          // LFO modulates filter cutoff. Sum it with the same base cutoff as
          // the filter envelope instead of connecting directly to
          // filter.frequency, where Tone signal connections reset the intrinsic
          // AudioParam value to 0.
          this.lfo.min = -lfoAmount * 2000;
          this.lfo.max = lfoAmount * 2000;
          this.lfo.connect(this.filterEnvAdder ?? this.filter.frequency);
          break;
        case 'pitch':
          // LFO modulates pitch (vibrato) - modulate both oscillators
          this.lfo.min = -lfoAmount * 100; // cents
          this.lfo.max = lfoAmount * 100;
          this.lfo.connect(this.osc1.detune);
          this.lfo.connect(this.osc2.detune);
          break;
        case 'amplitude':
          // LFO modulates amplitude (tremolo)
          this.lfo.min = 1 - lfoAmount;
          this.lfo.max = 1;
          if (this.output) {
            this.lfo.connect(this.output.gain);
          }
          break;
      }
    }

    // Validate state in development mode
    this.validateVoiceState(preset.name);
  }

  /**
   * Validate voice state after preset application (development only)
   * Catches bugs like AudioParams left in bad state after LFO disconnect
   */
  private validateVoiceState(presetName: string): void {
    if (import.meta.env.DEV) {
      const issues: string[] = [];

      // Voice output is unity unless an amplitude LFO owns the AudioParam.
      if (this.output && this.preset?.lfo.destination !== 'amplitude') {
        if (this.output.gain.value !== 1) {
          issues.push(`output.gain is ${this.output.gain.value}, expected 1`);
        }
      }

      // Check oscillator detune matches preset
      if (this.osc1 && this.preset) {
        const expected = this.preset.oscillator1.detune + (this.preset.oscillator1.coarseDetune * 100);
        if (Math.abs(this.osc1.detune.value - expected) > 0.01) {
          issues.push(`osc1.detune is ${this.osc1.detune.value}, expected ${expected}`);
        }
      }

      if (issues.length > 0) {
        logger.audio.warn(
          `Voice state validation failed after applying "${presetName}":\n` +
          issues.map(i => `  - ${i}`).join('\n')
        );
      }
    }
  }

  /**
   * Trigger note on
   */
  triggerAttack(frequency: number, time?: number): void {
    if (!this.osc1 || !this.osc2 || !this.ampEnvelope || !this.filterEnvelope || !this.noise || !this.lfo) {
      return;
    }

    // Schedule retuning with the attack so a reused voice's release tail does
    // not jump pitch during scheduler lookahead.
    const frequencyTime = time ?? Tone.immediate();
    this.noteStartTime = frequencyTime;
    this.activeUntilAudioTime = Number.POSITIVE_INFINITY;
    this.osc1.frequency.setValueAtTime(frequency, frequencyTime);
    this.osc2.frequency.setValueAtTime(frequency, frequencyTime);

    // Start oscillators if not running
    if (!this.sourcesStarted) {
      this.osc1.start(time);
      this.osc2.start(time);
      this.lfo.start(time);
      this.sourcesStarted = true;
    }
    if (!this.noiseStarted && this.preset && this.preset.noiseLevel > 0) {
      this.noise.start(time);
      this.noiseStarted = true;
    }
    this.active = true;

    // Trigger envelopes
    this.ampEnvelope.triggerAttack(time);
    this.filterEnvelope.triggerAttack(time);
  }

  /**
   * Trigger note off
   */
  triggerRelease(time?: number): void {
    if (!this.ampEnvelope || !this.filterEnvelope) return;

    this.ampEnvelope.triggerRelease(time);
    this.filterEnvelope.triggerRelease(time);
    const releaseStart = time ?? Tone.immediate();
    this.activeUntilAudioTime = releaseStart
      + normalizeSynthReleaseSeconds(Number(this.ampEnvelope.release))
      + VOICE_TAIL_GUARD_SECONDS;
  }

  /**
   * Trigger attack and release with duration
   * @param volume Volume multiplier from P-lock (0-1, default 1)
   */
  triggerAttackRelease(frequency: number, duration: number | string, time?: number, volume: number = 1): void {
    if (!this.osc1 || !this.osc2 || !this.ampEnvelope || !this.filterEnvelope || !this.noise || !this.lfo) {
      logger.audio.warn('Voice triggerAttackRelease: nodes not initialized');
      return;
    }

    // Comprehensive diagnostic logging for debugging "no sound" issue
    const filterFreq = this.filterEnvAdder?.addend?.value ?? this.filter?.frequency?.value ?? 'null';
    const osc1Gain = this.osc1Gain?.gain?.value ?? 'null';
    const osc2Gain = this.osc2Gain?.gain?.value ?? 'null';
    const outputGain = this.output?.gain?.value ?? 'null';
    logger.audio.log(`Voice triggering: freq=${frequency.toFixed(1)}Hz, vol=${volume}, wasActive=${this.active}, time=${time?.toFixed(3) ?? 'undefined'}, filter=${filterFreq}, osc1=${osc1Gain}, osc2=${osc2Gain}, out=${outputGain}`);

    // Schedule retuning with the attack so voice stealing cannot alter an
    // audible tail before the replacement note begins.
    const frequencyTime = time ?? Tone.immediate();
    this.noteStartTime = frequencyTime;
    this.osc1.frequency.setValueAtTime(frequency, frequencyTime);
    this.osc2.frequency.setValueAtTime(frequency, frequencyTime);

    // Start oscillators if not running
    if (!this.sourcesStarted) {
      this.osc1.start(time);
      this.osc2.start(time);
      this.lfo.start(time);
      this.sourcesStarted = true;
    }
    if (!this.noiseStarted && this.preset && this.preset.noiseLevel > 0) {
      this.noise.start(time);
      this.noiseStarted = true;
    }
    this.active = true;

    const durationSeconds = noteDurationSeconds(duration, this.tempo);

    // Resolve notation against Keyboardia's tempo before handing it to Tone.
    // Tone's global Transport is not the sequencer clock, so passing "4n"
    // through directly would render at Tone's default BPM while the allocator
    // retired the voice against the app tempo.
    this.ampEnvelope.triggerAttackRelease(durationSeconds, time, volume);
    this.filterEnvelope.triggerAttackRelease(durationSeconds, time);

    // Voice allocation follows Tone's audio clock. When a tab is suspended,
    // wall time keeps advancing but this deadline does not, so a releasing
    // voice cannot be recycled before its audible tail has actually rendered.
    const releaseSeconds = normalizeSynthReleaseSeconds(Number(this.ampEnvelope.release));
    this.activeUntilAudioTime = frequencyTime
      + durationSeconds
      + releaseSeconds
      + VOICE_TAIL_GUARD_SECONDS;
  }

  /**
   * Check if voice is active
   */
  isActive(): boolean {
    if (this.active && Tone.immediate() >= this.activeUntilAudioTime) {
      this.active = false;
    }
    return this.active;
  }

  /**
   * Get note start time for voice stealing priority (older notes get stolen first)
   */
  getNoteStartTime(): number {
    return this.noteStartTime;
  }

  /**
   * Make this voice immediately available to the allocator.
   */
  cancelPendingRelease(): void {
    this.active = false;
    this.activeUntilAudioTime = Number.NEGATIVE_INFINITY;
  }

  /**
   * Dispose voice resources
   */
  dispose(): void {
    // Cancel any pending release first
    this.cancelPendingRelease();

    this.osc1?.stop();
    this.osc2?.stop();
    this.noise?.stop();
    this.lfo?.stop();

    this.osc1?.dispose();
    this.osc2?.dispose();
    this.noise?.dispose();
    this.osc1Gain?.dispose();
    this.osc2Gain?.dispose();
    this.noiseGain?.dispose();
    this.filter?.dispose();
    this.ampEnvelope?.dispose();
    this.filterEnvelope?.dispose();
    this.filterEnvScaler?.dispose();
    this.filterEnvAdder?.dispose();
    this.lfo?.dispose();
    this.output?.dispose();

    this.osc1 = null;
    this.osc2 = null;
    this.noise = null;
    this.osc1Gain = null;
    this.osc2Gain = null;
    this.noiseGain = null;
    this.filter = null;
    this.ampEnvelope = null;
    this.filterEnvelope = null;
    this.filterEnvScaler = null;
    this.filterEnvAdder = null;
    this.lfo = null;
    this.output = null;
    this.noteStartTime = 0;
    this.sourcesStarted = false;
    this.noiseStarted = false;

    logger.audio.log('AdvancedSynthVoice disposed');
  }
}

/**
 * Diagnostic state for tracking engine health
 */
export interface AdvancedSynthDiagnostics {
  ready: boolean;
  voiceCount: number;
  activeVoices: number;
  outputConnected: boolean;
  currentPreset: string | null;
  lastPlayAttempt: number;
  lastSuccessfulPlay: number;
  playAttempts: number;
  playSuccesses: number;
  playFailures: number;
  failureReasons: string[];
  toneContextState: string;
  toneContextSampleRate: number;
}

/**
 * AdvancedSynthEngine - Polyphonic advanced synth with voice management
 *
 * Features:
 * - 8 voice polyphony
 * - Voice stealing (oldest note first)
 * - Preset management
 * - Semitone to frequency conversion
 * - Comprehensive diagnostics for debugging
 */
export class AdvancedSynthEngine {
  private voices: AdvancedSynthVoice[] = [];
  private output: Tone.Gain | null = null;
  private currentPreset: AdvancedSynthPreset | null = null;
  private currentPresetId: string | null = null;
  private overrides: {
    filterFrequency?: number;
    filterResonance?: number;
    lfoRate?: number;
    lfoAmount?: number;
    attack?: number;
    release?: number;
    envelope?: TrackEnvelope;
    oscMix?: number;
  } = {};
  private ready = false;

  // Diagnostic tracking
  private lastPlayAttempt = 0;
  private lastSuccessfulPlay = 0;
  private playAttempts = 0;
  private playSuccesses = 0;
  private playFailures = 0;
  private recentFailureReasons: string[] = [];
  private static readonly MAX_FAILURE_REASONS = 10;

  private static readonly MAX_VOICES = 8;

  /**
   * Initialize the synth engine
   */
  async initialize(): Promise<void> {
    if (this.ready) return;

    logger.audio.log('Initializing AdvancedSynthEngine...');

    // Create output gain
    this.output = new Tone.Gain(1);

    // Create voice pool
    for (let i = 0; i < AdvancedSynthEngine.MAX_VOICES; i++) {
      const voice = new AdvancedSynthVoice();
      voice.initialize();
      const voiceOutput = voice.getOutput();
      if (voiceOutput && this.output) {
        voiceOutput.connect(this.output);
      }
      this.voices.push(voice);
    }

    // bug_004: a shared-LFO AudioWorkletNode was removed here (6d97bf1).
    // It was never .connect()-ed — pure CPU waste. Resurrect the worklet
    // from git history (6d97bf1^) if voice-modulation wiring is finished.

    // Apply default preset
    this.setPreset('supersaw');

    this.ready = true;
    logger.audio.log('AdvancedSynthEngine initialized with', this.voices.length, 'voices');
  }

  /**
   * Get the output node
   */
  getOutput(): Tone.Gain | null {
    return this.output;
  }

  /**
   * Check if engine is ready
   */
  isReady(): boolean {
    return this.ready;
  }

  /**
   * Get comprehensive diagnostic state for debugging
   */
  getDiagnostics(): AdvancedSynthDiagnostics {
    let toneContextState = 'unknown';
    let toneContextSampleRate = 0;
    try {
      const ctx = Tone.getContext();
      toneContextState = ctx.state;
      toneContextSampleRate = ctx.sampleRate;
    } catch (e) {
      toneContextState = `error: ${e}`;
    }

    return {
      ready: this.ready,
      voiceCount: this.voices.length,
      activeVoices: this.voices.filter(v => v.isActive()).length,
      outputConnected: this.output !== null,
      currentPreset: this.currentPreset?.name ?? null,
      lastPlayAttempt: this.lastPlayAttempt,
      lastSuccessfulPlay: this.lastSuccessfulPlay,
      playAttempts: this.playAttempts,
      playSuccesses: this.playSuccesses,
      playFailures: this.playFailures,
      failureReasons: [...this.recentFailureReasons],
      toneContextState,
      toneContextSampleRate,
    };
  }

  /**
   * Record a failure reason for diagnostics
   */
  private recordFailure(reason: string): void {
    this.playFailures++;
    this.recentFailureReasons.push(`[${new Date().toISOString()}] ${reason}`);
    if (this.recentFailureReasons.length > AdvancedSynthEngine.MAX_FAILURE_REASONS) {
      this.recentFailureReasons.shift();
    }
    logger.audio.warn(`AdvancedSynth failure: ${reason}`);
  }

  /**
   * Check invariants and log warnings if violated
   */
  private checkInvariants(context: string): boolean {
    const issues: string[] = [];

    if (!this.ready) {
      issues.push('engine not ready');
    }
    if (this.voices.length === 0) {
      issues.push('no voices created');
    }
    if (this.output === null) {
      issues.push('output is null');
    }
    if (this.currentPreset === null) {
      issues.push('no preset applied');
    }

    try {
      const ctx = Tone.getContext();
      if (ctx.state !== 'running') {
        issues.push(`Tone.js context state is "${ctx.state}" (expected "running")`);
      }
    } catch (e) {
      issues.push(`Failed to get Tone.js context: ${e}`);
    }

    if (issues.length > 0) {
      const msg = `AdvancedSynth invariant violation in ${context}: ${issues.join(', ')}`;
      logger.audio.error(msg);
      this.recordFailure(msg);
      return false;
    }

    return true;
  }

  /**
   * Set the current preset
   */
  setPreset(presetId: string): void {
    const preset = getUnifiedAdvancedSynthPreset(presetId);
    if (!preset) {
      logger.audio.warn(`Unknown preset: ${presetId}`);
      return;
    }
    if (this.currentPresetId === presetId) return;

    const previousPreset = this.currentPreset?.name ?? 'none';
    const activeVoices = this.voices.filter(v => v.isActive()).length;
    this.currentPreset = preset;
    this.currentPresetId = presetId;
    if (this.output) {
      const gainDb = preset.outputGainDb
        ?? ADVANCED_SOURCE_GAIN_DB[presetId as keyof typeof ADVANCED_SOURCE_GAIN_DB]
        ?? 0;
      this.output.gain.value = dbToGain(gainDb);
    }

    // Apply the instrument definition, then restore live control overrides.
    for (const voice of this.voices) voice.applyPreset(preset);
    this.applyOverridesToVoices();

    logger.audio.log(`Applied preset: ${previousPreset} -> ${preset.name} (${activeVoices} voices active)`);
  }

  /**
   * Get available preset names
   */
  getPresetNames(): string[] {
    return [...Object.keys(ADVANCED_SYNTH_PRESETS), ...Object.keys(NATIVE_ADVANCED_SYNTH_PRESETS)];
  }

  /**
   * Get current preset
   */
  getCurrentPreset(): AdvancedSynthPreset | null {
    return this.currentPreset;
  }

  // ─── Individual Parameter Setters (for XY Pad real-time control) ──────

  private applyLfoAmount(voice: AdvancedSynthVoice, amount: number): void {
    const lfo = voice['lfo'] as Tone.LFO | null;
    const preset = voice['preset'] as AdvancedSynthPreset | null;
    if (!lfo || !preset) return;
    switch (preset.lfo.destination) {
      case 'filter':
        lfo.min = -amount * 2000;
        lfo.max = amount * 2000;
        break;
      case 'pitch':
        lfo.min = -amount * 100;
        lfo.max = amount * 100;
        break;
      case 'amplitude':
        lfo.min = 1 - amount;
        lfo.max = 1;
        break;
    }
  }

  private applyOverridesToVoice(voice: AdvancedSynthVoice): void {
    const ov = this.overrides;
    const effectiveAt = audioTime(Tone.immediate());
    if (ov.filterFrequency !== undefined) voice.setFilterFrequency(ov.filterFrequency, effectiveAt);
    if (ov.filterResonance !== undefined && voice['filter']) {
      slewAudioParam(voice['filter'].Q, ov.filterResonance, effectiveAt);
    }
    if (ov.lfoRate !== undefined) voice.setLfoRate(ov.lfoRate, effectiveAt);
    if (ov.lfoAmount !== undefined) this.applyLfoAmount(voice, ov.lfoAmount);
    this.applyAmplitudeEnvelope(voice, ov.envelope);
    if (ov.oscMix !== undefined) {
      const [osc1Level, osc2Level] = peakSafeOscillatorMix(ov.oscMix);
      if (voice['osc1Gain']) slewAudioParam(voice['osc1Gain'].gain, osc1Level, effectiveAt);
      if (voice['osc2Gain']) slewAudioParam(voice['osc2Gain'].gain, osc2Level, effectiveAt);
    }
  }

  private applyAmplitudeEnvelope(voice: AdvancedSynthVoice, noteEnvelope?: TrackEnvelope): void {
    const target = voice['ampEnvelope'];
    if (!target || !this.currentPreset) return;
    const base = noteEnvelope ?? this.overrides.envelope ?? this.currentPreset.amplitudeEnvelope;
    // Resolved per-note seconds have already crossed the authored-state
    // validation boundary; adapter code must not clamp them to legacy limits.
    target.attack = this.overrides.attack ?? Math.max(0, base.attack);
    target.decay = Math.max(0, base.decay);
    target.sustain = Math.min(1, Math.max(0, base.sustain));
    target.release = this.overrides.release ?? Math.max(0, base.release);
    target.attackCurve = 'linear';
    target.decayCurve = 'linear';
    target.releaseCurve = 'exponential';
  }

  private applyOverridesToVoices(): void {
    for (const voice of this.voices) this.applyOverridesToVoice(voice);
  }

  setTempo(bpm: number): void {
    for (const voice of this.voices) voice.setTempo(bpm);
    // An explicit XY LFO rate remains authoritative over preset sync.
    if (this.overrides.lfoRate !== undefined) {
      for (const voice of this.voices) voice.setLfoRate(this.overrides.lfoRate);
    }
  }

  /** Set filter cutoff frequency across all voices. */
  setFilterFrequency(hz: number, effectiveAt?: AudioTime): void {
    this.overrides.filterFrequency = hz;
    for (const voice of this.voices) voice.setFilterFrequency(hz, effectiveAt);
  }

  /**
   * Set filter resonance (Q) across all voices.
   */
  setFilterResonance(q: number, effectiveAt?: AudioTime): void {
    this.overrides.filterResonance = q;
    const now = effectiveAt ?? audioTime(Tone.immediate());
    for (const voice of this.voices) {
      if (voice['filter']) slewAudioParam(voice['filter'].Q, q, now);
    }
  }

  /**
   * Set LFO rate across all voices.
   */
  setLfoRate(hz: number, effectiveAt?: AudioTime): void {
    this.overrides.lfoRate = hz;
    for (const voice of this.voices) voice.setLfoRate(hz, effectiveAt);
  }

  /**
   * Set LFO modulation amount across all voices.
   * Adjusts the LFO min/max range based on current destination.
   */
  setLfoAmount(amount: number): void {
    this.overrides.lfoAmount = amount;
    for (const voice of this.voices) this.applyLfoAmount(voice, amount);
  }

  /**
   * Set amplitude envelope attack across all voices.
   */
  setAttack(seconds: number): void {
    const attack = normalizeSynthAttackSeconds(seconds);
    this.overrides.attack = attack;
    for (const voice of this.voices) {
      if (voice['ampEnvelope']) voice['ampEnvelope'].attack = attack;
    }
  }

  /**
   * Set amplitude envelope release across all voices.
   */
  setRelease(seconds: number): void {
    const release = normalizeSynthReleaseSeconds(seconds);
    this.overrides.release = release;
    for (const voice of this.voices) {
      if (voice['ampEnvelope']) voice['ampEnvelope'].release = release;
    }
  }

  /** Apply or clear the authored per-track envelope override. */
  setEnvelope(envelope: TrackEnvelope | null): void {
    this.overrides.envelope = envelope ?? undefined;
    for (const voice of this.voices) {
      this.applyAmplitudeEnvelope(voice);
    }
  }

  /**
   * Set oscillator mix (osc1 level vs osc2 level) across all voices.
   * 0 = only osc1, 1 = only osc2, 0.5 = equal mix.
   */
  setOscMix(mix: number, effectiveAt?: AudioTime): void {
    this.overrides.oscMix = mix;
    const now = effectiveAt ?? audioTime(Tone.immediate());
    const [osc1Level, osc2Level] = peakSafeOscillatorMix(mix);
    for (const voice of this.voices) {
      const osc1Gain = voice['osc1Gain'] as Tone.Gain | null;
      const osc2Gain = voice['osc2Gain'] as Tone.Gain | null;
      if (osc1Gain) slewAudioParam(osc1Gain.gain, osc1Level, now);
      if (osc2Gain) slewAudioParam(osc2Gain.gain, osc2Level, now);
    }
  }

  /**
   * Get a free voice (or steal the oldest one)
   */
  private allocateVoice(): AdvancedSynthVoice | null {
    // First try to find an inactive voice
    for (const voice of this.voices) {
      if (!voice.isActive()) {
        return voice;
      }
    }

    // If all voices are active, steal the oldest one (earliest noteStartTime)
    let oldestVoice = this.voices[0];
    let oldestTime = oldestVoice?.getNoteStartTime() ?? Infinity;

    for (const voice of this.voices) {
      const startTime = voice.getNoteStartTime();
      if (startTime < oldestTime) {
        oldestTime = startTime;
        oldestVoice = voice;
      }
    }

    return oldestVoice || null;
  }

  /**
   * Play a note by semitone offset from C4
   * @param volume Volume multiplier from P-lock (0-1, default 1)
   */
  playNoteSemitone(
    semitone: number,
    duration: number | string,
    time?: number,
    volume: number = 1,
    midiVelocity: number = DEFAULT_MIDI_VELOCITY,
    noteEnvelope?: TrackEnvelope,
  ): void {
    const frequency = semitoneToFrequency(semitone);
    this.playNoteFrequency(frequency, duration, time, volume, midiVelocity, noteEnvelope);
  }

  /**
   * Play a note by frequency
   * @param volume Volume multiplier from P-lock (0-1, default 1)
   */
  playNoteFrequency(
    frequency: number,
    duration: number | string,
    time?: number,
    volume: number = 1,
    midiVelocity: number = DEFAULT_MIDI_VELOCITY,
    noteEnvelope?: TrackEnvelope,
  ): void {
    // Track all play attempts for diagnostics
    this.playAttempts++;
    this.lastPlayAttempt = Date.now();

    // Check invariants first - this logs detailed info on failure
    if (!this.checkInvariants('playNoteFrequency')) {
      return;
    }

    if (!this.ready) {
      this.recordFailure('engine not ready (ready flag is false)');
      return;
    }

    const voice = this.allocateVoice();
    if (!voice) {
      this.recordFailure('no voice available (all voices active, voice stealing failed)');
      return;
    }

    const startTime = absoluteToneStartTime(time, Tone.immediate());

    // setPreset() applies definitions to every voice. Reapplying the same
    // preset here would disconnect/reconnect LFO AudioParams on the scheduler
    // hot path. Keep graph mutation out of note dispatch; per-note velocity is
    // the only state that belongs here.
    if (this.currentPreset) {
      this.applyAmplitudeEnvelope(voice, noteEnvelope);
      const baseCutoff = this.overrides.filterFrequency ?? this.currentPreset.filter.frequency;
      // Velocity is note state, not a live UI control. Bind it to the same raw
      // AudioContext timestamp as the attack so Tone lookahead cannot make a
      // soft note begin with the previous voice cutoff.
      voice.setFilterFrequency(
        advancedVelocityFilterFrequency(baseCutoff, midiVelocity),
        audioTime(startTime),
      );
    } else {
      this.recordFailure('no preset applied');
      return;
    }

    logger.audio.log(`AdvancedSynth playing: freq=${frequency.toFixed(1)}Hz, duration=${duration}, time=${startTime.toFixed(3)}, vol=${volume}, velocity=${midiVelocity}, preset=${this.currentPreset?.name}`);

    // Volume P-lock is passed to voice for amplitude scaling. If Tone rejects
    // the event, report it at the authoritative time instead of shifting the
    // note to a renderer-chosen retry timestamp.
    try {
      voice.triggerAttackRelease(frequency, duration, startTime, volume);
      // Track successful play
      this.playSuccesses++;
      this.lastSuccessfulPlay = Date.now();
    } catch (error) {
      voice.cancelPendingRelease();
      this.recordFailure(`Tone.js timing error at ${startTime.toFixed(3)}: ${error}`);
    }
  }

  /**
   * Play a note by note name (e.g., "C4", "F#5")
   */
  playNote(
    note: string,
    duration: number | string,
    time?: number
  ): void {
    const frequency = Tone.Frequency(note).toFrequency();
    this.playNoteFrequency(frequency, duration, time);
  }

  /**
   * Stop tracking all playing voices in the allocator.
   */
  stopAll(): void {
    for (const voice of this.voices) {
      voice.cancelPendingRelease();
    }
    logger.audio.log('AdvancedSynthEngine: stopped all voices');
  }

  /**
   * Dispose engine resources
   */
  dispose(): void {
    if (!this.ready) return;

    logger.audio.log('Disposing AdvancedSynthEngine...');

    for (const voice of this.voices) {
      voice.dispose();
    }
    this.voices = [];

    this.output?.dispose();
    this.output = null;

    this.ready = false;
    this.currentPreset = null;
    this.currentPresetId = null;
    this.overrides = {};

    logger.audio.log('AdvancedSynthEngine disposed');
  }
}

// NOTE: Singleton pattern removed in Phase 22.
// Singletons cache Tone.js nodes across HMR (Hot Module Reload), causing
// "cannot connect to an AudioNode belonging to a different audio context" errors.
// Always use `new AdvancedSynthEngine()` to ensure nodes are in the current AudioContext.
// See audio-context-safety.test.ts for comprehensive documentation.

/**
 * Check if a sample ID is an advanced synth
 * Format: "advanced:{preset}" e.g., "advanced:supersaw"
 */
export function isAdvancedSynth(sampleId: string): boolean {
  // Use centralized instrument-types.ts utility to avoid namespace inconsistency
  return parseInstrumentId(sampleId).type === 'advanced';
}

/**
 * Extract the preset name from an advanced synth sample ID
 */
export function getAdvancedSynthPresetId(sampleId: string): string | null {
  if (!isAdvancedSynth(sampleId)) return null;
  const presetId = sampleId.replace('advanced:', '');
  return ADVANCED_SYNTH_PRESETS[presetId] ? presetId : null;
}
