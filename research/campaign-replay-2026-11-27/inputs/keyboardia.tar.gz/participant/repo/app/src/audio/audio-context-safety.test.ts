import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';

/**
 * AudioContext Safety Tests
 *
 * These tests verify that all Tone.js components are created in the same
 * AudioContext to prevent "cannot connect to an AudioNode belonging to a
 * different audio context" errors.
 *
 * Root cause: Singleton patterns can retain stale Tone.js nodes across
 * Hot Module Reload (HMR), causing context mismatches.
 *
 * Key invariant: ALL Tone.js nodes must be created AFTER Tone.setContext()
 * is called with the correct AudioContext.
 */

// Mock Tone.js with context tracking
let mockContextId = 0;
let currentMockContext: { id: number } | null = null;

vi.mock('tone', () => {
  const mockParam = (value: number | string) => ({
    value,
    cancelScheduledValues: vi.fn().mockReturnThis(),
    setTargetAtTime: vi.fn().mockReturnThis(),
  });

  // Base mock class with context tracking
  const createMockClass = () => {
    return class {
      contextId: number;
      connect = vi.fn().mockReturnThis();
      disconnect = vi.fn().mockReturnThis();
      toDestination = vi.fn().mockReturnThis();
      dispose = vi.fn();
      start = vi.fn().mockReturnThis();
      stop = vi.fn().mockReturnThis();
      constructor() {
        this.contextId = currentMockContext?.id ?? -1;
      }
    };
  };

  class MockGain extends createMockClass() {
    gain = mockParam(1);
  }

  class MockFreeverb extends createMockClass() {
    roomSize = mockParam(0.7);
    dampening = 3000;
    wet = mockParam(0);
  }

  class MockReverb extends createMockClass() {
    decay = 1.5;
    preDelay = 0.01;
    wet = mockParam(1);
    ready = Promise.resolve();
  }

  class MockFeedbackDelay extends createMockClass() {
    delayTime = mockParam('8n');
    feedback = mockParam(0.3);
    wet = mockParam(0);
  }

  class MockChorus extends createMockClass() {
    frequency = mockParam(1.5);
    depth = 0.5;
    wet = mockParam(0);
  }

  class MockDistortion extends createMockClass() {
    distortion = 0;
    wet = mockParam(0);
  }

  class MockLimiter extends createMockClass() {
    threshold = mockParam(-1);
  }

  class MockCompressor extends createMockClass() {
    threshold = mockParam(-10);
    ratio = mockParam(3);
    knee = mockParam(12);
    attack = mockParam(0.015);
    release = mockParam(0.2);
  }

  class MockOscillator extends createMockClass() {
    frequency = mockParam(440);
    detune = mockParam(0);
    type = 'sawtooth';
  }

  class MockNoise extends createMockClass() {
    type = 'white';
  }

  class MockFilter extends createMockClass() {
    frequency = mockParam(1000);
    Q = mockParam(1);
    type = 'lowpass';
  }

  class MockAmplitudeEnvelope extends createMockClass() {
    attack = 0.01;
    decay = 0.1;
    sustain = 0.5;
    release = 0.5;
    triggerAttack = vi.fn();
    triggerRelease = vi.fn();
  }

  class MockEnvelope extends createMockClass() {
    attack = 0.01;
    decay = 0.1;
    sustain = 0.5;
    release = 0.5;
    triggerAttack = vi.fn();
    triggerRelease = vi.fn();
  }

  class MockLFO extends createMockClass() {
    frequency = mockParam(5);
    amplitude = mockParam(1);
    type = 'sine';
  }

  class MockMultiply extends createMockClass() {
    value = 1;
  }

  class MockAdd extends createMockClass() {
    addend = mockParam(0);
    constructor(value?: number) {
      super();
      if (value !== undefined) this.addend.value = value;
    }
  }

  class MockFMSynth extends createMockClass() {
    triggerAttackRelease = vi.fn();
    triggerAttack = vi.fn();
    triggerRelease = vi.fn();
  }

  class MockAMSynth extends createMockClass() {
    triggerAttackRelease = vi.fn();
  }

  class MockMembraneSynth extends createMockClass() {
    triggerAttackRelease = vi.fn();
  }

  class MockMetalSynth extends createMockClass() {
    triggerAttackRelease = vi.fn();
  }

  class MockPluckSynth extends createMockClass() {
    triggerAttackRelease = vi.fn();
  }

  class MockDuoSynth extends createMockClass() {
    triggerAttackRelease = vi.fn();
  }

  return {
    start: vi.fn().mockResolvedValue(undefined),
    setContext: vi.fn((ctx: { id: number }) => {
      currentMockContext = ctx;
    }),
    getContext: vi.fn(() => ({
      state: 'running',
      rawContext: currentMockContext,
    })),
    Frequency: vi.fn(() => ({
      toFrequency: () => 440,
    })),
    now: vi.fn(() => 0),
    immediate: vi.fn(() => 0),
    Gain: MockGain,
    Freeverb: MockFreeverb,
    Reverb: MockReverb,
    FeedbackDelay: MockFeedbackDelay,
    Chorus: MockChorus,
    Distortion: MockDistortion,
    Limiter: MockLimiter,
    Compressor: MockCompressor,
    Oscillator: MockOscillator,
    Noise: MockNoise,
    Filter: MockFilter,
    AmplitudeEnvelope: MockAmplitudeEnvelope,
    Envelope: MockEnvelope,
    LFO: MockLFO,
    Multiply: MockMultiply,
    Add: MockAdd,
    FMSynth: MockFMSynth,
    AMSynth: MockAMSynth,
    MembraneSynth: MockMembraneSynth,
    MetalSynth: MockMetalSynth,
    PluckSynth: MockPluckSynth,
    DuoSynth: MockDuoSynth,
  };
});

import { ToneEffectsChain } from './toneEffects';
import { AdvancedSynthEngine } from './advancedSynth';
import { ToneSynthManager } from './toneSynths';
import * as Tone from 'tone';

const outputDestination = {} as AudioNode;

describe('AudioContext Safety', () => {
  beforeEach(() => {
    // Reset context for each test
    mockContextId++;
    currentMockContext = { id: mockContextId };
    vi.mocked(Tone.setContext)(currentMockContext as unknown as Tone.BaseContext);
  });

  afterEach(() => {
    vi.clearAllMocks();
  });

  describe('ToneEffectsChain context consistency', () => {
    it('creates all nodes in the current context', async () => {
      const chain = new ToneEffectsChain();
      await chain.initialize(outputDestination);

      const input = chain.getInput() as unknown as { contextId: number };
      expect(input.contextId).toBe(currentMockContext?.id);

      chain.dispose();
    });

    it('nodes from different contexts cannot be safely connected', async () => {
      // Simulate first context
      const context1 = { id: 100 };
      vi.mocked(Tone.setContext)(context1 as unknown as Tone.BaseContext);
      currentMockContext = context1;

      const chain1 = new ToneEffectsChain();
      await chain1.initialize(outputDestination);
      const input1 = chain1.getInput() as unknown as { contextId: number };

      // Simulate HMR - new context
      const context2 = { id: 200 };
      vi.mocked(Tone.setContext)(context2 as unknown as Tone.BaseContext);
      currentMockContext = context2;

      const chain2 = new ToneEffectsChain();
      await chain2.initialize(outputDestination);
      const input2 = chain2.getInput() as unknown as { contextId: number };

      // Verify they have DIFFERENT context IDs
      expect(input1.contextId).toBe(100);
      expect(input2.contextId).toBe(200);
      expect(input1.contextId).not.toBe(input2.contextId);

      // This is the bug scenario - connecting nodes from different contexts
      // In real code, this throws "cannot connect to an AudioNode belonging to a different audio context"

      chain1.dispose();
      chain2.dispose();
    });
  });

  describe('Fresh instance pattern (recommended)', () => {
    it('engine should create fresh instances, not use singletons', async () => {
      // This test documents the recommended pattern:
      // Always use `new ClassName()` instead of singleton getters for Tone.js components
      // when creating them in the engine's initializeTone method

      const context = { id: 300 };
      vi.mocked(Tone.setContext)(context as unknown as Tone.BaseContext);
      currentMockContext = context;

      // Correct pattern: fresh instances
      const effects = new ToneEffectsChain();
      await effects.initialize(outputDestination);

      const synths = new ToneSynthManager();
      await synths.initialize();

      const advanced = new AdvancedSynthEngine();
      await advanced.initialize();

      // All should have the same context ID
      const effectsInput = effects.getInput() as unknown as { contextId: number };
      const synthsOutput = synths.getOutput() as unknown as { contextId: number };
      const advancedOutput = advanced.getOutput() as unknown as { contextId: number };

      expect(effectsInput.contextId).toBe(300);
      expect(synthsOutput.contextId).toBe(300);
      expect(advancedOutput.contextId).toBe(300);

      effects.dispose();
      synths.dispose();
      advanced.dispose();
    });
  });

  describe('Singleton danger scenario', () => {
    it('demonstrates why singletons are dangerous with HMR', async () => {
      // First "page load" - context 1
      const context1 = { id: 400 };
      vi.mocked(Tone.setContext)(context1 as unknown as Tone.BaseContext);
      currentMockContext = context1;

      const singleton = new AdvancedSynthEngine();
      await singleton.initialize();
      const output1 = singleton.getOutput() as unknown as { contextId: number };
      expect(output1.contextId).toBe(400);

      // Simulate HMR - context 2
      const context2 = { id: 500 };
      vi.mocked(Tone.setContext)(context2 as unknown as Tone.BaseContext);
      currentMockContext = context2;

      // If we reuse the singleton, it still has context 1 nodes!
      // (In real code, initialize() would return early because ready=true)

      // But if we create fresh effects in context 2...
      const freshEffects = new ToneEffectsChain();
      await freshEffects.initialize(outputDestination);
      const effectsInput = freshEffects.getInput() as unknown as { contextId: number };
      expect(effectsInput.contextId).toBe(500);

      // Now we have a mismatch: singleton nodes (400) vs fresh effects (500)
      // This is the bug that was fixed by using `new AdvancedSynthEngine()`
      // instead of `getAdvancedSynthEngine()` in engine.ts
      expect(output1.contextId).not.toBe(effectsInput.contextId);

      singleton.dispose();
      freshEffects.dispose();
    });
  });
});

describe('Singleton audit documentation', () => {
  it('verifies dangerous singleton patterns are not present', async () => {
    // Phase 22: These dangerous singleton getters should NOT exist:
    // - getEffectsChain() from toneEffects.ts
    // - getSynthManager() from toneSynths.ts
    // - getAdvancedSynthEngine() from advancedSynth.ts
    // - initializeToneEffects() from toneEffects.ts
    //
    // They cached Tone.js nodes across HMR, causing AudioContext mismatch errors.
    // Engine.ts now always uses `new ClassName()` to ensure fresh instances.

    // Verify the dangerous exports don't exist
    const toneEffects = await import('./toneEffects');
    const toneSynths = await import('./toneSynths');
    const advancedSynth = await import('./advancedSynth');

    expect(toneEffects).not.toHaveProperty('getEffectsChain');
    expect(toneEffects).not.toHaveProperty('initializeToneEffects');
    expect(toneSynths).not.toHaveProperty('getSynthManager');
    expect(advancedSynth).not.toHaveProperty('getAdvancedSynthEngine');
  });
});
