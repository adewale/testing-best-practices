/**
 * Instrument Range Definitions
 *
 * Phase 31H: Defines playable MIDI ranges for each instrument
 * Used for range warnings in pitch visualization
 */

/**
 * Instrument range definition
 */
export interface InstrumentRange {
  minMidi: number; // Lowest playable MIDI note
  maxMidi: number; // Highest playable MIDI note
  optimalMin?: number; // Optimal low range (sounds best)
  optimalMax?: number; // Optimal high range (sounds best)
}

/**
 * Default range for instruments without specific definitions
 * Based on general synth/sampler capabilities
 */
export const DEFAULT_RANGE: InstrumentRange = {
  minMidi: 24, // C1
  maxMidi: 96, // C7
  optimalMin: 36, // C2
  optimalMax: 84, // C6
};

/**
 * Instrument ranges by sample ID prefix/name
 * Based on real instrument characteristics and sample availability
 */
export const INSTRUMENT_RANGES: Record<string, InstrumentRange> = {
  // Sampled instruments. Keep these in sync with manifest.playableRange;
  // SampledInstrument.playNote() returns null outside that exact range.
  'sampled:808-clap': { minMidi: 27, maxMidi: 73 },
  'sampled:808-hihat-closed': { minMidi: 30, maxMidi: 73 },
  'sampled:808-hihat-open': { minMidi: 34, maxMidi: 73 },
  'sampled:808-kick': { minMidi: 24, maxMidi: 73 },
  'sampled:808-snare': { minMidi: 26, maxMidi: 73 },
  'sampled:acoustic-crash': { minMidi: 37, maxMidi: 73 },
  'sampled:acoustic-guitar': { minMidi: 34, maxMidi: 83 },
  'sampled:acoustic-hihat-closed': { minMidi: 30, maxMidi: 73 },
  'sampled:acoustic-hihat-open': { minMidi: 34, maxMidi: 73 },
  'sampled:acoustic-kick': { minMidi: 24, maxMidi: 73 },
  'sampled:acoustic-ride': { minMidi: 39, maxMidi: 73 },
  'sampled:acoustic-snare': { minMidi: 26, maxMidi: 73 },
  'sampled:alto-sax': { minMidi: 47, maxMidi: 83 },
  'sampled:brushes-snare': { minMidi: 26, maxMidi: 73 },
  'sampled:clean-guitar': { minMidi: 37, maxMidi: 82 },
  'sampled:finger-bass': { minMidi: 18, maxMidi: 66 },
  'sampled:french-horn': { minMidi: 33, maxMidi: 79 },
  'sampled:hammond-organ': { minMidi: 36, maxMidi: 84 },
  'sampled:kalimba': { minMidi: 53, maxMidi: 87 },
  'sampled:marimba': { minMidi: 35, maxMidi: 102 },
  'sampled:piano': { minMidi: 30, maxMidi: 78 },
  'sampled:slap-bass': { minMidi: 28, maxMidi: 72 },
  'sampled:steel-drums': { minMidi: 54, maxMidi: 87 },
  'sampled:string-section': { minMidi: 33, maxMidi: 88 },
  'sampled:vibraphone': { minMidi: 47, maxMidi: 94 },
  'sampled:vinyl-crackle': { minMidi: 48, maxMidi: 72 },

  // Synth presets (generally full range)
  'synth:bass': {
    minMidi: 24, // C1
    maxMidi: 60, // C4
    optimalMin: 28, // E1
    optimalMax: 55, // G3
  },
  'synth:lead': {
    minMidi: 48, // C3
    maxMidi: 96, // C7
    optimalMin: 60, // C4
    optimalMax: 84, // C6
  },
  'synth:pad': {
    minMidi: 36, // C2
    maxMidi: 96, // C7
    optimalMin: 48, // C3
    optimalMax: 84, // C6
  },

  // Advanced synths
  'advanced:sub-bass': {
    minMidi: 24, // C1
    maxMidi: 55, // G3
    optimalMin: 28, // E1
    optimalMax: 48, // C3
  },
  'advanced:wobble-bass': {
    minMidi: 24, // C1
    maxMidi: 60, // C4
    optimalMin: 28, // E1
    optimalMax: 55, // G3
  },
  'advanced:acid-bass': {
    minMidi: 24, // C1
    maxMidi: 72, // C5
    optimalMin: 36, // C2
    optimalMax: 60, // C4
  },
  'advanced:supersaw': {
    minMidi: 36, // C2
    maxMidi: 96, // C7
    optimalMin: 48, // C3
    optimalMax: 84, // C6
  },
  'advanced:thick-lead': {
    minMidi: 48, // C3
    maxMidi: 96, // C7
    optimalMin: 60, // C4
    optimalMax: 84, // C6
  },
  'advanced:warm-pad': {
    minMidi: 36, // C2
    maxMidi: 96, // C7
    optimalMin: 48, // C3
    optimalMax: 84, // C6
  },

  // Tone.js FM/AM synths
  'tone:fm-epiano': {
    minMidi: 36, // C2
    maxMidi: 96, // C7
    optimalMin: 48, // C3
    optimalMax: 84, // C6
  },
  'tone:fm-bass': {
    minMidi: 24, // C1
    maxMidi: 60, // C4
    optimalMin: 28, // E1
    optimalMax: 55, // G3
  },
  'tone:fm-bell': {
    minMidi: 48, // C3
    maxMidi: 96, // C7
    optimalMin: 60, // C4
    optimalMax: 84, // C6
  },

  // Drum synths have no pitch range (single sound)
  'tone:membrane-kick': {
    minMidi: 36, // C2
    maxMidi: 60, // C4
    optimalMin: 36,
    optimalMax: 48,
  },
  'tone:membrane-tom': {
    minMidi: 36, // C2
    maxMidi: 72, // C5
    optimalMin: 48,
    optimalMax: 60,
  },
  'tone:metal-cymbal': {
    minMidi: 48, // C3
    maxMidi: 84, // C6
    optimalMin: 60,
    optimalMax: 72,
  },
  'tone:metal-hihat': {
    minMidi: 48, // C3
    maxMidi: 84, // C6
    optimalMin: 60,
    optimalMax: 72,
  },
};

/**
 * Get instrument range for a sample ID
 */
export function getInstrumentRange(sampleId: string): InstrumentRange {
  // Direct match
  if (INSTRUMENT_RANGES[sampleId]) {
    return INSTRUMENT_RANGES[sampleId];
  }

  // Match by prefix for generic synth types
  const prefix = sampleId.split(':')[0];
  if (prefix === 'synth') {
    // Check for specific synth types in name
    if (sampleId.includes('bass')) {
      return INSTRUMENT_RANGES['synth:bass'];
    }
    if (sampleId.includes('lead')) {
      return INSTRUMENT_RANGES['synth:lead'];
    }
    if (sampleId.includes('pad')) {
      return INSTRUMENT_RANGES['synth:pad'];
    }
  }

  return DEFAULT_RANGE;
}

/**
 * Check if a MIDI note is within instrument range
 */
export function isInRange(midiNote: number, sampleId: string): boolean {
  const range = getInstrumentRange(sampleId);
  return midiNote >= range.minMidi && midiNote <= range.maxMidi;
}

/**
 * Check if a MIDI note is in optimal range
 */
export function isInOptimalRange(midiNote: number, sampleId: string): boolean {
  const range = getInstrumentRange(sampleId);
  const min = range.optimalMin ?? range.minMidi;
  const max = range.optimalMax ?? range.maxMidi;
  return midiNote >= min && midiNote <= max;
}

// === Frequency Helpers (Phase 31 - Inaudible Warning) ===

/**
 * Middle C (C4) frequency in Hz
 * Standard concert pitch reference
 */
export const C4_FREQUENCY = 261.625565;

/**
 * Threshold below which frequencies are inaudible on typical laptop speakers
 * Most laptop speakers can't reproduce frequencies below ~100 Hz
 */
export const LAPTOP_SPEAKER_MIN_FREQUENCY = 100;

/**
 * Convert MIDI note to frequency in Hz
 * MIDI note 60 = C4 = 261.63 Hz
 */
export function midiToFrequency(midiNote: number): number {
  return C4_FREQUENCY * Math.pow(2, (midiNote - 60) / 12);
}

/**
 * Sub-bass instrument prefixes
 * These instruments primarily operate in the sub-bass range
 */
const SUB_BASS_PREFIXES = [
  'advanced:sub-bass',
  'advanced:wobble-bass',
  'tone:fm-bass',
  'tone:membrane-kick',
  'sampled:finger-bass',
];

/**
 * Check if an instrument is primarily a sub-bass instrument
 */
export function isSubBassInstrument(sampleId: string): boolean {
  return SUB_BASS_PREFIXES.some(prefix => sampleId.startsWith(prefix));
}

/**
 * Check if a track configuration might be inaudible on laptop speakers
 * Returns a warning message if the instrument + transpose puts it in sub-bass range
 */
export function getInaudibleWarning(
  sampleId: string,
  transpose: number = 0,
  baseMidi: number = 60
): string | null {
  const effectiveMidi = baseMidi + transpose;
  const frequency = midiToFrequency(effectiveMidi);

  // Check if this is a bass instrument in sub-bass territory
  if (isSubBassInstrument(sampleId) && frequency < LAPTOP_SPEAKER_MIN_FREQUENCY) {
    return `Sub-bass (${Math.round(frequency)} Hz) may be inaudible on laptop speakers`;
  }

  // For any instrument transposed very low
  if (frequency < 65) { // Below C2 (65 Hz)
    return `Very low frequency (${Math.round(frequency)} Hz) - may be inaudible on most speakers`;
  }

  return null;
}

// === Pitch-Shift Quality (Phase 29 - Sample Quality) ===

/**
 * Quality levels for pitch-shifting
 */
export type PitchShiftQuality = 'excellent' | 'good' | 'fair' | 'poor' | 'bad';

/**
 * Sample mappings for instruments to calculate pitch-shift distance
 * AUTO-GENERATED from manifests - do not edit manually!
 * Run: npm run generate:instrument-notes
 */
const SAMPLED_INSTRUMENT_NOTES: Record<string, number[]> = {
  'sampled:808-clap': [39],
  'sampled:808-hihat-closed': [42],
  'sampled:808-hihat-open': [46],
  'sampled:808-kick': [36],
  'sampled:808-snare': [38],
  'sampled:acoustic-crash': [49],
  'sampled:acoustic-guitar': [40, 43, 46, 49, 52, 55, 58, 61, 64, 68, 71, 74, 77, 80, 83],
  'sampled:acoustic-hihat-closed': [42],
  'sampled:acoustic-hihat-open': [46],
  'sampled:acoustic-kick': [36],
  'sampled:acoustic-ride': [51],
  'sampled:acoustic-snare': [38],
  'sampled:alto-sax': [50, 54, 60, 66, 72, 80],
  'sampled:brushes-snare': [38],
  'sampled:clean-guitar': [40, 52, 64, 76],
  'sampled:finger-bass': [21, 24, 27, 30, 33, 36, 39, 42, 45, 48, 51, 54, 57, 60],
  'sampled:french-horn': [36, 39, 43, 46, 50, 53, 60, 74, 77],
  'sampled:hammond-organ': [36, 40, 44, 48, 52, 56, 60, 64, 68, 72, 76, 80, 84],
  'sampled:kalimba': [59, 61, 63, 66, 68, 71, 73, 75, 78, 81],
  'sampled:marimba': [41, 48, 55, 59, 65, 72, 79, 83, 89, 96],
  'sampled:piano': [36, 41, 48, 53, 60, 65, 72],
  'sampled:slap-bass': [40, 48, 57, 60],
  'sampled:steel-drums': [60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83],
  'sampled:string-section': [36, 40, 43, 47, 50, 52, 55, 60, 65, 69, 72, 76, 79, 83, 86],
  'sampled:vibraphone': [53, 57, 60, 64, 67, 71, 74, 77, 81, 84, 88],
  'sampled:vinyl-crackle': [60],
};

/**
 * Get the pitch-shift amount for a MIDI note on a sampled instrument
 * Returns the number of semitones the note will be shifted from nearest sample
 */
export function getPitchShiftAmount(midiNote: number, sampleId: string): number {
  const sampleNotes = SAMPLED_INSTRUMENT_NOTES[sampleId];
  if (!sampleNotes || sampleNotes.length === 0) {
    return 0; // Non-sampled instruments don't pitch-shift
  }

  let minDistance = Infinity;
  for (const sampleNote of sampleNotes) {
    const distance = Math.abs(midiNote - sampleNote);
    minDistance = Math.min(minDistance, distance);
  }
  return minDistance;
}

/**
 * Get pitch-shift quality for a MIDI note on a sampled instrument
 * Based on how far the note is from the nearest sample
 */
export function getPitchShiftQuality(midiNote: number, sampleId: string): PitchShiftQuality {
  const shift = getPitchShiftAmount(midiNote, sampleId);

  if (shift <= 3) return 'excellent';
  if (shift <= 6) return 'good';
  if (shift <= 9) return 'fair';
  if (shift <= 12) return 'poor';
  return 'bad';
}

/**
 * Check if a sampled instrument would benefit from pitch-shift quality indication
 * Returns true for sampled instruments with sparse sample coverage
 */
export function needsPitchShiftWarning(sampleId: string): boolean {
  return sampleId.startsWith('sampled:') && SAMPLED_INSTRUMENT_NOTES[sampleId] !== undefined;
}
