import { describe, it, expect, vi, beforeEach } from 'vitest';
import { TrackBus } from './track-bus';
import {
  TRACK_SAMPLE_PEAK_CEILING,
  TRACK_SAMPLE_PEAK_CURVE_POINTS,
  TRACK_PEAK_LIMITER_MAKEUP_GAIN,
  TRACK_PEAK_LIMITER_SETTINGS,
} from './constants';
import { audioTime } from './audio-time';

/**
 * Phase 25: TrackBus Unit Tests
 *
 * Tests the per-track audio bus that provides unified volume/mute/pan control.
 * Uses mocked AudioContext since tests run in Node.
 */

// Mock AudioContext and related nodes
function createMockGainNode() {
  const node = {
    gain: {
      value: 1,
      cancelScheduledValues: vi.fn(),
      setValueAtTime: vi.fn((value: number) => { node.gain.value = value; }),
      linearRampToValueAtTime: vi.fn(),
      setTargetAtTime: vi.fn((value: number) => { node.gain.value = value; }),
    },
    connect: vi.fn(),
    disconnect: vi.fn(),
  };
  return node;
}

function createMockStereoPannerNode() {
  const node = {
    pan: {
      value: 0,
      setValueAtTime: vi.fn((value: number) => { node.pan.value = value; }),
      setTargetAtTime: vi.fn((value: number) => { node.pan.value = value; }),
      cancelScheduledValues: vi.fn(),
    },
    connect: vi.fn(),
    disconnect: vi.fn(),
  };
  return node;
}

function createMockDynamicsCompressorNode() {
  return {
    threshold: { value: 0 },
    knee: { value: 0 },
    ratio: { value: 0 },
    attack: { value: 0 },
    release: { value: 0 },
    connect: vi.fn(),
    disconnect: vi.fn(),
  };
}

function createMockWaveShaperNode() {
  return {
    curve: null as Float32Array | null,
    oversample: 'none' as OverSampleType,
    connect: vi.fn(),
    disconnect: vi.fn(),
  };
}

function createMockAudioContext() {
  return {
    createGain: vi.fn(() => createMockGainNode()),
    createStereoPanner: vi.fn(() => createMockStereoPannerNode()),
    createDynamicsCompressor: vi.fn(() => createMockDynamicsCompressorNode()),
    createWaveShaper: vi.fn(() => createMockWaveShaperNode()),
    currentTime: 0,
  } as unknown as AudioContext;
}

describe('TrackBus', () => {
  let context: AudioContext;
  let destination: GainNode;

  beforeEach(() => {
    context = createMockAudioContext();
    destination = createMockGainNode() as unknown as GainNode;
  });

  describe('initialization', () => {
    it('should create all internal nodes', () => {
      new TrackBus(context, destination);

      // input, volume, mute, limiter makeup trim, and output
      expect(context.createGain).toHaveBeenCalledTimes(5);
      expect(context.createStereoPanner).toHaveBeenCalledTimes(1);
      expect(context.createDynamicsCompressor).toHaveBeenCalledTimes(1);
      expect(context.createWaveShaper).toHaveBeenCalledTimes(1);
    });

    it('configures the post-pan track peak ceiling', () => {
      new TrackBus(context, destination);
      const limiter = vi.mocked(context.createDynamicsCompressor).mock.results[0]?.value;
      const makeupTrim = vi.mocked(context.createGain).mock.results[3]?.value;
      const sampleCeiling = vi.mocked(context.createWaveShaper).mock.results[0]?.value;

      expect(limiter?.threshold.value).toBe(TRACK_PEAK_LIMITER_SETTINGS.threshold);
      expect(limiter?.knee.value).toBe(TRACK_PEAK_LIMITER_SETTINGS.knee);
      expect(limiter?.ratio.value).toBe(TRACK_PEAK_LIMITER_SETTINGS.ratio);
      expect(limiter?.attack.value).toBe(TRACK_PEAK_LIMITER_SETTINGS.attack);
      expect(limiter?.release.value).toBe(TRACK_PEAK_LIMITER_SETTINGS.release);
      expect(makeupTrim?.gain.value).toBeCloseTo(TRACK_PEAK_LIMITER_MAKEUP_GAIN, 12);
      expect(sampleCeiling?.oversample).toBe('none');
      expect(sampleCeiling?.curve).toHaveLength(TRACK_SAMPLE_PEAK_CURVE_POINTS);
      expect(Math.max(...sampleCeiling!.curve!)).toBeCloseTo(TRACK_SAMPLE_PEAK_CEILING, 6);
      expect(Math.min(...sampleCeiling!.curve!)).toBeCloseTo(-TRACK_SAMPLE_PEAK_CEILING, 6);
    });

    it('should connect nodes in correct order', () => {
      const bus = new TrackBus(context, destination);

      // Verify the chain is connected to destination
      expect(destination.connect).not.toHaveBeenCalled(); // destination is the endpoint
      expect(bus.isDisposed()).toBe(false);
    });
  });

  describe('volume control', () => {
    it('should default to volume 1', () => {
      const bus = new TrackBus(context, destination);
      expect(bus.getVolume()).toBe(1);
    });

    it('should set volume between 0 and 1', () => {
      const bus = new TrackBus(context, destination);

      bus.setVolume(0.5);
      expect(bus.getVolume()).toBe(0.5);

      bus.setVolume(0);
      expect(bus.getVolume()).toBe(0);

      bus.setVolume(1);
      expect(bus.getVolume()).toBe(1);
    });

    it('should clamp volume to valid range', () => {
      const bus = new TrackBus(context, destination);

      bus.setVolume(-0.5);
      expect(bus.getVolume()).toBe(0);

      bus.setVolume(1.5);
      expect(bus.getVolume()).toBe(1);
    });
  });

  describe('mute control', () => {
    it('should default to unmuted', () => {
      const bus = new TrackBus(context, destination);
      expect(bus.isMuted()).toBe(false);
    });

    it('should toggle mute state', () => {
      const bus = new TrackBus(context, destination);

      bus.setMuted(true);
      expect(bus.isMuted()).toBe(true);

      bus.setMuted(false);
      expect(bus.isMuted()).toBe(false);
    });
  });

  describe('pan control', () => {
    it('should default to center pan (0)', () => {
      const bus = new TrackBus(context, destination);
      expect(bus.getPan()).toBe(0);
    });

    it('should set pan between -1 and 1', () => {
      const bus = new TrackBus(context, destination);

      bus.setPan(-1);
      expect(bus.getPan()).toBe(-1);

      bus.setPan(0);
      expect(bus.getPan()).toBe(0);

      bus.setPan(1);
      expect(bus.getPan()).toBe(1);
    });

    it('smooths pan changes with the shared continuous-parameter slew', () => {
      const bus = new TrackBus(context, destination);
      bus.setPan(0.5);
      const panner = vi.mocked(context.createStereoPanner).mock.results[0]?.value;
      expect(panner.pan.cancelScheduledValues).toHaveBeenCalledWith(context.currentTime);
      expect(panner.pan.setTargetAtTime).toHaveBeenCalledWith(0.5, context.currentTime, 0.04);
    });

    it('anchors pan automation at an explicit audio timestamp', () => {
      const bus = new TrackBus(context, destination);
      bus.setPan(0.5, audioTime(4.25));
      const panner = vi.mocked(context.createStereoPanner).mock.results[0]?.value;
      expect(panner.pan.cancelScheduledValues).toHaveBeenCalledWith(4.25);
      expect(panner.pan.setTargetAtTime).toHaveBeenCalledWith(0.5, 4.25, 0.04);
    });

    it('should clamp pan to valid range', () => {
      const bus = new TrackBus(context, destination);

      bus.setPan(-2);
      expect(bus.getPan()).toBe(-1);

      bus.setPan(2);
      expect(bus.getPan()).toBe(1);
    });
  });

  describe('getInput', () => {
    it('should return the input gain node', () => {
      const bus = new TrackBus(context, destination);
      const input = bus.getInput();

      expect(input).toBeDefined();
      expect(input).toHaveProperty('gain');
    });
  });

  describe('dispose', () => {
    it('should mark bus as disposed', () => {
      const bus = new TrackBus(context, destination);

      expect(bus.isDisposed()).toBe(false);
      bus.dispose();
      expect(bus.isDisposed()).toBe(true);
    });

    it('should be idempotent', () => {
      const bus = new TrackBus(context, destination);

      bus.dispose();
      bus.dispose(); // Should not throw
      expect(bus.isDisposed()).toBe(true);
    });
  });
});
