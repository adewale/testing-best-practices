it('replay observes the authored tempo on a second socket and REST', async () => {
  const sessionId = await createSession();
  const author = await connect(sessionId, 'author');
  const peer = await connect(sessionId, 'peer');
  expect(author.snapshot.state?.tempo).toBe(120);
  expect(peer.snapshot.state?.tempo).toBe(120);
  author.socket.send(JSON.stringify({ type: 'set_tempo', tempo: 143, seq: 73 }));
  const isTempo = (m: ServerMessage) => m.type === 'tempo_changed' && m.clientSeq === 73;
  const ack = await author.inbox.waitFor(isTempo, 'author acknowledgement of 143');
  expect(ack).toMatchObject({ type: 'tempo_changed', tempo: 143, playerId: 'author', clientSeq: 73 });
  const response = await SELF.fetch(`http://localhost/api/sessions/${sessionId}`);
  expect(response.status).toBe(200);
  expect((await response.json() as { state: { tempo: number } }).state.tempo).toBe(143);
  const delivered = await peer.inbox.waitFor(isTempo, 'independent peer delivery of 143');
  expect(delivered).toEqual(ack);
});
