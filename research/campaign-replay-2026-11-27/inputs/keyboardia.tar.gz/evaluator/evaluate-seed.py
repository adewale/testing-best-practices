#!/usr/bin/env python3
"""Check a valid schedule and a genuine persistence fault with the actual Workers config."""
from argparse import ArgumentParser
from pathlib import Path
import json
import os
import shutil
import subprocess
import sys
import tempfile

HERE = Path(__file__).resolve().parent
PUBLIC = HERE.parent / "participant"
p = ArgumentParser(description=__doc__)
p.add_argument("--repo", type=Path, default=PUBLIC / "repo")
p.add_argument("--out", type=Path, required=True)
p.add_argument("--app-modules", type=Path, default=Path("/opt/keyboardia-app/node_modules"))
p.add_argument("--worker-modules", type=Path, default=Path("/opt/keyboardia-worker/node_modules"))
p.add_argument("--assert-original", action="store_true")
p.add_argument("--assert-repaired", action="store_true")
args = p.parse_args()
out = args.out.resolve()
out.mkdir(parents=True, exist_ok=True)
results = {}
with tempfile.TemporaryDirectory(prefix="keyboardia-seeds-") as tmp:
    repo = Path(tmp) / "repo"
    shutil.copytree(args.repo,repo,ignore=shutil.ignore_patterns(".git","node_modules","dist",".wrangler",".vite","coverage","test-results"))
    subprocess.run([sys.executable,str(PUBLIC/"runtime/attach.py"),"--repo",str(repo),
                    "--app-modules",str(args.app_modules),"--worker-modules",str(args.worker_modules)],check=True)
    env = {**os.environ, "KEYBOARDIA_REPO":str(repo),"WRANGLER_LOG_PATH":str(Path(tmp)/"logs"),"NO_COLOR":"1"}
    for name, seed, title in [
        ("default_model", None, "model: read-your-writes"),
        ("valid_schedule", "45182094013", "model: read-your-writes"),
        ("persistence_original", None, "WS mutation makes KV lag"),
        ("persistence_fault", None, "WS mutation makes KV lag"),
    ]:
        for k in ("FC_SEED", "FUZZ_SEEDS"):
            env.pop(k, None)
            if seed:
                env[k] = seed
        if name == "persistence_fault":
            target = repo/"app/src/worker/live-session.ts"
            text = target.read_text()
            before = "      await this.saveToKV();\n      this.pendingKVSave = false;\n    } catch (e) {\n      console.error(`[KV] Flush failed:"
            if text.count(before) != 1:
                raise SystemExit("Mutation anchor changed; review applicability.")
            target.write_text(text.replace(before,before.replace("await this.saveToKV();","void this.state;")))
        child = subprocess.run([str(PUBLIC/"runtime/run-worker.sh"),"state-machine-fuzz.test.ts","-t",title],
                               env=env,cwd=repo,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=90)
        body=child.stdout.decode(errors="replace")
        (out/(name+".log")).write_bytes(child.stdout)
        results[name] = {"exit":child.returncode,"seed":seed,"selector":title,"log":name+".log",
                         "matched":("1 passed" in body if child.returncode == 0 else (
                             'expected 99 to be greater than or equal to 100' in body if name == "valid_schedule" else
                             'expected 120 to be 150' in body if name == "persistence_fault" else False))}
        print(name, child.returncode, flush=True)
(out/"results.json").write_text(json.dumps(results,indent=2)+"\n")
if args.assert_original or args.assert_repaired:
    expected = [0, 1 if args.assert_original else 0, 0, 1]
    assert [item["exit"] for item in results.values()] == expected and all(item["matched"] for item in results.values()), results
