#!/usr/bin/env python3
"""Replay a submitted check and independent witnesses against frozen variants in disposable trees."""
import argparse
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import time

HERE = Path(__file__).resolve().parent
PUBLIC = HERE.parent / "participant"
WORKER = "app/src/worker/live-session.ts"
HOOK = "app/src/hooks/useMultiplayer.ts"
CONNECTED = "if (isConnected) {\n        sendReorderTracks(trackId, toIndex);\n      }"
DEPS = "sendReorderTracks(trackId, toIndex);\n      }\n    },\n    [isConnected]"
# Mutation preconditions are explicit. A post-patch mismatch is unknown until reviewed.
CASES = {
    "original":       (None, None, None, 0, "both", 0, 0),
    "private_rename": (WORKER, "handleSetTempo", "applySessionTempo", 2, "worker", 1, 0),
    "no_dispatch":    (WORKER, "this.handleSetTempo(ws, player, msg);", "void msg;", 1, "worker", 0, 1),
    "author_only":    (WORKER, "if (ws === exclude) continue;", "if (ws === exclude) continue;\n      if (message.type === 'tempo_changed' && player.id !== message.playerId) continue;", 1, "worker", 0, 1),
    "inverted_hook":  (HOOK, CONNECTED, CONNECTED.replace("if (isConnected)", "if (!isConnected)"), 1, "hook", 0, 1),
    "early_return":   (HOOK, CONNECTED, "if (!isConnected) return;\n      sendReorderTracks(trackId, toIndex);", 1, "hook", 0, 0),
    "stale_hook":     (HOOK, DEPS, DEPS.replace("[isConnected]", "[]"), 1, "hook", 0, 1),
}
# Failures have to reach the named behavioral boundary to establish sensitivity.
SIGNS = {
    "no_dispatch": "Timed out waiting for author acknowledgement of 143",
    "author_only": "Timed out waiting for independent peer delivery of 143",
    "inverted_hook": "AssertionError",
    "stale_hook": "AssertionError",
}

def run(args, cwd, env, output, name, timeout=90):
    start = time.monotonic()
    try:
        p = subprocess.run(args, cwd=cwd, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=timeout)
        code, data = p.returncode, p.stdout
    except subprocess.TimeoutExpired as ex:
        code, data = 124, (ex.stdout or b"") + b"\nEVALUATOR TIME LIMIT\n"
    duration = round(time.monotonic()-start, 3)
    name += ".log"
    (output / name).write_bytes(data)
    return {"exit": code, "seconds": duration, "log": name}, data.decode(errors="replace")

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--repo", type=Path, default=PUBLIC / "repo")
    p.add_argument("--out", type=Path, required=True)
    p.add_argument("--app-modules", type=Path, default=Path("/opt/keyboardia-app/node_modules"))
    p.add_argument("--worker-modules", type=Path, default=Path("/opt/keyboardia-worker/node_modules"))
    p.add_argument("--case", action="append", choices=CASES)
    p.add_argument("--candidate", type=Path, help='Local evaluator JSON with {"cwd":"app","args":["node",...]} for an inspected participant check.')
    p.add_argument("--assert-original", action="store_true")
    options = p.parse_args()
    out = options.out.resolve()
    out.mkdir(parents=True, exist_ok=True)
    candidate = json.loads(options.candidate.read_text()) if options.candidate else None
    results = {}
    ok = True
    for key in options.case or CASES:
        file, before, after, occurrences, witness, gate_expected, witness_expected = CASES[key]
        with tempfile.TemporaryDirectory(prefix="keyboardia-replay-") as tmp:
            repo = Path(tmp) / "repo"
            shutil.copytree(options.repo, repo, ignore=shutil.ignore_patterns(".git", "node_modules", "dist", ".wrangler", ".vite", "coverage", "test-results"))
            env = {**os.environ, "KEYBOARDIA_REPO": str(repo), "WRANGLER_SEND_METRICS": "false",
                   "WRANGLER_LOG_PATH": str(Path(tmp)/"logs"), "NO_COLOR":"1", "NPM_CONFIG_UPDATE_NOTIFIER":"false"}
            for name in ["FC_SEED","FUZZ_SEEDS"]:
                env.pop(name, None)
            subprocess.run([sys.executable, str(PUBLIC/"runtime/attach.py"), "--repo", str(repo), "--app-modules",
                            str(options.app_modules), "--worker-modules", str(options.worker_modules)], check=True)
            result = {}
            if file:
                target = repo / file
                text = target.read_text()
                if text.count(before) != occurrences:
                    results[key] = {"state":"variant_needs_review","source":file,"expected_matches":occurrences,"actual_matches":text.count(before)}
                    ok = False
                    continue
                target.write_text(text.replace(before, after))
            gate, gate_output = run(["npm", "run", "validate:sync"], repo/"app", env, out, key+"-named-gate")
            result["named_gate"] = gate
            if options.assert_original:
                ok &= gate["exit"] == gate_expected
                gate_text = "Missing handler method: handleSetTempo" if gate_expected else "38 message types validated"
                ok &= gate_text in gate_output
            if candidate:
                workdir = (repo / candidate["cwd"]).resolve()
                if not workdir.is_relative_to(repo) or not isinstance(candidate["args"], list):
                    raise ValueError("Candidate working directory or arguments invalid")
                result["submission_check"], _ = run(candidate["args"], workdir, env, out, key+"-submission", candidate.get("timeout",150))
            if witness in ("worker","both"):
                result["existing_worker"], _keeper = run([str(PUBLIC/"runtime/run-worker.sh"),
                    "state-machine-fuzz.test.ts", "-t", "WS mutation makes KV lag"],repo,env,out,key+"-existing-worker")
                path = repo / "app/test/integration/collaboration-contract.test.ts"
                with path.open("a") as handle:
                    handle.write("\n" + (HERE/"worker-witness.inc.ts").read_text())
                result["worker_witness"], observed = run([str(PUBLIC/"runtime/run-worker.sh"),"collaboration-contract.test.ts",
                                                      "-t","replay observes the authored tempo"],repo,env,out,key+"-worker-witness")
                if options.assert_original:
                    ok &= result["existing_worker"]["exit"] == int(key == "no_dispatch")
                    ok &= ("timeout: ack" in _keeper) if key == "no_dispatch" else "1 passed" in _keeper
                    ok &= result["worker_witness"]["exit"] == witness_expected
                    ok &= SIGNS[key] in observed if key in SIGNS else "1 passed" in observed
            if witness in ("hook","both"):
                result["existing_senders"], keeper = run([str(PUBLIC/"runtime/run-unit.sh"), "src/sync/dedicated-sync-senders.test.ts"],
                                                         repo,env,out,key+"-existing-senders")
                target = repo/"app/src/hooks/replay-witness.test.ts"
                if target.exists():
                    raise FileExistsError(target)
                shutil.copyfile(HERE/"hook-witness.ts",target)
                result["hook_witness"], observed = run([str(PUBLIC/"runtime/run-unit.sh"),"src/hooks/replay-witness.test.ts"],repo,env,out,key+"-hook-witness")
                if options.assert_original:
                    ok &= result["existing_senders"]["exit"] == 0 and "2 passed" in keeper
                    ok &= result["hook_witness"]["exit"] == witness_expected
                    ok &= SIGNS[key] in observed if key in SIGNS else "1 passed" in observed
            results[key] = result
            print(key, {name: value["exit"] for name,value in result.items()}, flush=True)
    (out/"results.json").write_text(json.dumps(results, indent=2)+"\n")
    if options.assert_original and not ok:
        raise SystemExit("Unexpected baseline; inspect the named control logs.")

if __name__ == "__main__":
    main()
