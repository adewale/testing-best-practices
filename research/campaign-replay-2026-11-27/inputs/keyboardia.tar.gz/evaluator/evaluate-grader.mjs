import { spawnSync } from 'node:child_process';
import { mkdtempSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { resolve, join } from 'node:path';
import { deepStrictEqual } from 'node:assert';

const flags = process.argv.slice(2);
const repoFlag = flags.indexOf('--repo');
if (repoFlag < 0) throw new Error('Supply --repo /path/to/repo');
const repo = resolve(flags[repoFlag + 1]);
const script = join(repo, 'evals/oracles/hidden-v11-answer.mjs');
const base = {
  catalog: { schema_identifier: 'https://schemas.agentskills.io/discovery/0.2.0/schema.json', schema_action: 'compare-opaque-identifier', max_redirects: 5, redirect_scope: 'same-origin' },
  selection: { name: 'collaborate-in-keyboardia', type: 'skill-md', exactly_one: true },
  digest: { algorithm: 'sha256', exact_response_bytes: true, on_mismatch: 'stop' },
  mcp: { endpoint: '/mcp', protocol_version: '2026-07-28', negotiation_method: 'server/discover', legacy_initialize: false },
  required_tools: ['analyze_session','create_session','edit_session','export_midi','get_session','publish_session','remix_session'],
};
const prefix = ['index.json','SKILL.md','digest','server/discover','tools/list'];
const correct = [...prefix,'get_session','edit_session','get_session'];
const variants = {
  correct: {trace: correct},
  reordered_tools: {trace: correct, required_tools: [...base.required_tools].reverse()},
  missing_post_read: {trace: [...prefix,'get_session','edit_session']},
  edit_before_both_reads: {trace: [...prefix,'edit_session','get_session','get_session']},
  no_read: {trace: [...prefix,'edit_session']},
  wrong_protocol: {trace: correct, mcp: {...base.mcp, protocol_version:'2024-11-05'}},
};
const tmp = mkdtempSync(join(tmpdir(),'keyboardia-discovery-'));
const output = {};
try {
  for (const [name, change] of Object.entries(variants)) {
    const fixture = join(tmp,name + '.json');
    writeFileSync(fixture,JSON.stringify({...base,...change}));
    const child = spawnSync(process.execPath,[script,'discovery-contract',fixture],{encoding:'utf8',cwd:repo,timeout:5000});
    if (child.error || child.signal || child.stderr.trim()) throw new Error(String(child.error ?? child.stderr ?? child.signal));
    output[name] = {exit:child.status, output:child.stdout.trim()};
  }
} finally {
  rmSync(tmp,{recursive:true,force:true});
}
console.log(JSON.stringify(output,null,2));
if (flags.includes('--assert-original')) deepStrictEqual(Object.values(output).map(v => v.exit),[0,0,0,0,1,1]);
if (flags.includes('--assert-repaired')) deepStrictEqual(Object.values(output).map(v => v.exit),[0,0,1,1,1,1]);
