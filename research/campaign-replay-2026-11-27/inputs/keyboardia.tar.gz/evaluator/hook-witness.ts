// @vitest-environment jsdom
import { act, renderHook } from '@testing-library/react';
import { expect, it, vi } from 'vitest';
import { useMultiplayerSync } from './useMultiplayer';
import { multiplayer } from '../sync/multiplayer';

it('replay observes the returned reorder callback across connection transitions', () => {
  const send = vi.spyOn(multiplayer, 'send').mockImplementation(() => {});
  try {
    const { result, rerender, unmount } = renderHook(
      ({ connected }) => useMultiplayerSync(connected),
      { initialProps: { connected: false } },
    );
    act(() => result.current.handleTrackReorder('track-b', 2));
    expect(send.mock.calls).toEqual([]);
    rerender({ connected: true });
    act(() => result.current.handleTrackReorder('track-c', 3));
    expect(send.mock.calls.map(([message]) => message)).toEqual([
      { type: 'reorder_tracks', trackId: 'track-c', toIndex: 3 },
    ]);
    rerender({ connected: false });
    act(() => result.current.handleTrackReorder('track-a', 0));
    expect(send).toHaveBeenCalledTimes(1);
    unmount();
  } finally {
    send.mockRestore();
  }
});
