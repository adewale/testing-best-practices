#!/usr/bin/env node
/**
 * Validate Personal Agent Protocol discovery documents from the command line.
 * Needs Node 22.18+ or 23.6+, which run TypeScript directly. See `--help`.
 */
import { existsSync, readFileSync } from "node:fs";
import { parseArgs } from "node:util";
import { validateTarget, validateText, VALIDATOR, validatorUserAgent, type DocumentKind, type Report } from "../src/validator/index.ts";
import { addressCheckingFetcher } from "./node-fetcher.ts";
import { reportMarkdown } from "../src/validator/markdown.ts";
import { withUserAgent } from "../src/validator/fetch.ts";
import { PROJECT_URL } from "../src/public/project.ts";

const HELP = `Usage: poppy-validate [options] <domain | url | file | ->

  example.com                         A Company: its poppy.json, protected resource metadata and issuer metadata
  https://agent.example/client.json   A Personal Agent: its client metadata and key set
  ./poppy.json                        A file (say what it is with --kind)
  -                                   A document on standard input

Options:
  --kind <kind>         poppy (default), protected-resource, oauth-metadata, client-metadata or jwks
  --domain <domain>     For a poppy.json file: the domain that serves it
  --fetched-from <url>  For a client metadata file: the URL that serves it
  --protocol <x.y>      Version for documents that don't declare one: 0.4, or 1.0 (the default)
  --json                Print the JSON report
  --markdown            Print the report as Markdown, to paste into an issue
  --strict              Fail on warnings too (SHOULDs, the Guides, our readings)
  --quiet               Print errors only
  --version, --help

Exit status: 0 valid, 1 invalid (an error: a MUST or normative rule broken), 2 couldn't check or bad usage.
Each message names its basis; only errors make a document invalid (docs/conformance-levels.md).
Every message's explanation: /validator/messages on any deployment of this agent.`;

const KINDS: readonly DocumentKind[] = ["poppy", "protected-resource", "oauth-metadata", "client-metadata", "jwks"];

function fail(message: string): never {
  process.stderr.write(`poppy-validate: ${message}\n\n${HELP}\n`);
  process.exit(2);
}

let parsed;
try {
  parsed = parseArgs({
    allowPositionals: true,
    options: {
      kind: { type: "string" },
      domain: { type: "string" },
      "fetched-from": { type: "string" },
      protocol: { type: "string" },
      json: { type: "boolean" },
      markdown: { type: "boolean" },
      strict: { type: "boolean" },
      quiet: { type: "boolean" },
      version: { type: "boolean" },
      help: { type: "boolean", short: "h" }
    }
  });
} catch (error) {
  fail((error as Error).message);
}
const { values, positionals } = parsed;
if (values.help) {
  process.stdout.write(`${HELP}\n`);
  process.exit(0);
}
if (values.version) {
  process.stdout.write(`${VALIDATOR.name} ${VALIDATOR.version}\n`);
  process.exit(0);
}
if (positionals.length !== 1) fail("give one domain, URL, file or -");
const target = positionals[0]!;
const kind = (values.kind ?? "poppy") as DocumentKind;
if (!KINDS.includes(kind)) fail(`--kind must be one of ${KINDS.join(", ")}`);
const options = {
  ...(values.domain ? { domain: values.domain } : {}),
  ...(values["fetched-from"] ? { fetchedFrom: values["fetched-from"] } : {}),
  ...(values.protocol ? { protocolVersion: values.protocol } : {})
};

let report: Report;
let label: string;
if (target === "-" || existsSync(target)) {
  const text = target === "-" ? readFileSync(0, "utf8") : readFileSync(target, "utf8");
  label = target === "-" ? "<stdin>" : target;
  report = validateText(kind, text, options);
} else {
  label = target;
  // Node can reach private networks, so this fetcher checks the address each name resolves to.
  // Run from anyone's machine, so it names its source project (the one place a fork changes it) rather than a deployment.
  report = await validateTarget(withUserAgent(addressCheckingFetcher(), validatorUserAgent(PROJECT_URL)), target, options);
}

if (values.json) {
  process.stdout.write(`${JSON.stringify(report, null, 2)}\n`);
} else if (values.markdown) {
  process.stdout.write(reportMarkdown(report));
} else {
  // The URL each document was asked for: where redirects led is in the messages that need it, and in --json.
  const where = (document: DocumentKind) => report.documents.find((d) => d.kind === document)?.url ?? label;
  for (const message of report.messages) {
    if (values.quiet && message.severity !== "error") continue;
    const position = message.line !== undefined ? `:${message.line}:${message.column}` : "";
    const pointer = message.pointer ? ` at ${message.pointer}` : "";
    const policy = message.refuses && message.severity !== "error" ? "; our agent refuses it" : !message.refuses && message.severity === "error" ? "; our agent tolerates it" : "";
    process.stdout.write(
      `${where(message.document)}${position}: ${message.severity} [${message.id}] ${message.text}${pointer} (${message.basis}${policy}; ${message.ref.label})\n`
    );
  }
  if (!values.quiet) {
    for (const skipped of report.skipped) process.stdout.write(`not checked: ${skipped.check}. ${skipped.reason}\n`);
  }
  const { error, warning, info } = report.counts;
  const headline =
    report.outcome === "indeterminate"
      ? "couldn't check: a document wasn't served, or couldn't be fetched within the limits"
      : report.outcome === "invalid"
        ? "not valid"
        : warning > 0
          ? "valid, with warnings"
          : "valid";
  const ours = report.outcome === "indeterminate" ? "" : report.refused ? "; our agent refuses it" : report.outcome === "invalid" ? "; our agent tolerates it" : "";
  process.stdout.write(`${headline} (${report.checkedAgainst}): ${error} errors, ${warning} warnings, ${info} info${ours}\n`);
}

const failed = report.outcome === "invalid" || (values.strict && report.counts.warning > 0);
process.exit(report.outcome === "indeterminate" ? 2 : failed ? 1 : 0);
