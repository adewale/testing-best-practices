# How we test against Companies

A Personal Agent can only be tested against a Company, and the tests need one they can sign in to, buy from and break without anyone being harmed. So we built one: the mock Company in [`test/mock-company/`](../test/mock-company). It implements the pinned 0.4 and published 1.0 specifications, records departures by name, and refuses what the applicable version tells a Company to refuse. Most of what this page describes exists to keep that mock honest, because a test is only as good as the Company it runs against.

This page explains the approach. The interop harness's contract is [interop-spec.md](interop-spec.md), how checks become failures or warnings is [conformance-levels.md](conformance-levels.md), and the page for other projects' maintainers is [testing-with-us.md](testing-with-us.md).

## The mock Company

The mock is one implementation of the Company side: discovery documents, OAuth metadata, the token endpoint, Direct, Device and Mediated Sign-In, conversations, OpenAPI and MCP APIs, a website with browser Sessions, and the Operations extension. Its MCP server speaks MCP 2025-06-18, 2026-07-28 or both (`mcpVersions`), and each mode enforces its own version's wire rules. In the Workers tests it runs as a Durable Object. The interop harness and the Hypothesis suite bundle the same code for Node.

Every check it makes records exactly one id from [`test/mock-company/violations.ts`](../test/mock-company/violations.ts), as `[id] detail`. Each id's description starts with its basis: `MUST`, `RFC` or `Rule` for a requirement, `SHOULD` or `Guides` for a recommendation, and `Reading` for our answer to an open question. The basis decides the level everywhere. A requirement broken is a failure, and anything else is a warning.

What the mock records is its verdict. Whether it also refuses the request is its behaviour, and the two are separate. It refuses where the specification gives it an error to send, and where a recommendation guards against replay, forgery or a repeated write.

## Keeping the mock honest

Four checks stand between a bug in the mock and a test that passes for the wrong reason.

1. **Tamper rows.** `TAMPERS` in [`test/mock-company.test.ts`](../test/mock-company.test.ts) drives the mock with hand-made requests, never our client. Each row breaks one thing in an otherwise correct request and expects exactly one violation id. A check that stops firing fails a named row.
2. **The catalogue test.** The same file checks that every id in `violations.ts` appears in the mock's source and has a tamper row. An id nobody tests can't be added quietly.
3. **A second client.** Our client and our mock were written by the same people, so a misreading they share passes every test. [`test/hypothesis/`](../test/hypothesis) holds an independent Poppy client in Python, written from the protocol text rather than ported from `src/poppy`, and six stateful, model-based Hypothesis tests that drive it against the mock. It runs locally, after a specification change or a large change to the mock, and not in CI.
4. **The maintainers' validator.** The [pinned 0.4 kit](../spec/company-kit-2026-11-11/README.md) runs unchanged over local HTTPS against the mock serving 0.4 alone, and the [published 1.0 kit](../spec/company-kit-2026-11-19/README.md) against the mock serving 1.0 alone, in its lenient, strict, Bearer and issuerless profiles. CI preserves the raw results and checks them against the reviewed findings ([0.4](../test/company-kit/reviewed-findings-0.4.json), [1.0](../test/company-kit/reviewed-findings-1.0.json)): the documented DPoP prerequisite findings, accepted controls and absent-feature skips. The 0.3 kit, which also checked the hosted dummy Company's handlers, stays pinned as history ([decision 49](decisions.md#49-03-dropped-the-agent-mock-validator-and-interop-speak-04-alone)); its [29 October review](company-kit-review.md) holds the last manual checklist review. The old 0.2 Docker lanes remain historical.

A new check therefore lands with three things: the check in the mock, its id with a basis in `violations.ts`, and a tamper row. The catalogue test fails until all three are there.

## Holding our client to the mock

Every Poppy test in the Workers suite runs against the mock, and the `afterEach` in [`test/agent-helpers.ts`](../test/agent-helpers.ts) fails the test if the mock recorded any violation or any warning. Our own client is held to the recommendations and our readings too, as h2spec's `--strict` holds a server. A test that breaks the protocol on purpose declares what it expects with `expectViolations`.

That strictness is for our own code only. In the interop grid a warning never fails a cell.

## One mock, three profiles

The interop grid runs the mock under three names, all built from one image in [`interop/impls/pda-mock`](../interop/impls/pda-mock) and told apart by environment variables in [`interop/registry.json`](../interop/registry.json).

| Name | What changes | What it is for |
| --- | --- | --- |
| `lenient-company` | Nothing: assertions need no `typ` or `kid` and may live 300 seconds | The reference Company. Attribution compares other cells against it |
| `strict-company` | `INTEROP_MOCK_PROFILE=strict`: `typ: "JWT"`, a published `kid` and assertions lasting at most 300 seconds under 1.0 (60 under 0.4) | The strictest reading live Companies take, so an agent learns where it would be refused |
| `evil-company` | `INTEROP_ADVERSARY=company`, then one attack armed per cell | Checking that an agent refuses a Company that misbehaves on purpose |

Every profile speaks the version our client speaks: the adapter takes it from `src/poppy/protocol-version.ts`, so our two sides can't drift apart. Until 29 October the adapter still declared 0.1, and CI's grid ran no cell for a day while passing; the runner now fails such a run. The two settings the retired official-validator lanes used (`INTEROP_MOCK_VARIANT`, `INTEROP_MOCK_FLAWS`) went with them.

Because the code is the same, a difference between two profiles' results comes from the profile and nothing else. Every profile reports every check it recorded at `GET /violations` with its basis and level, and the runner turns failures into errors and everything else into warnings.

## Other projects' Companies

The local grid runs other projects' Companies at pinned commits, unchanged, in Docker containers on a network with no route to the internet. Each runs in its own demo or simulated mode, so nothing reaches a payment, print or email provider. Whatever an adapter turns on to make that work is declared in its manifest as a relaxation, and we don't patch the code.

The grid judges a Company two ways:

- **From the recording.** A proxy records every exchange, and the runner's Company-side checks, prefixed `company.` in [`interop/runner/checks.ts`](../interop/runner/checks.ts), read it: `WWW-Authenticate` on a 401, `Retry-After` on a 429, OAuth error bodies, `iss` on authorization responses, the shape of event reads and more. The validator reads the Company's documents.
- **From a strict agent.** `strict-personal-agent` runs those same checks and the validator over everything it receives, refuses at the first finding of any level, and reports what it found at `GET /violations`.

A failure that belongs to upstream or to the draft goes in [`interop/known-failures.json`](../interop/known-failures.json) with a reason. It doesn't fail the run, but an entry that stops matching any failure does.

The live lane runs against a few public deployments at their own URLs, signed out unless the owner agrees to more, one request a second, and only the scenarios listed for that Company in the registry.

## The evil Company

The honest grid assumes both sides are trying. To check refusals, `evil-company` misbehaves on purpose. It is the lenient mock with one attack switched on per cell, so the attack is the only thing that differs from a correct Company. The adapter's `arm` hook switches the attack on, and the options it sets are grouped under "Interop adversarial options" in [`test/mock-company/types.ts`](../test/mock-company/types.ts), each off by default.

A cell against it ends with checks on the recording: one that proves the attack actually happened, and harm checks such as a token never reaching a host it shouldn't. A cell whose attack never happened is a harness error, not a pass. When the agent fails to refuse, attribution blames the agent, or the draft when the scenario names a draft gap that permits the attack.

Its cells run only in the local grid, never live, and appear in a separate security grid that never counts toward the interop pass rates. The evil Company may attack other projects' agents, with the owner's approval since 13 October 2026. What those cells find stays in the gitignored results until that project's maintainers have heard privately ([`SECURITY.md`](../SECURITY.md)).

The attacks, what each expects of an agent, and which are not built yet are in [adversarial-interop.md](adversarial-interop.md), Part B. Who may be attacked is [interop-spec.md](interop-spec.md) §13. The committed results are in the security grid of [interop-results/README.md](interop-results/README.md#security-grid).

## Checking our checks

Tamper rows prove the mock notices an agent's mistakes. Nothing proved that our checks notice a Company's, until the flawed-Company lane (`npm run interop:flaws`), which ran at 0.2 and was retired with it on 28 October, since its main checker was the official 0.2 validator. It gave our 0.2 mock one known flaw at a time, from `COMPANY_FLAWS` in [`test/mock-company/types.ts`](../test/mock-company/types.ts), which remain, with the test that each changes what the mock does: it accepts a replayed assertion or DPoP proof, a proof from another key or for another URL, a token in the query string, a token-endpoint audience at 0.2, or a rotated Account Token; it drops `Cache-Control: no-store`; or it starts a second conversation for a retried message. The official validator, our adversarial agent's attacks and the strict agent each check the flawed mock. A test in `test/mock-company.test.ts` proves each flaw changes what the mock does, and the honest mock must pass every one of those checks first, so a catch means something.

On 24 October the official validator caught nine of ten deliberate flaws and our checks six. That comparison prompted the missing token-response `Cache-Control: no-store` check; its other findings and counts are [historical 0.2 results](interop-results/2026-10-24-official-and-flaws.json). The [0.3 kit review](company-kit-review.md) records the independent checks, the mock defects they found, and the remaining manual requirements. It does not treat the old flaw experiment as a 0.3 result.

## What this approach can't show

- **A misreading the draft allows.** Where the draft is ambiguous, the mock takes a reading, recorded in [readings.md](readings.md). A Company that reads it the other way isn't wrong, and the grid attributes such a failure to the draft.
- **Behaviour no scenario exercises.** A cell covers only what both sides list in their manifests. A Company's untested paths stay untested.
- **A requirement nothing of ours checks.** The retired 0.2 comparison found 25 of the official validator's 74 checks had no counterpart in our checks. Since 0.3 the independent kit reports its own verdicts, and the [manual checklist review](company-kit-review.md#manual-checklist-review) records gaps in production Company behavior. Neither count is a conformance percentage.
- **What a deployment does.** The local grid runs code. Hosting, redirects and a live allowlist show up only in the live lane, which mostly runs signed out.
- **A real model.** The harness drives protocol code with no model, so whether a model obeys text a Company sends is tested separately, in [`test/prompt-injection.test.ts`](../test/prompt-injection.test.ts), with a fake model that obeys everything.
