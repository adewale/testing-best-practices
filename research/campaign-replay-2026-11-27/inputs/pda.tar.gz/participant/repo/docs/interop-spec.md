# Poppy interop harness specification

The runner checks Poppy 0.4, published 10 November, and published 1.0, pinned on 19 November, both pinned in [`spec/upstream.json`](../spec/upstream.json) ([decision 51](decisions.md#51-10-beside-04)). The agent dropped 0.3 on 12 November ([decision 49](decisions.md#49-03-dropped-the-agent-mock-validator-and-interop-speak-04-alone)); sections 14 and 15 list what spoke 0.1, 0.2 or 0.3. Each cell records the common `protocolVersion` and local `specificationRevision`; a pair with no common version is unsupported, except two of our own builds (`owner: "self"`), which always speak the same version: for them it is an `error` blamed on the harness. A run in which no cell passed or failed fails (exit 1), so a grid that ran nothing can't pass empty, as CI's did from 28 to 29 October. Retries preserve the version context. A known failure without a version applies to the version we speak. Registry entries marked `vectorsOnly` are explicit provisioning helpers excluded from the default M×N grid.


Version 1. What an implementation of the [Personal Agent Protocol](https://personalagentprotocol.org/) (Poppy) provides to join the M×N interop grid, and what the runner does with it. The rationale and plan are in [interop-testing.md](history/interop-testing.md); the code is in [`interop/`](../interop).

The key words MUST, SHOULD and MAY are used as in RFC 2119.

## 1. Terms

- **Implementation:** one Personal Agent (role `agent`) or one Company (role `company`). A project with both sides registers two implementations.
- **Adapter:** the thin, per-implementation shim that exposes this spec's API in front of an implementation. It is the pirate-testing harness: the test data is shared, the adapter is not.
- **Scenario:** a named sequence of steps, written as data (section 6).
- **Cell:** one agent × one Company × one scenario. A **run** executes a set of cells.
- **Reading:** an implementation's answer to an open question in the draft (section 7).
- **Verdict:** a cell's outcome and the side blamed for it (section 9).

## 2. Registry

`interop/registry.json` lists the implementations. A new implementation joins by pull request to this file.

```json
{
  "version": 1,
  "implementations": [
    {
      "name": "pda",
      "role": "agent",
      "source": "https://github.com/adewale/pda",
      "commit": "850860c",
      "build": "interop/impls/pda-agent",
      "notes": "Drives src/poppy directly; no model."
    }
  ]
}
```

- `name` MUST match `^[a-z0-9-]{1,32}$` and be unique within its role.
- `build` is a directory holding a `Dockerfile`, or `url` is a running deployment (live lane only, section 10).
- `context` (optional) is the Docker build context, relative to the repository root; without it the context is `build`. Our own adapters build from the repository root (`"context": "."`), since they bundle `src/`.
- `commit` MUST pin the implementation's source. The runner records it in every result. `"HEAD"` means the commit of this repository being run, for implementations built from it.
- `liveScenarios` (optional, live lane only) lists the only scenarios the live lane may run against a Company: what its owner agreed to, or what its notes allow (a store taking real payments gets `D` only, as `print-with-poppy-live` did until 0.3 was dropped). Any other is `unsupported` before anything is sent.
- `fixture` (optional, live lane only) is a live Company's fixture, since it has no adapter to answer the `fixture` hook: for example `openapi_public`, the read N calls. It is merged over the lane's one greeting.
- `subdomains` (optional) lists further names under `<name>.company.interop.test` the Company serves, beyond the runner's defaults (`www`, `auth`, `api`, `mcp`, `cdn`, `uk`, `app`, `login`, `id`, `accounts`, `oauth`, `chat`, `agent`).
- `env` (optional) is extra environment for the container. Entries of one role with the same `build` and `context` share one image, named after the first; `env` tells them apart (`lenient-company` and `strict-company` are one image with two `INTEROP_MOCK_PROFILE`s; `lenient-personal-agent`, `strict-personal-agent` and `sloppy-personal-agent` are `pda`'s image with an `INTEROP_AGENT_PROFILE`; and the adversarial `evil-company` is the honest image with `INTEROP_ADVERSARY` set).
- `owner` (optional) is `"self"` for an implementation this project owns. An adversarial or faulted cell runs only when every honest side is `owner: "self"`, except `evil-company` against another project's agent (section 13).
- `adversarial` (optional) is `true` for an implementation that misbehaves on purpose (`evil-company`). The live lane (section 10) refuses it; it is never a grid reference (section 9, rule 2) and never counts toward interop pass rates.
- `fake` (optional) is `true` for an honest implementation built to test the other side: the fake Personal Agents (section 2.1).
- `live` (optional) is `false` for one of ours the live lane never runs and never gives its identity: the sloppy fake agent (section 10).

### 2.1 The fake implementations

Our own code with a profile, each set with a lenient and a strict member, both sets an evil one, and the agents a sloppy one. All spoke 0.3 alone from 28 October 2026 (section 14), and 0.4 alone since 0.3 was dropped on 12 November ([decision 49](decisions.md#49-03-dropped-the-agent-mock-validator-and-interop-speak-04-alone)): the agents declare 0.4, both mocks serve it with no other version in `supported_versions` (3.4), and `evil-personal-agent` sends raw 0.4 requests, with `Poppy-Version`, `Poppy-Extensions` and Operations 3 approvals. Since 13 November ([decision 51](decisions.md#51-10-beside-04)) the agents declare 0.4 and 1.0, `lenient-company` and `strict-company` serve 1.0, `lenient-company-v04` serves 0.4 (`INTEROP_MOCK_VERSION`), and `evil-personal-agent` declares the version of the Company it attacks. Renamed on 23 October 2026 (`pda-mock` → `lenient-company`, `pda-mock-strict` → `strict-company`, `pda-mock-v02` → `lenient-company-v02`, `evil-agent` → `evil-personal-agent`); results from before then use the old names.

| | Personal Agent (`interop/impls/pda-agent`, `INTEROP_AGENT_PROFILE`) | Company (`interop/impls/pda-mock`, `INTEROP_MOCK_PROFILE`) |
| --- | --- | --- |
| Lenient | `lenient-personal-agent`, the reference agent (rule 2): accepts every reading of what a Company does that gives no more access. Server metadata at the appended location when the RFC 8414 inserted one is 404 (S3 `either`; the metadata's `issuer` must still equal `auth.issuer`), and, after `invalid_client` at an endpoint the request carries no DPoP proof to, the client assertion again naming the token endpoint, then the issuer, each freshly signed (S1). | `lenient-company`, the reference Company: S2-lenient assertions. |
| Strict | `strict-personal-agent`: runs the runner's own Company-side checks (section 8) and the validator over everything it receives, refuses at the first finding of any level, a SHOULD or the Guides included (`company_departure`, or `discovery_failed` for a document), and serves its findings at `GET /violations`. | `strict-company`: `typ: "JWT"`, a published `kid` and assertions lasting at most 300 seconds under 1.0 (60 under 0.4). |
| Sloppy | `sloppy-personal-agent`: what real agents get wrong, declared honestly in its readings (S1 `token-endpoint`, S2 `lenient-300s`): client assertions with no `typ`, living 300 seconds, naming the token endpoint as `aud` everywhere, where 4.1 says the issuer. Honest, not adversarial: every departure is a reading some live agent took. | none |
| Evil | `evil-personal-agent`: raw requests at the Company's version, with accepted controls and precise mutation/refusal oracles (section 13) | `evil-company` (section 13) |

An agent's profile changes only the adapter's network seam (`interop/impls/pda-agent/profiles.ts`): `src/poppy` runs unchanged, as it does for `pda`. A profile never takes the live identity.

## 3. Network

Every cell runs on a private network with one recording proxy, and nothing on that network can reach the internet.

- **Isolation.** The local lane's network is created `--internal`: no route out, and Docker's resolver answers only the run's own names, so no container, ours or a third party's, can reach a real system, whether for analytics, a model API or a package install at startup. The runner MUST NOT run an implementation on a network that isn't internal, and no option, setting or registry field lifts this. Before any implementation starts, the runner checks that `docker network inspect` reports the network internal and runs an egress probe with `docker exec` in the proxy (on the internal network only, as every implementation is): a TCP connection to `1.1.1.1:443` and to `8.8.8.8:53`, and a DNS lookup of `example.com`. Every attempt must fail; if one succeeds, or the probe gives no verdict, the run stops. `results.json` records the probe's outcome as `isolation` (a typical one: `ENETUNREACH`, `ENETUNREACH`, `EAI_AGAIN`). An implementation that needs the internet at runtime fails its cells, and the failure is a known failure with what it tried to reach; the network is never opened for it. Everything an image needs is fetched when it is built.
- **Control relay.** A port can't be published from an internal network, so the runner reaches the proxy's control port (8082) through a relay: a second container of the proxy image running `relay.mjs`, on the internal network and on a second, ordinary per-run network, publishing only its own port on `127.0.0.1` and forwarding every connection to one fixed address, the proxy's control port. Adapters' control calls go through the proxy's `/control`, and the proxy, on the internal network only, has no way out either. The relay is the only container with a published port or a route out, and it runs our code. It carries only control traffic, which the proxy never records, so the recording and attribution don't see it.
- **Names.** A Company `x` is reached at `x.company.interop.test` and any subdomain of it. An agent `y` publishes its client metadata and JWKS at `y.agent.interop.test`. The runner itself is `runner.interop.test`.
- **Resolution.** Every name resolves to the proxy through Docker network aliases: each Company's name, the default subdomains and its registry `subdomains`, each agent's name, and `runner.interop.test`. A name not in that list doesn't resolve.
- **TLS.** The proxy terminates TLS with a certificate for `*.company.interop.test`, `*.<x>.company.interop.test` for each Company `x`, `*.agent.interop.test` and `runner.interop.test`, issued by a CA generated per run. (TLS wildcards match one label, so `*.*.company.interop.test` would match nothing; each Company gets its own.) Every container MUST trust that CA; the runner copies it to `/interop/ca.pem` before the container starts and sets `NODE_EXTRA_CA_CERTS`, `SSL_CERT_FILE` and `REQUESTS_CA_BUNDLE` to it.
- **`/interop` belongs to the runner.** An adapter image MUST NOT create `/interop`. The runner copies its trust directory with `docker cp`, which creates `/interop` when it is absent but copies *into* it when it exists; the CA would then land at `/interop/trust/ca.pem` and every TLS connection would fail.
- **`SSL_CERT_FILE` replaces the system bundle.** Clients that honour it (Python's `ssl` and `httpx`, Ruby, Go on Linux) read `SSL_CERT_FILE` *instead of* the system CAs, and `REQUESTS_CA_BUNDLE` does the same for `requests`. Inside the private network that is what is wanted: every name is the proxy's, and nothing else is reachable (Isolation). An adapter whose implementation insists on a combined bundle MAY build one of the system CAs and `/interop/ca.pem` and point these variables at it; Node's `NODE_EXTRA_CA_CERTS` adds to the built-in CAs and needs nothing.
- **Upstreams.** The proxy forwards each name to its container over plain HTTP on port 8080, adding `X-Forwarded-Proto: https` and the original `Host`. Containers carry the network alias `<role>-<name>` (`company-x`, `agent-y`). An implementation MUST build its own URLs from its configured origin, not from the inner request.
- **Environment.** The runner sets `INTEROP_SECRET`, `INTEROP_NAME`, `INTEROP_ROLE`, `INTEROP_DOMAIN` (`x.company.interop.test` or `y.agent.interop.test`), `INTEROP_ORIGIN` (`https://` and the domain) and `INTEROP_COMMIT`, then the registry's `env` and any `--set name:KEY=VALUE` given to the runner.
- **Recording.** The proxy writes every exchange, request and response in full, to a HAR file per cell, up to 2,000 exchanges a cell. Past that, requests still pass through and the HAR's comment counts the ones not recorded, so an agent that loops (XR, XT) leaves a HAR small enough to send and still fails `bounded_requests`. Nothing is redacted: every key and token is generated for the run.
- **Fault injection.** A scenario's `faults` list (section 6) makes the proxy the network adversary. Each fault is `{match, action}`, where `match` is `{host?, path?, method?, direction?, nth?}` and `action` is one of `replay` (resend an honest request verbatim, later), `duplicate` (forward the request twice), `drop_response` (forward it, then drop the answer to the client), `delay` (`{ms}`, hold the request), `truncate` (`{bytes}`, cut the answer), `reset` (reset the client connection) and `status` (`{status}`, answer another status). An exchange the proxy created or altered is marked `_interop.injected`/`_interop.fault` in the HAR; the checks skip injected exchanges, so an injected request is never blamed on an honest side.
- **Labels and cleanup.** Every container, network (the internal one and the relay's) and volume the runner creates carries the label `interop.run=<tag>`, the run's random tag. On exit, on error and on SIGINT or SIGTERM it removes exactly those (containers with their anonymous volumes), unless `--keep`. It never removes images, which runs reuse, never touches the build cache, and never removes anything without its own run's label.
- **Disk.** Before it starts, the runner runs `df -Pk /` in a short-lived container of the proxy image (its root is the overlay on Docker's data disk) and refuses to start with less free than `--min-free-gb` (2 GB by default). A first run, before the proxy image exists, skips the check.
- **Interop-only settings.** An implementation MAY need to allow `*.interop.test` names, a private CA or a peer it doesn't know. Each such relaxation MUST be a setting that is off by default, and the adapter MUST name it in its manifest (`relaxations`).

## 4. Manifest

Every adapter serves `GET /manifest` on its control port (8081), with no authentication:

```json
{
  "interop": 1,
  "name": "pda",
  "role": "agent",
  "commit": "a7fbe96",
  "poppy": ["0.4", "1.0"],
  "extensions": ["operations"],
  "scenarios": ["D", "S0", "N", "SD", "C", "CI", "SO", "O"],
  "readings": { "S1": "issuer", "S2": "jwt-60s", "S3": "insertion", "S23": "per-origin" },
  "relaxations": []
}
```

- `scenarios` lists what the adapter claims to support. A cell whose scenario either side doesn't list is `unsupported`, not failed.
- `readings` keys are section 7's question ids.
- `attacks` (adversarial adapters only) lists the attack ids the adapter can `arm` (section 5). An armed attack the adapter doesn't support answers 501, so the cell is `unsupported`.

## 5. Adapter APIs

Control requests carry `Authorization: Bearer <secret>`, where the runner passes the secret in `INTEROP_SECRET`. Bodies are JSON. Every endpoint answers 200 with a JSON body, 501 for an operation the adapter doesn't support, or 4xx/5xx with `{"error": "<code>", "detail": "<text>"}`.

### 5.1 Common

| Request | Meaning |
| --- | --- |
| `GET /manifest` | Section 4. |
| `POST /reset` | Forget every Company, Session, token, key and conversation; the next run starts clean. Agents also rotate the keys their client metadata lists, each new key under a new `kid`: a Company that cached the previous JWKS must not find a reused `kid` naming a different key. |
| `GET /healthz` | 200 once ready. The runner waits up to 60 s. |

### 5.2 Agent

`POST /step` with `{"op": "<op>", "company": "<domain>", "params": {...}}`. The `company` is a host name such as `x.company.interop.test`. The result is `{"ok": true, "result": {...}}` or an error as above. A Poppy error the Company returned is not an adapter error: it is `{"ok": false, "poppy_error": "<code>", "status": <http status>}`. So is the agent's own refusal of something the Company did (`discovery_failed` for documents it won't use, `access_denied` for a declined sign-in), with `status` 0.

| `op` | `params` | `result` |
| --- | --- | --- |
| `discover` | | `{"issuer", "poppy_version", "conversations": bool, "apis": [types]}` |
| `session` | `{"label"?}` | `{"session_id", "signed_in": false, "scope"}` |
| `signin` | `{"method": "direct" \| "device" \| "mediated", "scopes"?, "account"?, "label"?}` | `{"pending": {"url"?, "user_code"?, "fields"?}}` or `{"signed_in": true, "account", "scope"}` |
| `signin_continue` | `{"callback_url"?, "fields"?, "code"?}` | `{"signed_in": true, "account", "scope"}`, or `{"pending": {"code_required": true}}` when a Mediated Sign-In asks for a one-time code. `callback_url` is the redirect the runner captured; `fields` answer a Mediated form; `code` is the one-time code. A Device Sign-In continues by polling until the Company answers. |
| `send` | `{"text", "conversation"?, "message_id"?, "wait"?, "sender"?, "parent_conversation"?}` | `{"conversation", "message_id", "status", "messages": [{"role", "sender"?, "text"}]}` (`sender` is the step's name for the message's `author.type`, 8.4). `message_id` in params is a retry key: two sends with the same key send the same message, with the same id. `sender` is `"human"` for the User's own words (7.8; the agent's default otherwise). `parent_conversation` starts a Direct Conversation under that conversation (7.10), its id the result's `conversation`. |
| `handoff` | `{"conversation", "text"?}` | `{"status", "responder"}`: the agent's own, since the Company's 202 carries no state (8.9, 8.3). An agent that sends a note for the person first may take it from `text`. |
| `close` | `{"conversation"}` | `{"status", "responder"}`: what reads say afterwards, since the Company acts on a close after accepting it (8.12). |
| `read` | `{"conversation", "cursor"?, "wait"?}` | `{"messages", "cursor", "has_more", "status"}` |
| `sse` | `{"conversation", "cursor"?, "max_events", "wait"?}` | `{"events": [{"id", "type", "data"}], "last_id"}` |
| `api` | `{"api", "operation" \| "tool", "args"}` | `{"status", "body"}`, or `{"held"}` (below) |
| `web_join` | `{"url"}` | `{"joined": bool}` |
| `approve_op` | `{"operation", "decision": "approve" \| "decline"}` | `{"status"}`; an accepted conversation approval is `{"status":"sent","outcome":"unknown"}`; for a held write, `{"status", "result"?}` with the API's answer as `api` gives it |
| `signout` | `{"label"?}` | `{"revoked": bool}` |
| `state` | | `{"sessions": [...], "accounts": [...]}`, with no token values |
| `arm` | `{"attack", ...}` | `{"armed": "<attack>"}` (adversarial agent only; an unknown attack answers 501) |
| `attack` | `{...}` | the Company's answer to the armed attack, or a Poppy refusal `{ok: false, poppy_error}` (adversarial agent only) |

- **`api`.** `api` is `"openapi"`, `"mcp"` or an API entry's `url`. For OpenAPI, `operation` names one operation of the description: its `operationId`, or, for one without, `"METHOD /path"` with the method in upper case and the path exactly as the description writes it (`"POST /orders/{order_id}/exchanges"`); `args` is `{"params"?, "body"?, "files"?}`, where `params` fill path and query parameters by name. `files` is for an operation whose request body is `multipart/form-data`: each file field's name, with the file as `{"name", "type", "data"}`, `data` its bytes in base64; `body`'s members are the form's other fields. In a scenario, `files` names a file in `interop/files/` (`{"photo": "lake.jpg"}`), and the runner sends the agent its name, media type and content, so adapters need no access to the harness's files. For MCP, `tool` is a tool's name and `args` its arguments. A Poppy error from the Company (a 4xx or 5xx whose body or `WWW-Authenticate` carries an `error`) is `{"ok": false, "poppy_error", "status"}`, as for any step. Any other answer, an HTTP error without a Poppy error included, is `{"ok": true, "result": {"status", "body"}}` with the API's real status: a 404 is reported as 404, never as a 200 with the 404 inside.
- **Conversation approvals.** A valid acknowledgement proves that the approval message was accepted, while the action's outcome stays unknown. The adapter reports `{"status":"sent","outcome":"unknown"}` only with that acknowledgement for the same conversation and operation revision. A lost or malformed response remains an error; no English receipt text is parsed to infer delivery. O and ODUP check the Company's independent `performed_count`: zero before approval and exactly one afterward, including after the injected duplicate.
- **Held writes.** An agent that holds a write for its User's approval (at a Company without the Operations extension, say, or any upload of its User's file) answers `api` with `{"held": "<id>"}` and sends nothing. `approve_op` with that id plays the User's decision through the agent's own approval path, and its answer is the write's outcome: a refusal as `{"ok": false, "poppy_error"}`, a response as `{"status": "done", "result": {"status", "body"}}`. Scenarios run that step with `"when": "${w.held}"` (section 6).
- **`read` with a `cursor`** returns only the messages after that cursor, as the Company's events endpoint does.

An agent adapter MUST drive the implementation's protocol code, not a language model, so that a result never depends on one.

### 5.3 Company

Company adapters use a hooks protocol modelled on poppyseed's check command (not identical to it): `GET /hooks` lists the hook names supported, and `POST /hooks/<name>` performs one, with the params as the request body. A hook answers its result object itself, raw: `{"redirect": "..."}`, not wrapped. (Agent `/step` results are wrapped, `{"ok": true, "result": {...}}`, because a step can also be a Poppy refusal; a hook can't.)

| Hook | `params` | `result` |
| --- | --- | --- |
| `approve_authorization` | `{"url", "account", "scopes"?}` (the authorization URL the agent produced) | `{"redirect"}`: the callback URL with `code`, `state` and `iss` |
| `deny_authorization` | `{"url"}` | `{"redirect"}` with `error=access_denied` |
| `approve_device` | `{"user_code", "account", "scopes"?}` | `{}` |
| `deny_device` | `{"user_code"}` | `{}` |
| `mediated_answers` | `{"account"}` | `{"fields": {...}}`: values that sign that account in |
| `last_one_time_code` | | `{"code"}` |
| `end_sessions` | | `{"ended": n}` |
| `staff_join` | `{"conversation", "text"}` | `{}` |
| `staff_reply` | `{"conversation", "text"}` | `{}` |
| `propose_operation` | `{"conversation"}` | `{"operation"}`: an operation proposed in that conversation. A Company whose agent proposes when asked (`fixture.prompts.operation`) may return the proposal it already made. |
| `settle_operation` | `{"operation", "outcome"}` | `{}` |
| `require_nonce` | | `{}`: from now until reset, DPoP proofs need a server nonce |
| `rate_limit` | `{"requests", "retry_after", "endpoint"?: "token" \| "resource"}` | `{}`: the next `requests` requests answer 429 with `Retry-After: retry_after` |
| `expire_tokens` | | `{"expired": n}`: every access token issued so far is now expired |
| `issuer_path` | `{"path"?}` (default `/tenant`) | `{"path"}`: from now until reset, the issuer has that path and its server metadata is only where RFC 8414 3.1 inserts it, `/.well-known/oauth-authorization-server<path>` (scenario `DP`, S3) |
| `arm` | `{"attack", ...}` | `{"armed": "<attack>"}`: reconfigure the Company so the attack is its only deviation (adversarial Company only; an unknown attack answers 501) |
| `fixture` | | `{"accounts": [...], "scopes"?: {"read", "write"}, "openapi"?, "openapi_public"?, "openapi_write"?, "openapi_upload"?, "openapi_propose"?, "mcp"?, "prompts"?, "otp_account"?}`: the data scenarios need (below) |

`fixture` members: `scopes.read` is the list of scopes a sign-in asks for to read and `scopes.write` those it asks for to write too. Poppy leaves scopes to each Company (4.7), so every Company names its own (`orders:read`), and a Company adapter that names none can't run a sign-in scenario; scenarios refer to them as `${fixture.scopes.read}` and `${fixture.scopes.write}`. (Version 1's `scopes`, a list of every scope offered, is still read, as `scopes.all`.) `openapi` is a read needing `scopes.read`, `openapi_public` one that works signed out, `openapi_write` one needing `scopes.write`, each `{"api", "operation", "args": {"params"?, "body"?}}`; `openapi_upload` is a signed-out upload (`args.files`, section 5.2) and `openapi_propose` a signed-out write that proposes an operation naming what was uploaded as `${upload_id}` (scenario OU); `mcp` is `{"api", "tool", "args"}`; `prompts` are messages to the Company's agent: `hello` (any reply), `sign_in` (one it answers with an `authorization` event asking for the account's scopes when signed out, 8.11), `operation` (one it answers with an operation to approve when signed in, Operations 2 4); `otp_account` is an account whose Mediated Sign-In asks for a one-time code; `web_page` is the page a browser join returns to (scenario W), which the runner sets to the Company's home page, `https://<domain>/`, when the fixture names none.

A Company adapter that records the agent's protocol violations MAY serve them at `GET /violations` (authenticated) as `{"violations": [{"id", "detail"}]}`. The runner adds each to the cell's checks as an agent-side error, with `source` `company:<name>`. An agent adapter MAY do the same for what it recorded of the Company (the strict fake agent does): each becomes a Company-side check with `source` `agent:<name>`, filed by its basis in the same way.

A Company with no hook for a human step MAY instead ship a Playwright script (`interop/impls/<name>/consent.mjs`) that the runner calls with the consent URL and account.

## 6. Scenarios

A scenario is a JSON file in `interop/scenarios/`:

```json
{
  "id": "SD",
  "title": "Direct Sign-In",
  "requirements": ["4.5", "4.6"],
  "needs": { "agent": ["discover", "session", "signin", "signin_continue"], "company": ["approve_authorization"] },
  "steps": [
    { "agent": "discover" },
    { "agent": "session", "save": "s" },
    { "agent": "signin", "params": { "method": "direct", "scopes": ["orders:read"] }, "save": "pending" },
    { "company": "approve_authorization", "params": { "url": "${pending.pending.url}", "account": "${fixture.accounts.0}" }, "save": "consent" },
    { "agent": "signin_continue", "params": { "callback_url": "${consent.redirect}" }, "save": "done" },
    { "expect": { "${done.signed_in}": true } }
  ]
}
```

- A step names one actor (`agent`, `company` or `runner`) and one operation. `save` stores its result for later `${...}` references. `fixture` is the Company's `fixture` hook result. A string that is exactly one reference becomes the referenced value, of any type; a reference to nothing fails the cell.
- `expect` compares saved values: a value, or operators `$exists`, `$in`, `$ne`, `$contains`, `$includes_scope`, `$gte`, `$lte`, `$length`, `$length_gte`, `$some` (an array member matching a partial object) and `$match` (a regular expression). `poppy_error` expectations (`{"step": "...", "poppy_error": "invalid_session"}`) are how scenarios test refusals: a refused step fails the cell unless a later expectation names it this way.
- A value a step's params take from the fixture may itself carry references, such as `openapi_propose`'s `${upload_id}`; they are resolved, once more, when the step runs.
- `runner` operations: `first` (`{"of": [references]}`: the first that names something other than null, resolved without failing on one that names nothing; for a result one of two steps saved, an `api` answer or the `approve_op` of a held write), `wait` (`{"ms"}`), `fetch` (a raw request through the proxy, for one-sided probes; it carries `X-Interop-Probe` and no check judges it) and `assert_trace` (a predicate over the recording so far: `request_seen`, `nonce_retry`, `revoked`, `refresh_rotated`, `retry_after_respected`, `browser_joined`, `client_fetched`, `one_session`, and the harm oracles below). `browser_joined`: a browser join was answered 303 with a cookie (its result says whether the browser carried the cookie onward); inapplicable when the Company lists no `web.browser_session_endpoint`. `client_fetched`: before accepting the first request that needed the agent's keys (a Session header, whose delegation a key in `jwks_uri` signed, or a client assertion), the Company fetched the agent's `client_id` document and the `jwks_uri` it names (agents' keys are new in every cell, section 5.1); inapplicable when the Company fetched nothing of the agent's, as when it registers agents ahead of time (4.1's MAY). `one_session`: every request to the Company's resources carried the Session header, all with one `sid`, and none went to an OAuth endpoint (5.2). A predicate with nothing to judge (no nonce was ever asked for) makes the cell `unsupported`.
- **Harm oracles** (adversarial scenarios): `assert_trace` predicates that check the attack did no harm. `no_request_to {host}` and `token_not_sent_to {host}` fail if the honest side reached, or leaked a token to, a sink host; `performed_at_most_once {path, method?}` fails on a second 2xx for a write; `no_2xx_after {path?}` fails if a replayed (injected) request was accepted; `no_secret_in {value | values}` fails if a planted canary or an issued token appeared in an outbound request. Injected exchanges (section 3) are skipped where an honest request is judged, and judged where the replay or the sink is.
- **The attack-observed precondition:** `assert_trace {check: "attack_observed", path?, method?, status?, injected?, body_contains?}` must find the attack in the recording. If it doesn't, the cell is `error` with blame `harness` (an attack that never happened proves nothing), the way a predicate with nothing to judge is `unsupported`.
- **The adversarial agent's predicates** use `attack_observed` with `agent_attack` plus `agent_attack_rejected`: an accepted control and the exact 0.4 mutation must be visible, followed by the specific refusal. `YM` also reads the interop-only `performed_count` hook between invalid, approved and repeated requests. `YR` and `YD` also send an unused `jti` with the wrong URL so optional replay policy cannot hide a missing URL check. `NREP` checks both an accepted code exchange followed by its exact injected duplicate, with no second token minted, and a second consumed-code request with fresh assertion and DPoP credentials, which must return `invalid_grant`. Older `replay`/`mutation`, `replay_rejected` and `audience_rejected` predicates remain for historical 0.2 recordings and unit fixtures.
- **Adversarial fields:** `"adversary": "company" | "agent" | "network"` marks the side that misbehaves (`network` is the fault-injection proxy). `"faults"` is the proxy's fault list (section 3). `"permitted_by": "N10"` names a draft requirement that permits the attack, so a failure is the spec's, not the honest side's (section 9, rule 0). An `arm` step (an agent or Company op) arms the attack before it is sprung.
- A step whose operation the adapter answers 501 ends the cell as `unsupported`, unless the step is `"optional": true`.
- `"when": "${name.path}"` runs a step only when the reference names something other than null or false; otherwise the step is recorded as skipped. It is for steps one side's design needs and another's doesn't (approving a held write, section 5.2).
- The scenarios are the files in `interop/scenarios/`; [interop-testing.md](history/interop-testing.md#scenarios) lists them by area. The five added last were named there before they were written, so each is defined from the draft section it targets:
  - `H` (8.7 to 8.9): a conversation, a handoff answered with `conversation_id`, the Company's `staff_join`, then a read showing a Company message whose `author.type` is `human`.
  - `DC` (8.3, 8.8, 8.10, 8.12): a conversation, then a Direct Conversation under it (`send` with `parent_conversation` and `author.type` `human`), a reply in it, the parent refusing a message with `direct_conversation_open`, the User's words, `close`, and the parent taking a message again.
  - `W` (6): a Session, then `web_join` with the fixture's `web_page`: the agent's browser loads the join page and reads its code, the agent authorizes the code at `{endpoint}/authorize`, and the browser submits it; `browser_joined` and the browser checks judge the wire. In Node the agent's image reads pages with lol-html in WebAssembly (`interop/impls/pda-agent/html-rewriter.ts`), as the Worker reads them with `HTMLRewriter`.
  - `CM` (4.1, 5.3): a Session's first request, a signed-out API call, then `client_fetched`; the validator judges the agent's documents and `company.metadata-fetch-credentials` the fetches.
  - Changed for 0.4 on 12 November, when 0.3 was dropped: the read-shape and handoff checks judge 0.4's shapes alone, and the adversarial agent's probes declare 0.4.
  - Changed for 0.3 on 29 October, when the grid first ran our pair at 0.3: `S0` makes two signed-out API calls in one Session and checks them with `one_session`, since a Session sends nothing until its first request (5.2); `N` and `XN` sign in first, since only token requests and DPoP-bound calls carry a proof at 0.3 (4.5). `O2` went with Operations 1. `NREP` now replays an authorization-code exchange at 0.3, with a successful first exchange and a recorded exact duplicate required.
- `readings` lists the section 7 questions the scenario depends on, which attribution rule 3 considers when the trace shows one of them mattered; `live: true` marks scenarios the live lane may run.

## 7. Readings

The open questions whose answers change the wire format. An adapter declares its reading; the runner checks the declared reading against the trace.

| Id | Question | Values |
| --- | --- | --- |
| S1 | Client assertion `aud` | `issuer`; `token-endpoint` (the token endpoint, at the device and revocation endpoints too); `endpoint` (the endpoint the assertion is sent to); `either` |
| S2 | Assertion `typ` and lifetime | `jwt-60s` (`typ: "JWT"`, at most 60 s); `jwt-300s` (`typ: "JWT"`, at most 300 s); `lenient-120s` (any `typ`, at most 120 s); `lenient-300s` (any `typ`, at most 300 s); `any` |
| S3 | Metadata location for an issuer with a path | `insertion`, `append`, `either` |
| S4 | `scope` on a signed-out Session request | `omit`, `poppy-read`, `either` |
| S23 | DPoP nonce scope | `per-origin`, `per-company` |

Our own adapters' readings, and why we chose them, are in [readings.md](readings.md).

## 8. Checks

After each cell the runner checks the recording, independently of either side's opinion.

- Discovery documents and client metadata go through [`src/validator/`](../src/validator).
- Trace checks over each exchange, named with the mock Company's violation ids (`test/mock-company/violations.ts`) where one exists: assertion `typ`, `kid`, lifetime and `jti` reuse; DPoP `htu`, `htm`, `ath`, `iat` and `jti` reuse; tokens in URLs; a Session Token sent to a host the Company didn't list; redirects followed with credentials.
- Browser joins (5), by the mock's ids and bases: the browser assertion goes in a form POST's body, never the URL (`browser-assertion.in-url`, MUST), with `typ` `poppy-browser+jwt`, `iss`, `iat` and `exp` at most 60 s apart, `aud` the endpoint it went to, a fresh `jti`, and `return_to` HTTPS on the Company's domain.
- Company-side checks, prefixed `company.`: `WWW-Authenticate` on 401, `Retry-After` on 429, OAuth error bodies, `iss` on authorization responses, SSE event ids, and the shape of a read of events and of a send with `wait`, which must carry `events`, `cursor`, `has_more`, `status` and `responder` (7.5's MUST; under 7.3 a send with `wait` answers as a read would). And, each with its basis:
  - `company.browser-session-response` (Rule, 5): a join the Company accepted (2xx or 3xx) answers 303 to `return_to` and sets a cookie; a 400 refusal isn't judged here.
  - `company.browser-cookie` (MUST, 5): that cookie is `Secure` and `HttpOnly`, and not `SameSite=Strict`.
  - `company.handoff-response` (Rule, 8.9, 8.3): a handoff the Company accepted answers 202 with `conversation_id`. The read-shape checks want 8.7's four state fields, and `company.sse-event-id` takes `working` stream events without an id, as text-delta.
  - `company.direct-parent-open` (Rule, 7.10): while a Direct Conversation is open (from the Company's 2xx to a start with `parent_conversation_id` until a close of either, or a `direct_closed` event the agent read), a message or handoff to its parent gets 409 `direct_conversation_open` naming it.
  - `company.confirm-repeated` (Rule, Ops 5.2; Ops 6's MUST): a confirm sent again for an operation the Company already answered with a confirmation gets that operation back with the same `confirmation`, not an error (401, 403 and 429 aside, which concern the token, its scopes or a limit).
  - `company.metadata-fetch-credentials` (Guides, "Fetching metadata safely"; a warning): the Company's fetch of a `client_id` document or key set carries no cookie, `Authorization` or `DPoP`.
- An agent's declared readings of S1, S2 and S4, checked against what it sent, as `reading.<id>` warnings. S1 is checked at every endpoint a client assertion goes to (token, device authorization, revocation). The runner finds server metadata wherever either S3 reading puts it (inserted before an issuer's path or appended after it).
- Refusals a Company's declared readings explain, as `reading.<id>.refused` warnings: an OAuth request answered `invalid_client` or `invalid_grant` that carried a client assertion `aud` other than the one the Company's S1 reading wants at that endpoint, or, when the Company reads S2 `jwt-60s`, an assertion without `typ: "JWT"` or living over 60 s (`lenient-120s`, `lenient-300s`: living over 120 s or 300 s). They judge neither side; attribution reads them as the evidence rule 3 needs (section 9).

Each check reports `{id, side, severity: "error" | "warning", basis, exchange, detail, source}`, and its basis sets its severity ([conformance-levels.md](conformance-levels.md)):

- **Error.** A MUST, an RFC's MUST or a normative rule without a key word, broken. Only errors fail a cell.
- **Warning.** A SHOULD, the Guides, or our reading of an open question. For example: S2's `typ`, `kid` and lifetime; S1's array `aud`; `token.unlisted-host` (N10); `redirect.credentials-followed` (the Guides). A reading is tentative: a failure it explains is the spec's.

A trace check that shares an id with the mock rests on the mock's basis. A Company adapter's `GET /violations` lists every check it recorded, with its `basis` and `level` (`failure`, `warning` or `tentative`; [spec/grounding.md](../spec/grounding.md#mock-company-checks)). The runner makes a failure an error and anything else a warning, and treats a record with no known basis as a failure. Both profiles of our mock report everything.

### 8.1 What the run is

Before any cell, the runner checks that each implementation is what its registry entry says (`manifestMismatch` in `interop/runner/expectations.ts`), and marks one that isn't as broken, so its cells are errors blamed on the harness: the profile `INTEROP_AGENT_PROFILE` or `INTEROP_MOCK_PROFILE` sets is the manifest's `profile`; the version `INTEROP_POPPY_VERSION` sets is its only `poppy` version; an `adversarial` entry's manifest says so; and in the live lane, an agent given the live identity reports it as its `client_id`. Two whole runs have passed while testing something else: on 23 October the live lane dropped a registry entry's `env`, so both fake agents ran as plain `pda`, and on 24 October the live identity named a host that had answered 404 since a domain move (section 10).

## 9. Results and attribution

A run writes `interop/results/<run>/results.json`:

```json
{
  "interop": 1,
  "run": "2026-11-12T01:22:40Z",
  "spec": "Personal Agent Protocol Drafts 0.4 (2026-11-11)",
  "implementations": [{ "name": "pda", "role": "agent", "commit": "a7fbe96", "readings": {} }],
  "cells": [
    {
      "agent": "pda", "company": "lenient-company", "scenario": "SD",
      "outcome": "pass" | "fail" | "unsupported" | "error",
      "blame": "agent" | "company" | "spec" | "harness" | null,
      "rule": "adversarial" | "violation" | "warning" | "grid" | "reading" | "unattributed" | null,
      "steps": [{ "actor", "op", "ms", "ok", "error"? }],
      "checks": [...],
      "har": "SD/pda__lenient-company.har",
      "flaky": true,
      "attempts": [{ "outcome", "reason"?, "har" }]
    }
  ],
  "flaky": [{ "agent", "company", "scenario" }],
  "staleKnown": [{ "agent", "company", "scenario", "issue", "reason" }],
  "levels": { "failure": 12, "warning": 340, "tentative": 95 }
}
```

- `pass`: every step and expectation held and no check reported an error. Warnings don't fail a cell. `levels` counts the interop cells' checks by level (failure, warning, tentative), and the console and report print it.
- `error`: the harness failed (a container didn't start, an adapter crashed); blame `harness`.
- A cell also carries `reason` (why it didn't pass, and what decided its blame) and `known` (a known failure's issue). The run carries `lane`, on the local lane `isolation` (the internal network's name and the egress probe's outcome, section 3), and each implementation its manifest's `relaxations`.
- **Retries.** A cell that fails or errors runs once more, after both adapters are reset again as for any cell (`--no-retry` turns this off; a cell whose implementation never started isn't retried). The cell records both runs in `attempts`, and the first run's HAR stays beside the second's (`SD/pda__x.attempt2.har`). A cell that passes the second time is a pass with `flaky: true`: it is listed apart, in the console and the report, doesn't fail the run and never matches a known failure. One that fails again is recorded as its second run.

A cell is a **security cell** when a side is an adversarial implementation, or its scenario names an `adversary` or a `faults` list. Security cells go in a separate security grid in the report, never count toward the interop pass rates, and never stand in as grid references (rule 2).

Attribution, applied in order, labels each failed cell with the rule that decided it:

0. **adversarial (applied first, for a cell with an adversarial side):** the adversarial side's violations are expected, so they don't count against it. The cell **passes** when the honest side refuses (the expected `poppy_error`, or status 0 for the agent's own refusal) and no harm oracle fires. A failed cell is blamed on the honest side with rule `adversarial`, or on the `spec` (still rule `adversarial`) when the scenario names a `permitted_by` the draft hasn't closed. A Company's recorded violation of an injected or adversarial request is a warning, not an error. (A network-fault cell has no adversarial side and falls through to the rules below; it is still a security cell.)
1. **violation:** checks found errors on one side only. An error the Company recorded that is exactly a declared reading difference is not counted. That is a check belonging to a section 7 question (S1: `client-assertion.aud`, an RFC check) where the two sides' declared readings of that question are incompatible; a cell whose every error is such a check goes to rule 3 at once. The S2 checks (`client-assertion.typ`, `.kid`, `.lifetime` and the same for `session-assertion`) rest on our reading, so they are warnings and go to rule 1b. A strict Company refusing a typ-less assertion from an agent that declared S2 `any` is the spec's open question; an agent that declared `jwt-60s` and sent no `typ` broke its own reading (rule `warning`). A cell with no one-sided errors whose trace has a `reading.<id>.refused` check (section 8) also goes to rule 3 at once when the two sides' readings of that question are incompatible. A Company that records no violations shows the same open question this way: its device endpoint answers `invalid_client` to an `aud` its S1 reading doesn't accept, from an agent that declared another reading.
1b. **warning, and readings below a failure:** with no error to decide the cell, a check one side recorded of the other at a lower level does (the mock Company's of the agent, the strict fake agent's of the Company). If it rests on our reading, the cell is blamed on the `spec` (rule `reading`). The exception is when both sides declared compatible readings of that question and the agent sent otherwise: then rule `warning` blames the agent. If it rests on a SHOULD or the Guides and is recorded on one side only, rule `warning` blames that side. Departing from a recommendation is not a violation, so the blame is at warning level. The runner's own trace and validator warnings are passive observations, not a Company's refusal, and decide nothing here.
2. **grid:** the same agent passes this scenario against the reference Company (`lenient-company`, the mock with its S2-lenient settings; `strict-company` is the same mock with strict assertions) but this Company fails it with every agent that ran it: blame the Company. Or this agent fails it with every Company it ran against, while this Company passes it with the reference agent (`lenient-personal-agent`) or any other: blame the agent. Unsupported and errored cells don't count.
3. **reading:** the two sides declare incompatible readings of a question the scenario lists in `readings`, or that one of the cell's error checks belongs to (rule 1), and the trace shows that question mattered: a `reading.<id>.refused` check (the Company refused what its reading doesn't accept) or a Company-recorded error of that question. Blame `spec`. Declarations that merely differ are not evidence: poppy-demo × lenient-company fails D on poppy-demo's issuer-origin rule, though the two read S3 differently, and without evidence the cell goes on to rule 4. (A `reading.<id>` warning isn't evidence either: it says the agent sent something other than its own declared reading, so the declared difference wasn't what went over the wire.) Compatible means equal, or `either` on one side. For S2, both assertion type and lifetime must fit: an agent’s maximum lifetime cannot exceed the Company’s, and a Company requiring `typ: "JWT"` needs an agent that sends it. Thus `jwt-300s` and `lenient-120s` are incomparable. Final 1.0’s 300-second bound is normative; exceeding it is a violation, not a reading difference. For S23 a Company reading `per-origin` is incompatible only with an agent reading `per-company`.
4. **unattributed:** none of the above.

A failed or errored cell that matches an entry of `interop/known-failures.json` (`{"version": 1, "failures": [{agent, company, scenario, blame, checks?, errors?, issue, reason}]}`) is shown with its issue link and reason. Any of `agent`, `company` and `scenario` may be `"*"`, for any: one root cause is one entry (`{"agent": "pi-poppy", "company": "*", "scenario": "SE", "blame": "agent", "errors": ["invalid_session"]}`). The rest says what the failure looks like, so that a different failure in a covered cell is still unexpected:

- `blame` (required): the side attribution blames, `agent`, `company`, `spec` or `harness`, or `null` for unattributed. The cell's must be the same. Where one root cause is blamed differently across the cells an entry spans (rule 2 can decide a cell its neighbours leave unattributed), `blame` is a list, and the cell's must be one of them.
- `checks`: every error check the failure may show (trace, validator and Company-recorded ids). Each of the cell's error checks must be in the list; warnings don't count. Absent, the cell may have none.
- `errors`: the codes its first failed step may show (`failureCode` in `interop/runner/attribution.ts`): the Poppy error of a refusal (`invalid_grant`), `expect <path>` for an expectation that didn't hold (`expect outcome.poppy_error`), the text before the first colon of any other step error, or `error` for a cell that errored before any step. A cell that failed only on its checks has no code, and needs none. Absent, the cell may not have one.

An entry matches a cell when it covers the cell and all three hold. When several entries match, the one with the fewest wildcards wins, then the first in the file. A covered cell that matches no entry is unexpected, and its `reason` names the entry it missed and what differed. The runner exits 1 when any failed or errored cell isn't a known failure, or when a known failure is **stale**: it matched no failed or errored cell (fixed, changed, or wrong), though the run could judge it. A run judges an entry when each field it names matched a cell that ran and each `*` spans a dimension the run covered whole (every honest agent, every honest Company or every scenario of the lane without an `adversary` or `faults`; the adversarial implementations and scenarios run apart, section 13, so a full grid without them still covers its dimensions), so a partial run (`--agents pda --companies lenient-company`, or `--scenarios D`) never flags an entry for cells it didn't run. A wildcard entry is stale only when no failed cell it covers is left, even where a more specific entry is the one attached to those cells. Stale entries are listed in the console, in `staleKnown` and in the report.

The runner also writes `index.html`: the grid, one table per scenario with agents as rows and Companies as columns, each cell linking to its steps, checks and HAR. A check that found a departure carries its `parts` (`subject`, `expected`, `got`, optionally `detail`) beside `detail`, and the page shows them apart. `results.md` is the same run as Markdown: the counts, each failed or errored cell with its error findings, and the grids.

## 10. Lanes

- **Local:** every implementation in a container, on the private, internal network, with no way to the internet (section 3, Isolation). The default.
- **Live:** public deployments, signed-out scenarios only (`D`, `S0`, `ML` (MCP listing, no tool call), `CL` where the Company allows signed-out conversations: one labelled test message, a read, a follow-up, then a close, so nothing is left open. `C`, which leaves the conversation open, and `CC`, which needs the Company to close it, run only in the local grid), at most one request a second per Company. The live lane uses real names and public TLS, and only our own agents (`pda`, and the lenient and strict fakes), which need the internet, so the runner keeps it apart from the local lane: it creates no internal network and runs our agents alone, on Docker's default bridge with its control port published, and no third-party image. It first ran on 13 October 2026, against `alpine-retail-live` with its developer's approval. A live Company has no adapter, so it is never reset, its hooks answer 501 (an optional hook step is skipped), and it gets a fixture of one greeting, which says it is a test and needs no action (`LIVE_GREETING` in `interop/runner/cli.ts`). Companies are registry entries with `url` and an expected `protocolVersion`; none is registered since the 0.2 ones were retired (section 14). A discovered version mismatch stops the cell before Session authentication; scenarios are those marked `live` that need no Company hook; nothing is recorded, so only steps and expectations decide a cell. Agents pace themselves from `INTEROP_PACE_MS`.
- **The live lane's identity.** A public Company fetches the agent's `client_id`, so the live lane needs one on the internet. Our deployed Worker serves a separate interop test client at `<PUBLIC_ORIGIN>/poppy/interop/client.json` with its public keys at `/poppy/interop/jwks.json`, only when the deployment sets `INTEROP_LIVE_JWKS`. It has its own key, never the real client's, and no redirect URI. Its private key stays on the runner's machine, in the gitignored `interop/.live-identity.json` that `scripts/interop-live-identity.mjs` writes. When that file exists, the runner passes the `client_id` and the key to our own agents' containers (not one marked `"live": false`) (`INTEROP_LIVE_CLIENT_ID`, and `INTEROP_LIVE_KEY` through the docker CLI's environment, not its arguments), and the agent signs as that client. No other implementation gets them, and the local lane never uses them. Without the file the agent names itself at `pda.agent.interop.test`, which no public Company can fetch: a Company that checks client metadata refuses `S0`, `N` and `CL` with `invalid_client`, and only `D` says anything. The runner says which identity it is using before it starts, then fetches it as a Company would, without following redirects (`checkLiveIdentity` in `interop/runner/expectations.ts`): the `client_id` document must be JSON naming itself, with `private_key_jwt` and a key set on the same origin, and that key set must hold the runner's key, the same `kid` and public point. Anything else stops the run before an agent starts or a request reaches a Company. A `client_id` on another origin than `deployment.local.json`'s `PUBLIC_ORIGIN` only warns, since a static host is a supported setup.
- **The live lane never runs adversarial cells.** Adversarial implementations and scenarios with an `adversary` or `faults` list are dropped from the live lane: we never attack a public deployment, whoever's it is.
- **Our fakes, but not the sloppy one.** The lenient and strict fake agents send what `pda` sends (the lenient one adds retries naming the same Company), so the live lane runs them, with the same identity. The strict agent matters most there: the live lane records nothing, so its findings at `GET /violations` are the only checks a live cell gets; in the live lane it takes every host but its own for the Company's. The sloppy agent is `"live": false`: its departures are deliberate, and a public deployment hasn't agreed to them.

## 11. One-sided vectors

Hardening cases that need no peer (SSRF, duplicate JSON members, redirects on `client_id`, malformed documents) stay out of the grid, as one-sided tests: our validator's fixtures in `test/validator.test.ts` and the mock Company's tamper rows in `test/mock-company.test.ts`. Version 1 of this document also exported both as language-neutral vectors in `interop/vectors/`, in Datalayer's schema (`id`, `kind`, `role`, `requirements`, `check`, `input`, `expect`), to seed a shared vectors repository. That repository was never made and nothing consumed the files, so they and the tests that kept them current were removed. The other direction, Datalayer's cases and the cross-check against independent validators, was 0.1 and 0.2 only and was retired with them (section 14).

## 12. Versioning

This document is version 1; every JSON body above carries `interop: 1` or `version: 1`. A change that breaks an adapter increments it, and the runner supports the previous version for one release.

## 13. The own-project rule

Adversarial testing (the malicious implementations and the fault-injection proxy of [`docs/adversarial-interop.md`](adversarial-interop.md)) is restricted to implementations this project owns, to control risk and blast radius.

- An adversarial or faulted cell runs only on the **local** lane, and only when every honest side is `owner: "self"`, with one exception: `evil-company` may attack any agent, our own or another project's built at its pinned commit, when the scenario has no proxy faults. The owner approved that exception on 13 October 2026. The runner refuses any other adversarial cell (it marks it `error`, blame `harness`, with the reason) and never runs one in the live lane. The usable cells are therefore `evil-company` × every agent, proxy faults over `pda × lenient-company`/`strict-company`, and `evil-personal-agent × lenient-company`/`strict-company` at 1.0 and `lenient-company-v04` at 0.4. CI selects these own-project cells explicitly and uses `--require-supported` to fail on skipped coverage.
- **No flag lifts the rest.** Running another adversarial implementation against someone else's, or anything adversarial in the live lane, is a code change, which goes through the disclosure process in [`SECURITY.md`](../SECURITY.md). A failure in an adversarial cell may be a vulnerability in someone's project, so its results stay in the gitignored `interop/results/` and go to its maintainers privately before anything about them is committed, and a spec-permitted attack goes to the authors as an N-numbered issue.
- `--image-tag <tag>` (default `latest`) builds and runs under a tag, so an adversarial run with `--image-tag adv` never overwrites the `:latest` images a full grid run is using. It is the only way to keep a side build of our images: don't `docker tag` them by hand. A side tag costs disk until it is removed (`docker image rm poppy-interop/<image>:<tag>`); the runner never removes images.

## 14. Retired with 0.1 and 0.2

On 28 October 2026 the project dropped Poppy 0.1 and 0.2 ([decision 37](decisions.md#37-03-alone-what-dropping-01-and-02-overturns-and-settles)). Everything below spoke one of them, so it left the registry, the runner and CI together. Each comes back as a new entry when it speaks 0.3; the pins say where each stood, for anyone picking one up.

| What | Role | Last pin |
| --- | --- | --- |
| `datalayer-ts`, `datalayer-py` | agent and Company | `datalayer/personal-agent-protocol` at `00216eb` (0.1); `-v02` entries at `0ff43c5` |
| `pi-poppy` | agent and Company | `richardanaya/pi-poppy` at `11ea106` |
| `poppy-demo` | agent and Company | `irvinebroque/poppy-demo` at `02a9b30` |
| `poppyseed`, `poppyseed-live` | Company | `akshay5995/poppyseed` at `f479fb6` |
| `ilmer`, `ilmer-live` | Company | `rbirkby/Ilmer.org` at `de0d1ec` |
| `print-with-poppy` | Company | `spenciefy/print-with-poppy` at `3360d8b`; the `-live` and `-sandbox-live` deployments expected 0.2. Back at 0.3 on 29 October (below) |
| `adonis-agora` | agent and Company | `DavideCarvalho/adonis-agora-agent` at `e139b95`, `adonis-agora-authkit` at `fe2a3ff` |
| `everruns` | agent and Company | `everruns/everruns` at `aceb2e2` |
| `tipping-co` | agent and Company | `timothyohare/personal-agent-protocol` at `fb7b4e6` |
| `alpine-retail-live`, `crosswalk-live`, `stacktree-live`, `planmyvisit-live`, `saferate-live` | live Company | registered expecting 0.2 |
| `official-validator` and `npm run interop:official`, `npm run interop:flaws` | Company checks | `personal-agent-protocol/personal-agent-protocol` at `39b35bd` (0.2); `spec/official-checks-0.2.json` mapped its checks to ours |
| Datalayer's conformance vectors and the validator cross-check (`interop/vectors/`) | one-sided | 0.1 and 0.2 |
| `lenient-company-v02` | Company | our mock at 0.2 |
| `evil-personal-agent` | adversarial agent | ours; its attacks (scenarios YR, YD, YA, YT, YS, YK, YU, YM) were written against Session Tokens and Operations 1 |
| Scenarios O2, XO, XT | Operations 1 | a second proposal, an operation altered in place, one stuck in progress: Operations 2 has no proposals or tracking |

The adversarial agent and the Hypothesis client in `test/hypothesis/` were ported on 29 October. The restored `evil-personal-agent` uses Session JWTs, delegated keys, OAuth access tokens and Operations 2. Its eight IDs retain their names but test the current wire: URL binding, audience, DPoP key binding, scopes, observed refresh rotation, User isolation and approval revisions. `NREP` now replays a successful authorization-code exchange. The retired 0.2 attack implementations remain historical; optional `jti` replay rejection and Operations 1 confirmation are not asserted as 0.3 requirements.

**Back at 0.3.** On 29 October we read each retired peer's head. Only print-with-poppy implements the 28 October text: `b340741` (28 October) takes the Session header, Operations 2 and Mediated Sign-In 1, and says agents built for 0.2 or the earlier delegated-keys draft can't use it. It is registered again as `print-with-poppy` at that commit, and its live store as `print-with-poppy-live` (discovery only), which our validator found valid at 0.3 that day; its Agent Sandbox still declared 0.2. Its first run that day ([results](interop-results/README.md#print-with-poppy-at-03)): our three honest agents pass all ten scenarios it claims, and the sloppy agent fails only its known `aud`; the initial restoration used a full builder, and the later conformance run uses the pinned slim runtime base with temporary build tools to reduce VFS snapshots. Datalayer's SDKs and poppyseed follow the earlier 0.3 draft, with Session Keys and Session Tokens, and everruns refuses 0.3, so none of them can pair with ours yet.

**Official kit back at 0.3.** The website download retrieved on 3 November (matching `kit/company` at upstream `7205250`) is pinned by archive and file hashes in [spec/company-kit-2026-11-03](../spec/company-kit-2026-11-03/README.md); the 29 October download stays as a record. `node scripts/check-company-kit.mjs --reviewed-findings --output /tmp/company-kit.json` runs its CLI unchanged over local HTTPS against our mock profiles and hosted dummy Company's workerd handlers. This one-sided Company check is outside M×N cell totals. [Raw verdicts, DPoP prerequisite findings and manual checklist review](company-kit-review.md). The old `interop:official` and `interop:flaws` commands are not restored.

## 15. Retired with 0.3

On 12 November 2026 the agent dropped 0.3 ([decision 49](decisions.md#49-03-dropped-the-agent-mock-validator-and-interop-speak-04-alone)) and speaks 0.4 alone. `print-with-poppy` (`spenciefy/print-with-poppy` at `b340741`) and `print-with-poppy-live` (discovery only) served only 0.3, so they left the registry; each comes back as a new entry when it serves 0.4. Its adapter stays in [`interop/impls/print-with-poppy-company/`](../interop/impls/print-with-poppy-company) as the record and a start for that, unbuilt by any run. The mocks no longer link 0.3 from `supported_versions`, and `evil-personal-agent` moved to raw 0.4 requests with Operations 3 approvals. CI runs the 0.4 kit (`spec/company-kit-2026-11-11`), with and without the DPoP probe patch; the 0.3 kit stays pinned as history, and `--verify-pin` still checks its hashes. Section 14's last two paragraphs are the 0.3 record.

**Back at 0.4.** Print with Poppy moved to 0.4 the same day, at `ae453ed` ([spenciefy/print-with-poppy#33](https://github.com/spenciefy/print-with-poppy/pull/33)). It implements the text of upstream `ad20217`, four commits after our pin `ed47408`; none of the four changes a 0.4 page. `print-with-poppy` is back in the registry at that commit, with the same adapter, now declaring 0.4 and Operations 3, and CI runs it against our agent in its own step. `print-with-poppy-live` and a new `print-with-poppy-sandbox` are discovery (D) only: a signed-in journey at either needs our interop client on the store's allowlist.

<a id="print-with-poppy-delegation"></a>**Its first 0.4 run.** Against our agent, `print-with-poppy` passes D, SD, SMC, SX and SO, and fails S0, AO, AS, OU and CM, which are known failures. The store refuses every Session JWT our agent sends with `400 invalid_session` ("carry its delegation in the pap_dlg header"). Its verifier at `ae453ed`, and on its `main` that day, reads the delegation from `pap_dlg` and requires `typ: pap-delegation+jwt`. The 0.4 text names `poppy_dlg` (5.2) and says the delegation's `typ` "MUST be `poppy-delegation+jwt`"; its changelog lists `pap_dlg` and `pap-delegation+jwt` as names from earlier in the 0.3 draft. Our agent sends the 0.4 names, which the CI HAR shows and which the pinned kit's `session-jwt` and `delegation` schemas require, so the agent is unchanged. The five that pass are discovery and the sign-in and sign-out journeys, which make no API request. When a later commit reads `poppy_dlg` and the pin moves to it, the entry goes stale and fails the run, as section 9 describes.

<a id="print-with-poppy-at-bd1dc43"></a>**At `bd1dc43`.** The store's PR #36, merged on 12 November, reads `poppy_dlg` and `poppy-delegation+jwt`; nothing else in it changes what the adapter starts. The pin moved to `bd1dc43` and the known failure went with it. `pda` and the lenient and strict agents pass all ten scenarios, with no check failures or warnings ([results](interop-results/README.md#print-with-poppy-at-04)).

<a id="print-with-poppy-sandbox-live"></a>**The live sandbox, 12 November.** `print-with-poppy-sandbox` lists S0 beside D since that day, with `getCatalog` as its public read: a signed-out Session and two reads, nothing written. Against `sandbox.printwithpoppy.com` at 20:42 UTC, from our live identity, D passes for `pda` and the strict agent, and S0 fails for both at its first API call: `400 invalid_session`, asking for the delegation in `pap_dlg`. The sandbox still runs a commit from before `bd1dc43`. The store's Cloudflare workflow deploys production on every push to `main`, and the sandbox only when someone dispatches it, so S0 was a known failure until the sandbox was redeployed. The store redeployed it the same evening: at 21:13 UTC D and S0 pass for `pda` and the lenient and strict agents, with no check failures or warnings, and the known failure is gone. Production takes real payments and stays at D.

<a id="print-with-poppy-at-20a3d56"></a>**At `20a3d56`.** The store's PR #38, merged on 12 November, writes an approval's `payment.amount` as a decimal string in whole units (`"12.00"`, with `amountUnit: "major"`), where it wrote integer cents (`1200`). Our cards had shown that as "1200 USD". The one commit between, PR #37, registers Muse in production and changes nothing the adapter starts, and the server still imports only the two `src` files the image copies. The pin moved to `20a3d56`. In CI's Print with Poppy step on 12 November, `pda` passed all ten scenarios with no check failures, warnings or known failures. Since the same evening CI runs the lenient and strict agents there too, and all 30 cells pass with no check failures or warnings.
