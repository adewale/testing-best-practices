/**
 * Our Personal Agent as an interop agent (docs/interop-spec.md, section
 * 5.2). It drives src/poppy directly, never the model: the same PoppyClient,
 * sign-in, conversation, API and operations code the Durable Object runs,
 * in Node, with SQLite from node:sqlite in place of the Durable Object's and
 * jobs run when a step waits on them instead of by alarms.
 *
 * Port 8080: our client metadata and keys at `$INTEROP_ORIGIN/poppy/*.json`
 * (behind the recording proxy), and `/poppy/callback` and `/poppy/sign-in` for Direct Sign-In.
 * Port 8081: the manifest and control API, with `Authorization: Bearer $INTEROP_SECRET`.
 *
 * No relaxation of src/poppy is needed: `*.interop.test` names already pass
 * its public-host check, and Node trusts the run's CA via NODE_EXTRA_CA_CERTS.
 * `INTEROP_FAULT` breaks the agent on purpose, to prove attribution; it lives
 * only here, in the adapter's network seam, never in src/poppy.
 * `INTEROP_AGENT_PROFILE` makes it one of the fake Personal Agents
 * (`lenient`, `strict` or `sloppy`; profiles.ts), in the same seam.
 * In the live lane, `INTEROP_LIVE_CLIENT_ID` and `INTEROP_LIVE_KEY` give it
 * the interop test client our deployed Worker publishes (live-identity.ts).
 */
import { decodeJwt, decodeProtectedHeader, exportJWK, generateKeyPair, SignJWT } from "jose";
import { memoryState } from "../shared/cloudflare-workers.ts";
import { authorized, body, failure, json, serve, setting } from "../shared/serve.ts";
import { memorySql } from "./sqlite.ts";
import { AttachmentError, migrateAttachments, saveAttachment } from "../../../src/attachments.ts";
import { callMcpTool, callOpenApi, listMcpTools } from "../../../src/poppy/apis.ts";
import { PoppyClient, PoppyError, type JobName, type PoppyHost } from "../../../src/poppy/client.ts";
import { departure, ours, shown } from "../../../src/diagnostic.ts";
import { closeConversation, conversation as conversationRow, handoff, readConversation, sendMessage } from "../../../src/poppy/conversations.ts";
import { browse } from "../../../src/poppy/browser.ts";
import { FetchBrowser } from "../../../src/poppy/fetch-browser.ts";
import { PROTOCOL_VERSIONS } from "../../../src/poppy/protocol-version.ts";
import { DiscoveryError, isCompany, type Company, type SignInType } from "../../../src/poppy/discovery.ts";
import { identifiedFetcher, type Fetcher } from "../../../src/poppy/fetch.ts";
import type { Json } from "../../../src/poppy/json.ts";
import { randomId } from "../../../src/poppy/jwt.ts";
import { currentKey } from "../../../src/poppy/keys.ts";
import { CompanyLimiter } from "../../../src/poppy/limiter.ts";
import { decideLocal } from "../../../src/poppy/operations.ts";
import { writtenBy } from "../../../src/poppy/message-author.ts";
import { EndpointRequest } from "../../../src/poppy/outgoing.ts";
import { MAX_SSE_CHARS, readSseChunk, SseLineEndings } from "../../../src/poppy/sse.ts";
import { handleIdentityRoute } from "../../../src/poppy/routes.ts";
import {
  completeDirectSignIn,
  pollDeviceSignIn,
  pushDirectSignIn,
  signOut,
  startSignIn,
  submitCredentials,
  submitSignInCode
} from "../../../src/poppy/signin.ts";
import { approvalsTable, inboxTable, intentsTable, migrate, signInsTable } from "../../../src/poppy/store.ts";
import { rows } from "../../../src/rows.ts";
import type { Card } from "../../../src/poppy/wire.ts";
import { LiveIdentityClient, liveIdentityFrom } from "./live-identity.ts";
import { changedClaims, Endpoints, lenientFetch, PROFILE_READINGS, profileFrom, sloppyRequest, StrictObserver, StrictRefusal, type Resign } from "./profiles.ts";
import { NodeHTMLRewriter } from "./html-rewriter.ts";
import { readApproval } from "../../../src/poppy/approvals.ts";
import { ApprovalAcknowledgements } from "./approval-delivery.ts";
import { ATTACKS, AttackSetupError, AttackUnsupported, freshCodeReplay, prepareAttack, type AttackId, type AttackPlan } from "./attacks.ts";

const NAME = process.env.INTEROP_NAME ?? "pda";
const ADVERSARY = process.env.INTEROP_ADVERSARY === "agent";
/** Interop-only: a fake Personal Agent's profile (profiles.ts). Off unless the registry sets it. */
const PROFILE = profileFrom(process.env.INTEROP_AGENT_PROFILE);
const SECRET = setting("INTEROP_SECRET");
/** Live lane only: the interop test client's public client_id and its key, from the runner (live-identity.ts). */
const LIVE = liveIdentityFrom({ INTEROP_LIVE_CLIENT_ID: process.env.INTEROP_LIVE_CLIENT_ID ?? "", INTEROP_LIVE_KEY: process.env.INTEROP_LIVE_KEY ?? "" });
// Read once; nothing else in this process needs the key in its environment.
delete process.env.INTEROP_LIVE_KEY;
if (ADVERSARY && (LIVE || PROFILE)) throw new Error("The adversarial agent only runs locally, without a profile or live identity");
if (LIVE && PROFILE === "sloppy") throw new Error("The sloppy fake agent never takes the live identity");
const ORIGIN = LIVE?.origin ?? process.env.INTEROP_ORIGIN ?? `https://${NAME}.agent.interop.test`;
const COMMIT = process.env.INTEROP_COMMIT ?? "unknown";
/** Interop-only: break the agent on purpose. `assertion-typ` drops `typ` from client assertions. */
const FAULT = process.env.INTEROP_FAULT ?? "";
/** Interop-only successful code exchange, kept in memory and reset per cell; never shown to the model. */
let approvalAcknowledgements = new ApprovalAcknowledgements();
let codeExchange: { request: Request; nonce: string | null } | null = null;

const MANIFEST = {
  interop: 1,
  name: NAME,
  role: "agent",
  commit: COMMIT,
  // Every version src/poppy speaks, 0.4 and 1.0 (decision 51); the adversarial agent's raw requests declare the Company's version too (attacks.ts).
  poppy: [...PROTOCOL_VERSIONS],
  extensions: ["operations"],
  scenarios: ADVERSARY ? [...ATTACKS] : [
    "D", "S0", "N", "SD", "SV", "SVN", "SM", "SMC", "SX", "SXV", "C", "CL", "CC", "CI", "CS", "CA", "SO", "O", "OX", "OU", "SE", "R", "AO", "AM", "AS", "RL", "DP",
    "H", "DC", "W", "CM", "ML",
    // Honest agent against the fault-injection proxy (docs/adversarial-interop.md) and malicious Companies.
    "NREP", "CDUP", "CIDUP", "ODUP", "XH", "XI", "BX", "XB", "XN", "XP", "XE", "XR"
  ],
  // 0.3 settled S1, and 0.4 keeps it: the issuer (4.1).
  readings: PROFILE ? PROFILE_READINGS[PROFILE] : { S1: "issuer", S2: "jwt-60s", S3: "insertion", S23: "per-origin" },
  relaxations: [] as string[],
  ...(ADVERSARY ? { adversarial: true, attacks: [...ATTACKS] } : {}),
  ...(PROFILE ? { profile: PROFILE } : {}),
  // The client_id it signs as, which the runner checks against the live identity it passed.
  client_id: LIVE?.clientId ?? `${ORIGIN}/poppy/client.json`,
  ...(FAULT ? { faults: [FAULT] } : {}),
  notes: ADVERSARY ? "Raw Poppy 0.4 adversarial requests; every probe establishes an accepted baseline; local own-project lane only." : PROFILE
    ? `Fake Personal Agent, ${PROFILE} profile: src/poppy with the adapter's network seam changed (interop/impls/pda-agent/profiles.ts).`
    : "Drives src/poppy directly (PoppyClient, signin, conversations, apis, operations); no model."
};

// ---------------------------------------------------------------- The agent, per reset

type Job = { fn: JobName; at: number; payload: Json };

type Agent = {
  client: PoppyClient;
  env: Env;
  jobs: Map<string, Job>;
  cards: Map<string, Card>;
  notes: string[];
  /** Labels are suffixed per reset, so module-level caches (MCP sessions) never carry over. */
  generation: string;
  /** The agent's own browser for the website (spec 5): src/poppy/fetch-browser.ts. */
  browser: FetchBrowser;
  /** The strict profile's record of what it saw (profiles.ts); null otherwise. */
  strict: StrictObserver | null;
};

/**
 * Node has no `HTMLRewriter`, with which src/poppy/fetch-browser.ts reads a
 * page's text, links and forms, and the browser join its code (6, step 1).
 * Interop-only: lol-html in WebAssembly stands in (html-rewriter.ts).
 */
if (!("HTMLRewriter" in globalThis)) (globalThis as Record<string, unknown>).HTMLRewriter = NodeHTMLRewriter;

async function signingKeys(): Promise<string> {
  const keys = [];
  for (const kid of [`k-${randomId("", 6)}`, `k-${randomId("", 6)}`]) {
    const { privateKey } = await generateKeyPair("ES256", { extractable: true });
    keys.push({ ...(await exportJWK(privateKey)), kid, alg: "ES256", use: "sig" });
  }
  return JSON.stringify(keys);
}

/** Re-sign a JWT's claims without `typ` in its header (INTEROP_FAULT=assertion-typ). */
async function withoutTyp(jwt: string, env: Env): Promise<string> {
  const header = decodeProtectedHeader(jwt);
  const key = await currentKey(env);
  return new SignJWT(decodeJwt(jwt)).setProtectedHeader({ alg: String(header.alg), ...(header.kid ? { kid: header.kid } : {}) }).sign(key.privateKey);
}

/** Live lane: at most one request per `INTEROP_PACE_MS` to each host. */
const PACE_MS = Number(process.env.INTEROP_PACE_MS ?? "0");
const lastRequest = new Map<string, Promise<void>>();
function pace(host: string): Promise<void> {
  if (!(PACE_MS > 0)) return Promise.resolve();
  const previous = lastRequest.get(host) ?? Promise.resolve();
  const turn = previous.then(() => new Promise<void>((resolve) => setTimeout(resolve, PACE_MS)));
  lastRequest.set(host, turn);
  return previous;
}

/** Re-sign an assertion with the agent's current key (the sloppy and lenient profiles). */
function resignerFor(env: Env): Resign {
  return async (jwt, change) => {
    const key = await currentKey(env);
    const { header, payload } = changedClaims(jwt, change);
    return new SignJWT(payload).setProtectedHeader({ ...header, alg: String(header.alg) }).sign(key.privateKey);
  };
}

/** Every outbound request: the network, through the proxy, with an optional fault or a fake agent's profile. */
function fetcherFor(env: Env, strict: StrictObserver | null): Fetcher {
  const endpoints = new Endpoints();
  const resign = resignerFor(env);
  const network = async (request: Request): Promise<Response> => {
    const approvalMessage = request.method === "POST" && /\/[^/]+\/messages$/.test(new URL(request.url).pathname) ? new Request(request.url, { method: request.method, headers: request.headers, body: await request.clone().text() }) : null;
    const saved = !LIVE && request.method === "POST" && (request.headers.get("content-type") ?? "").startsWith("application/x-www-form-urlencoded") ? request.clone() : null;
    const response = await fetch(request);
    if (approvalMessage) await approvalAcknowledgements.observe(approvalMessage, response);
    if (saved && response.ok && new URLSearchParams(await saved.clone().text()).get("grant_type") === "authorization_code") codeExchange = { request: new Request(saved.url, { method: saved.method, headers: saved.headers, body: await saved.text() }), nonce: response.headers.get("dpop-nonce") };
    return response;
  };
  const send = async (request: Request): Promise<Response> => {
    const started = Date.now();
    const sent = strict ? { method: request.method, url: request.url, headers: new Headers(request.headers), body: request.body ? await request.clone().text() : "" } : null;
    const response = await network(request);
    await endpoints.observe(request.url, response);
    if (strict && sent) {
      const found = await strict.observe(sent, response, started);
      if (found.length) throw strict.refusal ?? new StrictRefusal(found);
    }
    return response;
  };
  return async (request) => {
    await pace(new URL(request.url).host);
    if (PROFILE === "sloppy") return send(await sloppyRequest(request, endpoints, resign));
    if (PROFILE === "lenient") return lenientFetch(request, send, endpoints, resign);
    if (PROFILE === "strict") return send(request);
    if (FAULT === "assertion-typ" && request.method === "POST" && (request.headers.get("content-type") ?? "").startsWith("application/x-www-form-urlencoded")) {
      const form = new URLSearchParams(await request.clone().text());
      let changed = false;
      for (const name of ["client_assertion", "assertion"]) {
        const value = form.get(name);
        if (value && value.split(".").length === 3) {
          form.set(name, await withoutTyp(value, env));
          changed = true;
        }
      }
      if (changed) return network(new Request(request, { body: form.toString() }));
    }
    return network(request);
  };
}

async function newAgent(): Promise<Agent> {
  const limiters = new Map<string, CompanyLimiter>();
  const env = {
    PUBLIC_ORIGIN: ORIGIN,
    POPPY_CLIENT_NAME: LIVE ? "Poppy Demo Agent (interop tests)" : `Interop agent ${NAME} (Poppy Demo Agent)`,
    POPPY_LOGO_URI: `${ORIGIN}/logo.png`,
    POPPY_SIGNING_JWKS: LIVE ? LIVE.signingJwks : await signingKeys(),
    TOKEN_ENC_KEY: Buffer.from(crypto.getRandomValues(new Uint8Array(32))).toString("base64"),
    CompanyLimiter: {
      getByName(name: string) {
        let limiter = limiters.get(name);
        if (!limiter) {
          limiter = new CompanyLimiter(memoryState(name) as never, {} as Env);
          limiters.set(name, limiter);
        }
        return limiter;
      }
    }
  } as unknown as Env;
  const strict = PROFILE === "strict" ? new StrictObserver(new URL(ORIGIN).hostname) : null;
  const sql = memorySql();
  migrate(sql);
  migrateAttachments(sql);
  const jobs = new Map<string, Job>();
  const cards = new Map<string, Card>();
  const notes: string[] = [];
  const host: PoppyHost = {
    env,
    sql,
    fetcher: identifiedFetcher(fetcherFor(env, strict)),
    showCard: async (card) => {
      cards.set(card.id, card);
    },
    notifyModel: async (text) => {
      notes.push(text);
    },
    schedule: async (fn, at, payload, id) => {
      jobs.set(id, { fn, at, payload });
    },
    hasJob: (id) => jobs.has(id),
    pushDirect: () => undefined,
    userContext: () => ({ locale: "en-GB", time_zone: "Europe/London", user_available: true }),
    sleep: (ms) => new Promise((resolve) => setTimeout(resolve, ms)),
    now: () => Date.now()
  };
  // The fetch-based browser of src/poppy (spec 5), on the adapter's network seam.
  const client = LIVE ? new LiveIdentityClient(host, LIVE) : new PoppyClient(host);
  return { client, env, jobs, cards, notes, generation: randomId("", 4), browser: new FetchBrowser(host.fetcher), strict };
}

let agent = await newAgent();
let armed: { attack: AttackId; params: Params; plan: AttackPlan | null } | null = null;

// ---------------------------------------------------------------- Steps

class StepError extends Error {
  status: number;
  code: string;
  constructor(status: number, code: string, detail: string) {
    super(detail);
    this.status = status;
    this.code = code;
  }
}

type Params = Record<string, unknown>;
const text = (value: unknown, name: string): string => {
  if (typeof value !== "string" || value === "") throw new StepError(400, "invalid_params", `${name} must be a non-empty string`);
  return value;
};
const optional = (value: unknown): string | undefined => (typeof value === "string" && value !== "" ? value : undefined);
const label = (params: Params) => `${optional(params.label) ?? "main"}@${agent.generation}`;
const plainLabel = (value: string) => value.replace(/@[^@]*$/, "");

/** How long the `sse` op waits for a stream's response headers. */
const SSE_HEADER_DEADLINE_MS = 10_000;

async function company(domain: string): Promise<Company> {
  return agent.client.company(domain);
}

function sessionResult(company: Company, sessionLabel: string) {
  const session = agent.client.session(company.issuer, sessionLabel);
  if (!session) throw new StepError(500, "no_session", "No Session after the exchange");
  return {
    session_id: session.session_id,
    signed_in: session.signed_in === 1,
    scope: session.scope,
    ...(session.account ? { account: session.account } : {})
  };
}

/** Run a scheduled job until it reports done, waiting until each run is due. */
async function drain(id: string, run: (job: Job) => Promise<number | null>, limitMs: number): Promise<void> {
  const deadline = Date.now() + limitMs;
  for (;;) {
    const job = agent.jobs.get(id);
    if (!job) return;
    const wait = job.at - Date.now();
    if (Date.now() + Math.max(0, wait) > deadline) return;
    if (wait > 0) await new Promise((resolve) => setTimeout(resolve, wait));
    agent.jobs.delete(id);
    const next = await run(job);
    if (next !== null && !agent.jobs.has(id)) agent.jobs.set(id, { ...job, at: next });
  }
}

/** The sign-in a step started, per Company and label, for `signin_continue`. */
const pending = new Map<string, { id: string; type: string; issuer: string; label: string }>();

function signInRow(id: string) {
  return rows(
    agent.client.sql,
    signInsTable.pick("status", "account", "label", "issuer"),
    "SELECT status, account, label, issuer FROM poppy_signins WHERE id = ?",
    id
  )[0];
}

/** Why a sign-in didn't complete, from what the agent told the model. */
function signInFailure(issuer: string): PoppyStepError {
  const note = [...agent.notes].reverse().find((line) => line.includes("didn't complete")) ?? "";
  // src/poppy/signin.ts words the outcome for the User; these are the codes behind its words.
  const worded: [RegExp, string][] = [
    [/the User declined/, "access_denied"],
    [/the code expired/, "expired_token"],
    [/the company returned ([a-z_]+)/, "$1"]
  ];
  const match = worded.map(([pattern, code]) => [pattern.exec(note), code] as const).find(([found]) => found);
  const code = match
    ? match[1].replace("$1", match[0]![1] ?? "")
    : (/\(([a-z_]+)\)/.exec(note)?.[1] ?? /: ([a-z_]+)$/.exec(note)?.[1] ?? "sign_in_failed");
  return new PoppyStepError(code, 0, `${issuer}: ${note}`);
}

/** A Poppy error the Company returned, or a refusal of ours: `{ok: false, poppy_error}`. */
class PoppyStepError extends Error {
  code: string;
  status: number;
  constructor(code: string, status: number, detail: string) {
    super(detail);
    this.code = code;
    this.status = status;
  }
}

async function signedInResult(company: Company, sessionLabel: string, id: string) {
  const row = signInRow(id);
  if (row?.status !== "done") throw signInFailure(company.issuer);
  pending.delete(`${company.issuer}|${sessionLabel}`);
  const session = sessionResult(company, sessionLabel);
  return { signed_in: session.signed_in, account: session.account ?? null, scope: session.scope, session_id: session.session_id };
}

const STEPS: Record<string, (domain: string, params: Params) => Promise<unknown>> = {
  async arm(_domain, params) {
    if (!ADVERSARY) throw new StepError(501, "unsupported", "Only the adversarial agent supports arm");
    const attack = text(params.attack, "attack");
    if (!ATTACKS.includes(attack as AttackId)) throw new StepError(501, "unsupported", `Unknown attack ${attack}`);
    armed = { attack: attack as AttackId, params, plan: null };
    return { armed: attack };
  },
  async attack(domain, params) {
    if (!ADVERSARY) throw new StepError(501, "unsupported", "Only the adversarial agent supports attack");
    if (!armed) throw new StepError(409, "not_armed", "Arm an attack first");
    armed.plan ??= await prepareAttack({ clientId: `${ORIGIN}/poppy/client.json`, signingJwks: agent.env.POPPY_SIGNING_JWKS as string, fetcher: (request) => fetch(request) }, await company(domain), armed.attack, { ...armed.params, ...params });
    return armed.plan.run(optional(params.phase));
  },
  async replay_code(domain) {
    if (LIVE) throw new StepError(501, "unsupported", "Code-reuse probes never run with the live identity");
    const c = await company(domain);
    if (!codeExchange) throw new AttackSetupError("No successful authorization-code exchange captured");
    const request = await freshCodeReplay({ clientId: `${ORIGIN}/poppy/client.json`, signingJwks: agent.env.POPPY_SIGNING_JWKS as string, fetcher: (request) => fetch(request) }, c, codeExchange.request, await agent.client.dpopKey(c.issuer), codeExchange.nonce ?? undefined);
    const response = await fetch(request);
    return { status: response.status, body: await response.json() };
  },
  async discover(domain) {
    const found = await agent.client.lookup(domain);
    if (!isCompany(found)) return { issuer: null, website_only: true, name: found.name };
    return {
      issuer: found.issuer,
      poppy_version: found.protocolVersion,
      conversations: !!found.conversations,
      apis: found.apis.map((api) => api.type),
      sign_in: Object.keys(found.signIn),
      extensions: Object.keys(found.extensions)
    };
  },

  async session(domain, params) {
    const c = await company(domain);
    await agent.client.token(c, { label: label(params) });
    return sessionResult(c, label(params));
  },

  async signin(domain, params) {
    const c = await company(domain);
    const method = optional(params.method);
    if (method && method !== "direct" && method !== "device" && method !== "mediated") {
      throw new StepError(400, "invalid_params", `Unknown sign-in method ${method}`);
    }
    const scopes = Array.isArray(params.scopes) ? params.scopes.filter((s): s is string => typeof s === "string") : [];
    const sessionLabel = label(params);
    const account = optional(params.account);
    const started = await startSignIn(agent.client, c, {
      label: sessionLabel,
      scopes,
      reason: "Interop scenario",
      ...(account ? { account } : {}),
      ...(method ? { type: method as SignInType } : {})
    });
    if (started.status === "signed_in") {
      const session = sessionResult(c, sessionLabel);
      return { signed_in: true, account: session.account ?? null, scope: started.scope };
    }
    pending.set(`${c.issuer}|${sessionLabel}`, { id: started.signInId, type: started.type, issuer: c.issuer, label: sessionLabel });
    const card = agent.cards.get(`signin-${started.signInId}`);
    if (card?.kind === "signin_link") {
      // With Pushed Authorization Requests the card links to the agent's own page (1.0: 4.2). Opening it pushes
      // the request, as the User's browser would, and the harness gets the Company's URL it redirects to.
      const page = new URL(card.url);
      if (page.origin === ORIGIN && page.pathname === "/poppy/sign-in") {
        const pushed = await pushDirectSignIn(agent.client, page.searchParams.get("id") ?? "");
        if (!pushed.ok) throw new StepError(pushed.status, "push_refused", pushed.message);
        return { pending: { type: "direct", url: pushed.location } };
      }
      return { pending: { type: "direct", url: card.url } };
    }
    if (card?.kind === "signin_device") {
      return {
        pending: {
          type: "device",
          url: card.verificationUri,
          user_code: card.userCode,
          ...(card.verificationUriComplete ? { url_complete: card.verificationUriComplete } : {})
        }
      };
    }
    if (card?.kind === "signin_credentials") return { pending: { type: "mediated", fields: card.fields.map((field) => field.name) } };
    throw new StepError(500, "no_card", `Sign-in ${started.signInId} showed no card`);
  },

  async signin_continue(domain, params) {
    const c = await company(domain);
    const sessionLabel = label(params);
    const started = pending.get(`${c.issuer}|${sessionLabel}`);
    if (!started) throw new StepError(409, "no_pending_signin", "No sign-in in progress for this Company and label");
    if (started.type === "direct") {
      const callback = new URL(text(params.callback_url, "callback_url"));
      const outcome = await completeDirectSignIn(agent.client, callback);
      if (!outcome.ok) {
        const error = callback.searchParams.get("error");
        if (error) throw new PoppyStepError(error, 0, outcome.message);
        throw signInFailure(c.issuer);
      }
      return signedInResult(c, sessionLabel, started.id);
    }
    if (started.type === "device") {
      await drain(`device-${started.id}`, async () => pollDeviceSignIn(agent.client, started.id), 90_000);
      return signedInResult(c, sessionLabel, started.id);
    }
    // Mediated: the fields, then perhaps a one-time code.
    const row = signInRow(started.id);
    if (row?.status === "code") {
      const outcome = await submitSignInCode(agent.client, started.id, text(params.code, "code"));
      if (outcome === "code") return { pending: { type: "mediated", code_required: true } };
      return signedInResult(c, sessionLabel, started.id);
    }
    const fields = typeof params.fields === "object" && params.fields !== null ? (params.fields as Record<string, string>) : {};
    const outcome = await submitCredentials(agent.client, started.id, fields);
    if (outcome === "code") return { pending: { type: "mediated", code_required: true } };
    return signedInResult(c, sessionLabel, started.id);
  },

  async send(domain, params) {
    const c = await company(domain);
    const conversationId = optional(params.conversation);
    const parentConversationId = optional(params.parent_conversation);
    const callKey = optional(params.message_id) ?? randomId("call_");
    if (params.sender !== undefined && params.sender !== "agent" && params.sender !== "human") {
      throw new StepError(400, "invalid_params", "sender must be agent or human");
    }
    const sent = await sendMessage(agent.client, c, {
      // A Direct Conversation goes in its parent's Session (7.10).
      label: (parentConversationId ? conversationRow(agent.client, parentConversationId)?.label : undefined) ?? label(params),
      callKey,
      ...(conversationId ? { conversationId } : {}),
      ...(parentConversationId ? { parentConversationId } : {}),
      // The User's own words, as a Direct Conversation carries them (7.8, 7.10).
      sender: params.sender === "human" ? "human" : "agent",
      text: text(params.text, "text"),
      ...(typeof params.wait === "number" ? { wait: params.wait } : {})
    });
    const intent = rows(agent.client.sql, intentsTable.pick("value"), "SELECT value FROM poppy_intents WHERE call_key = ?", `message|${callKey}`)[0];
    // A message's id is its request's (8.3).
    const messageId = intent ? ((JSON.parse(intent.value) as { id?: string }).id ?? null) : null;
    return {
      conversation: sent.conversationId,
      message_id: messageId,
      // The harness contract's status (interop-spec.md): the local one, which 0.4 derives from the four fields.
      status: conversationRow(agent.client, sent.conversationId)!.status,
      responder: sent.responder,
      messages: sent.replies.map((reply) => ({ role: "company", sender: reply.sender, text: reply.text ?? null, ...(reply.data !== undefined ? { data: reply.data } : {}) }))
    };
  },

  async read(domain, params) {
    const c = await company(domain);
    const id = text(params.conversation, "conversation");
    const stored = conversationRow(agent.client, id);
    if (!stored || stored.issuer !== c.issuer) throw new StepError(404, "unknown_conversation", `No conversation ${id}`);
    await readConversation(agent.client, id, typeof params.wait === "number" ? params.wait : 0);
    const row = conversationRow(agent.client, id)!;
    let events = rows(agent.client.sql, inboxTable.pick("event"), "SELECT event FROM poppy_inbox WHERE conversation_id = ? ORDER BY seq", id);
    // With a cursor, only what came after that event (the agent's inbox, in the order it arrived).
    const after = optional(params.cursor);
    const at = after ? events.findIndex((entry) => (JSON.parse(entry.event) as { id?: string }).id === after) : -1;
    if (at !== -1) events = events.slice(at + 1);
    return {
      messages: events.map((entry) => {
        const event = JSON.parse(entry.event) as { id: string; message: { role?: string; author?: Json; text?: string; data?: Json; extensions?: { operations?: { operation?: { operation_id?: string } } } } };
        // Operations 2's operation, in the message's extension content (8.4, Ops 4).
        const operation = event.message.extensions?.operations?.operation;
        return {
          event: event.id,
          role: event.message.role ?? null,
          // `author.type` (8.4); the field keeps the harness's name for it.
          sender: writtenBy(event.message) ?? null,
          text: event.message.text ?? null,
          ...(operation?.operation_id ? { operation: operation.operation_id } : {})
        };
      }),
      cursor: row.cursor,
      has_more: false,
      status: row.status,
      responder: row.responder
    };
  },

  async sse(domain, params) {
    const c = await company(domain);
    const id = text(params.conversation, "conversation");
    const stored = conversationRow(agent.client, id);
    if (!stored || stored.issuer !== c.issuer) throw new StepError(404, "unknown_conversation", `No conversation ${id}`);
    const endpoint = c.conversations?.endpoint.replace(/\/+$/, "");
    if (!endpoint) throw new PoppyStepError("no_company_agent", 0, "No conversation endpoint");
    const url = new URL(`${endpoint}/${encodeURIComponent(stored.remote_id)}/events`);
    const cursor = optional(params.cursor);
    if (cursor) url.searchParams.set("cursor", cursor);
    url.searchParams.set("wait", String(typeof params.wait === "number" ? params.wait : 1));
    const opened = agent.client.resource(
      c,
      EndpointRequest.to(c, { method: "GET", url: url.href, accept: "text/event-stream", ...(cursor ? { headers: { "Last-Event-ID": cursor } } : {}) }),
      { label: label(params), service: c.conversations!.endpoint }
    );
    // A Company may hold an idle stream's headers until its first event: that is a stream with nothing new yet.
    const response = await Promise.race([opened, new Promise<"timeout">((resolve) => setTimeout(() => resolve("timeout"), SSE_HEADER_DEADLINE_MS))]);
    if (response === "timeout") {
      opened.then((late) => late.body?.cancel(), () => undefined);
      return { events: [], last_id: null, note: `no response headers within ${SSE_HEADER_DEADLINE_MS / 1000} s` };
    }
    const max = typeof params.max_events === "number" ? params.max_events : 50;
    const type = response.headers.get("content-type") ?? "";
    if (!type.includes("text/event-stream")) {
      await response.body?.cancel();
      throw new PoppyStepError("not_streamed", response.status, `Answered ${type || "no content type"}`);
    }
    const events: { id: string | null; type: string; data: Json }[] = [];
    const reader = response.body!.pipeThrough(new TextDecoderStream()).getReader();
    const deadline = Date.now() + 10_000;
    const lineEndings = new SseLineEndings();
    let buffer = "";
    try {
      while (events.length < max && Date.now() < deadline) {
        const next = await readSseChunk(reader, deadline);
        if (next === "timeout" || next.done) break;
        buffer += lineEndings.normalize(next.value);
        let split: number;
        while ((split = buffer.indexOf("\n\n")) !== -1 && events.length < max) {
          if (split > MAX_SSE_CHARS) throw new PoppyError("invalid_response", departure(ours("the Company's stream event"), shown`at most ${MAX_SSE_CHARS} characters`, shown`${split}`), 0);
          const block = buffer.slice(0, split);
          buffer = buffer.slice(split + 2);
          let eventId: string | null = null;
          let eventType = "message";
          const data: string[] = [];
          for (const line of block.split("\n")) {
            if (line.startsWith(":")) continue;
            const colon = line.indexOf(":");
            const field = colon === -1 ? line : line.slice(0, colon);
            const value = colon === -1 ? "" : line.slice(colon + 1).replace(/^ /, "");
            if (field === "id") eventId = value;
            else if (field === "event") eventType = value;
            else if (field === "data") data.push(value);
          }
          if (data.length === 0) continue;
          // 0.4: `working` isn't an event, but the state, streamed with no id (8.6).
          if (eventType === "working" && eventId === null) continue;
          let payload: Json = data.join("\n");
          try {
            payload = JSON.parse(data.join("\n")) as Json;
          } catch {
            // Kept as text.
          }
          events.push({ id: eventId, type: eventType, data: payload });
        }
        if (events.length < max && buffer.length > MAX_SSE_CHARS) throw new PoppyError("invalid_response", departure(ours("the Company's unfinished stream event"), shown`at most ${MAX_SSE_CHARS} characters`, shown`${buffer.length}`), 0);
      }
    } finally {
      await reader.cancel().catch(() => undefined);
    }
    const ids = events.map((event) => event.id).filter((value): value is string => !!value);
    return { events, last_id: ids.at(-1) ?? null };
  },

  async mcp_list(domain, params) {
    const c = await company(domain);
    try {
      const tools = await listMcpTools(agent.client, c, label(params));
      return { tools: tools.map((tool) => isRecord(tool) ? { name: tool.name } : tool) };
    } catch (error) {
      if (error instanceof PoppyError && error.is("insufficient_scope")) {
        throw new StepError(501, "authentication_required", "MCP tool listing requires Sign-In; this signed-out scenario cannot exercise it");
      }
      throw error;
    }
  },

  async api(domain, params) {
    const c = await company(domain);
    const args = typeof params.args === "object" && params.args !== null ? (params.args as Record<string, unknown>) : {};
    const api = optional(params.api) ?? "openapi";
    if (api === "mcp" || api.endsWith("/mcp")) {
      const result = await callMcpTool(agent.client, c, label(params), {
        ...(api.startsWith("https://") ? { apiUrl: api } : {}),
        tool: text(params.tool, "tool"),
        args: args as Json
      });
      if (isRecord(result) && typeof result.proposed === "string") return heldApiResult(c, result.proposed);
      return { status: 200, body: result };
    }
    const files = uploads(args.files);
    const result = await callOpenApi(agent.client, c, label(params), {
      ...(api.startsWith("https://") ? { apiUrl: api } : {}),
      operation: text(params.operation, "operation"),
      params: (args.params ?? {}) as Record<string, string>,
      ...(args.body !== undefined ? { body: args.body as Json } : {}),
      ...(files ? { files } : {}),
      callKey: randomId("call_")
    });
    // File disclosure and Company operations wait for a User decision:
    // `held` is the approval `approve_op` decides. Routine task writes run normally.
    if (isRecord(result) && typeof result.proposed === "string") return heldApiResult(c, result.proposed);
    return apiResult(result);
  },

  /**
   * The agent's browser joins the Session (spec 5) as `poppy_browse` does:
   * src/poppy/browser.ts posts the browser assertion as a form from the
   * Session's own fetch-based browser context, which follows the 303 with
   * the Company's cookie, then loads `url`.
   */
  async web_join(domain, params) {
    const c = await company(domain);
    const url = text(params.url, "url");
    const page = (await browse(agent.client, agent.browser, c, label(params), { kind: "open", url })) as { url?: string; status?: number };
    return { joined: !!c.web?.browserSessionEndpoint, status: page.status ?? null, url: page.url ?? null };
  },

  /** Ask for a person at the Company (7.9); src/poppy sends a short summary for them first. */
  async handoff(domain, params) {
    const c = await company(domain);
    const id = text(params.conversation, "conversation");
    if (!conversationRow(agent.client, id)) throw new StepError(404, "unknown_conversation", `No conversation ${id}`);
    const summary = optional(params.text) ?? "The User would like to speak with someone at your company.";
    await handoff(agent.client, c, id, summary, randomId("call_"));
    const row = conversationRow(agent.client, id)!;
    return { status: row.status, responder: row.responder };
  },

  /** Close a conversation (7.12). */
  async close(domain, params) {
    const c = await company(domain);
    const id = text(params.conversation, "conversation");
    if (!conversationRow(agent.client, id)) throw new StepError(404, "unknown_conversation", `No conversation ${id}`);
    await closeConversation(agent.client, c, id);
    // 0.4: the 202 says only that the Company accepted the close; a read says when it acted (8.12).
    for (let read = 0; read < 3 && conversationRow(agent.client, id)!.status !== "closed"; read++) {
      await readConversation(agent.client, id, 2);
    }
    const row = conversationRow(agent.client, id)!;
    return { status: row.status, responder: row.responder };
  },

  /**
   * The User's decision on a card: one of ours (`apr_`, `apr2_`), or the
   * card of an operation the Company returned, by its `operation_id` (Ops 5).
   * Approved, the request goes again with the approval (Ops 6).
   */
  async approve_op(domain, params) {
    const c = await company(domain);
    const id = text(params.operation, "operation");
    const decision = params.decision === "decline" ? "decline" : "approve";
    if (/^apr2?_/.test(id)) return decideHeld(id, decision, c);
    const card = rows(
      agent.client.sql,
      approvalsTable.pick("id"),
      `SELECT id FROM poppy_approvals WHERE issuer = ? AND status = 'pending'
       AND ? IN (json_extract(request, '$.approval.operation_id'), json_extract(request, '$.call.approval.operation_id'))
       ORDER BY created_at DESC LIMIT 1`,
      c.issuer,
      id
    )[0];
    if (!card) throw new StepError(404, "unknown_operation", `The agent has no card for operation ${id} from ${c.issuer}`);
    return decideHeld(card.id, decision, c);
  },

  async signout(domain, params) {
    const c = await company(domain);
    const session = agent.client.session(c.issuer, label(params));
    if (!session?.account) return { revoked: false };
    // The agent stops using the account either way; `revoked` says whether the Company accepted the revocation.
    const outcome = await signOut(agent.client, c.issuer, session.account);
    return { revoked: outcome !== "not_accepted" };
  },


  /**
   * What the agent would show the User to identify a Company (XP, N14): the
   * verified `organization.domain` and issuer, and the unverified
   * `organization.name`. A misleading name can't impersonate another Company
   * because the agent anchors on the domain, which is verified against the
   * host the document was served for.
   */
  async display(domain) {
    const c = await company(domain);
    return { name: c.name, domain: c.domain, issuer: c.issuer };
  },

  async state() {
    return {
      sessions: agent.client.sessions().map((session) => ({
        issuer: session.issuer,
        label: plainLabel(session.label),
        session_id: session.session_id,
        signed_in: session.signed_in === 1,
        account: session.account,
        scope: session.scope
      })),
      accounts: agent.client.accounts().map((account) => ({ issuer: account.issuer, account: account.account, scope: account.scope }))
    };
  }
};

const isRecord = (value: unknown): value is Record<string, unknown> => typeof value === "object" && value !== null && !Array.isArray(value);

/** Distinguish actual Company terms from separate file-disclosure consent. */
function heldApiResult(company: Company, id: string) {
  const row = rows(agent.client.sql, approvalsTable.pick("request"), "SELECT request FROM poppy_approvals WHERE id = ? AND issuer = ?", id, company.issuer)[0];
  const saved = row ? readApproval(row.request) : undefined;
  if (!saved?.ok) throw new StepError(500, "invalid_response", "The held request has no readable approval record");
  const approval = saved.value.kind === "openapi" || saved.value.kind === "mcp" ? saved.value.call.approval : undefined;
  return { held: id, ...(approval ? { operation: { operation_id: approval.operation_id, revision: approval.revision } } : {}) };
}

/**
 * An `api` step's files (spec section 5.2: each `{name, type, data}`, the
 * runner having read it from interop/files/), attached as the User attaches
 * a photo on the page: kept in the agent's own storage, and named to the API
 * tool by attachment id.
 */
function uploads(value: unknown): Record<string, string> | undefined {
  if (!isRecord(value)) return undefined;
  const files: Record<string, string> = {};
  for (const [field, file] of Object.entries(value)) {
    if (!isRecord(file) || typeof file.data !== "string") throw new StepError(400, "invalid_params", `files.${field} must be {name, type, data}`);
    try {
      files[field] = saveAttachment(agent.client.sql, {
        name: typeof file.name === "string" ? file.name : null,
        bytes: new Uint8Array(Buffer.from(file.data, "base64"))
      }).id;
    } catch (error) {
      if (error instanceof AttachmentError) throw new StepError(400, "invalid_params", `files.${field}: ${error.message}`);
      throw error;
    }
  }
  return Object.keys(files).length ? files : undefined;
}

/**
 * An OpenAPI call's outcome as section 5.2 has it: a Poppy error from the
 * Company (`{"error": code}` with a 4xx or 5xx) is a refusal; any other
 * answer, an HTTP error included, is `{status, body}` with its real status.
 */
function apiResult(result: Json): unknown {
  if (isRecord(result) && typeof result.status === "number" && result.status >= 400) {
    const body = result.body;
    if (isRecord(body) && typeof body.error === "string") {
      throw new PoppyStepError(body.error, result.status, typeof body.error_description === "string" ? body.error_description : `HTTP ${result.status}`);
    }
  }
  return result;
}

/** The User's decision on a held write, through the same path the approval card takes. */
async function decideHeld(id: string, decision: "approve" | "decline", company: Company) {
  await decideLocal(agent.client, id, decision);
  const row = rows(agent.client.sql, approvalsTable.pick("status", "result", "request", "issuer"), "SELECT status, result, request, issuer FROM poppy_approvals WHERE id = ?", id)[0];
  if (!row) throw new StepError(404, "unknown_operation", `The agent has no held write ${id}`);
  if (row.status === "failed") {
    const code = /\[([a-z_0-9]+)\]$/.exec(row.result ?? "")?.[1] ?? "approved_write_failed";
    throw new PoppyStepError(code, 0, row.result ?? "");
  }
  // No answer came: what the Company did is unknown, as a failure was before (docs/interop-spec.md 4).
  if (row.status === "unknown") {
    const stored = readApproval(row.request);
    const conversation = stored.ok && stored.value.kind === "message-approval" ? conversationRow(agent.client, stored.value.conversationId) : undefined;
    const sent = row.issuer === company.issuer && conversation?.issuer === company.issuer ? approvalAcknowledgements.outcome(row, company.conversations?.endpoint, conversation) : null;
    if (sent) return sent;
    throw new PoppyStepError("approved_write_failed", 0, row.result ?? "");
  }
  // Sent, and the Company answered other than 2xx: the receipt says "answered 500 (server_error)".
  // A Poppy error is a refusal, as `api` gives it; an answer with no code is the response.
  if (row.status === "refused") {
    const answered = /answered (\d{3})(?: \(([^)]+)\))?/.exec(row.result ?? "");
    const status = Number(answered?.[1] ?? 0);
    if (answered?.[2]) throw new PoppyStepError(answered[2], status, row.result ?? "");
    return { status: "done", result: { status, body: null } };
  }
  // Sent, and the Company answered with an operation (Ops 4): its terms wait on the next card, held for the User too.
  if (row.status === "terms") {
    const next = rows(agent.client.sql, approvalsTable.pick("id"), "SELECT id FROM poppy_approvals WHERE status = 'pending' AND terms IS NOT NULL ORDER BY created_at DESC LIMIT 1")[0];
    return { status: "terms", ...(next ? { held: next.id } : {}) };
  }
  if (row.status !== "done") return { status: row.status };
  let outcome: Json = null;
  try {
    outcome = JSON.parse(row.result ?? "null") as Json;
  } catch {
    // The executor's summary was cut short; keep the text.
    outcome = row.result;
  }
  const approved = heldApiResult(company, id).operation;
  return { status: "done", result: apiResult(outcome) as Json, ...(approved ? { approved } : {}) };
}

async function step(request: Request): Promise<Response> {
  const input = await body(request);
  const op = typeof input.op === "string" ? input.op : "";
  const run = STEPS[op];
  if (!run) return failure(501, "unsupported", `No op ${op}`);
  const domain = typeof input.company === "string" ? input.company : "";
  const params = typeof input.params === "object" && input.params !== null ? (input.params as Params) : {};
  if (agent.strict) agent.strict.refusal = null;
  try {
    const result = await run(domain, params);
    const refused = agent.strict?.refusal;
    if (refused) throw refused;
    return json({ ok: true, result });
  } catch (caught) {
    // The strict agent's refusal stands, whatever src/poppy made of the error it threw.
    const error = agent.strict?.refusal ?? caught;
    if (error instanceof StrictRefusal) return json({ ok: false, poppy_error: error.document ? "discovery_failed" : "company_departure", status: 0, detail: error.message });
    if (error instanceof AttackSetupError) return failure(500, "attack_setup_failed", error.message);
    if (error instanceof AttackUnsupported) return failure(501, "unsupported", error.message);
    if (error instanceof StepError) return failure(error.status, error.code, error.message);
    if (error instanceof PoppyStepError) return json({ ok: false, poppy_error: error.code, status: error.status, detail: error.message });
    if (error instanceof PoppyError) {
      return json({ ok: false, poppy_error: error.code, status: error.status, detail: error.message, ...(error.detail.extension ? { extension: error.detail.extension } : {}) });
    }
    if (error instanceof DiscoveryError) return json({ ok: false, poppy_error: "discovery_failed", status: 0, detail: error.message });
    console.error(`step ${op} failed`, error);
    return failure(500, "step_failed", error instanceof Error ? `${error.name}: ${error.message}` : String(error));
  }
}

async function control(request: Request): Promise<Response> {
  const url = new URL(request.url);
  if (request.method === "GET" && url.pathname === "/healthz") return json({ ok: true });
  if (request.method === "GET" && url.pathname === "/manifest") return json(MANIFEST);
  if (!authorized(request, SECRET)) return failure(401, "unauthorized", "Control calls need Authorization: Bearer $INTEROP_SECRET");
  if (request.method === "POST" && url.pathname === "/reset") {
    agent = await newAgent();
    pending.clear();
    armed = null;
    codeExchange = null;
    approvalAcknowledgements = new ApprovalAcknowledgements();
    return json({ ok: true });
  }
  if (request.method === "POST" && url.pathname === "/step") return step(request);
  if (request.method === "GET" && url.pathname === "/log") return json({ notes: agent.notes });
  // The strict agent's findings about the Company, in the mock's shape (spec §5.3, `GET /violations`).
  if (request.method === "GET" && url.pathname === "/violations" && agent.strict) return json({ violations: agent.strict.recorded });
  return failure(404, "not_found", `${request.method} ${url.pathname}`);
}

/** Our identity documents, and Direct Sign-In's callback for a Company that redirects a browser to it. */
async function site(request: Request): Promise<Response> {
  const started = Date.now();
  const identity = await handleIdentityRoute(request, agent.env);
  if (identity) {
    // The strict agent judges how the Company fetched its documents too (metadata fetched with credentials).
    const url = new URL(request.url);
    url.protocol = "https:";
    await agent.strict?.observe({ method: request.method, url: url.href, headers: request.headers, body: "" }, identity, started);
    return identity;
  }
  const url = new URL(request.url);
  if (url.pathname === "/poppy/callback" && request.method === "GET") {
    const outcome = await completeDirectSignIn(agent.client, url);
    return new Response(outcome.message, { status: outcome.ok ? 200 : 400, headers: { "content-type": "text/plain" } });
  }
  // A Company that lists pushed_authorization_request_endpoint: the card links here, and opening it pushes the request (1.0: 4.2).
  if (url.pathname === "/poppy/sign-in" && request.method === "GET") {
    const pushed = await pushDirectSignIn(agent.client, url.searchParams.get("id") ?? "");
    return pushed.ok
      ? new Response(null, { status: 303, headers: { Location: pushed.location, "Cache-Control": "no-store" } })
      : new Response(pushed.message, { status: pushed.status, headers: { "content-type": "text/plain" } });
  }
  return new Response("Not found", { status: 404 });
}

serve(8080, site);
serve(8081, control);
console.log(`pda-agent: ${LIVE ? `live identity ${LIVE.clientId}` : ORIGIN} on 8080, control on 8081${PROFILE ? `, profile ${PROFILE}` : ""}${FAULT ? `, fault ${FAULT}` : ""}`);
