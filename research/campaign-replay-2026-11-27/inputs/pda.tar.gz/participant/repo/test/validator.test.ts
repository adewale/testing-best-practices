import { env } from "cloudflare:workers";
import { describe, expect, it, vi } from "vitest";
import { exportJWK, generateKeyPair, importJWK } from "jose";
import {
  levelOf,
  MESSAGES,
  severityOf,
  validateClient,
  validateCompany,
  validateTarget,
  validateText,
  summarize,
  VALIDATOR,
  type CompanyReport,
  type DocumentKind,
  type Fetcher,
  type IdentifiedFetcher,
  type MessageId,
  type Report
} from "../src/validator/index.ts";
import { isPublicAddress, NonPublicAddressError, parseIPv6, pinnedLookup } from "../src/validator/address.ts";
import { fetchDocument, INVALID_STATUS, isPublicHost, LIMITS, readLimited, retryAfterSeconds, withUserAgent, workerPorts } from "../src/validator/fetch.ts";
import { Checker } from "../src/validator/primitives.ts";
import { handleValidator } from "../src/validator/http.ts";
import type { MockCompany, MockConfig } from "./mock-company";
import worker, { testFetcher } from "./worker";
import { named } from "./named-fetcher.ts";

/**
 * The discovery-document validator. As with feed validators' test suites,
 * every message id must be produced by at least one fixture here, and the
 * message catalog test checks that.
 *
 * A fixture is plain data: a name (its test's title), how to get its
 * report, and the message ids the report must have, exactly and in order or
 * at least. The catalog test reads the ids the fixtures declare, not reports
 * from earlier tests, so it gives the same answer alone, in any order, or
 * shuffled; each fixture's own test proves its declared ids are produced.
 */
type Fixture = {
  readonly name: string;
  readonly run: () => Report | Promise<Report>;
  /** The report's message ids: exactly these, in order, or at least these. */
  readonly ids: readonly MessageId[] | { readonly contains: readonly MessageId[] };
  readonly outcome?: Report["outcome"];
  /** Assertions beyond ids and outcome: pointers, positions, wording, counts. */
  readonly also?: (report: Report) => void | Promise<void>;
};

const ids = (report: Report) => report.messages.map((m) => m.id);

const declaredIds = (fixture: Fixture): readonly MessageId[] =>
  "contains" in fixture.ids ? fixture.ids.contains : (fixture.ids as readonly MessageId[]);

/**
 * Every message a departure is (every one but the notes and the `fact`s)
 * says what was expected and what was got, as fields and in its text; a
 * fact has neither. The types require it at each report (ProblemFor); this
 * holds it for every message every fixture produces.
 */
function sidesMatchCatalog(report: Report) {
  for (const message of report.messages) {
    const definition = MESSAGES[message.id] as { readonly note?: true; readonly fact?: string };
    const fact = definition.note === true || definition.fact !== undefined;
    if (fact) {
      for (const part of ["subject", "expected", "got", "detail"]) expect(message, message.id).not.toHaveProperty(part);
    } else {
      expect(message.subject, message.id).toBeTruthy();
      expect(message.expected, message.id).toBeTruthy();
      expect(message.got, message.id).toBeTruthy();
      // The parts rebuild the sentence exactly, so a reader that shows them apart (the results page) loses nothing.
      const said = `${message.subject}: expected ${message.expected}, got ${message.got}${message.detail === undefined ? "" : `. ${message.detail}`}`;
      expect(message.text, message.id).toBe(/[.!?…]$/.test(said) ? said : `${said}.`);
    }
  }
}

async function check(fixture: Fixture) {
  const report = await fixture.run();
  sidesMatchCatalog(report);
  if ("contains" in fixture.ids) {
    expect(ids(report)).toEqual(expect.arrayContaining([...fixture.ids.contains]));
  } else {
    expect(ids(report)).toEqual(fixture.ids);
  }
  if (fixture.outcome) expect(report.outcome).toBe(fixture.outcome);
  await fixture.also?.(report);
}

/** Each fixture is its own test, titled by its name. */
function testEach(fixtures: readonly Fixture[]) {
  it.each(fixtures.map((fixture) => [fixture.name, fixture] as const))("%s", (_name, fixture) =>
    check(fixture)
  );
}

function text(kind: DocumentKind, doc: unknown, options: Parameters<typeof validateText>[2] = {}): Report {
  const source = typeof doc === "string" ? doc : JSON.stringify(doc, null, 2);
  return validateText(kind, source, options);
}

/** A fake network: URL → response. Anything else fails like a DNS error. */
function network(routes: Record<string, () => Response>): IdentifiedFetcher {
  return named(async (request) => {
    const route = routes[request.url];
    if (!route) throw new TypeError("fetch failed");
    return route();
  });
}
const jsonResponse = (body: unknown, headers: Record<string, string> = {}) => () =>
  new Response(typeof body === "string" ? body : JSON.stringify(body), {
    headers: { "Content-Type": "application/json", "Cache-Control": "max-age=300", ...headers }
  });

/** The poppy.json example in spec section 3, with Operations 3 for website operations, Mediated Sign-In and Browser Control from the extension pages. */
const SPEC_POPPY = {
  protocol_version: "0.4",
  organization: { name: "Example Company", domain: "example.com", logo_uri: "https://example.com/logo.png" },
  auth: {
    scopes: {
      "orders:read": "See your orders, returns, and bookings",
      "orders:write": "Exchange or return items, and change bookings",
      addresses: "See and change your saved shipping addresses",
      "poppy:browser-sign-in": "Use the website signed in, with the other access you approve"
    },
    scope_hints: {
      "orders:read": { changes: "none", personal_data: true },
      "orders:write": { changes: "irreversible", personal_data: true },
      addresses: { changes: "reversible", personal_data: true }
    }
  },
  agent: { protocols: [{ type: "poppy", endpoint: "https://api.example.com/poppy/conversations" }] },
  web: { browser_session_endpoint: "https://example.com/poppy/browser-session" },
  tasks: { endpoint: "https://api.example.com/poppy/tasks" },
  apis: [
    { type: "openapi", url: "https://api.example.com/openapi.json", description: "Orders, returns, and exchanges" },
    { type: "mcp", url: "https://mcp.example.com/mcp", description: "Product search and sizing" }
  ],
  extensions: {
    operations: [{ version: "3", endpoint: "https://example.com/poppy/operations" }],
    "mediated-sign-in": [{ version: "1", fields: [{ name: "email", label: "Email", secret: false }, { name: "password", label: "Password", secret: true }], scopes: ["orders:read"] }],
    "browser-control": [{ version: "1" }]
  }
};

/** A 0.3 poppy.json, as a Company not yet on 0.4 serves it: one object per extension, and feedback and excluded tasks in poppy.json. */
const POPPY_03 = {
  protocol_version: "0.3",
  organization: { name: "Example Company", domain: "example.com" },
  agent: { protocols: [{ type: "poppy", endpoint: "https://api.example.com/poppy/conversations" }] },
  web: { browser_session_endpoint: "https://example.com/poppy/browser-session" },
  feedback: { endpoint: "https://api.example.com/poppy/feedback" },
  excluded_tasks: { url: "https://example.com/poppy/excluded-tasks.json" },
  extensions: { operations: { version: "2" } }
};

/** Spec 3.2's protected resource metadata for example.com. */
const SPEC_PRM = { resource: "https://example.com", authorization_servers: ["https://auth.example.com"] };

/** Spec 3.2's issuer metadata, with the Mediated Sign-In grant, poppy:browser-sign-in for browser join (6) and the iss parameter. */
const SPEC_METADATA = {
  issuer: "https://auth.example.com",
  token_endpoint: "https://auth.example.com/oauth/token",
  revocation_endpoint: "https://auth.example.com/oauth/revoke",
  authorization_endpoint: "https://auth.example.com/oauth/authorize",
  device_authorization_endpoint: "https://auth.example.com/oauth/device",
  grant_types_supported: ["refresh_token", "authorization_code", "urn:ietf:params:oauth:grant-type:device_code", "https://personalagentprotocol.org/grant/mediated-sign-in"],
  scopes_supported: ["orders:read", "orders:write", "addresses", "poppy:browser-sign-in"],
  protected_resources: ["https://example.com", "https://example.co.uk", "https://mcp.example.com/mcp"],
  authorization_response_iss_parameter_supported: true
};

/** The client metadata example in spec 4.1, verbatim. */
const SPEC_CLIENT = {
  client_id: "https://agent.example/agent.json",
  client_name: "Example Agent",
  logo_uri: "https://agent.example/logo.png",
  jwks_uri: "https://agent.example/jwks.json",
  redirect_uris: ["https://agent.example/oauth/callback"],
  token_endpoint_auth_method: "private_key_jwt"
};

const EC_KEY = { kty: "EC", crv: "P-256", x: "8-v-FQSg6HqFvDLzsN9fEh7NvGi44Yqf-NKynVlZowc", y: "NgMN41ye2FK9tOqb9Ok-UknmdzyXZp5RUrGqivhZjZY", kid: "k1", use: "sig", alg: "ES256" };
/** A canonical Base64urlUInt with 2048 bits; signature tests use generated RSA keys. */
const RSA_N = `${"x".repeat(341)}w`;

const withPoppy = (change: (doc: Record<string, any>) => void) => {
  const doc = structuredClone(SPEC_POPPY) as Record<string, any>;
  change(doc);
  return doc;
};

/** A Company that offers only its website, which needs no issuer (3.2). */
const WEBSITE_ONLY = { protocol_version: "0.4", organization: { name: "A", domain: "example.com" }, web: {} };

/** A fresh mock Company, whose documents the conformance tests rely on. */
async function mockCompany(config: Partial<MockConfig> = {}): Promise<string> {
  const id = `v${crypto.randomUUID().replace(/-/g, "").slice(0, 12)}`;
  await (env as Env & { MOCK_COMPANY: DurableObjectNamespace<MockCompany> }).MOCK_COMPANY.getByName(id).configure(config);
  return `${id}.shop.test`;
}

/** example.com's poppy.json, protected resource metadata and issuer metadata, from a fake network, each changed as given. */
const company = (change: { poppy?: (doc: Record<string, any>) => void; prm?: unknown; metadata?: (doc: Record<string, any>) => void; routes?: Record<string, () => Response> } = {}) => {
  const poppy = structuredClone(SPEC_POPPY) as Record<string, any>;
  change.poppy?.(poppy);
  const metadata = structuredClone(SPEC_METADATA) as Record<string, any>;
  change.metadata?.(metadata);
  return validateCompany(
    network({
      "https://example.com/.well-known/poppy.json": jsonResponse(poppy),
      "https://example.com/.well-known/oauth-protected-resource": jsonResponse(change.prm ?? SPEC_PRM),
      "https://auth.example.com/.well-known/oauth-authorization-server": jsonResponse(metadata),
      "https://auth.example.org/.well-known/oauth-authorization-server": jsonResponse({ ...metadata, issuer: "https://auth.example.org" }),
      ...(change.routes ?? {})
    }),
    "example.com"
  );
};

const wellKnown = "https://example.com/.well-known/poppy.json";
/** The mock Companies, named as a caller must name its fetcher. */
const mockCompanies = () => named(testFetcher(env));
const fetchOne = (route: () => Response) => validateCompany(network({ [wellKnown]: route }), "example.com");

const noErrorsOrWarnings = (report: Report) => expect(report.counts.error + report.counts.warning).toBe(0);

const VALID: readonly Fixture[] = [
  {
    name: "accepts the specification's poppy.json example with no messages",
    run: () => text("poppy", SPEC_POPPY, { domain: "example.com" }),
    ids: [],
    outcome: "valid",
    also: (report) => {
      expect(report.checkedAgainst).toBe("Draft 0.4");
      expect(report.specificationRevision).toBe("2026-11-11");
    }
  },
  {
    name: "accepts the specification's client metadata example with no messages",
    run: () => text("client-metadata", SPEC_CLIENT, { fetchedFrom: SPEC_CLIENT.client_id }),
    ids: [],
    outcome: "valid"
  },
  {
    name: "accepts the specification's examples as a Company, with the issuer from the domain's protected resource metadata",
    run: () => company(),
    ids: [],
    outcome: "valid",
    also: (report) => {
      expect(report.checkedAgainst).toBe("Draft 0.4");
      expect(report.protocolVersion).toBe("0.4");
      expect((report as CompanyReport).issuer).toBe("https://auth.example.com");
      expect(report.documents.map((d) => d.kind)).toEqual(["poppy", "protected-resource", "oauth-metadata"]);
    }
  },
  {
    // As the interop grid serves it (MOCK_BASE: no unknown API type). Its deliberately unknown
    // protocol, extension and field are reported as info only.
    name: "accepts the mock Company's documents, as the reference Company in the grid serves them",
    run: async () => validateCompany(mockCompanies(), await mockCompany({ unknownApi: false })),
    ids: { contains: ["protocol-type-unknown", "unknown-member"] },
    outcome: "valid",
    also: noErrorsOrWarnings
  },
  {
    // The conformance tests' default lists a graphql API on purpose, to check that agents skip
    // it (7: SHOULD skip). Since 0.3 other types are allowed, so that's information, not an error.
    name: "notes the unknown API type the conformance tests' mock lists on purpose",
    run: async () => validateCompany(mockCompanies(), await mockCompany()),
    ids: { contains: ["api-type-unknown", "protocol-type-unknown", "unknown-member"] },
    outcome: "valid",
    also: (report) => {
      noErrorsOrWarnings(report);
      expect(report.refused).toBe(false);
    }
  },
  {
    name: "accepts the mock Company's documents without its deliberate oddities, with no messages",
    run: async () => validateCompany(mockCompanies(), await mockCompany({ unknownApi: false, unknownExtension: false, unknownField: false, unknownProtocol: false })),
    ids: [],
    outcome: "valid"
  },
  {
    name: "accepts our own client metadata and keys",
    run: () => validateClient(mockCompanies(), "https://agent.test/poppy/client.json"),
    ids: [],
    outcome: "valid",
    also: (report) => expect(report.documents.map((d) => d.kind)).toEqual(["client-metadata", "jwks"])
  }
];

/** poppy.json as served for example.com, checked without fetching anything else. */
const served = (doc: unknown) => text("poppy", doc, { domain: "example.com" });

/** example.com serving a 0.3 poppy.json that links its 0.4 document, or another root, each changed as given. */
const versioned = (change: { root?: Record<string, any>; linked?: Record<string, any>; linkedUrl?: string; routes?: Record<string, () => Response>; versions?: readonly string[] } = {}) => {
  const linkedUrl = change.linkedUrl ?? "https://example.com/poppy/0.4.json";
  const root = change.root ?? { ...structuredClone(POPPY_03), supported_versions: { "0.4": linkedUrl } };
  return validateCompany(
    network({
      "https://example.com/.well-known/poppy.json": jsonResponse(root),
      [linkedUrl]: jsonResponse(change.linked ?? SPEC_POPPY),
      "https://example.com/.well-known/oauth-protected-resource": jsonResponse(SPEC_PRM),
      "https://auth.example.com/.well-known/oauth-authorization-server": jsonResponse(SPEC_METADATA),
      ...(change.routes ?? {})
    }),
    "example.com",
    change.versions ? { versions: change.versions } : {}
  );
};

/** SPEC_POPPY as published 1.0 writes it: a description on each conversation protocol entry (8.1). */
const POPPY_10 = {
  ...structuredClone(SPEC_POPPY),
  protocol_version: "1.0",
  agent: { protocols: [{ type: "poppy", endpoint: "https://api.example.com/poppy/conversations", description: "Anything about your orders, returns, account, and our products" }] }
};
const with10 = (change: (doc: Record<string, any>) => void) => {
  const doc = structuredClone(POPPY_10) as Record<string, any>;
  change(doc);
  return doc;
};
/** A Company whose poppy.json is `root`, linking `linked` (each version's document) on the same host. */
const servedVersions = (root: Record<string, any>, linked: Record<string, Record<string, any>> = {}, versions?: readonly string[]) =>
  validateCompany(
    network({
      "https://example.com/.well-known/poppy.json": jsonResponse(root),
      ...Object.fromEntries(Object.entries(linked).map(([version, doc]) => [`https://example.com/poppy/${version}.json`, jsonResponse(doc)])),
      "https://example.com/.well-known/oauth-protected-resource": jsonResponse(SPEC_PRM),
      "https://auth.example.com/.well-known/oauth-authorization-server": jsonResponse(SPEC_METADATA)
    }),
    "example.com",
    versions ? { versions } : {}
  );

const POPPY_10_FIXTURES: readonly Fixture[] = [
  {
    name: "1.0: the spec's poppy.json with a description on its conversation protocol is valid",
    run: () => served(POPPY_10),
    ids: [],
    outcome: "valid",
    also: (report) => expect(report.checkedAgainst).toBe("1.0")
  },
  {
    // refFor: the catalog is written against 0.4's pages; npm run check:spec checks each section is the same in 1.0.
    name: "1.0: a report links the 1.0 pages, and a 0.4 report the 0.4 pages",
    run: async () => {
      const site = (report: Report) => [...new Set(report.messages.map((m) => /personalagentprotocol\.org\/docs\/([^/]+)\//.exec(m.ref.url)?.[1]).filter(Boolean))];
      const v04 = text("poppy", { ...SPEC_POPPY, organization: { ...SPEC_POPPY.organization, logo_uri: "http://example.com/logo.png" } }, { domain: "example.com" });
      expect(v04.checkedAgainst).toBe("Draft 0.4");
      expect(site(v04)).toEqual(["0.4"]);
      return served(with10((d) => (d.organization.logo_uri = "http://example.com/logo.png")));
    },
    ids: { contains: [] },
    also: (report) => {
      expect(report.messages.length).toBeGreaterThan(0);
      expect(report.messages.every((m) => !m.ref.url.includes("/docs/0.4/"))).toBe(true);
      expect(report.messages.some((m) => m.ref.url.startsWith("https://personalagentprotocol.org/docs/1.0/spec#"))).toBe(true);
    }
  },
  {
    name: "1.0: every conversation protocol entry needs a description",
    run: () => served(with10((d) => delete d.agent.protocols[0].description)),
    ids: ["missing-member"],
    outcome: "invalid",
    also: (report) => {
      expect(report.messages[0]!.pointer).toBe("/agent/protocols/0/description");
      expect(report.messages[0]!.ref.url).toBe("https://personalagentprotocol.org/docs/1.0/spec#conversation-protocols");
      expect(report.refused).toBe(true);
    }
  },
  {
    name: "1.0: an empty description says nothing",
    run: () => served(with10((d) => (d.agent.protocols[0].description = "  "))),
    ids: ["protocol-description-empty"],
    outcome: "invalid"
  },
  {
    name: "1.0: 0.4 defines no description, so a 0.4 document's is an unknown member",
    run: () => served(withPoppy((d) => (d.agent.protocols[0].description = "Orders"))),
    ids: ["unknown-member"],
    outcome: "valid"
  },
  {
    name: "1.0: a 1.1 document is checked with 1.0's rules, ignoring what 1.1 adds",
    run: () => served(with10((d) => {
      d.protocol_version = "1.1";
      d.loyalty = { tier: "gold" };
    })),
    ids: ["version-newer-minor", "unknown-member"],
    outcome: "valid",
    also: (report) => expect(report).toMatchObject({ checkedAgainst: "1.0", protocolVersion: "1.0", refused: false })
  },
  {
    name: "1.0: a 0.4 poppy.json that links a 1.0 document is used in 1.0, the newest version both speak",
    run: () => servedVersions({ ...structuredClone(SPEC_POPPY), supported_versions: { "1.0": "https://example.com/poppy/1.0.json" } }, { "1.0": POPPY_10 }),
    ids: [],
    outcome: "valid",
    also: (report) => expect((report as CompanyReport).poppy).toMatchObject({ protocol_version: "1.0" })
  },
  {
    name: "1.0: an agent that speaks only 0.4 keeps to 0.4 when the Company links 1.0",
    run: () => servedVersions({ ...structuredClone(SPEC_POPPY), supported_versions: { "1.0": "https://example.com/poppy/1.0.json" } }, { "1.0": POPPY_10 }, ["0.4"]),
    ids: [],
    outcome: "valid",
    also: (report) => expect(report).toMatchObject({ checkedAgainst: "Draft 0.4", poppy: { protocol_version: "0.4" } })
  },
  {
    name: "1.0: a 1.0 agent uses a Company that serves only 1.1",
    run: () => servedVersions(with10((d) => (d.protocol_version = "1.1")), {}, ["0.4", "1.0"]),
    ids: ["version-newer-minor"],
    outcome: "valid",
    also: (report) => expect(report).toMatchObject({ checkedAgainst: "1.0", poppy: { protocol_version: "1.1" } })
  },
  {
    name: "1.0: a 0.4 agent doesn't use a Company that serves only 1.0, a version it can't speak",
    run: () => servedVersions(POPPY_10, {}, ["0.4"]),
    ids: ["version-unsupported"],
    outcome: "invalid",
    also: (report) => expect(report.refused).toBe(true)
  },
  {
    name: "1.0: an issuer that lists client-assertion algorithms lists ES256 and PS384 (4.1)",
    run: () => company({ poppy: (d) => Object.assign(d, structuredClone(POPPY_10)), metadata: (d) => { d.token_endpoint_auth_signing_alg_values_supported = ["ES256"]; } }),
    ids: ["metadata-assertion-algs"],
    outcome: "invalid",
    also: async (report) => {
      expect(report.messages[0]!.ref.url).toBe("https://personalagentprotocol.org/docs/1.0/spec#agent-identity");
      const both = await company({ poppy: (d) => Object.assign(d, structuredClone(POPPY_10)), metadata: (d) => { d.token_endpoint_auth_signing_alg_values_supported = ["PS384", "ES256"]; } });
      expect(both.messages).toEqual([]);
      // 0.4 only recommended PS384.
      const draft04 = await company({ metadata: (d) => { d.token_endpoint_auth_signing_alg_values_supported = ["ES256"]; } });
      expect(draft04.messages).toEqual([]);
    }
  },
  {
    name: "1.0: organization.domain carries its port when that isn't 443 (3.1)",
    run: () => text("poppy", with10((d) => (d.organization.domain = "example.com:8443")), { domain: "example.com:8443" }),
    ids: [],
    outcome: "valid",
    also: async () => {
      const ids = async (doc: unknown) => (await text("poppy", doc, {})).messages.map((m) => m.id);
      expect(await ids(with10((d) => (d.organization.domain = "example.com:443")))).toEqual(["domain-invalid"]);
      expect(await ids(with10((d) => (d.organization.domain = "example.com:70000")))).toEqual(["domain-invalid"]);
      expect(await ids(withPoppy((d) => (d.organization.domain = "example.com:8443")))).toEqual(["domain-invalid"]);
    }
  },
  {
    name: "requires a pushed_authorization_request_endpoint when Pushed Authorization Requests are required (RFC 9126 §5)",
    run: () => company({ metadata: (doc) => { doc.require_pushed_authorization_requests = true; } }),
    ids: ["par-endpoint-missing"],
    outcome: "invalid",
    also: async () => {
      const listed = await company({ metadata: (doc) => { doc.require_pushed_authorization_requests = true; doc.pushed_authorization_request_endpoint = "https://auth.example.com/oauth/par"; } });
      expect(listed.messages).toEqual([]);
      const insecure = await company({ metadata: (doc) => { doc.pushed_authorization_request_endpoint = "http://auth.example.com/oauth/par"; } });
      expect(insecure.messages.map((m) => m.pointer)).toEqual(["/pushed_authorization_request_endpoint"]);
    }
  }
];

const POPPY_04: readonly Fixture[] = [
  {
    name: "0.4: links each message to the 0.4 pages",
    run: () => served(withPoppy((d) => delete d.organization.name)),
    ids: ["organization-name-missing"],
    also: (report) => expect(report.messages[0]!.ref.url).toMatch(/^https:\/\/personalagentprotocol\.org\/docs\/0\.4\//)
  },
  {
    name: "0.4: an extension written as 0.3's single object is skipped",
    run: () => served(withPoppy((d) => (d.extensions.operations = { version: "3" }))),
    ids: ["extension-entries"],
    outcome: "invalid",
    also: (report) => expect(report.refused).toBe(false)
  },
  {
    name: "0.4: excluded tasks, the skill index and feedback moved to the tasks endpoint",
    run: () => served(withPoppy((d) => {
      d.feedback = { endpoint: "https://api.example.com/poppy/feedback" };
      d.excluded_tasks = { url: "https://example.com/x.json" };
      d.skill_index = { $schema: "https://schemas.agentskills.io/discovery/0.2.0/schema.json", skills: [] };
    })),
    ids: ["member-moved-to-tasks", "member-moved-to-tasks", "member-moved-to-tasks"],
    outcome: "valid"
  },
  {
    name: "0.4: web.disabled lists no browser-session endpoint, and needs the agent or an API",
    run: () => served({ protocol_version: "0.4", organization: { name: "A", domain: "example.com" }, web: { disabled: true, browser_session_endpoint: "https://example.com/join" } }),
    ids: ["web-disabled-browser-session", "web-disabled-no-alternative"],
    outcome: "invalid"
  },
  {
    name: "0.4: website operations need browser join, and so does Browser Control",
    run: () => served(withPoppy((d) => delete d.web.browser_session_endpoint)),
    ids: ["operations-endpoint-without-join", "browser-control-without-join"],
    outcome: "invalid"
  },
  {
    name: "0.4: web.unscoped needs browser join",
    run: () => served(withPoppy((d) => {
      d.web = { unscoped: true };
      delete d.extensions.operations;
      delete d.extensions["browser-control"];
    })),
    ids: ["web-unscoped-without-join"],
    outcome: "invalid"
  },
  {
    name: "0.4: a Company with browser join and sign-in supports poppy:browser-sign-in",
    run: () => company({ metadata: (doc) => { doc.scopes_supported = doc.scopes_supported.filter((scope: string) => scope !== "poppy:browser-sign-in"); } }),
    ids: ["browser-sign-in-unsupported"],
    outcome: "invalid"
  },
  {
    name: "0.4: an operations version this validator doesn't know is noted, and 0.3's version 2 is one",
    run: () => served(withPoppy((d) => (d.extensions.operations = [{ version: "2" }]))),
    ids: ["extension-version-unknown"],
    outcome: "valid"
  },
  {
    name: "0.4: Device Sign-In without Direct is a warning",
    run: () => company({ metadata: (doc) => { doc.grant_types_supported = ["refresh_token", "urn:ietf:params:oauth:grant-type:device_code", "https://personalagentprotocol.org/grant/mediated-sign-in"]; } }),
    ids: ["direct-sign-in-preferred"],
    outcome: "valid"
  },
  {
    name: "0.4: uses a 0.4 poppy.json's own version, without fetching the 0.3 document it links",
    run: () => versioned({ root: { ...structuredClone(SPEC_POPPY), supported_versions: { "0.3": "https://example.com/poppy/0.3.json" } }, linkedUrl: "https://example.com/poppy/0.3.json", linked: POPPY_03 }),
    ids: [],
    outcome: "valid",
    also: (report) => {
      expect(report.checkedAgainst).toBe("Draft 0.4");
      expect((report as CompanyReport).poppy).toMatchObject({ protocol_version: "0.4" });
      expect(report.documents.map((d) => d.kind)).toEqual(["poppy", "protected-resource", "oauth-metadata"]);
    }
  },
  {
    name: "0.4: a 0.3 poppy.json that links 0.4 is checked by its 0.4 document",
    run: () => versioned(),
    ids: [],
    outcome: "valid",
    also: (report) => {
      expect(report.checkedAgainst).toBe("Draft 0.4");
      expect((report as CompanyReport).poppy).toMatchObject({ protocol_version: "0.4" });
      expect(report.documents.map((d) => d.url)).toEqual(["https://example.com/.well-known/poppy.json", "https://example.com/poppy/0.4.json", "https://example.com/.well-known/oauth-protected-resource", "https://auth.example.com/.well-known/oauth-authorization-server"]);
    }
  },
  {
    name: "0.4: a poppy.json in a version the agent doesn't speak, listing none it does, is refused",
    run: () => versioned({ root: SPEC_POPPY, versions: ["0.3"] }),
    ids: ["version-unsupported"],
    outcome: "invalid"
  },
  {
    name: "0.4: a linked document on another host, over http or for its own version is skipped",
    run: () => versioned({
      root: { ...structuredClone(SPEC_POPPY), supported_versions: { "0.3": "https://cdn.example.com/0.3.json", "0.2": "http://example.com/0.2.json", "0.4": "https://example.com/0.4.json", latest: "https://example.com/x.json" } }
    }),
    ids: ["supported-version-unusable", "supported-version-unusable", "supported-version-unusable", "supported-version-unusable"],
    outcome: "invalid",
    also: (report) => {
      expect(report.checkedAgainst).toBe("Draft 0.4");
      expect(report.refused).toBe(false);
    }
  },
  {
    name: "0.4: a linked document that redirects is skipped, so a 0.3 poppy.json that links only it is refused",
    run: () => versioned({
      routes: { "https://example.com/poppy/0.4.json": () => new Response(null, { status: 302, headers: { Location: "https://example.com/elsewhere.json" } }) }
    }),
    ids: ["supported-version-unusable", "version-unsupported"],
    outcome: "invalid",
    also: (report) => {
      expect(report.messages[1]!.text).toBe('protocol_version: expected a version this validator supports (0.4 or 1.0), got "0.3".');
      expect(report.refused).toBe(true);
    }
  },
  {
    name: "0.4: a linked document for another version refuses the Company rather than falling back",
    run: () => versioned({ linked: { ...SPEC_POPPY, protocol_version: "0.5" } }),
    ids: ["linked-document-version"],
    outcome: "invalid",
    also: (report) => expect(report.refused).toBe(true)
  },
  {
    name: "0.4: a linked document lists no supported_versions, and has poppy.json's domain",
    run: () => versioned({ linked: { ...structuredClone(SPEC_POPPY), supported_versions: {}, organization: { name: "A", domain: "example.org" } } }),
    ids: { contains: ["linked-document-supported-versions", "linked-document-domain"] },
    also: (report) => expect(report.refused).toBe(true)
  }
];

const POPPY_JSON: readonly Fixture[] = [
  {
    name: "refuses cumulative JSON location amplification as an implementation limit, not a syntax error",
    run: () => text("poppy", { ["x".repeat(4_000)]: Array(300).fill(0) }),
    ids: ["json-resource-limit"],
    outcome: "indeterminate",
    also: (report) => expect(report).toMatchObject({ refused: true, counts: { error: 0, warning: 1 } })
  },
  {
    name: "reports a JSON syntax error with line and column",
    run: () => text("poppy", '{\n  "protocol_version": "0.4",\n  "organization": {\n}'),
    ids: { contains: ["json-syntax"] },
    outcome: "invalid",
    also: (report) => expect(report.messages[0]).toMatchObject({ id: "json-syntax", line: 4, column: 2 })
  },
  {
    name: "reports a duplicate member name with line, column and pointer",
    run: () => text("poppy", '{"protocol_version":"0.4","protocol_version":"0.4","organization":{"name":"A","domain":"a.example"},"web":{}}'),
    ids: { contains: ["json-duplicate-member"] },
    also: (report) =>
      expect(report.messages.find((m) => m.id === "json-duplicate-member")).toMatchObject({ line: 1, column: 27, pointer: "/protocol_version" })
  },
  {
    name: "reports a byte order mark",
    run: () => text("poppy", `﻿${JSON.stringify(SPEC_POPPY)}`),
    ids: { contains: ["json-bom"] }
  },
  {
    name: "chooses rules by protocol_version: a version that isn't major.minor",
    run: () => text("poppy", withPoppy((d) => (d.protocol_version = "3"))),
    ids: { contains: ["version-format"] }
  },
  {
    name: "chooses rules by protocol_version: an unsupported major version",
    run: () => text("poppy", withPoppy((d) => (d.protocol_version = "2.0"))),
    ids: ["version-unsupported-major"],
    also: (report) => expect(report.messages[0]!.text).toMatch(/got "2\.0"/)
  },
  {
    name: "refuses a newer pre-1.0 version before checking its fields",
    run: () =>
      text("poppy", withPoppy((d) => {
        d.protocol_version = "0.7";
        d.loyalty = { tier: "gold" };
      })),
    ids: ["version-unsupported"],
    outcome: "invalid"
  },
  {
    // Before 1.0 every version can break the one before (3.1), and only 0.4 and 1.0 are checked.
    name: "refuses a 0.3 document, which this validator no longer checks, before checking its fields",
    run: () => text("poppy", POPPY_03, { domain: "example.com" }),
    ids: ["version-unsupported"],
    outcome: "invalid",
    also: (report) => {
      expect(report.messages[0]!.text).toBe('protocol_version: expected a version this validator supports (0.4 or 1.0), got "0.3".');
      expect(report.refused).toBe(true);
    }
  },
  {
    name: "refuses a 0.2 document, which this validator no longer checks",
    run: () => text("poppy", withPoppy((d) => (d.protocol_version = "0.2"))),
    ids: ["version-unsupported"],
    outcome: "invalid",
    also: (report) => expect(report.messages[0]!.text).toBe('protocol_version: expected a version this validator supports (0.4 or 1.0), got "0.2".')
  },
  {
    name: "chooses rules by protocol_version: none given",
    run: () => text("poppy", withPoppy((d) => delete d.protocol_version)),
    // The newest version the validator knows.
    ids: { contains: ["missing-member"] },
    also: (report) => expect(report.checkedAgainst).toBe("1.0")
  },
  {
    name: "checks organization: not an object",
    run: () => text("poppy", withPoppy((d) => (d.organization = "Example"))),
    ids: { contains: ["wrong-type"] }
  },
  {
    name: "checks organization: no name",
    run: () => text("poppy", withPoppy((d) => delete d.organization.name)),
    ids: ["organization-name-missing"]
  },
  {
    name: "checks organization: a blank name is no display name, and our client refuses it",
    run: () => text("poppy", withPoppy((d) => (d.organization.name = "  "))),
    ids: ["organization-name-missing"],
    outcome: "invalid",
    also: (report) => expect(report.refused).toBe(true)
  },
  {
    name: "checks organization: a URL as the domain",
    run: () => text("poppy", withPoppy((d) => (d.organization.domain = "https://example.com/"))),
    ids: { contains: ["domain-invalid"] }
  },
  {
    name: "checks organization: a domain other than the one that served it",
    run: () => text("poppy", SPEC_POPPY, { domain: "evil.example" }),
    ids: ["organization-domain-mismatch"]
  },
  {
    // 3.1: "Domains are compared ignoring case, with no other normalization."
    name: "checks organization: compares the domain ignoring case only, so a leading www. counts",
    run: () => text("poppy", SPEC_POPPY, { domain: "www.example.com" }),
    ids: ["organization-domain-mismatch"],
    also: () => expect(ids(text("poppy", SPEC_POPPY, { domain: "EXAMPLE.com" }))).toEqual([])
  },
  {
    name: "accepts a website-only Company, with a note",
    run: () => text("poppy", WEBSITE_ONLY),
    ids: ["website-only"],
    outcome: "valid"
  },
  {
    name: "requires something to offer",
    run: () =>
      text("poppy", withPoppy((d) => {
        delete d.agent;
        delete d.apis;
        delete d.web;
        // Website operations and Browser Control need browser join, which went with web.
        delete d.extensions.operations;
        delete d.extensions["browser-control"];
      })),
    ids: ["nothing-offered"]
  },
  {
    name: "checks the issuer: http",
    run: () => text("poppy", withPoppy((d) => (d.auth.issuer = "http://auth.example.com/?tenant=1"))),
    ids: ["not-https-url"],
    // The URL itself is what was got, without its query.
    also: (report) => expect(report.messages[0]!.text).toBe("auth.issuer: expected an https URL, got http://auth.example.com/?…")
  },
  {
    name: "checks the issuer: a query",
    run: () => text("poppy", withPoppy((d) => (d.auth.issuer = "https://auth.example.com?tenant=1"))),
    ids: ["issuer-query"]
  },
  {
    name: "checks the issuer: a fragment",
    run: () => text("poppy", withPoppy((d) => (d.auth.issuer = "https://auth.example.com/#x"))),
    ids: ["url-has-fragment"]
  },
  {
    name: "checks the issuer: a URL with no usable host",
    run: () => text("poppy", withPoppy((d) => (d.auth.issuer = "https://."))),
    ids: ["not-a-url"],
    outcome: "invalid"
  },
  {
    name: "checks the issuer: not a URL",
    run: () => text("poppy", withPoppy((d) => (d.auth.issuer = "auth.example.com"))),
    ids: ["not-a-url"]
  },
  {
    name: "checks scope descriptions and hints: names that aren't OAuth scopes, and a description that isn't a string",
    run: () =>
      text("poppy", withPoppy((d) => {
        d.auth.scopes["bad scope"] = "Everything";
        d.auth.scopes.loyalty = 7;
        d.auth.scope_hints["bad\"hint"] = { changes: "none", personal_data: false };
      })),
    ids: ["scope-syntax", "wrong-type", "scope-syntax"]
  },
  {
    name: "warns of an extension version written as a number, whose type the draft doesn't give (N22)",
    run: () => text("poppy", withPoppy((d) => (d.extensions.operations = [{ version: 3 }]))),
    ids: ["extension-version-number"],
    outcome: "valid",
    also: (report) => expect(report.refused).toBe(false)
  },
  {
    name: "checks Mediated Sign-In's scopes: a duplicate and a name that isn't an OAuth scope",
    run: () => text("poppy", withPoppy((d) => (d.extensions["mediated-sign-in"][0].scopes = ["orders:read", "orders:read", "bad scope"]))),
    ids: ["scope-duplicate", "scope-syntax"],
    also: (report) => expect(report.messages.map((m) => m.pointer)).toEqual(["/extensions/mediated-sign-in/0/scopes/1", "/extensions/mediated-sign-in/0/scopes/2"])
  },
  {
    name: "checks Mediated Sign-In's scopes: none",
    run: () => text("poppy", withPoppy((d) => (d.extensions["mediated-sign-in"][0].scopes = []))),
    ids: ["scopes-empty"]
  },
  {
    name: "checks Mediated Sign-In's fields: none",
    run: () => text("poppy", withPoppy((d) => (d.extensions["mediated-sign-in"][0].fields = []))),
    ids: ["mediated-fields-empty"],
    also: (report) => expect(report.messages[0]!.text).toBe("extensions.mediated-sign-in[0].fields: expected at least one field, got none.")
  },
  {
    name: "checks Mediated Sign-In's fields: secret missing, looks secret, duplicate",
    run: () =>
      text("poppy", withPoppy((d) => {
        d.extensions["mediated-sign-in"][0].fields = [
          { name: "email", label: "Email" },
          { name: "pin", label: "PIN", secret: false },
          { name: "email", label: "Email again", secret: false }
        ];
      })),
    ids: ["mediated-secret-missing", "mediated-looks-secret", "mediated-field-duplicate"]
  },
  {
    // 0.3 removed `resource` from agent.protocols and apis (4.5): it's an unknown member.
    name: "checks the agent's protocols, and notes a resource, which 0.3 removed",
    run: () =>
      text("poppy", withPoppy((d) => {
        d.agent.protocols = [{ type: "example.com/chat", endpoint: "https://api.example.com/chat", resource: "https://api.example.com" }];
      })),
    ids: ["protocol-type-unknown", "unknown-member", "no-poppy-protocol"],
    also: (report) => expect(report.messages[1]!.pointer).toBe("/agent/protocols/0/resource")
  },
  {
    name: "checks the conversation endpoint: http",
    run: () =>
      text("poppy", withPoppy((d) => {
        d.agent.protocols = [{ type: "poppy", endpoint: "http://api.example.com/poppy/conversations" }];
      })),
    ids: ["not-https-url"]
  },
  {
    name: "checks the APIs",
    run: () =>
      text("poppy", withPoppy((d) => {
        d.apis = [
          { type: "graphql", url: "https://api.example.com/graphql", description: "Everything" },
          { type: "openapi", url: "https://api.example.com/openapi.json" },
          { type: "mcp", url: "https://mcp.example.com/mcp", description: "Search", resource: "https://mcp.example.com/mcp" }
        ];
      })),
    ids: ["api-type-unknown", "api-description-missing", "unknown-member"],
    // A normative statement without a key word ("a short description") is an error, but one
    // our client tolerates: it still uses the Company. Another API type is allowed (7).
    outcome: "invalid",
    also: (report) => {
      expect(report.messages.find((m) => m.id === "api-type-unknown")).toMatchObject({ severity: "info", refuses: false });
      expect(report.messages.find((m) => m.id === "api-description-missing")).toMatchObject({ basis: "Rule", severity: "error", refuses: false });
      expect(report.refused).toBe(false);
    }
  },
  {
    // 3: "Every URL this protocol defines or exchanges MUST be an HTTPS URL", which spec-issues N9 asked for.
    name: "requires an HTTPS API URL, as every URL the protocol defines",
    run: () => text("poppy", withPoppy((d) => (d.apis = [{ type: "openapi", url: "http://api.example.com/openapi.json", description: "Orders" }]))),
    ids: ["not-https-url"],
    outcome: "invalid",
    also: (report) => {
      expect(report.messages[0]).toMatchObject({ basis: "MUST", severity: "error", refuses: true });
      expect(report.messages[0]!.ref.label).toBe("Spec 7");
    }
  },
  {
    name: "warns of a fragment in an API URL, where no rule forbids one, and our client refuses it",
    run: () => text("poppy", withPoppy((d) => (d.apis[0].url = "https://api.example.com/openapi.json#x"))),
    ids: ["url-has-fragment-unstated"],
    outcome: "valid",
    also: (report) => expect(report.refused).toBe(true)
  },
  {
    name: "checks extensions: names and versions",
    run: () =>
      text("poppy", withPoppy((d) => {
        d.extensions = {
          operations: [{ version: "3" }],
          "example.com/gift-wrap": [{ version: "2", anything: true }],
          "gift-wrap": [{ version: "1" }],
          "notadomain/gift-wrap": [{ version: "1" }],
          "example.com/no-version": [{}]
        };
      })),
    ids: ["extension-plain-unknown", "extension-name", "missing-member"]
  },
  {
    name: "refuses a Mediated Sign-In field named like a grant parameter",
    run: () => text("poppy", withPoppy((d) => (d.extensions["mediated-sign-in"][0].fields[0].name = "scope"))),
    ids: ["mediated-field-reserved"],
    outcome: "invalid"
  },
  {
    name: "refuses a scope hint without both fields, and notes a changes value it doesn't define",
    run: () =>
      text("poppy", withPoppy((d) => {
        d.auth.scope_hints["orders:read"] = { changes: "none" };
        d.auth.scope_hints.addresses = { changes: "sometimes", personal_data: true };
      })),
    ids: ["scope-hint-invalid", "scope-hint-changes-unknown"],
    outcome: "invalid"
  }
];

const DISCOVERY: readonly Fixture[] = [
  {
    name: "refuses a document a redirect moved off the well-known path",
    run: () =>
      company({
        routes: {
          "https://example.com/.well-known/poppy.json": () => new Response(null, { status: 302, headers: { Location: "https://example.com/uploads/poppy.json" } }),
          "https://example.com/uploads/poppy.json": jsonResponse(SPEC_POPPY)
        }
      }),
    ids: ["poppy-redirect-path"],
    outcome: "invalid"
  },
  {
    // 3: the document speaks for the host that served it, after any redirects.
    name: "compares organization.domain with the host a redirect ended at",
    run: () =>
      company({
        routes: {
          "https://example.com/.well-known/poppy.json": () => new Response(null, { status: 302, headers: { Location: "https://www.example.com/.well-known/poppy.json" } }),
          "https://www.example.com/.well-known/poppy.json": jsonResponse(SPEC_POPPY)
        }
      }),
    ids: ["organization-domain-mismatch"],
    outcome: "invalid",
    also: (report) => expect(report.messages[0]!.text).toBe('organization.domain: expected "www.example.com", the host that served the document, got "example.com".')
  },
  {
    name: "refuses protected resource metadata for another resource",
    run: () => company({ prm: { ...SPEC_PRM, resource: "https://example.com/api" } }),
    ids: ["prm-resource-mismatch"],
    outcome: "invalid"
  },
  {
    // 3.2: no authorization server means no issuer, which is invalid only for a Company that offers sign-in.
    name: "refuses protected resource metadata with no authorization server when poppy.json offers sign-in",
    run: () => company({ prm: { ...SPEC_PRM, authorization_servers: [] } }),
    ids: ["prm-no-issuer", "issuer-required"],
    outcome: "invalid",
    also: (report) => {
      expect((report as CompanyReport).issuerless).toBe(true);
      expect(report.messages[1]!.text).toContain("the Mediated Sign-In extension");
    }
  },
  {
    // The reported case: an MCP catalog, signed out only, with no OAuth issuer yet.
    name: "accepts a signed-out Company whose protected resource metadata is a 404, identified by its domain",
    run: () =>
      validateCompany(
        network({
          "https://example.com/.well-known/poppy.json": jsonResponse({
            protocol_version: "0.4",
            organization: { name: "Example Company", domain: "example.com" },
            apis: [{ type: "mcp", url: "https://mcp.example.com/mcp", description: "Plans, phones, promotions and accessories" }]
          }),
          "https://example.com/.well-known/oauth-protected-resource": () => new Response(JSON.stringify({ error: "not_found" }), { status: 404, headers: { "Content-Type": "application/json" } })
        }),
        "example.com"
      ),
    ids: ["prm-no-issuer"],
    outcome: "valid",
    also: (report) => {
      const company = report as CompanyReport;
      expect(company.refused).toBe(false);
      expect(company.issuerless).toBe(true);
      expect(company.identifier).toBe("https://example.com");
      expect(company.issuer).toBeUndefined();
      expect(company.documents.map((d) => [d.kind, d.status])).toEqual([["poppy", 200], ["protected-resource", 404]]);
    }
  },
  {
    // 3.2: no fallback to the domain after another error status.
    name: "doesn't treat another error status for the protected resource metadata as no issuer",
    run: () =>
      company({
        poppy: (doc) => { delete doc.auth; delete doc.extensions; },
        routes: { "https://example.com/.well-known/oauth-protected-resource": () => new Response("", { status: 503 }) }
      }),
    ids: ["http-status", "prm-unsettled"],
    outcome: "indeterminate",
    also: (report) => {
      expect((report as CompanyReport).issuerless).toBeUndefined();
      expect((report as CompanyReport).identifier).toBeUndefined();
      expect(report.refused).toBe(true);
      expect(report.messages[1]!.text).toBe(
        "Agents can't tell from https://example.com/.well-known/oauth-protected-resource whether the Company has an OAuth issuer, so they don't fall back to https://example.com as its identifier and can't open Sessions with it."
      );
    }
  },
  {
    // Nothing here uses Sessions, so an unknown issuer stops sign-in, not Sessions.
    name: "says an unsettled issuer stops sign-in for a Company that names one but uses no Sessions",
    run: () =>
      validateCompany(
        network({
          "https://example.com/.well-known/poppy.json": jsonResponse({ protocol_version: "1.0", organization: { name: "Example Company", domain: "example.com" }, web: {}, auth: { issuer: "https://auth.example.com" } }),
          "https://example.com/.well-known/oauth-protected-resource": () => new Response("", { status: 503 })
        }),
        "example.com"
      ),
    ids: ["http-status", "prm-unsettled"],
    outcome: "indeterminate",
    also: (report) => expect(report.messages[1]!.text).toMatch(/as its identifier and can't sign in with it\.$/)
  },
  {
    // The reported case: a signed-out Company whose site sends every unknown path, /.well-known/ included, to a sign-in page elsewhere.
    name: "reports a sign-in page where the protected resource metadata should be as a web page, and what it means for the issuer",
    run: () =>
      validateCompany(
        network({
          "https://example.com/.well-known/poppy.json": jsonResponse({
            protocol_version: "1.0",
            organization: { name: "Example Company", domain: "example.com" },
            agent: { protocols: [{ type: "poppy", endpoint: "https://agents.example.net/poppy/conversations", description: "Claims and benefits" }] }
          }),
          "https://example.com/.well-known/oauth-protected-resource": () => new Response(null, { status: 301, headers: { Location: "/app/portal" } }),
          "https://example.com/app/portal": () =>
            new Response(null, { status: 302, headers: { Location: "https://login.example-idp.com/sso/saml?SAMLRequest=fVLRctow&RelayState=https%3A%2F%2Fexample.com%2Fapp%2Fportal" } }),
          "https://login.example-idp.com/sso/saml?SAMLRequest=fVLRctow&RelayState=https%3A%2F%2Fexample.com%2Fapp%2Fportal": () =>
            new Response("<!DOCTYPE html>\n<html><head><title>Sign in</title></head><body><form></form></body></html>", {
              headers: { "Content-Type": "text/html;charset=utf-8", "Cache-Control": "no-cache, no-store" }
            })
        }),
        "example.com"
      ),
    // Nothing about the page's syntax, type or cache lifetime: it isn't the document.
    ids: ["http-web-page", "prm-unsettled"],
    outcome: "indeterminate",
    also: (report) => {
      expect(report.refused).toBe(true);
      expect((report as CompanyReport).identifier).toBeUndefined();
      const [page, note] = report.messages;
      expect(page).toMatchObject({ document: "protected-resource", severity: "error", refuses: true });
      expect(page!.text).toBe(
        "https://example.com/.well-known/oauth-protected-resource: expected HTTP 404 (no issuer), or protected resource metadata as application/json, got a web page (HTTP 200, text/html) at https://login.example-idp.com/sso/saml?…, on another host, after redirects."
      );
      // The redirect's query can carry one-time values, and this text reaches the agent's model (summarize); the data keeps it.
      expect(summarize(report)).toBe(page!.text.replace(/\.$/, ""));
      expect(summarize(report)).not.toMatch(/SAMLRequest|RelayState/);
      expect(report.documents[1]).toMatchObject({ status: 200, contentType: "text/html;charset=utf-8", finalUrl: expect.stringContaining("SAMLRequest=fVLRctow") });
      expect(report.documents[1]).not.toHaveProperty("value");
      expect(note).toMatchObject({ document: "protected-resource", severity: "info", refuses: false });
      expect(note!.text).toContain("don't fall back to https://example.com as its identifier");
    }
  },
  {
    // 3.2: invalid metadata settles nothing either; its own messages say what is wrong with it.
    name: "notes an unsettled issuer after protected resource metadata that isn't JSON",
    run: () =>
      company({
        poppy: (doc) => { delete doc.auth; delete doc.extensions; },
        routes: { "https://example.com/.well-known/oauth-protected-resource": () => new Response("OK", { headers: { "Content-Type": "text/plain", "Cache-Control": "max-age=300" } }) }
      }),
    ids: ["http-content-type", "json-syntax", "prm-unsettled"],
    outcome: "invalid"
  },
  {
    name: "refuses sign-in without an issuer: auth.issuer or signed_in access with a 404",
    run: () =>
      company({
        poppy: (doc) => { delete doc.extensions; doc.auth.issuer = "https://auth.example.com"; doc.agent.protocols[0].access = "signed_in"; },
        routes: { "https://example.com/.well-known/oauth-protected-resource": () => new Response("", { status: 404 }) }
      }),
    ids: ["prm-no-issuer", "issuer-required"],
    outcome: "invalid",
    also: (report) => expect(report.messages[1]!.text).toContain("auth.issuer and signed_in access")
  },
  {
    name: "refuses an auth.issuer the domain doesn't list",
    run: () => company({ poppy: (doc) => { doc.auth.issuer = "https://auth.example.org"; } }),
    ids: ["issuer-not-listed"],
    outcome: "invalid"
  },
  {
    name: "refuses several authorization servers without auth.issuer, and uses auth.issuer when it chooses one",
    run: () => company({ prm: { ...SPEC_PRM, authorization_servers: ["https://auth.example.com", "https://staff.example.com"] } }),
    ids: ["issuer-ambiguous"],
    outcome: "invalid",
    also: async () => {
      const chosen = await company({ prm: { ...SPEC_PRM, authorization_servers: ["https://staff.example.com", "https://auth.example.com"] }, poppy: (doc) => { doc.auth.issuer = "https://auth.example.com"; } });
      expect(chosen.messages).toEqual([]);
      expect(chosen.issuer).toBe("https://auth.example.com");
    }
  },
  {
    name: "checks pasted protected resource metadata, where no authorization server means no issuer",
    run: () => text("protected-resource", { resource: "https://example.com", authorization_servers: [] }),
    ids: ["prm-no-issuer"],
    outcome: "valid",
    also: (report) => {
      expect(report.skipped.map((s) => s.check)).toContain("Nothing in poppy.json offers sign-in, as a Company without an issuer must not");
      expect(text("protected-resource", { resource: "https://example.com" }).messages.map((m) => m.id)).toEqual(["prm-no-issuer"]);
    }
  },
  {
    name: "refuses auth.disabled with Mediated Sign-In or signed_in access",
    run: () => text("poppy", withPoppy((d) => { d.auth.disabled = true; d.agent.protocols[0].access = "signed_in"; }), { domain: "example.com" }),
    ids: ["auth-disabled-sign-in", "auth-disabled-sign-in"],
    outcome: "invalid"
  },
  {
    name: "notes a conversation access hint agents ignore, and accepts session and signed_in",
    run: () => text("poppy", withPoppy((d) => { d.agent.protocols[0].access = "always"; }), { domain: "example.com" }),
    ids: ["access-unknown"],
    outcome: "valid",
    also: () => {
      for (const access of ["session", "signed_in"]) expect(text("poppy", withPoppy((d) => { d.agent.protocols[0].access = access; }), { domain: "example.com" }).messages).toEqual([]);
    }
  },
];

const METADATA: readonly Fixture[] = [
  {
    name: "requires the issuer to match exactly, so a trailing slash doesn't",
    run: () => company({ metadata: (doc) => { doc.issuer = "https://auth.example.com/"; } }),
    ids: { contains: ["metadata-issuer-mismatch"] },
    outcome: "invalid"
  },
  {
    name: "refuses issuer metadata whose protected_resources leaves out the domain, compared exactly but for the host's case",
    run: () => company({ metadata: (doc) => { doc.protected_resources = ["https://example.com/", "https://EXAMPLE.co.uk"]; } }),
    ids: ["metadata-protected-resources"],
    outcome: "invalid",
    also: async () => {
      expect((await company({ metadata: (doc) => { doc.protected_resources = ["https://EXAMPLE.com"]; } })).messages).toEqual([]);
    }
  },
  {
    name: "requires grant_types_supported, with refresh_token",
    run: () => company({ metadata: (doc) => { doc.grant_types_supported = ["authorization_code", "https://personalagentprotocol.org/grant/mediated-sign-in"]; delete doc.device_authorization_endpoint; } }),
    ids: ["metadata-refresh-grant"],
    outcome: "invalid"
  },
  {
    name: "requires the endpoint each sign-in grant needs",
    run: () => company({ metadata: (doc) => { delete doc.authorization_endpoint; delete doc.device_authorization_endpoint; } }),
    ids: ["missing-member", "missing-member"],
    outcome: "invalid",
    also: (report) => expect(report.messages.map((m) => m.pointer)).toEqual(["/authorization_endpoint", "/device_authorization_endpoint"])
  },
  {
    // 3.2: SHOULD since 850a46d; RFC 8414 makes it optional.
    name: "recommends scopes_supported when the Company offers sign-in, and doesn't ask for it with auth.disabled",
    run: () => company({ metadata: (doc) => { delete doc.scopes_supported; } }),
    ids: ["scopes-supported-missing"],
    outcome: "valid",
    also: async (report) => {
      expect(report.messages[0]!.pointer).toBe("/scopes_supported");
      const disabled = await company({
        poppy: (doc) => { doc.auth.disabled = true; delete doc.extensions["mediated-sign-in"]; },
        metadata: (doc) => { delete doc.scopes_supported; }
      });
      expect(disabled.messages).toEqual([]);
    }
  },
  {
    name: "refuses Mediated Sign-In without its grant, or with scopes the issuer doesn't support",
    run: () =>
      company({
        poppy: (doc) => { doc.extensions["mediated-sign-in"][0].scopes = ["orders:read", "gift-cards"]; },
        metadata: (doc) => { doc.grant_types_supported = doc.grant_types_supported.filter((grant: string) => !grant.endsWith("mediated-sign-in")); }
      }),
    ids: ["mediated-grant-missing", "mediated-scope-unsupported"],
    outcome: "invalid"
  },
  {
    // 4.7: SHOULD be described in an OpenAPI description poppy.json lists, or otherwise in auth.scopes.
    name: "recommends auth.scopes describe each supported scope when no OpenAPI description could",
    run: () =>
      company({
        poppy: (doc) => { doc.apis = doc.apis.filter((api: { type: string }) => api.type !== "openapi"); },
        metadata: (doc) => { doc.scopes_supported.push("loyalty"); }
      }),
    ids: ["scope-undescribed"],
    outcome: "valid",
    also: async (report) => {
      expect(report.messages[0]).toMatchObject({ severity: "warning", document: "oauth-metadata", pointer: "/scopes_supported/4" });
      // With an OpenAPI description listed, it may describe the scope: nothing to say.
      expect((await company({ metadata: (doc) => { doc.scopes_supported.push("loyalty"); } })).messages).toEqual([]);
    }
  },
  {
    // Readings: the domain's own scopes_supported names the scopes it offers; the issuer's may serve other clients (3.2).
    name: "checks the domain's scopes, not the issuer's others, when the protected resource metadata lists them",
    run: () =>
      company({
        poppy: (doc) => { doc.apis = doc.apis.filter((api: { type: string }) => api.type !== "openapi"); },
        prm: { ...SPEC_PRM, scopes_supported: ["orders:read", "orders:write", "loyalty"] },
        metadata: (doc) => { doc.scopes_supported.push("openid", "profile", "offline_access"); }
      }),
    ids: ["scope-undescribed"],
    outcome: "valid",
    also: (report) => {
      expect(report.messages[0]).toMatchObject({ severity: "warning", document: "protected-resource", pointer: "/scopes_supported/2" });
    }
  },
  {
    name: "notes what agents can't use in the advertised capabilities",
    run: () =>
      company({
        metadata: (doc) => {
          doc.dpop_signing_alg_values_supported = ["RS256"];
          doc.code_challenge_methods_supported = ["plain"];
          delete doc.authorization_response_iss_parameter_supported;
        }
      }),
    ids: ["metadata-dpop-alg", "metadata-pkce", "metadata-iss-parameter"],
    outcome: "valid"
  },
  {
    name: "notes poppy_domains, which 0.3 replaced with protected_resources, and an Operations version it doesn't know",
    run: () => company({ poppy: (doc) => { doc.extensions.operations = [{ version: "1", endpoint: "https://api.example.com/poppy/operations" }]; }, metadata: (doc) => { doc.poppy_domains = ["example.com"]; } }),
    ids: ["extension-version-unknown", "unknown-member"],
    outcome: "valid"
  },
  {
    name: "finds metadata for an issuer with a path (RFC 8414 §3.1)",
    run: () =>
      company({
        prm: { ...SPEC_PRM, authorization_servers: ["https://auth.example.com/tenant/"] },
        routes: {
          "https://auth.example.com/.well-known/oauth-authorization-server/tenant": jsonResponse({ ...SPEC_METADATA, issuer: "https://auth.example.com/tenant/" })
        }
      }),
    ids: [],
    outcome: "valid",
    also: (report) => expect((report as CompanyReport).issuer).toBe("https://auth.example.com/tenant/")
  }
];

const CLIENT: readonly Fixture[] = [
  {
    name: "checks client_id, domains and the auth method",
    run: () =>
      text(
        "client-metadata",
        { ...SPEC_CLIENT, jwks_uri: "https://keys.other.example/jwks.json", redirect_uris: ["https://other.example/cb"], token_endpoint_auth_method: "none" },
        { fetchedFrom: "https://agent.example/client.json" }
      ),
    ids: ["client-id-mismatch", "client-other-domain", "client-other-domain", "client-auth-method"]
  },
  {
    name: "requires redirect_uris",
    run: () => {
      const { redirect_uris: _r, ...noRedirects } = SPEC_CLIENT;
      return text("client-metadata", noRedirects);
    },
    ids: ["client-no-redirects"]
  },
  {
    // 4.1: an HTTPS URL on client_id's domain, or a loopback redirect URI as RFC 8252 §7.3 defines.
    name: "accepts loopback redirect URIs on any port, but not localhost, which RFC 8252 doesn't recommend",
    run: () =>
      text("client-metadata", {
        ...SPEC_CLIENT,
        redirect_uris: ["https://agent.example/oauth/callback", "http://127.0.0.1/callback", "http://[::1]:8080/cb", "http://localhost:8080/cb", "http://127.0.0.1/cb#x"]
      }),
    ids: ["not-https-url", "url-has-fragment"],
    also: (report) => expect(report.messages.map((m) => m.pointer)).toEqual(["/redirect_uris/3", "/redirect_uris/4"])
  },
  {
    name: "requires an HTTPS logo_uri, as every URL in client metadata",
    run: () => text("client-metadata", { ...SPEC_CLIENT, logo_uri: "http://agent.example/logo.png" }),
    ids: ["not-https-url"],
    outcome: "invalid"
  },
  {
    name: "checks every key",
    run: () =>
      text("jwks", {
        keys: [
          { ...EC_KEY, d: "private" },
          { kty: "EC", crv: "P-384", x: "a", y: "b", kid: "k2" },
          { kty: "RSA", n: "AQAB", e: "AQAB", kid: "k3" },
          { kty: "oct", k: "secret", kid: "k4" },
          { ...EC_KEY, kid: "k5", alg: "ES384", use: "enc" },
          { ...EC_KEY, kid: undefined },
          { ...EC_KEY, kid: "k1" },
          { kty: "RSA", n: RSA_N, e: "AQAB", kid: "k6", alg: "PS384" },
          { kty: "RSA", n: RSA_N, e: "AQAB", kid: "k7", alg: "RS256" }
        ]
      }),
    ids: [
      "jwks-private-key",
      "jwks-key-type",
      "jwks-rsa-small",
      "jwks-private-key",
      "jwks-key-type",
      "jwks-alg",
      "jwks-use",
      "jwks-no-kid",
      "jwks-kid-duplicate",
      "jwks-alg"
    ],
    // PS384 is one of the two algorithms Companies must accept (4.1); RS256 can't sign a delegation (5.2).
    also: (report) => expect(report.messages.filter((m) => m.id === "jwks-alg").map((m) => m.pointer)).toEqual(["/keys/4/alg", "/keys/8/alg"])
  },
  {
    name: "requires at least one key",
    run: () => text("jwks", { keys: [] }),
    ids: ["jwks-empty"]
  },
  {
    name: "refuses a fetched EC signing key whose public coordinates are missing",
    run: () => validateClient(network({
      "https://agent.example/agent.json": jsonResponse(SPEC_CLIENT),
      "https://agent.example/jwks.json": jsonResponse({ keys: [{ kty: "EC", crv: "P-256", kid: "missing", alg: "ES256" }] })
    }), "https://agent.example/agent.json"),
    ids: ["jwks-key-material", "jwks-key-material"],
    outcome: "invalid",
    also: async report => {
      expect(report.refused).toBe(true);
      expect(report.messages.map(message => message.pointer)).toEqual(["/keys/0/x", "/keys/0/y"]);
      expect(report.messages.every(message => message.severity === "error" && message.refuses && message.basis === "RFC")).toBe(true);
      await expect(importJWK({ kty: "EC", crv: "P-256", kid: "missing", alg: "ES256" }, "ES256")).rejects.toThrow();
    }
  },
  {
    name: "rejects malformed coordinate encodings and points outside P-256",
    run: () => text("jwks", { keys: [
      { ...EC_KEY, kid: "short", x: "AQ" },
      { ...EC_KEY, kid: "padded", x: `${EC_KEY.x}=` },
      { ...EC_KEY, kid: "spelling", x: `${EC_KEY.x.slice(0, -1)}d` },
      { ...EC_KEY, kid: "point", x: "A".repeat(43), y: "A".repeat(43) }
    ] }),
    ids: Array(4).fill("jwks-key-material"),
    outcome: "invalid",
    also: report => expect(report.messages.map(message => message.pointer)).toEqual(["/keys/0/x", "/keys/1/x", "/keys/2/x", "/keys/3"])
  },
  {
    name: "requires RSA key integers and checks their exact bit length",
    run: () => text("jwks", { keys: [
      { kty: "RSA", kid: "missing", alg: "PS384" },
      { kty: "RSA", kid: "malformed", n: `${RSA_N}=`, e: "AQAC", alg: "PS384" },
      { kty: "RSA", kid: "noncanonical", n: "x".repeat(342), e: "AAEAAQ", alg: "PS384" },
      { kty: "RSA", kid: "small", n: `AR${"x".repeat(339)}w`, e: "AQAB", alg: "PS384" }
    ] }),
    ids: [...Array(6).fill("jwks-key-material"), "jwks-rsa-small"],
    outcome: "invalid",
    also: report => expect(report.messages.at(-1)?.text).toContain("expected at least 2048 bits, got 2041 bits")
  },
  {
    name: "rejects supported algorithms paired with the wrong key type or curve",
    run: () => text("jwks", { keys: [
      { ...EC_KEY, alg: "PS384" },
      { kty: "RSA", n: RSA_N, e: "AQAB", kid: "rsa", alg: "ES256" }
    ] }),
    ids: ["jwks-key-material", "jwks-key-material"],
    outcome: "invalid"
  },
  {
    name: "accepts generated EC and RSA public signing keys that the cryptographic verifier can import",
    run: async () => {
      const keys = await Promise.all(["ES256", "PS384"].map(async alg => ({
        ...await exportJWK((await generateKeyPair(alg, { extractable: true })).publicKey), alg, kid: alg
      })));
      for (const key of keys) await expect(importJWK(key, key.alg)).resolves.toBeDefined();
      return text("jwks", { keys });
    },
    ids: [],
    outcome: "valid",
    also: report => expect(report.refused).toBe(false)
  },
  {
    // 5.3: Companies fetch client_id without following redirects, as the CIMD draft requires.
    name: "refuses a client_id that redirects, as Companies do",
    run: () =>
      validateClient(
        network({ "https://agent.example/agent.json": () => new Response(null, { status: 302, headers: { Location: "https://agent.example/v2.json" } }) }),
        "https://agent.example/agent.json"
      ),
    ids: ["http-redirect-not-allowed"],
    outcome: "indeterminate",
    also: (report) => expect(report.messages[0]).toMatchObject({ basis: "Rule", severity: "error", refuses: true })
  }
];

const FETCHING: readonly Fixture[] = [
  {
    name: "follows HTTPS redirects but not to HTTP",
    run: () => fetchOne(() => new Response(null, { status: 302, headers: { Location: "http://cdn.example.com/poppy.json" } })),
    ids: ["http-redirect-not-https"]
  },
  {
    name: "follows redirects, but not too many",
    run: () => fetchOne(() => new Response(null, { status: 302, headers: { Location: wellKnown } })),
    ids: ["http-too-many-redirects"],
    // A Guides limit: a warning, but the document wasn't fetched, so nothing was checked, and our client refuses it.
    outcome: "indeterminate",
    also: (report) => expect(report.refused).toBe(true)
  },
  {
    name: "calls a missing document indeterminate, not invalid",
    run: () => fetchOne(() => new Response("Not found", { status: 404 })),
    ids: ["http-status"],
    outcome: "indeterminate"
  },
  {
    // A Worker's fetch answers 520 itself when the site resets the connection, as bot protection does.
    name: "reports Cloudflare's 520 as a failed fetch that may be bot protection, not as the site's status",
    run: () => fetchOne(() => new Response("error code: 520", { status: 520, headers: { "Content-Type": "text/plain" } })),
    ids: ["http-failed"],
    outcome: "indeterminate",
    also: (report) => {
      expect(report.messages[0]!.text).toMatch(/dropped the connection.*HTTP 520 is Cloudflare's code for that, not a status the server sent/);
      expect(report.messages[0]!.text).toMatch(/block automated clients/);
      // The agent's model reads this text too: nothing only a validator user could act on.
      expect(report.messages[0]!.text).not.toMatch(/validator|saved copy|npm/);
      expect(report.documents[0]).toMatchObject({ status: 520 });
    }
  },
  {
    name: "reports Cloudflare's other connection statuses as failed fetches without the bot-protection hint",
    run: () => fetchOne(() => new Response(null, { status: 525 })),
    ids: ["http-failed"],
    outcome: "indeterminate",
    also: (report) => {
      expect(report.messages[0]!.text).toMatch(/failed the TLS handshake\. HTTP 525 is Cloudflare's code/);
      expect(report.messages[0]!.text).not.toMatch(/automated/);
    }
  },
  {
    name: "reports a connection the server drops as a failed fetch that may be bot protection",
    run: () =>
      validateCompany(named(async () => {
        throw Object.assign(new Error("read ECONNRESET"), { code: "ECONNRESET" });
      }), "example.com"),
    ids: ["http-failed"],
    outcome: "indeterminate",
    also: (report) => expect(report.messages[0]!.text).toMatch(/dropped the connection\. Sites that block automated clients/)
  },
  {
    name: "reports a redirect to something that isn't a URL instead of failing",
    run: () => fetchOne(() => new Response(null, { status: 302, headers: { Location: "https://[bad" } })),
    ids: ["http-status"],
    outcome: "indeterminate",
    also: (report) => expect(report.messages[0]!.text).toBe(`${wellKnown}'s redirect (HTTP 302): expected a Location that is a URL, got "https://[bad".`)
  },
  {
    name: "reports a Cloudflare challenge as bot protection, not the site's status",
    run: () => fetchOne(() => new Response("<html>Just a moment...</html>", { status: 403, headers: { "cf-mitigated": "challenge", Server: "cloudflare" } })),
    ids: ["http-failed"],
    outcome: "indeterminate",
    also: (report) => {
      expect(report.messages[0]!.text).toBe(
        `Fetching ${wellKnown} failed: Cloudflare's bot protection answered (HTTP 403) instead of the site, which wasn't asked. It turns away automated clients, agents included, unless the site lets them through.`
      );
      expect(report.messages[0]!.text).not.toMatch(/validator|saved copy|npm/);
    }
  },
  {
    // The block recorded in docs/deployment-tasks.md, from the validator API itself.
    name: "reports a Cloudflare 1010 block as bot protection",
    run: () => fetchOne(() => new Response("error code: 1010", { status: 403, headers: { Server: "cloudflare", "Content-Type": "text/plain" } })),
    ids: ["http-failed"],
    also: (report) => expect(report.messages[0]!.text).toContain("Cloudflare's bot protection")
  },
  {
    name: "reports an Akamai denial as bot protection",
    run: () => fetchOne(() => new Response("<HTML><HEAD><TITLE>Access Denied</TITLE></HEAD>Reference #18.1", { status: 403, headers: { Server: "AkamaiGHost" } })),
    ids: ["http-failed"],
    also: (report) => expect(report.messages[0]!.text).toContain("Akamai's bot protection")
  },
  {
    name: "reports DataDome and Imperva refusals as bot protection",
    run: async () => {
      const datadome = await fetchOne(() => new Response(null, { status: 403, headers: { "x-datadome": "protected" } }));
      expect(datadome.messages[0]!.text).toContain("DataDome's bot protection");
      return fetchOne(() => new Response("<html>Request unsuccessful. Incapsula incident ID: 123</html>", { status: 403 }));
    },
    ids: ["http-failed"],
    also: (report) => expect(report.messages[0]!.text).toContain("Imperva's bot protection")
  },
  {
    // A site behind Cloudflare sends Server: cloudflare on its own 403s too, so that alone isn't a bot refusal.
    name: "leaves a plain 403 as the site's status, with a hint about automated clients",
    run: () => fetchOne(() => new Response("<html>Forbidden</html>", { status: 403, headers: { Server: "cloudflare" } })),
    ids: ["http-status"],
    outcome: "indeterminate",
    also: (report) => expect(report.messages[0]!.text).toBe(
      `${wellKnown}: expected HTTP 200 with a JSON document, got HTTP 403. If it opens in a browser, the site may be turning away automated clients or cloud addresses, which would turn agents away too.`
    )
  },
  {
    name: "reports a rate limit as a failed fetch to try again, with its Retry-After",
    run: () => fetchOne(() => new Response(null, { status: 429, headers: { "Retry-After": "120" } })),
    ids: ["http-failed"],
    outcome: "indeterminate",
    also: (report) => expect(report.messages[0]!.text).toBe(`Fetching ${wellKnown} failed: the server is limiting how often it's asked (HTTP 429), and asks to wait 120 seconds. Try again later.`)
  },
  {
    name: "says a server error is often temporary, with its Retry-After",
    run: async () => {
      const plain = await fetchOne(() => new Response(null, { status: 500 }));
      expect(plain.messages[0]!.text).toBe(`${wellKnown}: expected HTTP 200 with a JSON document, got HTTP 500, a server error. Server errors are often temporary; try again later.`);
      return fetchOne(() => new Response(null, { status: 503, headers: { "Retry-After": new Date(Date.now() + 60_000).toUTCString() } }));
    },
    ids: ["http-status"],
    outcome: "indeterminate",
    also: (report) => expect(report.messages[0]!.text).toMatch(/: expected HTTP 200 with a JSON document, got HTTP 503, a server error, and asks to wait (59|60) seconds\. Server errors are often temporary/)
  },
  {
    name: "says why a fetch failed when the fetcher knows: DNS, refusal, certificate, impossible status",
    run: async () => {
      const failing = (code: string, message = code, status?: number) => validateCompany(named(async () => {
        throw Object.assign(new Error(message), { code, ...(status === undefined ? {} : { status }) });
      }), "example.com");
      expect((await failing("ENOTFOUND")).messages[0]!.text).toBe(`Fetching ${wellKnown} failed: the host name doesn't resolve.`);
      expect((await failing("ECONNREFUSED")).messages[0]!.text).toBe(`Fetching ${wellKnown} failed: the server refused the connection.`);
      expect((await failing(INVALID_STATUS, "the server answered with HTTP status 999, which isn't a valid status", 999)).messages[0]!.text)
        .toBe(`Fetching ${wellKnown} failed: the server answered with HTTP status 999, which isn't a valid status.`);
      // undici puts the code on the cause.
      const viaCause = await validateCompany(named(async () => {
        throw new TypeError("fetch failed", { cause: Object.assign(new Error("getaddrinfo"), { code: "ENOTFOUND" }) });
      }), "example.com");
      expect(viaCause.messages[0]!.text).toBe(`Fetching ${wellKnown} failed: the host name doesn't resolve.`);
      return failing("CERT_HAS_EXPIRED");
    },
    ids: ["http-failed"],
    outcome: "indeterminate",
    also: (report) => expect(report.messages[0]!.text).toMatch(/its TLS certificate didn't verify \(CERT_HAS_EXPIRED\)\. The Guides ask agents to validate certificates/)
  },
  {
    // A Worker's fetch passes 999 or 600 through (checked against the deployed validator), though no Response can be constructed with it.
    name: "reports a status outside 200 to 599 as a failed fetch, worded as the CLI words it",
    run: () => fetchOne(() => Object.defineProperty(new Response("odd", { status: 500 }), "status", { value: 999 })),
    ids: ["http-failed"],
    outcome: "indeterminate",
    also: (report) => expect(report.messages[0]!.text).toBe(`Fetching ${wellKnown} failed: the server answered with HTTP status 999, which isn't a valid status.`)
  },
  {
    // Checked against the deployed validator: a name that resolves to 127.0.0.1 or 10.0.0.1 gets 530, as an unknown name does.
    name: "says a 530 may also mean a name that resolves to a private address",
    run: () => fetchOne(() => new Response("error code: 1003", { status: 530, headers: { Server: "cloudflare" } })),
    ids: ["http-failed"],
    also: (report) => expect(report.messages[0]!.text).toContain("(from a Cloudflare Worker, a name that resolves to a private address gets 530 too)")
  },
  {
    // docs/readings.md#worker-ports: a Worker would silently fetch port 443 instead.
    name: "refuses, on Workers, a port a Worker wouldn't honour, asked for or redirected to",
    run: async () => {
      const asked: string[] = [];
      const behind = workerPorts(async (request) => {
        asked.push(request.url);
        return request.url === wellKnown
          ? new Response(null, { status: 302, headers: { Location: "https://example.com:4443/.well-known/poppy.json" } })
          : new Response("{}", { headers: { "Content-Type": "application/json" } });
      });
      const direct = await validateTarget(named(behind), "https://api.example.com:9443/openapi.json");
      expect(direct.messages[0]!.text).toBe(
        "Fetching https://api.example.com:9443/openapi.json failed: a Cloudflare Worker can't fetch port 9443 over HTTPS (only 443, 2053, 2083, 2087, 2096 and 8443), so it wasn't fetched."
      );
      // A port on the list goes through.
      await validateTarget(named(behind), "https://api.example.com:8443/openapi.json");
      expect(asked).toEqual(["https://api.example.com:8443/openapi.json"]);
      return validateCompany(named(behind), "example.com");
    },
    ids: ["http-failed"],
    outcome: "indeterminate",
    also: (report) => expect(report.messages[0]!.text).toContain("can't fetch port 4443")
  },
  {
    name: "calls an unreachable host indeterminate, not invalid",
    run: () => validateCompany(network({}), "example.com"),
    ids: ["http-failed"],
    outcome: "indeterminate"
  },
  {
    name: "checks size",
    run: () => fetchOne(jsonResponse("x".repeat(100_001))),
    ids: ["http-too-large"],
    outcome: "indeterminate"
  },
  {
    name: "checks encoding",
    run: () => fetchOne(() => new Response(new Uint8Array([0x7b, 0xff, 0x7d]), { headers: { "Content-Type": "application/json", "Cache-Control": "max-age=60" } })),
    ids: ["not-utf8"]
  },
  {
    name: "checks content type and caching headers",
    run: () => fetchOne(() => new Response(JSON.stringify(WEBSITE_ONLY), { headers: { "Content-Type": "text/plain" } })),
    ids: ["http-content-type", "http-no-cache-headers", "website-only"]
  },
  {
    // A single-page app answers every path with its index.
    name: "reports a web page served where the document should be, without checking it as JSON",
    run: () => fetchOne(() => new Response("<!doctype html><html><body><div id=root></div></body></html>", { headers: { "Content-Type": "text/html; charset=utf-8", "Cache-Control": "max-age=300" } })),
    ids: ["http-web-page"],
    // Like a 404: the document isn't there, so nothing in it was checked.
    outcome: "indeterminate",
    also: (report) => {
      expect(report.messages[0]!.text).toBe("https://example.com/.well-known/poppy.json: expected HTTP 200 with a JSON document, got a web page (HTTP 200, text/html).");
      expect(report.refused).toBe(true);
    }
  },
  {
    name: "recognises a web page by its markup when its Content-Type doesn't say HTML, after a byte order mark",
    run: () => fetchOne(() => new Response("\uFEFF\n  <HTML><body>Moved</body></HTML>", { headers: { "Content-Type": "text/plain" } })),
    ids: ["http-web-page"],
    outcome: "indeterminate",
    also: (report) => expect(report.messages[0]!.text).toContain("got a web page (HTTP 200, text/plain).")
  },
  {
    name: "names a same-host redirect that ends at a web page, without calling it another host",
    run: () =>
      validateCompany(
        network({
          [wellKnown]: () => new Response(null, { status: 302, headers: { Location: "/home" } }),
          "https://example.com/home": () => new Response("<!DOCTYPE html><html></html>", { headers: { "Content-Type": "text/html" } })
        }),
        "example.com"
      ),
    ids: ["http-web-page"],
    also: (report) =>
      expect(report.messages[0]!.text).toBe("https://example.com/.well-known/poppy.json: expected HTTP 200 with a JSON document, got a web page (HTTP 200, text/html) at https://example.com/home, after redirects.")
  },
  {
    // The text where the word should be, not just its first letter, which matched.
    name: "says what stood where true, false or null should be",
    run: () => text("poppy", '{"a": trux}'),
    ids: ["json-syntax"],
    also: (report) => expect(report.messages[0]!.text).toBe('line 1, column 7: expected true, got "trux".')
  },
  {
    // Only markup that is a page: other markup is reported as what it is, a document that isn't JSON.
    name: "checks XML as a document that isn't JSON, not as a web page",
    run: () => fetchOne(() => new Response('<?xml version="1.0"?><poppy/>', { headers: { "Content-Type": "application/xml", "Cache-Control": "max-age=300" } })),
    ids: ["http-content-type", "json-syntax"],
    outcome: "invalid"
  },
  {
    // A mislabelled document is still a document: a warning, and every rule checked.
    name: "checks JSON served as text/html as JSON",
    run: () => fetchOne(() => new Response(JSON.stringify(WEBSITE_ONLY), { headers: { "Content-Type": "text/html", "Cache-Control": "max-age=300" } })),
    ids: ["http-content-type", "website-only"],
    outcome: "valid"
  },
  {
    name: "checks a cache lifetime is bounded",
    run: () => fetchOne(jsonResponse(WEBSITE_ONLY, { "Cache-Control": "max-age=5" })),
    ids: { contains: ["http-cache-bounded"] }
  },
  {
    name: "refuses non-HTTPS",
    run: () => validateClient(network({}), "http://agent.example/agent.json"),
    ids: ["http-not-https"]
  },
  {
    // 3: "MUST NOT connect to a loopback, private, or link-local address" a party gave them.
    name: "refuses private hosts",
    run: () => validateClient(network({}), "https://localhost/agent.json"),
    ids: ["http-non-public-host"],
    outcome: "indeterminate",
    also: (report) => expect(report.messages[0]).toMatchObject({ basis: "MUST", severity: "error", refuses: true })
  },
  {
    name: "refuses special-use and private-use names, such as .internal and .home.arpa",
    run: () => validateClient(network({}), "https://metadata.google.internal/agent.json"),
    ids: ["http-non-public-host"],
    outcome: "indeterminate"
  },
  {
    // The CLI's fetcher (scripts/node-fetcher.ts) throws this when a public-looking name resolves to a private address.
    name: "refuses a name a fetcher found resolves to a private address",
    run: () =>
      validateCompany(named(async (request) => {
        throw new NonPublicAddressError(new URL(request.url).hostname, "169.254.169.254");
      }), "169.254.169.254.nip.io"),
    ids: ["http-non-public-address"],
    outcome: "indeterminate",
    also: (report) => {
      expect(report.refused).toBe(true);
      expect(report.messages[0]!.text).toBe(
        "169.254.169.254.nip.io's address: expected a public address, got 169.254.169.254. So https://169.254.169.254.nip.io/.well-known/poppy.json wasn't fetched."
      );
    }
  },
  {
    name: "refuses non-domains",
    run: () => validateCompany(network({}), "not a domain"),
    ids: ["domain-invalid"]
  }
];

describe("valid documents", () => testEach(VALID));
describe("poppy.json", () => testEach(POPPY_JSON));
describe("poppy.json in the 0.4 draft, and choosing a version", () => testEach(POPPY_04));
describe("poppy.json in published 1.0, and choosing between 0.4 and 1.0", () => testEach(POPPY_10_FIXTURES));
describe("discovery: the issuer from the domain's protected resource metadata", () => testEach(DISCOVERY));
describe("OAuth server metadata, checked against poppy.json", () => testEach(METADATA));
describe("client metadata and keys", () => testEach(CLIENT));
describe("fetching", () => {
  testEach(FETCHING);

  it("reads Retry-After as delay seconds or an HTTP date (RFC 9110 10.2.3)", () => {
    const now = Date.parse("2026-11-21T12:00:00Z");
    expect(retryAfterSeconds(new Headers({ "Retry-After": "30" }), now)).toBe(30);
    expect(retryAfterSeconds(new Headers({ "Retry-After": "Sat, 21 Nov 2026 12:02:00 GMT" }), now)).toBe(120);
    expect(retryAfterSeconds(new Headers({ "Retry-After": "Sat, 21 Nov 2026 11:00:00 GMT" }), now)).toBe(0);
    expect(retryAfterSeconds(new Headers({ "Retry-After": "soon" }), now)).toBeUndefined();
    expect(retryAfterSeconds(new Headers(), now)).toBeUndefined();
  });

  it("answers the HTTP API with a report, not a server error, for a redirect that isn't a URL", async () => {
    const response = await handleValidator(new Request("https://validator.test/validator/api?url=example.com"), {
      fetcher: async () => new Response(null, { status: 301, headers: { Location: "https://exa mple.com/x" } }),
      allowFetch: async () => true
    });
    expect(response!.status).toBe(200);
    const report = (await response!.json()) as Report;
    expect(ids(report)).toEqual(["http-status"]);
  });

  it("reads a 403's first bytes within the deadline, so a stalled error page can't hold the report", async () => {
    vi.useFakeTimers();
    try {
      let cancelled = false;
      const pending = validateCompany(named(async () => new Response(new ReadableStream<Uint8Array>({
        start(controller) { controller.enqueue(new TextEncoder().encode("error code: 1010")); },
        cancel: () => { cancelled = true; }
      }), { status: 403, headers: { Server: "cloudflare" } })), "example.com");
      await vi.advanceTimersByTimeAsync(LIMITS.timeoutMs);
      const report = await pending;
      expect(ids(report)).toEqual(["http-failed"]);
      expect(report.messages[0]!.text).toContain("Cloudflare's bot protection");
      expect(cancelled).toBe(true);
    } finally {
      vi.useRealTimers();
    }
  });

  it("names itself with a User-Agent on every fetch the HTTP validator makes, redirects included; the library leaves naming to its caller", async () => {
    const agents: (string | null)[] = [];
    const fetcher: Fetcher = async (request) => {
      agents.push(request.headers.get("User-Agent"));
      return request.url === wellKnown
        ? new Response(null, { status: 302, headers: { Location: "https://www.example.com/.well-known/poppy.json" } })
        : new Response("Not found", { status: 404 });
    };
    await handleValidator(new Request("https://validator.test/validator/api?url=example.com"), { fetcher, allowFetch: async () => true });
    expect(agents.length).toBeGreaterThanOrEqual(2);
    // Named with the deployment that answered, not a fixed one.
    expect(new Set(agents)).toEqual(new Set([`PoppyValidator/${VALIDATOR.version} (+https://validator.test/validator)`]));
    // The library requires a named fetcher and keeps its caller's name: the agent's discovery fetches through it as the agent (src/poppy/fetch.ts).
    agents.length = 0;
    await validateCompany(withUserAgent(fetcher, "Caller/1.0"), "example.com");
    expect(new Set(agents)).toEqual(new Set(["Caller/1.0"]));
  });

  it("reports a body that stalls past the time limit as http-failed, not an exception", async () => {
    vi.useFakeTimers();
    try {
      // Headers at once, then one byte and silence: a fetcher that ignores the request's signal.
      let cancelled = false;
      const stalling: Fetcher = async () =>
        new Response(
          new ReadableStream<Uint8Array>({
            start: (controller) => controller.enqueue(new TextEncoder().encode("{")),
            cancel: () => {
              cancelled = true;
            }
          }),
          { headers: { "Content-Type": "application/json", "Cache-Control": "max-age=300" } }
        );
      const pending = validateCompany(named(stalling), "example.com");
      await vi.advanceTimersByTimeAsync(LIMITS.timeoutMs);
      const report = await pending;
      expect(ids(report)).toEqual(["http-failed"]);
      expect(report.outcome).toBe("indeterminate");
      expect(report.messages[0]!.text).toContain(`Fetching ${wellKnown} timed out after 10 seconds.`);
      expect(cancelled).toBe(true);
    } finally {
      vi.useRealTimers();
    }
  });

  it("times out before headers even if the fetcher ignores abort, and cancels its eventual response", async () => {
    vi.useFakeTimers();
    let release!: (response: Response) => void;
    const cancel = vi.fn(() => new Promise<void>(() => {}));
    try {
      const pending = validateCompany(named(() => new Promise((resolve) => { release = resolve; })), "example.com");
      await vi.advanceTimersByTimeAsync(LIMITS.timeoutMs);
      const report = await pending;
      expect(ids(report)).toEqual(["http-failed"]);
      expect(report.outcome).toBe("indeterminate");
      expect(report.messages[0]!.text).toContain("timed out after 10 seconds");
      release(new Response(new ReadableStream({ cancel })));
      await vi.advanceTimersByTimeAsync(0);
      expect(cancel).toHaveBeenCalledOnce();
    } finally {
      vi.useRealTimers();
    }
  });

  it("refuses an already-aborted buffered response", async () => {
    const deadline = new AbortController();
    const reason = new DOMException("Expired", "TimeoutError");
    deadline.abort(reason);
    await expect(readLimited(Response.json({ accepted: true }), LIMITS.maxBytes, deadline.signal)).rejects.toBe(reason);
  });

  it("refuses a buffered read that completes in the same turn as abort", async () => {
    const deadline = new AbortController();
    const reason = new DOMException("Expired", "TimeoutError");
    const response = new Response(new ReadableStream<Uint8Array>({
      pull(controller) {
        controller.enqueue(new TextEncoder().encode("{}"));
        controller.close();
        deadline.abort(reason);
      }
    }));
    await expect(readLimited(response, LIMITS.maxBytes, deadline.signal)).rejects.toBe(reason);
  });

  it.each(["pending source cancellation", "a clone reader"] as const)("reports a body timeout without waiting for %s", async (mode) => {
    vi.useFakeTimers();
    let source!: ReadableStreamDefaultController<Uint8Array>;
    const cancel = vi.fn(() => new Promise<void>(() => {}));
    const response = new Response(new ReadableStream<Uint8Array>({
      start(controller) { source = controller; controller.enqueue(new TextEncoder().encode("{")); },
      cancel
    }), { headers: { "Content-Type": "application/json" } });
    // Match the harness's detached JSON observer: cancelling one tee branch
    // cannot finish while its sibling is still consuming the stalled source.
    const clone = mode === "a clone reader" ? response.clone().text().catch(() => undefined) : undefined;
    try {
      const pending = validateCompany(named(async () => response), "example.com");
      await vi.advanceTimersByTimeAsync(LIMITS.timeoutMs);
      const report = await pending;
      expect(ids(report)).toEqual(["http-failed"]);
      expect(report.outcome).toBe("indeterminate");
      expect(report.messages[0]!.text).toContain("timed out after 10 seconds");
      expect(cancel).toHaveBeenCalledTimes(clone ? 0 : 1);
    } finally {
      if (clone) { source.close(); await clone; }
      vi.useRealTimers();
    }
  });

  it.each([
    { name: "declared oversize", status: 200, headers: new Headers({ "Content-Length": String(LIMITS.maxBytes + 1) }), bytes: 1, message: "http-too-large" },
    { name: "streamed oversize", status: 200, headers: new Headers(), bytes: LIMITS.maxBytes + 1, message: "http-too-large" },
    { name: "redirect", status: 302, headers: new Headers({ Location: "https://elsewhere.example/poppy.json" }), bytes: 1, message: "http-redirect-not-allowed" },
    { name: "HTTP error", status: 503, headers: new Headers(), bytes: 1, message: "http-status" }
  ])("keeps the $name verdict even if discarding its body never finishes", async ({ status, headers, bytes, message }) => {
    const cancel = vi.fn(() => new Promise<void>(() => {}));
    const response = new Response(new ReadableStream<Uint8Array>({
      start(controller) { controller.enqueue(new Uint8Array(bytes)); },
      cancel
    }), { status, headers });
    const checker = new Checker("poppy");
    const result = await fetchDocument(named(async () => response), wellKnown, checker, { followRedirects: false });
    expect(result.text).toBeUndefined();
    expect(checker.messages.map((entry) => entry.id)).toEqual([message]);
    expect(cancel).toHaveBeenCalledOnce();
  });
});

describe("which hosts and addresses are public (Guides, 'Fetching metadata safely')", () => {
  it("refuses by name: IP literals, single labels, and special-use and private-use names", () => {
    const refused = [
      "127.0.0.1",
      "[::1]",
      "localhost",
      "intranet",
      "foo.localhost",
      "printer.local",
      "printer.local.",
      "router.home.arpa",
      "1.0.0.127.in-addr.arpa",
      "ipv4only.arpa",
      "metadata.google.internal",
      "INTERNAL.Example.internal",
      "x.invalid",
      "abc.onion",
      "x.alt",
      "nas.lan",
      "mail.corp",
      "box.home",
      "wiki.intranet",
      "db.private"
    ];
    for (const host of refused) expect(isPublicHost(new URL(`https://${host}/`)), host).toBe(false);
    // Names alone can't tell where these resolve: the address check is the fetcher's (below).
    const byName = ["example.com", "localtest.me", "127.0.0.1.nip.io", "169.254.169.254.nip.io", "company.interop.test", "local.example.com", "internal.example.com", "arpa.example"];
    for (const host of byName) expect(isPublicHost(new URL(`https://${host}/`)), host).toBe(true);
  });

  it("classifies resolved addresses: loopback, RFC 1918, link-local, CGNAT, ULA, mapped, unspecified and multicast are not public", () => {
    const notPublic = [
      "127.0.0.1",
      "127.255.255.254",
      "10.0.0.1",
      "172.16.0.1",
      "172.31.255.255",
      "192.168.1.1",
      "169.254.169.254",
      "100.64.0.1",
      "100.127.255.255",
      "0.0.0.0",
      "224.0.0.1",
      "239.255.255.250",
      "255.255.255.255",
      "192.0.0.170",
      "::",
      "::1",
      "fc00::1",
      "fd12:3456::1",
      "fe80::1",
      "fe80::1%en0",
      "ff02::1",
      "::ffff:127.0.0.1",
      "::ffff:7f00:1",
      "::ffff:10.1.2.3",
      "::ffff:169.254.169.254",
      "::ffff:100.64.0.1",
      "64:ff9b::192.168.0.1",
      "2002:c0a8:0101::1",
      "::127.0.0.1",
      "2001:db8::1",
      "not an address",
      "1.2.3",
      "256.1.1.1"
    ];
    for (const address of notPublic) expect(isPublicAddress(address), address).toBe(false);
    const isPublic = ["1.1.1.1", "8.8.8.8", "100.63.255.255", "100.128.0.0", "172.15.255.255", "172.32.0.0", "169.253.0.1", "2606:4700::1111", "2001:4860:4860::8888", "::ffff:1.1.1.1", "64:ff9b::808:808"];
    for (const address of isPublic) expect(isPublicAddress(address), address).toBe(true);
  });

  it("reads IPv6 in its short, full and mixed forms alike", () => {
    expect(parseIPv6("::ffff:127.0.0.1")).toEqual([0, 0, 0, 0, 0, 0xffff, 0x7f00, 1]);
    expect(parseIPv6("0:0:0:0:0:ffff:7f00:1")).toEqual([0, 0, 0, 0, 0, 0xffff, 0x7f00, 1]);
    expect(parseIPv6("[fe80::1]")).toEqual([0xfe80, 0, 0, 0, 0, 0, 0, 1]);
    for (const bad of ["1::2::3", "1:2:3:4:5:6:7:8:9", "12345::", "::ffff:300.0.0.1", "1:2:3:4:5:6:7"]) expect(parseIPv6(bad), bad).toBeNull();
  });

  // The CLI's fetcher (scripts/node-fetcher.ts) hands this lookup to Node's https.request, with the system resolver in place of `resolve`.
  describe("the CLI's pinned lookup", () => {
    const lookupOf = (answers: Record<string, readonly { address: string; family: 4 | 6 }[]>) => {
      const asked: string[] = [];
      const lookup = pinnedLookup(async (hostname) => {
        asked.push(hostname);
        return answers[hostname] ?? [];
      });
      const run = (hostname: string, options: { all?: boolean } = {}) =>
        new Promise<{ error: Error | null; address: unknown; family?: number }>((resolve) => lookup(hostname, options, (error, address, family) => resolve({ error, address, family })));
      return { run, asked };
    };

    it("refuses a public-looking name that resolves to a private address, before any connection", async () => {
      const { run } = lookupOf({ "127.0.0.1.nip.io": [{ address: "127.0.0.1", family: 4 }], "169.254.169.254.nip.io": [{ address: "169.254.169.254", family: 4 }] });
      for (const host of ["127.0.0.1.nip.io", "169.254.169.254.nip.io"]) {
        const { error } = await run(host);
        expect(error, host).toBeInstanceOf(NonPublicAddressError);
        expect((error as NonPublicAddressError).hostname).toBe(host);
      }
    });

    it("refuses a name when any of its addresses isn't public, so a mixed answer can't pick the private one", async () => {
      const { run } = lookupOf({ "mixed.example": [{ address: "93.184.216.34", family: 4 }, { address: "::ffff:10.0.0.1", family: 6 }] });
      const { error } = await run("mixed.example");
      expect((error as NonPublicAddressError).address).toBe("::ffff:10.0.0.1");
    });

    it("hands the connection exactly the addresses it checked, resolving once per connection", async () => {
      const { run, asked } = lookupOf({ "public.example": [{ address: "93.184.216.34", family: 4 }, { address: "2606:2800:220:1::1", family: 6 }] });
      expect(await run("public.example")).toEqual({ error: null, address: "93.184.216.34", family: 4 });
      expect(await run("public.example", { all: true })).toEqual({
        error: null,
        address: [
          { address: "93.184.216.34", family: 4 },
          { address: "2606:2800:220:1::1", family: 6 }
        ],
        family: undefined
      });
      expect(asked).toEqual(["public.example", "public.example"]);
    });

    it("fails a name with no address, or whose lookup fails", async () => {
      const { run } = lookupOf({});
      expect((await run("nowhere.example")).error?.message).toBe("nowhere.example has no address");
      const failing = pinnedLookup(async () => {
        throw new Error("SERVFAIL");
      });
      const error = await new Promise<Error | null>((resolve) => failing("x.example", {}, (e) => resolve(e)));
      expect(error?.message).toBe("SERVFAIL");
    });
  });
});
describe("over HTTP", () => {
  const call = (path: string, init?: RequestInit) => worker.fetch(new Request(`https://agent.test${path}`, init), env);

  it("serves the form and the messages page", async () => {
    const form = await call("/validator");
    expect(form.status).toBe(200);
    const page = await form.text();
    expect(page).toContain("<title>Poppy Validator</title>");
    expect(page).toContain('<label for="url">');
    const messages = await (await call("/validator/messages")).text();
    for (const id of Object.keys(MESSAGES)) expect(messages).toContain(`id="${id}"`);
  });

  it("answers a JSON POST with the JSON report, for any origin", async () => {
    const response = await call("/validator/api", {
      method: "POST",
      headers: { "Content-Type": "application/json", Origin: "https://elsewhere.example" },
      body: JSON.stringify({ document: SPEC_POPPY, kind: "poppy", domain: "example.com" })
    });
    expect(response.status).toBe(200);
    expect(response.headers.get("Access-Control-Allow-Origin")).toBe("*");
    const report = (await response.json()) as Report;
    expect(report).toMatchObject({ outputVersion: 1, outcome: "valid", checkedAgainst: "Draft 0.4" });
    const preflight = await call("/validator/api", { method: "OPTIONS" });
    expect(preflight.status).toBe(204);
    const bad = await call("/validator/api", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ document: "{}", kind: "feed" }) });
    expect(bad.status).toBe(400);
    expect(await bad.json()).toEqual({
      error: 'kind: expected one of poppy, protected-resource, oauth-metadata, client-metadata or jwks, got "feed".',
      expected: "one of poppy, protected-resource, oauth-metadata, client-metadata or jwks",
      got: '"feed"'
    });
  });

  it("answers the form with an escaped results page", async () => {
    const response = await call("/validator", {
      method: "POST",
      body: new URLSearchParams({ document: '{"protocol_version":"0.4","organization":{"name":"<script>alert(1)</script>","domain":"a.example"},"agent":{}}', kind: "poppy" })
    });
    const page = await response.text();
    expect(page).toContain("Not valid");
    expect(page).not.toContain("<script>alert");
    expect(page).toContain("&#60;script&#62;");
  });

  it("checks a URL, within the caller's rate limit", async () => {
    const host = await mockCompany({ unknownApi: false });
    const request = () => new Request(`https://agent.test/validator/api?url=${host}`);
    const allowed = await handleValidator(request(), { fetcher: testFetcher(env), allowFetch: async () => true });
    expect(((await allowed!.json()) as Report).outcome).toBe("valid");
    const limited = await handleValidator(request(), { fetcher: testFetcher(env), allowFetch: async () => false });
    expect(limited!.status).toBe(429);
  });
});

describe("the message catalog", () => {
  it("marks as a fact only an error or warning that says why it has nothing to compare", () => {
    for (const [id, definition] of Object.entries(MESSAGES) as [string, { note?: true; fact?: string }][]) {
      if (definition.fact === undefined) continue;
      expect(definition.note, id).toBeUndefined();
      expect(definition.fact.length, id).toBeGreaterThan(40);
    }
    expect(Object.entries(MESSAGES).filter(([, d]) => (d as { fact?: string }).fact !== undefined).map(([id]) => id)).toEqual(["http-failed"]);
  });

  const fixtures = [...VALID, ...POPPY_JSON, ...POPPY_04, ...POPPY_10_FIXTURES, ...DISCOVERY, ...METADATA, ...CLIENT, ...FETCHING];

  it("has a fixture that produces every message", () => {
    const declared = new Set(fixtures.flatMap(declaredIds));
    // Retired diagnostics, kept for saved reports and never emitted.
    const retired = new Set<MessageId>(["api-type-newer", "skill-index-schema", "skill-digest"]);
    const missing = (Object.keys(MESSAGES) as MessageId[]).filter((id) => !declared.has(id) && !retired.has(id));
    expect(missing).toEqual([]);
  });

  it("has fixtures with distinct names", () => {
    const names = fixtures.map((fixture) => fixture.name);
    expect(names.filter((name, index) => names.indexOf(name) !== index)).toEqual([]);
  });

  // docs/conformance-levels.md: a MUST, an RFC's MUST or a keyword-less rule is an error; a
  // SHOULD, the Guides or our reading a warning; a message reporting a fact (note) is info.
  it("derives each message's severity from its basis", () => {
    const entries = Object.entries(MESSAGES) as [MessageId, (typeof MESSAGES)[MessageId]][];
    const wrong = entries.filter(([, m]) => m.severity !== ("note" in m && m.note ? "info" : severityOf(levelOf(m.basis))));
    expect(wrong.map(([id]) => id)).toEqual([]);
    // Nothing optional is reported against the document that takes the option.
    expect(entries.filter(([, m]) => (m.basis as string) === "MAY").map(([id]) => id)).toEqual([]);
  });

  it("refuses over every error but those a reader is told to tolerate, and names the warnings it refuses", () => {
    const entries = Object.entries(MESSAGES) as [MessageId, (typeof MESSAGES)[MessageId]][];
    // 0.4's skipped versions and extensions: an agent is told to ignore them (3.3, 3.4), so the rest of the Company is still used.
    expect(entries.filter(([, m]) => m.severity === "error" && !m.refuses).map(([id]) => id)).toEqual(["json-bom", "api-description-missing", "supported-version-unusable", "linked-document-supported-versions", "extension-entries"]);
    // Refused warnings guard against a hostile or unusable document; each says so in its explanation.
    const refusedWarnings = entries.filter(([, m]) => m.severity !== "error" && m.refuses);
    expect(refusedWarnings.map(([id]) => id)).toEqual([
      "http-too-many-redirects",
      "http-failed",
      "http-too-large",
      "json-resource-limit",
      "json-duplicate-member",
      "url-has-fragment-unstated",
      "mediated-fields-empty"
    ]);
    for (const [id, m] of refusedWarnings) expect(m.explain, id).toMatch(/our client|nothing was checked/i);
  });
});
