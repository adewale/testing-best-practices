/** Browser acceptance fixture: real Worker/auth/tools; only the model and Company are synthetic. */
import { createAssistantMessageEventStream, fauxAssistantMessage, fauxProvider, fauxText, fauxToolCall, type AssistantMessage, type AssistantMessageEventStream, type TranscriptContext } from "@earendil-works/pi-ai";
import type { DemoRoute, LaneModel } from "../../src/model-router";
import { PersonalAgent as TestAgent } from "../worker";
import type { Fetcher } from "../../src/poppy/fetch";

export { default, CompanyLimiter, DomainBudget, MockCompany, StorageProbe } from "../worker";

function text(context: TranscriptContext): string {
  const user = context.messages.filter(message => message.role === "user").at(-1);
  return typeof user?.content === "string" ? user.content : user?.content.filter(part => part.type === "text").map(part => part.type === "text" ? part.text : "").join("") ?? "";
}

function photoOrder(photoId: string) {
  return { email: "ada@example.com", ship_to: { name: "Ada Lovelace", line1: "12 St James's Square", city: "London", postal_code: "SW1Y 4JH", country: "GB" }, items: [{ photo_id: photoId, copies: 1 }] };
}

function photoResponse(context: TranscriptContext, prompt: string): AssistantMessage | null {
  const request = /^Please print this photo at (cphoto(?:desktop|mobile)\.shop\.test)\./.exec(prompt);
  // The baseline's disclosure decision starts a separate model turn. This
  // fixture recognizes only its synthetic upload notice, not order receipts.
  const notice = prompt.startsWith("[system]") && /Mock Shop cphoto(?:desktop|mobile)/.test(prompt) && prompt.includes("POST /photos");
  if (!request && !notice) return null;
  const domain = request?.[1] ?? /Mock Shop (cphoto(?:desktop|mobile))/.exec(prompt)![1] + ".shop.test";
  let latest = context.messages.length - 1;
  while (latest >= 0 && context.messages[latest]!.role !== "user") latest--;
  const after = context.messages.slice(latest + 1);
  const called = (operation: string) => after.some(message => message.role === "assistant" && message.content.some(part => part.type === "toolCall" && part.name === "poppy_api_call" && part.arguments.operation === operation));
  const answer = (args: Record<string, unknown>) => fauxAssistantMessage([fauxToolCall("poppy_api_call", { domain, ...args })], { stopReason: "toolUse" });
  if (request && !called("uploadPhoto")) {
    const id = /\[attachment (att_[A-Za-z0-9_-]{22})/.exec(prompt)?.[1];
    return id ? answer({ operation: "uploadPhoto", files: { photo: id } }) : fauxAssistantMessage([fauxText("Please select the photo.")]);
  }
  const result = after.find(message => message.role === "toolResult" && message.toolName === "poppy_api_call");
  const details = result?.role === "toolResult" ? result.details : undefined;
  const body = details && typeof details === "object" && "body" in details ? details.body : undefined;
  const photoId = notice ? /"id":"(pho_[A-Za-z0-9_-]+)"/.exec(prompt)?.[1]
    : body && typeof body === "object" && "id" in body && typeof body.id === "string" ? body.id : undefined;
  if (photoId && !called("orderPrints")) return answer({ operation: "orderPrints", body: photoOrder(photoId) });
  return fauxAssistantMessage([fauxText("The print request and its approval card show the current status.")]);
}

/**
 * Decision 50: a request naming a Company that isn't selected asks on a card;
 * the User's Allow message then selects it, and the print goes ahead.
 */
function companyAccessResponse(context: TranscriptContext, prompt: string): AssistantMessage | null {
  const asked = /^Print this photo at (caccess(?:desktop|mobile)\.shop\.test), please\.$/.exec(prompt.replace(/\s*\[attachment [^\]]*\]/g, "").trim());
  const allowed = /^Yes, you can contact (caccess(?:desktop|mobile)\.shop\.test) and send it that photo\.$/.exec(prompt);
  if (!asked && !allowed) return null;
  const domain = (asked ?? allowed)![1]!;
  let latest = context.messages.length - 1;
  while (latest >= 0 && context.messages[latest]!.role !== "user") latest--;
  const after = context.messages.slice(latest + 1);
  const called = (name: string, operation?: string) => after.some(message => message.role === "assistant" && message.content.some(part => part.type === "toolCall" && part.name === name && (operation === undefined || part.arguments.operation === operation)));
  // The User's photo, from the message that asked: the Allow message names none.
  const words = (message: TranscriptContext["messages"][number]) => message.role !== "user" ? "" : typeof message.content === "string" ? message.content
    : message.content.map(part => part.type === "text" ? part.text : "").join("");
  const photo = [...context.messages].reverse().map(message => /\[attachment (att_[A-Za-z0-9_-]{22})/.exec(words(message))?.[1]).find(Boolean);
  if (asked) {
    return called("poppy_request_company") ? fauxAssistantMessage([fauxText("I've asked to contact it on a card.")])
      : fauxAssistantMessage([fauxToolCall("poppy_request_company", { domain, photos: photo ? [photo] : [] })], { stopReason: "toolUse" });
  }
  const answer = (args: Record<string, unknown>) => fauxAssistantMessage([fauxToolCall("poppy_api_call", { domain, ...args })], { stopReason: "toolUse" });
  if (!called("poppy_api_call", "uploadPhoto")) return photo ? answer({ operation: "uploadPhoto", files: { photo } }) : fauxAssistantMessage([fauxText("Please attach the photo.")]);
  const result = after.find(message => message.role === "toolResult" && message.toolName === "poppy_api_call");
  const details = result?.role === "toolResult" ? result.details : undefined;
  const body = details && typeof details === "object" && "body" in details ? details.body : undefined;
  const photoId = body && typeof body === "object" && "id" in body && typeof body.id === "string" ? body.id : undefined;
  if (photoId && !called("poppy_api_call", "orderPrints")) return answer({ operation: "orderPrints", body: photoOrder(photoId) });
  return fauxAssistantMessage([fauxText("The print request and its approval card show the current status.")]);
}

function respond(context: TranscriptContext): AssistantMessage {
  const prompt = text(context);
  const photo = photoResponse(context, prompt) ?? companyAccessResponse(context, prompt);
  if (photo) return photo;
  const request = /^Please exchange my Stormline Jacket for the insulated medium at ([a-z0-9.-]+) using (OpenAPI|MCP)\.$/.exec(prompt);
  const verification = /^Please send a verification reply at ([a-z0-9.-]+) in ([A-Za-z0-9_-]+)\.$/.exec(prompt);
  let response;
  if (request || verification) {
    const domain = (request ?? verification)![1]!;
    const api = request?.[2] === "OpenAPI";
    const name = verification ? "poppy_message" : api ? "poppy_api_call" : "poppy_mcp_call";
    let latestUser = context.messages.length - 1;
    while (latestUser >= 0 && context.messages[latestUser]!.role !== "user") latestUser--;
    const made = context.messages.slice(latestUser + 1).some(message => message.role === "assistant" && message.content.some(part => part.type === "toolCall" && part.name === name && part.arguments.domain === domain));
    const call = verification ? fauxToolCall(name, { domain, conversation: verification[2]!, text: "The verification code is 482913" }) : api
      ? fauxToolCall(name, { domain, operation: "exchangeItem", params: { order_id: "ord_7Hk2" }, body: { item_id: "itm_4Qa", replacement_sku: "stormline-insulated-m" } })
      : fauxToolCall(name, { domain, tool: "exchange_item", args: { order_id: "ord_7Hk2", item_id: "itm_4Qa", replacement_sku: "stormline-insulated-m" } });
    response = made
      ? fauxAssistantMessage([fauxText("The approval cards and the request below show its current status.")])
      : fauxAssistantMessage([call], { stopReason: "toolUse" });
  } else {
    response = fauxAssistantMessage([fauxText(prompt.startsWith("[system]") ? "The request and its approval cards show the current status." : `echo: ${prompt}`)]);
  }
  return response;
}

/** Same known synthetic charge as test/worker.ts, after fauxProvider calculates its final usage. */
function priced(stream: AssistantMessageEventStream): AssistantMessageEventStream {
  const out = createAssistantMessageEventStream();
  const price = (message: AssistantMessage): AssistantMessage => ({ ...message, usage: { ...message.usage, cost: { ...message.usage.cost, total: 0.000001 } } });
  void (async () => {
    for await (const event of stream) out.push(event.type === "done" ? { ...event, message: price(event.message) } : event.type === "error" ? { ...event, error: price(event.error) } : event);
    out.end(price(await stream.result()));
  })();
  return out;
}

export class PersonalAgent extends TestAgent {
  #model: ReturnType<typeof fauxProvider> | undefined;

  protected override poppyFetcher(): Fetcher {
    const send = super.poppyFetcher();
    return async request => {
      const response = await send(request);
      if (new URL(request.url).hostname.startsWith("api.copenapijourney.") && new URL(request.url).pathname.endsWith("/exchanges") && response.status === 201) {
        const original = await response.json();
        return Response.json({ result: original, description: "Synthetic result padding. ".repeat(120), checkout_url: "https://checkout.example/pay?session=synthetic%2Fcheckout%2Bproof&return=%2Forders#receipt" }, { status: 201 });
      }
      return response;
    };
  }

  protected override demoLane(_route: DemoRoute): LaneModel {
    this.#model ??= fauxProvider({ tokensPerSecond: 1000 });
    this.#model.setResponses(Array.from({ length: 200 }, () => respond));
    const inner = this.#model.provider;
    return { provider: { ...inner, stream: (...args) => priced(inner.stream(...args)), streamSimple: (...args) => priced(inner.streamSimple(...args)) }, model: this.#model.getModel() };
  }
}
