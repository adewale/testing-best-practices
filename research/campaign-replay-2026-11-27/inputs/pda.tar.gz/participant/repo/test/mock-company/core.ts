import {
  base64url,
  calculateJwkThumbprint,
  compactVerify,
  createLocalJWKSet,
  decodeJwt,
  decodeProtectedHeader,
  importJWK,
  jwtVerify,
  type JSONWebKeySet,
  type JWK,
  type JWTPayload
} from "jose";
import worker from "../../src/index";
import {
  DEFAULT_CONFIG,
  hostsFor,
  type CompanyFlaw,
  type Hosts,
  type AgentPayload,
  type DecodedJwt,
  type MockConfig,
  type MockRequest
} from "./types";
import { departure, ours, render, show, shown, type Problem, type Shown } from "../../src/diagnostic";
import { isViolation, type JwtKind, type SignedKind, type ViolationId } from "./violations";

export const DEVICE_CODE = "urn:ietf:params:oauth:grant-type:device_code";
/** The Mediated Sign-In extension's grant (Mediated Sign-In 2). */
export const MEDIATED_GRANT = "https://personalagentprotocol.org/grant/mediated-sign-in";
export const CLIENT_ASSERTION_TYPE =
  "urn:ietf:params:oauth:client-assertion-type:jwt-bearer";

/** DPoP proofs (RFC 9449; the metadata lists ES256). */
const SIGNING_ALGS = ["ES256", "RS256"];
/** Client assertions: Companies MUST accept ES256 and PS384 (4.1); since 0.4 the Guides no longer add RS256. */
const CLIENT_ASSERTION_ALGS = ["ES256", "PS384"];
const PRIVATE_JWK_FIELDS = ["d", "p", "q", "dp", "dq", "qi", "k"];
/** DPoP acceptance window plus clock skew, seconds. */
const DPOP_WINDOW = 60;
/** The Session JWT's `iat` window (5.3: "such as one minute"), and the longest delegation (5.2). */
const SESSION_JWT_WINDOW = 60;
const DELEGATION_LIFETIME = 24 * 60 * 60;
/** Delegations may be signed with either (5.2: "Companies MUST accept both"). */
const DELEGATION_ALGS = ["ES256", "PS384"];
const SKEW = 30;
/** Longest assertion lifetime accepted, seconds; strict Companies allow 60. */
const MAX_ASSERTION_LIFETIME = 300;
const STRICT_ASSERTION_LIFETIME = 60;

/** A Response to send instead of continuing. */
export class HttpError extends Error {
  constructor(readonly response: Response) {
    super(`HTTP ${response.status}`);
  }
}

export type ClientInfo = {
  readonly clientId: string;
  readonly name: string;
  readonly jwks: JSONWebKeySet;
  readonly redirectUris: readonly string[];
};

export type Session = {
  readonly id: string;
  /** The `sid` the agent chose (5.2). */
  readonly sid: string;
  readonly clientId: string;
  readonly userId: string;
  /** The account the Session is signed in to now, if any. */
  account: string | null;
  /** The account it was ever signed in to; another is refused (5.4). */
  boundAccount: string | null;
  /** The sign-in whose refresh token it is signed in with, if any: revoking that token signs it out (4.6, 5.5). */
  grant: string | null;
  scope: string[];
  ended: boolean;
  /**
   * What its requests declared (3.4): `Poppy-Version`, and the extensions
   * in `Poppy-Extensions`, fixed for the Session.
   */
  declaration?: { readonly version: string; readonly extensions: string; readonly declared: ReadonlyMap<string, string> };
  /** The Agent ID its Session JWTs carry, if any (5.1). */
  readonly agentId: string | null;
};

export type AccessToken = {
  readonly value: string;
  readonly kind: "dpop" | "bearer";
  readonly jkt: string | null;
  readonly resource: string | null;
  readonly scope: readonly string[];
  readonly account: string;
  readonly expiresAt: number;
  readonly issuedAt: number;
  /** Who it was issued to, and the sign-in it descends from, so revoking its refresh token ends it (RFC 7009 2.1). Access tokens belong to no Session (5.4). */
  readonly clientId: string;
  readonly grant: string;
};

/** A refresh token (4.4). The type keeps its old name, as do the violation ids that mention it. */
export type AccountToken = {
  readonly value: string;
  readonly clientId: string;
  readonly account: string;
  /** The sign-in it descends from; a rotated token keeps its predecessor's. */
  readonly grant: string;
  readonly scope: readonly string[];
  readonly expiresAt: number | null;
  /** The key of the DPoP proof sent when the sign-in issued it; rotation keeps it (1.0: 4.4). */
  readonly jkt: string | null;
  revoked: boolean;
  rotated: boolean;
};

/**
 * 3.4, read here apart from the agent's code: `major.minor` versions are
 * compatible with the same major version and, before 1.0, the same minor.
 */
function compatible(a: string, b: string): boolean {
  const match = (v: string) => /^(0|[1-9]\d*)\.(0|[1-9]\d*)$/.exec(v);
  const x = match(a), y = match(b);
  return !!x && !!y && x[1] === y[1] && (x[1] !== "0" || x[2] === y[2]);
}

/** One parsed inbound request. */
export type Inbound = {
  readonly request: Request;
  readonly url: URL;
  readonly bodyText: string;
  /** The body as sent, for a multipart upload's file. */
  readonly bodyBytes: Uint8Array;
};

/**
 * The header the test agent's fetcher stamps on every request: the time on
 * its fake clock, in epoch ms. Once a request carries it, the mock's clock
 * reads the latest such time (it stands still between them, as the agent's
 * does), so a Retry-After the agent waited out on the fake clock has elapsed
 * here too, and nothing else has.
 */
export const CLOCK_HEADER = "x-test-clock";

/** A client metadata document or JWKS a test serves at a URL instead of our Worker. */
export type ServedDocument = { readonly status: number; readonly body: string };

/** Who is calling a resource, after the Session header and any access token checked out. */
export type ResourceContext = {
  /** The access token; null for a request with only the Session header (5). */
  readonly token: AccessToken | null;
  readonly session: Session;
  readonly client: ClientInfo;
  /** Signed in now, to the account the token was issued for. */
  readonly signedIn: boolean;
  readonly account: string | null;
  readonly scope: readonly string[];
};

export function randomId(prefix: string, bytes = 16): string {
  return `${prefix}${base64url.encode(crypto.getRandomValues(new Uint8Array(bytes)))}`;
}

export function json(
  body: unknown,
  status = 200,
  headers: Record<string, string> = {}
): Response {
  return new Response(JSON.stringify(body), {
    status,
    headers: { "Content-Type": "application/json", ...headers }
  });
}

/** OAuth error response (RFC 6749 5.2). */
export function oauthError(
  status: number,
  error: string,
  description?: string,
  headers: Record<string, string> = {}
): HttpError {
  return new HttpError(
    json(
      { error, ...(description ? { error_description: description } : {}) },
      status,
      { "Cache-Control": "no-store", ...headers }
    )
  );
}

/** Resource error in `WWW-Authenticate` (RFC 9449 / RFC 6750). */
export function resourceError(
  scheme: "DPoP" | "Bearer",
  status: number,
  error: string,
  extra: { scope?: string; headers?: Record<string, string> } = {}
): HttpError {
  const challenge = `${scheme} error="${error}"${extra.scope ? `, scope="${extra.scope}"` : ""}`;
  return new HttpError(
    json({ error, ...(extra.scope ? { scope: extra.scope } : {}) }, status, {
      "WWW-Authenticate": challenge,
      ...(extra.headers ?? {})
    })
  );
}

export function parseScope(value: string | null | undefined): string[] {
  return (value ?? "").split(" ").filter((part) => part !== "");
}

/** A loopback redirect URI for an app on the User's computer (RFC 8252 7.3), which 4.1 allows beside HTTPS ones. */
export function isLoopbackRedirect(value: unknown): value is string {
  if (typeof value !== "string") return false;
  try {
    const url = new URL(value);
    return url.protocol === "http:" && (url.hostname === "127.0.0.1" || url.hostname === "[::1]");
  } catch {
    return false;
  }
}

/** Whether `given` is the registered `redirect_uri` exactly, or it but for a loopback URI's port (4.2, RFC 8252 7.3). */
export function redirectUriMatches(registered: string, given: string): boolean {
  if (registered === given) return true;
  if (!isLoopbackRedirect(registered) || !isLoopbackRedirect(given)) return false;
  const a = new URL(registered);
  const b = new URL(given);
  a.port = "";
  b.port = "";
  return a.href === b.href;
}

function isPrivateJwk(jwk: Record<string, unknown>): boolean {
  return PRIVATE_JWK_FIELDS.some((field) => field in jwk);
}

/** The private members a JWK carries, by name only: `private members d and p`. */
export function privateMembers(jwk: Record<string, unknown>): Shown {
  return shown`private members ${show.list(PRIVATE_JWK_FIELDS.filter((field) => field in jwk).map((field) => show.code(field)))}`;
}

/** A request as a check names it: `GET /orders`, without its host or query. */
export function requestAt(inbound: Inbound): Shown {
  return shown`${show.name(inbound.request.method)} ${show.name(inbound.url.pathname)}`;
}

/** How far a JWT's `iat` is from `now`, in whole minutes (a check's exact second would race the clock), or its kind. */
export function offset(iat: unknown, now: number): Shown {
  if (typeof iat !== "number") return show.kind(iat);
  return shown`one ${Math.round(Math.abs(now - iat) / 60)} minutes ${iat < now ? ours("earlier") : ours("later")}`;
}

/** A `Poppy-Extensions` value as declared, unquoted: `Poppy-Extensions "operations";v="3"`. */
function declaredExtensions(value: string): Shown {
  return value.trim() === "" ? ours("no Poppy-Extensions") : shown`Poppy-Extensions ${show.name(value)}`;
}

/** A claim or field that should be a URL: the URL without its query, or its kind. */
export function urlOrKind(value: unknown): Shown {
  return typeof value === "string" ? show.url(value) : show.kind(value);
}

async function sha256b64(text: string): Promise<string> {
  const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(text));
  return base64url.encode(new Uint8Array(digest));
}

export { sha256b64 };

/** All the Company's state, and the checks a strict Company makes. */
export class Company {
  #config: MockConfig = DEFAULT_CONFIG;
  hosts: Hosts;
  /** Every check the Company recorded, `[id] detail`, in order: violations and warnings (violations.ts). */
  readonly recorded: string[] = [];
  readonly requests: { -readonly [K in keyof MockRequest]: MockRequest[K] }[] = [];
  /** What the Personal Agent sent, decoded for the kit's schemas. */
  readonly sent: AgentPayload[] = [];
  readonly revocationHints: (string | null)[] = [];
  /** Revocation requests refused so far under `refuseRevocations`. */
  revocationsRefused = 0;
  /** Documents tests serve in place of a client's metadata or JWKS, by URL. */
  readonly served = new Map<string, ServedDocument>();
  /** Exchanges actually made, by account, order and item, to catch one made twice. */
  readonly exchanged = new Set<string>();
  /** The latest time a request carried in `CLOCK_HEADER`, if any did. */
  #stampedNow: number | null = null;
  readonly clients = new Map<string, ClientInfo>();
  readonly userIds = new Set<string>();
  /** The User each DPoP key was first bound for, by thumbprint: a key pair for each User (4.3). */
  readonly dpopKeyUsers = new Map<string, { clientId: string; userId: string }>();
  readonly sessions = new Map<string, Session>();
  readonly accessTokens = new Map<string, AccessToken>();
  /** Latest token issued per Session and kind/resource, with when. */
  readonly accountTokens = new Map<string, AccountToken>();
  readonly seenJtis = new Map<string, Set<string>>();
  /**
   * When each DPoP key, at each server origin, first sent the nonce: that
   * proof's `iat`. From then on it holds the nonce and must keep using it.
   */
  readonly nonceHeldSince = new Map<string, number>();
  /** DPoP nonces, one for the Company or one per origin (`nonceScope`). */
  readonly #nonces = new Map<string, string>();
  /** One-time codes we've "sent" to Users, for the secret scan. */
  readonly oneTimeCodes = new Set<string>();
  lastOneTimeCode: string | null = null;
  performs = 0;
  browserJoins = 0;
  /** Forms the website received: the signed-in account and every field, in order. */
  readonly formPosts: { account: string | null; fields: [string, string][] }[] = [];
  readonly returns: { account: string; controller: string; reason: string; cardLast4: string }[] = [];
  readonly feedback: { task: string; signedIn: boolean }[] = [];
  tokenRequestCount = 0;
  otherRequestCount = 0;
  pageRequestCount = 0;
  joinPageRequestCount = 0;
  retryAfterUntil = 0;
  /** When each request (method and URL without the query) that got 429 may be sent again. */
  readonly retryAfterByRequest = new Map<string, number>();

  constructor(
    readonly id: string,
    readonly env: Env
  ) {
    this.hosts = hostsFor(id);
  }

  get config(): MockConfig {
    return this.#config;
  }

  /** The versions this Company serves now (3.4): poppy.json's, and the one it links. */
  get servedVersions(): readonly string[] {
    return [this.#config.protocolVersion, ...(this.#config.linkedVersion ? [this.#config.linkedVersion] : [])];
  }

  /** Every version this Company has served while taking requests, so an agent declaring one it dropped since isn't at fault. */
  readonly #listed = new Set<string>();

  /** The Company has this flaw (`COMPANY_FLAWS`): one of its protections is off. */
  flawed(flaw: CompanyFlaw): boolean {
    return this.#config.flaws.includes(flaw);
  }

  set config(config: MockConfig) {
    this.#config = config;
    this.hosts = hostsFor(this.id, { issuerTrailingSlash: config.issuerTrailingSlash, issuerPath: config.issuerPath, issuerOnDomain: config.issuerOnDomain });
  }

  /**
   * Now, for comparing when requests arrive (rate limits, device polling,
   * token age): the test agent's fake clock once it has stamped a request,
   * the real clock until then. JWT times are always checked on the real
   * clock, since the agent signs with it.
   */
  now(): number {
    return this.#stampedNow ?? Date.now();
  }

  /**
   * Record a check; `id` names it (see `violations.ts`). Its basis decides
   * whether it's a violation or a warning; whether the request is also
   * refused is up to the caller.
   */
  violation(id: ViolationId, detail: Problem): void {
    this.recorded.push(`[${id}] ${render(detail)}`);
  }

  /** The recorded checks that are failures: a MUST, an RFC's MUST or a keyword-less rule broken. */
  get violations(): string[] {
    return this.recorded.filter(isViolation);
  }

  /** The recorded checks that are warnings: a SHOULD, the Guides or our reading. */
  get warnings(): string[] {
    return this.recorded.filter((entry) => !isViolation(entry));
  }

  /** Log a request as it arrives; the response fills in `status` and `error`. */
  log(inbound: Inbound, bodyKeys: string[]): { -readonly [K in keyof MockRequest]: MockRequest[K] } {
    const stamped = Number(inbound.request.headers.get(CLOCK_HEADER) ?? "");
    if (inbound.request.headers.has(CLOCK_HEADER) && Number.isFinite(stamped)) {
      this.#stampedNow = Math.max(stamped, this.#stampedNow ?? 0);
    }
    const headers: Record<string, string> = {};
    inbound.request.headers.forEach((value, name) => {
      if (name === "authorization") headers[name] = `${value.split(" ")[0]} <redacted>`;
      else headers[name] = name === "dpop" || name === "cookie" ? "<present>" : value;
    });
    let proofNonce: string | null = null;
    try {
      const proof = inbound.request.headers.get("DPoP");
      const nonce = proof ? decodeJwt(proof).nonce : undefined;
      if (typeof nonce === "string") proofNonce = nonce;
    } catch {
      // Not a JWT; verifyDpop records that.
    }
    const type = inbound.request.headers.get("Content-Type") ?? "";
    const grant = type.startsWith("application/x-www-form-urlencoded")
      ? new URLSearchParams(inbound.bodyText).get("grant_type")
      : null;
    const entry = {
      method: inbound.request.method,
      url: inbound.url.href,
      headers,
      bodyKeys,
      grant,
      proofNonce,
      at: this.now(),
      status: 0,
      error: null as string | null
    };
    this.requests.push(entry);
    this.#capture(inbound, type);
    return entry;
  }

  #capture(inbound: Inbound, type: string): void {
    const decode = (jwt: unknown): DecodedJwt | undefined => {
      if (typeof jwt !== "string") return undefined;
      try {
        return { header: { ...decodeProtectedHeader(jwt) }, payload: { ...decodeJwt(jwt) } };
      } catch {
        return undefined; // verifySessionHeader records it.
      }
    };
    let json: unknown;
    if (/^application\/(?:[\w.+-]+\+)?json\b/.test(type)) {
      try {
        json = JSON.parse(inbound.bodyText);
      } catch {
        // Not JSON; the route refuses it.
      }
    }
    const sessionJwt = decode(inbound.request.headers.get("Poppy-Session"));
    const delegation = decode(sessionJwt?.header.poppy_dlg);
    const approval = inbound.request.headers.get("Poppy-Approval") ?? undefined;
    const version = inbound.request.headers.get("Poppy-Version") ?? undefined;
    if (json === undefined && !sessionJwt && approval === undefined) return;
    this.sent.push({ method: inbound.request.method, url: inbound.url.href, json, sessionJwt, delegation, approval, ...(version !== undefined ? { version } : {}) });
  }

  /** JTIs are single-use within each kind of JWT. */
  freshJti(kind: JwtKind, jti: unknown): boolean {
    if (typeof jti !== "string" || jti === "") {
      this.violation(`${kind}.jti-missing`, departure(ours(kind), ours("a jti"), jti === undefined ? ours("none") : shown`jti ${show.value(jti)}`));
      return false;
    }
    if (!/^[A-Za-z0-9_-]{22,}$/.test(jti)) {
      this.violation(`${kind}.jti-weak`, departure(shown`${ours(kind)}'s jti`, ours("128 random bits of base64url, 22 characters or more"), show.value(jti)));
    }
    let seen = this.seenJtis.get(kind);
    if (!seen) {
      seen = new Set();
      this.seenJtis.set(kind, seen);
    }
    if (seen.has(jti)) {
      this.violation(`${kind}.jti-reused`, departure(shown`${ours(kind)}'s jti`, ours("a jti not used before"), shown`${show.value(jti)} again`));
      return kind === "dpop" ? this.flawed("accept-replayed-proof") : kind === "client-assertion" && this.flawed("accept-replayed-assertion");
    }
    seen.add(jti);
    return true;
  }

  /** The DPoP nonce the server at `origin` expects. */
  nonceFor(origin: string): string {
    // Interop XN: a fresh nonce on every call, so a retrying agent's proof
    // never carries the one the server now wants. nonceLoop also makes the
    // check below always challenge, so this value is only ever handed out.
    if (this.config.nonceLoop) return randomId("n_");
    const key = this.config.nonceScope === "origin" ? origin : "company";
    let nonce = this.#nonces.get(key);
    if (!nonce) {
      nonce = randomId("n_");
      this.#nonces.set(key, nonce);
    }
    return nonce;
  }

  /**
   * Make the jacket exchange. An item can be exchanged once, so a second time
   * for the same account means the agent retried a write without its
   * Idempotency-Key or confirmed the same thing twice.
   */
  performExchange(account: string | null, how: string): void {
    this.performs += 1;
    const key = `${account ?? ""}|ord_7Hk2|itm_4Qa`;
    if (this.exchanged.has(key)) {
      this.violation("exchange.performed-twice", departure(ours("the exchange of itm_4Qa on ord_7Hk2"), shown`one for ${show.value(account)}`, shown`a second, by ${show.name(how)}`));
    }
    this.exchanged.add(key);
  }

  /** The scopes this Company describes (4.7): its `scopes_supported`, every scope a Personal Agent can request (3.2). */
  scopeDescriptions(): Record<string, string> {
    const { read, write } = this.orderScopes;
    // A Company with browser join and sign-in supports poppy:browser-sign-in (6).
    // Unscoped, it MUST be described as the account's full access on the website (6).
    const browserSignIn: Record<string, string> = this.browserJoin
      ? { "poppy:browser-sign-in": this.config.webUnscoped ? "Browse the website, and see and do anything your account can do there" : "Use the website signed in, with the other access you approve" } : {};
    return { [read]: "See your orders and exchanges", [write]: "Exchange items on your orders", addresses: "See and change your saved shipping addresses", ...browserSignIn, ...this.config.customScopes };
  }

  /** Whether `poppy.json` lists a `browser_session_endpoint` (6), which it never does with `web.disabled`. */
  get browserJoin(): boolean {
    return this.config.web && this.config.browserSession && !this.config.webDisabled;
  }

  /** What the Company calls reading and changing orders: its own scopes, since the protocol defines none (4.7). */
  get orderScopes(): { readonly read: string; readonly write: string } {
    return { read: "orders:read", write: "orders:write" };
  }

  /** Scopes a sign-in type can grant, or null when it isn't offered. */
  offeredScopes(type: "direct" | "device" | "mediated"): readonly string[] | null {
    if (this.config.issuerless || (type === "mediated" && this.config.authDisabled)) return null;
    const offered = this.config.signIn[type];
    // 0.4: a Company with browser join and sign-in MUST support poppy:browser-sign-in (6); Mediated Sign-In keeps its own list.
    return offered && type !== "mediated" && "poppy:browser-sign-in" in this.scopeDescriptions() && !offered.includes("poppy:browser-sign-in")
      ? [...offered, "poppy:browser-sign-in"] : offered;
  }

  /** The Company's identifier (3.2): its issuer, or `https://{domain}` without one. Session JWTs' audience. */
  get identifier(): string {
    const none = this.config.issuerless || this.config.authorizationServersOverride?.length === 0;
    return none ? `https://${this.hosts.domain.toLowerCase()}` : this.hosts.issuer;
  }

  // ---- Rate limits (4.3) ----

  /**
   * 429 when configured. Until the `Retry-After` passes, every request gets
   * 429 too, since the Company's limit covers them all. Only the same
   * request (method and URL) sent again before its own `Retry-After` breaks
   * 4.3's MUST ("before sending the request again"); a different request
   * breaks the Guides' advice to share a Company's limits across tasks.
   */
  rateLimit(kind: "token" | "other" | "page" | "join", inbound: Inbound): void {
    const now = this.now();
    const request = `${inbound.request.method} ${inbound.url.origin}${inbound.url.pathname}`;
    if (now < this.retryAfterUntil) {
      const own = this.retryAfterByRequest.get(request);
      if (own !== undefined && now < own) {
        this.violation(
          "rate-limit.retry-after-ignored",
          departure(requestAt(inbound), ours("no repeat until its Retry-After elapsed"), shown`the same request ${own - now} ms before it did`)
        );
      } else {
        this.violation(
          "rate-limit.shared-limit-ignored",
          departure(requestAt(inbound), ours("no request until an earlier request's Retry-After elapsed"), shown`this one ${this.retryAfterUntil - now} ms before it did`)
        );
      }
      this.retryAfterByRequest.set(request, this.retryAfterUntil);
      throw this.tooMany(Math.ceil((this.retryAfterUntil - now) / 1000));
    }
    const limits = this.config.rateLimit;
    const limit = kind === "token" ? limits.tokenRequests429 : kind === "page" ? (limits.pages429 ?? 0) : kind === "join" ? (limits.joinPages429 ?? 0) : limits.requests429;
    const count =
      kind === "token" ? ++this.tokenRequestCount : kind === "page" ? ++this.pageRequestCount : kind === "join" ? ++this.joinPageRequestCount : ++this.otherRequestCount;
    if (count <= limit) {
      this.retryAfterUntil = now + this.config.rateLimit.retryAfterSeconds * 1000;
      this.retryAfterByRequest.set(request, this.retryAfterUntil);
      throw this.tooMany(this.config.rateLimit.retryAfterSeconds);
    }
  }

  tooMany(seconds: number): HttpError {
    return new HttpError(
      json({ error: "rate_limited" }, 429, {
        "Retry-After": String(Math.max(1, seconds)),
        "Cache-Control": "no-store"
      })
    );
  }

  // ---- Secrets never sent to the wrong place (4.7, 4.8, Guides) ----

  /**
   * Passwords may appear only in the mediated sign-in body, one-time codes
   * only in the code submission, refresh tokens only at the token and
   * revocation endpoints. Anything else is a violation.
   */
  scanSecrets(inbound: Inbound, allowed: "account-token" | "token-endpoint" | null): void {
    const headerText: string[] = [];
    inbound.request.headers.forEach((value, name) => headerText.push(`${name}: ${value}`));
    const places: ["URL" | "headers" | "body", string][] = [
      ["URL", inbound.url.href],
      ["headers", headerText.join("\n")],
      ["body", inbound.bodyText]
    ];
    const check = (
      id: "secret.password" | "secret.one-time-code" | "secret.account-token",
      kind: "password" | "one-time code" | "refresh token",
      secret: string,
      allowedHere: boolean
    ) => {
      const only = id === "secret.account-token" ? ours("the body of a token or revocation request only") : ours("the token endpoint's body only");
      for (const [where, text] of places) {
        if (!text.includes(secret)) continue;
        if (allowedHere && where === "body") continue;
        this.violation(id, departure(shown`the ${ours(kind)}`, only, shown`it in the ${ours(where)} of ${show.name(inbound.request.method)} ${show.url(inbound.url)}`));
      }
    };
    for (const account of this.config.accounts) {
      check("secret.password", "password", account.password, allowed === "token-endpoint");
    }
    for (const code of this.oneTimeCodes) check("secret.one-time-code", "one-time code", code, allowed === "token-endpoint");
    for (const token of this.accountTokens.values()) {
      check("secret.account-token", "refresh token", token.value, (allowed === "account-token" || allowed === "token-endpoint"));
    }
    // Tokens never belong in a URL (4.5).
    for (const [name, value] of inbound.url.searchParams) {
      if (
        name === "access_token" ||
        name === "token" ||
        this.accessTokens.has(value) ||
        this.accountTokens.has(value)
      ) {
        this.violation("secret.token-in-url", departure(ours("the request URL"), ours("no token in its query"), shown`${show.code(name)}= in ${show.url(inbound.url)}`));
        // Refuse the transport itself, independently of whether the supplied token exists.
        if (!this.flawed("accept-query-token")) throw resourceError("DPoP", 400, "invalid_request");
      }
    }
  }

  // ---- Fetching the Personal Agent's metadata (4.1) ----

  async #fetchAgent(url: string): Promise<Response> {
    const served = this.served.get(url);
    if (served) {
      return new Response(served.body, { status: served.status, headers: { "Content-Type": "application/json" } });
    }
    const agentHost = new URL(this.env.PUBLIC_ORIGIN).host;
    const request = new Request(url, { redirect: "manual" });
    // Guides: never send credentials on metadata fetches; fetch without redirects.
    if (new URL(url).host === agentHost) return worker.fetch(request, this.env);
    return fetch(request);
  }

  async client(clientId: string): Promise<ClientInfo> {
    const cached = this.clients.get(clientId);
    if (cached) return cached;
    /** Records `detail`, and refuses with `message` as the error_description. */
    const fail = (id: ViolationId, detail: Problem, message: string): HttpError => {
      this.violation(id, detail);
      return oauthError(401, "invalid_client", message);
    };
    let url: URL;
    try {
      url = new URL(clientId);
    } catch {
      throw fail("client-metadata.not-url", departure(ours("client_id"), ours("an HTTPS URL"), show.text(clientId, 200)), `client_id ${JSON.stringify(clientId)} is not a URL`);
    }
    if (url.protocol !== "https:") throw fail("client-metadata.not-https", departure(ours("client_id"), ours("an https URL"), show.url(url)), "client_id must be an https URL");
    const response = await this.#fetchAgent(clientId);
    if (response.status !== 200) {
      throw fail("client-metadata.fetch-status", departure(ours("fetching client_id"), ours("HTTP 200, without a redirect"), show.status(response.status)), `fetching client_id returned ${response.status}; it must not redirect`);
    }
    let metadata: Record<string, unknown>;
    try {
      metadata = (await response.json()) as Record<string, unknown>;
    } catch {
      throw fail("client-metadata.not-json", departure(ours("the client metadata"), ours("a JSON document"), shown`a body that doesn't parse as JSON (${show.type(response.headers.get("Content-Type"))})`), "client metadata is not JSON");
    }
    // A document a test serves in its place isn't what the agent publishes.
    if (!this.served.has(clientId)) this.sent.push({ method: "GET", url: clientId, clientMetadata: metadata });
    if (metadata.client_id !== clientId) {
      throw fail("client-metadata.client-id-mismatch", departure(ours("the document's client_id"), shown`the URL it was fetched from, ${show.url(clientId)}`, urlOrKind(metadata.client_id)), "client_id in the document doesn't equal the URL it was fetched from");
    }
    const sameDomain = (value: unknown): value is string => {
      if (typeof value !== "string") return false;
      try {
        const parsed = new URL(value);
        return parsed.protocol === "https:" && parsed.hostname === url.hostname;
      } catch {
        return false;
      }
    };
    if (!sameDomain(metadata.jwks_uri)) {
      throw fail("client-metadata.jwks-uri", departure(ours("jwks_uri"), shown`an https URL on ${show.name(url.hostname)}, client_id's host`, urlOrKind(metadata.jwks_uri)), "jwks_uri must be https on the client_id domain");
    }
    const redirectUris = Array.isArray(metadata.redirect_uris) ? metadata.redirect_uris : [];
    const strayRedirect = redirectUris.find((uri) => !sameDomain(uri) && !isLoopbackRedirect(uri));
    if (strayRedirect !== undefined) {
      throw fail("client-metadata.redirect-uris", departure(ours("each redirect_uri"), shown`an https URL on ${show.name(url.hostname)}, client_id's host, or a loopback redirect URI`, urlOrKind(strayRedirect)), "redirect_uris must be https on the client_id domain");
    }
    if (metadata.token_endpoint_auth_method !== "private_key_jwt") {
      this.violation("client-metadata.auth-method", departure(ours("token_endpoint_auth_method"), ours("private_key_jwt"), show.value(metadata.token_endpoint_auth_method)));
    }
    const jwksResponse = await this.#fetchAgent(metadata.jwks_uri as string);
    if (jwksResponse.status !== 200) throw fail("client-metadata.jwks-status", departure(ours("fetching jwks_uri"), ours("HTTP 200"), show.status(jwksResponse.status)), `jwks_uri returned ${jwksResponse.status}`);
    const jwks = (await jwksResponse.json().catch(() => ({}))) as JSONWebKeySet;
    if (!Array.isArray(jwks.keys) || jwks.keys.length === 0) {
      throw fail("client-metadata.jwks-empty", departure(ours("the JWKS"), ours("at least one key"), Array.isArray(jwks.keys) ? ours("an empty keys array") : shown`keys as ${show.kind(jwks.keys)}`), "JWKS has no keys");
    }
    for (const key of jwks.keys) {
      if (isPrivateJwk(key as unknown as Record<string, unknown>)) {
        throw fail("client-metadata.jwks-private", departure(ours("each JWKS key"), ours("a public key only"), privateMembers(key as unknown as Record<string, unknown>)), "JWKS publishes a private key");
      }
      if (!key.kid) {
        this.violation("client-metadata.key-without-kid", departure(ours("each JWKS key"), ours("a kid"), ours("a key without one")));
      }
    }
    const info: ClientInfo = {
      clientId,
      name: typeof metadata.client_name === "string" ? metadata.client_name : clientId,
      jwks,
      redirectUris: redirectUris as string[]
    };
    this.clients.set(clientId, info);
    return info;
  }

  /** Verify a JWT signed by the client's keys; returns its payload. */
  /** Verify a JWT signed by the client's keys, its header already decoded; returns its payload. */
  async #verifyClientJwt(
    client: ClientInfo,
    token: string,
    header: ReturnType<typeof decodeProtectedHeader>,
    kind: SignedKind,
    error: () => HttpError
  ): Promise<JWTPayload> {
    if (!header.alg || !CLIENT_ASSERTION_ALGS.includes(header.alg)) {
      this.violation(`${kind}.alg`, departure(ours("the client assertion's alg"), ours("ES256 or PS384"), show.value(header.alg)));
      throw error();
    }
    if (header.jku || header.x5u || header.jwk) {
      const named = (["jku", "x5u", "jwk"] as const).filter((name) => header[name] !== undefined).map((name) => ours(name));
      this.violation(`${kind}.embedded-key`, departure(ours("the client assertion's header"), ours("no key of its own: no jku, x5u or jwk"), show.list(named)));
    }
    if (this.config.strictAssertions) {
      if (header.typ !== "JWT") {
        this.violation(`${kind}.typ`, departure(ours("the client assertion's typ"), ours("\"JWT\", as the strict Company reads S2"), show.value(header.typ)));
        throw error();
      }
      if (!header.kid || !client.jwks.keys.some((key) => key.kid === header.kid)) {
        this.violation(`${kind}.kid`, departure(ours("the client assertion's kid"), ours("the kid of a key in the client's JWKS, as the strict Company reads S2"), show.value(header.kid)));
        throw error();
      }
    }
    try {
      const { payload } = await jwtVerify(token, createLocalJWKSet(client.jwks), {
        algorithms: CLIENT_ASSERTION_ALGS,
        clockTolerance: SKEW
      });
      return payload;
    } catch (cause) {
      this.violation(`${kind}.signature`, departure(ours("the client assertion"), ours("a signature by a key in the client's JWKS, within its exp"), show.text(cause instanceof Error ? cause.message : String(cause))));
      throw error();
    }
  }

  #checkLifetime(kind: SignedKind, payload: JWTPayload): boolean {
    if (typeof payload.iat !== "number" || typeof payload.exp !== "number") {
      this.violation(`${kind}.iat-exp-missing`, departure(ours("the client assertion's iat and exp"), ours("two numbers"), shown`iat as ${show.kind(payload.iat)} and exp as ${show.kind(payload.exp)}`));
      return false;
    }
    const final = !this.config.protocolVersion.startsWith("0.");
    const longest = final || !this.config.strictAssertions ? MAX_ASSERTION_LIFETIME : STRICT_ASSERTION_LIFETIME;
    if (payload.exp - payload.iat > longest) {
      this.violation(final ? "client-assertion.lifetime-1.0" : `${kind}.lifetime`, departure(ours("the client assertion's lifetime"), shown`at most ${longest} s`, shown`${payload.exp - payload.iat} s`));
      return false;
    }
    return true;
  }

  /**
   * Client authentication at the token, device and revocation endpoints:
   * `private_key_jwt` (RFC 7523) against the client's `jwks_uri`.
   *
   * `client_id` is optional beside a client assertion (RFC 7521 4.2: the
   * assertion's subject names the client), and the draft doesn't require it, so
   * a request without one is the client its assertion's `iss` and `sub` both
   * name (RFC 7523 3). One that sends it must name that same client.
   */
  async authenticateClient(form: URLSearchParams, endpoint: string): Promise<ClientInfo> {
    const assertion = form.get("client_assertion");
    if (form.get("client_assertion_type") !== CLIENT_ASSERTION_TYPE || !assertion) {
      this.violation("client-assertion.missing", departure(shown`the request to ${show.url(endpoint)}`, ours("a client_assertion of client_assertion_type jwt-bearer"), assertion ? shown`client_assertion_type ${show.value(form.get("client_assertion_type") ?? undefined)}` : ours("no client_assertion")));
      throw oauthError(401, "invalid_client", "client assertion is required");
    }
    const clientId = form.get("client_id") ?? this.#assertedClient(assertion);
    if (!clientId) throw oauthError(401, "invalid_client", "no client_id, and the client assertion's iss and sub don't name one client");
    const registered = this.config.requireRegistration;
    if (registered && !registered.includes(clientId)) {
      throw oauthError(401, "invalid_client", "this Personal Agent is not registered");
    }
    const client = await this.client(clientId);
    let header;
    try {
      header = decodeProtectedHeader(assertion);
      decodeJwt(assertion);
    } catch {
      this.violation("client-assertion.not-jwt", departure(ours("the client assertion"), ours("a JWT"), ours("a value that doesn't decode as one")));
      throw oauthError(401, "invalid_client", "client assertion is not a JWT");
    }
    // Explicit typing (RFC 8725 3.11, 5.2): a DPoP proof, Session JWT or delegation is never a client assertion.
    if (header.typ === "dpop+jwt" || header.typ === "poppy-session+jwt" || header.typ === "poppy-delegation+jwt") {
      this.violation("client-assertion.wrong-typ", departure(ours("the client assertion's typ"), ours("a client assertion's, not a DPoP proof's, Session JWT's or delegation's"), show.value(header.typ)));
      throw oauthError(401, "invalid_client");
    }
    const payload = await this.#verifyClientJwt(client, assertion, header, "client-assertion", () =>
      oauthError(401, "invalid_client", "client assertion did not verify")
    );
    if (Array.isArray(payload.aud)) {
      this.violation("client-assertion.aud-array", departure(ours("the client assertion's aud"), ours("the issuer, as a single string"), show.kind(payload.aud)));
      throw oauthError(401, "invalid_client");
    }
    // 4.1: the issuer, as a single string, compared character for character; never an endpoint.
    const audiences = [this.hosts.issuer, ...(this.flawed("accept-token-endpoint-aud") ? [this.hosts.tokenEndpoint] : [])];
    if (typeof payload.aud !== "string" || !audiences.includes(payload.aud)) {
      this.violation("client-assertion.aud", departure(ours("the client assertion's aud"), shown`the issuer, ${show.text(this.hosts.issuer, 200)}`, typeof payload.aud === "string" ? show.text(payload.aud, 200) : show.kind(payload.aud)));
      throw oauthError(401, "invalid_client");
    }
    if (payload.iss !== clientId || payload.sub !== clientId) {
      this.violation("client-assertion.iss-sub", departure(ours("the client assertion's iss and sub"), shown`both the client_id, ${show.url(clientId)}`, shown`iss ${urlOrKind(payload.iss)} and sub ${urlOrKind(payload.sub)}`));
      throw oauthError(401, "invalid_client");
    }
    if (!this.#checkLifetime("client-assertion", payload)) {
      throw oauthError(401, "invalid_client");
    }
    if (!this.freshJti("client-assertion", payload.jti)) {
      throw oauthError(401, "invalid_client", "assertion jti already used");
    }
    return client;
  }

  /** The client an unverified client assertion names: its `iss`, when `sub` is the same (RFC 7523 3). */
  #assertedClient(assertion: string): string | null {
    try {
      const { iss, sub } = decodeJwt(assertion);
      return typeof iss === "string" && iss !== "" && iss === sub ? iss : null;
    } catch {
      return null;
    }
  }

  /** User IDs MUST NOT contain or be derived from personal information (5.1). */
  checkUserId(userId: string): void {
    if (!this.userIds.has(userId)) {
      const lower = userId.toLowerCase();
      // The local part counts only as a whole word ("usr_ada", "ada_lovelace"):
      // 22 random base64url characters contain "ada" in about 1 ID in 1,600.
      // And not at all in an ID shaped like 128 random bits after a prefix,
      // whose `-` and `_` can make "ada" a word by chance (about 10 in a
      // million, as in "usr_hB1U-xQz3FnJ1q7J8u_adA"): both made tests fail at random.
      const random = /^[a-z]+_[A-Za-z0-9_-]{22,}$/.test(userId);
      const words = lower.split(/[^a-z0-9]+/);
      const personal = this.config.accounts.some(
        (account) =>
          lower.includes(account.email.toLowerCase()) ||
          (!random && words.includes(account.email.split("@")[0]!.toLowerCase()))
      );
      if (userId.includes("@") || personal) {
        this.violation("user-id.personal", departure(ours("the User ID"), ours("an identifier with no personal information"), shown`${show.value(userId)}, which holds an account's email address or its name`));
      }
    }
    this.userIds.add(userId);
  }

  // ---- DPoP (4.5, RFC 9449) ----

  /**
   * Check a DPoP proof. At the token endpoint `accessToken` is undefined and
   * the proof must not carry `ath`. Returns the key's thumbprint.
   */
  async verifyDpop(
    inbound: Inbound,
    accessToken: string | undefined
  ): Promise<string> {
    const atTokenEndpoint = accessToken === undefined;
    const origin = inbound.url.origin;
    const where = requestAt(inbound);
    /** The DPoP proof's `part` on this request, as a check's subject. */
    const onProof = (part: Shown): Shown => shown`${part} on ${where}`;
    /** Records `detail` under `id` when there is one (never dropped: `why` stands in for a missing detail), and refuses with `why` as the error_description. */
    const fail = (error: string, why: string, id: ViolationId | null, detail?: Problem): HttpError => {
      if (id) this.violation(id, detail ?? show.text(why));
      const headers: Record<string, string> = { "WWW-Authenticate": `DPoP error="${error}"` };
      if (error === "use_dpop_nonce") headers["DPoP-Nonce"] = this.nonceFor(origin);
      return atTokenEndpoint
        ? oauthError(400, error, why, headers)
        : resourceError("DPoP", 401, error, {
            headers: error === "use_dpop_nonce" ? { "DPoP-Nonce": this.nonceFor(origin) } : {}
          });
    };
    const proofs = inbound.request.headers.get("DPoP");
    if (!proofs) throw fail("invalid_dpop_proof", "missing DPoP header", "dpop.missing", departure(onProof(ours("the DPoP header")), ours("a DPoP proof for the DPoP-bound token"), ours("none")));
    if (proofs.includes(",")) {
      throw fail("invalid_dpop_proof", "more than one DPoP proof", "dpop.multiple", departure(onProof(ours("the DPoP header")), ours("one proof"), shown`${proofs.split(",").length} proofs`));
    }
    let header;
    let claims: JWTPayload;
    try {
      header = decodeProtectedHeader(proofs);
      claims = decodeJwt(proofs);
    } catch {
      throw fail("invalid_dpop_proof", "proof is not a JWT", "dpop.not-jwt", departure(onProof(ours("the DPoP proof")), ours("a JWT"), ours("a value that doesn't decode as one")));
    }
    if (header.typ !== "dpop+jwt") throw fail("invalid_dpop_proof", `typ is ${header.typ}`, "dpop.typ", departure(onProof(ours("the DPoP proof's typ")), ours("dpop+jwt"), show.value(header.typ)));
    if (!header.alg || !SIGNING_ALGS.includes(header.alg)) {
      throw fail("invalid_dpop_proof", `alg ${header.alg} not allowed`, "dpop.alg", departure(onProof(ours("the DPoP proof's alg")), ours("ES256 or RS256"), show.value(header.alg)));
    }
    const jwk = header.jwk as JWK | undefined;
    if (!jwk) throw fail("invalid_dpop_proof", "no jwk in header", "dpop.no-jwk", departure(onProof(ours("the DPoP proof's header")), ours("a jwk"), ours("none")));
    if (isPrivateJwk(jwk as unknown as Record<string, unknown>)) {
      throw fail("invalid_dpop_proof", "jwk contains a private key", "dpop.private-jwk", departure(onProof(ours("the DPoP proof's jwk")), ours("a public key only"), privateMembers(jwk as unknown as Record<string, unknown>)));
    }
    try {
      const key = await importJWK(jwk, header.alg);
      await jwtVerify(proofs, key, { typ: "dpop+jwt", algorithms: SIGNING_ALGS });
    } catch (cause) {
      const message = cause instanceof Error ? cause.message : String(cause);
      throw fail("invalid_dpop_proof", `signature: ${message}`, "dpop.signature", departure(onProof(ours("the DPoP proof")), ours("a signature by its jwk"), show.text(message)));
    }
    const htu = `${inbound.url.origin}${inbound.url.pathname}`;
    if (claims.htm !== inbound.request.method) {
      throw fail("invalid_dpop_proof", `htm ${String(claims.htm)} != ${inbound.request.method}`, "dpop.htm", departure(onProof(ours("the DPoP proof's htm")), shown`the request's method, ${show.value(inbound.request.method)}`, show.value(claims.htm)));
    }
    if (claims.htu !== htu) {
      const error = fail("invalid_dpop_proof", `htu ${String(claims.htu)} != ${htu}`, "dpop.htu", departure(onProof(ours("the DPoP proof's htu")), shown`the request URL without its query, ${show.url(htu)}`, urlOrKind(claims.htu)));
      if (!this.flawed("accept-wrong-htu")) throw error;
    }
    // Proofs carry the agent's real time; the fake clock moves only request timing.
    const now = Math.floor(Date.now() / 1000);
    if (typeof claims.iat !== "number" || Math.abs(now - claims.iat) > DPOP_WINDOW + SKEW) {
      throw fail("invalid_dpop_proof", "iat outside the acceptance window", "dpop.iat", departure(onProof(ours("the DPoP proof's iat")), shown`a time within ${DPOP_WINDOW + SKEW} s of now`, offset(claims.iat, now)));
    }
    if (!this.freshJti("dpop", claims.jti)) {
      throw fail("invalid_dpop_proof", "jti reused", null);
    }
    // At the token endpoint there's no access token, so ath isn't checked (RFC 9449 4.3).
    if (!atTokenEndpoint && claims.ath !== (await sha256b64(accessToken))) {
      throw fail("invalid_dpop_proof", "ath doesn't match the token", "dpop.ath", departure(onProof(ours("the DPoP proof's ath")), ours("the hash of the access token sent"), claims.ath === undefined ? ours("none") : ours("another value")));
    }
    const jkt = await calculateJwkThumbprint(jwk);
    if (this.config.nonceLoop) {
      // Interop XN: never accept the nonce it issued, so every reply is a
      // fresh `use_dpop_nonce` challenge. An agent that retries without bound
      // would loop; a correct one gives up after a bounded number of tries.
      throw fail("use_dpop_nonce", "nonce required (loop)", null);
    }
    if (this.config.requireNonce) {
      // Nonces belong to a server (RFC 9449; Guides: "keep it for that server").
      const holder = `${jkt}|${origin}`;
      const since = this.nonceHeldSince.get(holder);
      if (claims.nonce === this.nonceFor(origin)) {
        if (since === undefined) this.nonceHeldSince.set(holder, claims.iat);
      } else {
        // Dropping a nonce this key already used here is a violation. A proof
        // made in the same second may have been in flight before the nonce
        // arrived (two requests racing to a server new to this key), so only
        // a later one counts.
        if (claims.nonce === undefined && since !== undefined && claims.iat > since) {
          this.violation(
            "dpop.nonce-ignored",
            departure(shown`a DPoP proof at ${show.name(origin)}`, ours("the nonce this key already used at this server"), ours("none"), ours("A key keeps using a server's nonces"))
          );
        }
        throw fail("use_dpop_nonce", "nonce required", null);
      }
    }
    return jkt;
  }

  // ---- Tokens ----

  /**
   * An access token from a sign-in or refresh (4.5). It belongs to the
   * client and the account, not to a Session (5.4); `grant` is the sign-in
   * its refresh token descends from.
   */
  issueAccess(holder: { clientId: string; account: string; grant: string }, binding: { jkt: string | null; resource: string | null }, scope: readonly string[]): AccessToken {
    const now = Date.now();
    const token: AccessToken = {
      value: randomId("at_", 24),
      kind: binding.jkt ? "dpop" : "bearer",
      jkt: binding.jkt,
      resource: binding.resource,
      scope,
      account: holder.account,
      expiresAt: now + this.config.accessTokenTtl * 1000,
      issuedAt: now,
      clientId: holder.clientId,
      grant: holder.grant
    };
    this.accessTokens.set(token.value, token);
    return token;
  }

  /** A refresh token for a sign-in (4.4): its client, account and grant; it names no Session or User ID. */
  issueAccountToken(holder: { readonly clientId: string; readonly account: string; readonly grant: string; readonly jkt: string | null }, scope: readonly string[]): AccountToken {
    const token: AccountToken = {
      value: randomId("pat_", 24),
      clientId: holder.clientId,
      account: holder.account,
      grant: holder.grant,
      jkt: holder.jkt,
      scope,
      expiresAt: this.config.refreshTokenTtl
        ? Date.now() + this.config.refreshTokenTtl * 1000
        : null,
      revoked: false,
      rotated: false
    };
    this.accountTokens.set(token.value, token);
    return token;
  }

  /** A token response for `access`, asked for with the scopes `requested`. */
  tokenResponse(access: AccessToken, requested: readonly string[], refresh?: AccountToken): Response {
    // RFC 6749 5.1: `scope` may be left out only when it is what was requested.
    const asRequested = access.scope.length === requested.length && access.scope.every((scope) => requested.includes(scope));
    const body: Record<string, unknown> = {
      access_token: access.value,
      token_type: access.kind === "dpop" ? "DPoP" : "Bearer",
      expires_in: this.config.accessTokenTtl,
      // Plain OAuth token responses (4.7); Sessions are the Session header's.
      ...(this.config.omitTokenScope && asRequested ? {} : { scope: access.scope.join(" ") })
    };
    if (refresh) {
      body.refresh_token = refresh.value;
      if (refresh.expiresAt) {
        body.refresh_token_expires_in = Math.round((refresh.expiresAt - Date.now()) / 1000);
      }
    }
    return json(body, 200, this.flawed("token-cacheable") ? {} : { "Cache-Control": "no-store", Pragma: "no-cache" });
  }

  // ---- The Session header (5.2, 5.3) ----

  /** Verified delegations by their compact form, until they expire (5.2: a resource "MAY cache a verified delegation"). */
  readonly #delegations = new Map<string, { readonly clientId: string; readonly jwk: JWK; readonly exp: number }>();
  /** The User each delegated key signed for, by thumbprint: one User ID per key (5.2). */
  readonly delegatedKeyUsers = new Map<string, string>();
  /** Sessions by `client_id` and `sid` (5.3, step 4). */
  readonly sessionsBySid = new Map<string, Session>();

  /** 400 `invalid_session` (5.3): a failed Session check or a refused client. A new Session doesn't fix it. */
  invalidSession(description?: string): HttpError {
    return new HttpError(json({ error: "invalid_session", ...(description ? { error_description: description } : {}) }, 400, { "Cache-Control": "no-store" }));
  }

  /** 400 `session_ended` (5.4, 5.5): an ended Session, or a refused account change. The agent starts a new Session once. */
  sessionEnded(description?: string): HttpError {
    return new HttpError(json({ error: "session_ended", ...(description ? { error_description: description } : {}) }, 400, { "Cache-Control": "no-store" }));
  }

  /**
   * A delegation (5.2, steps 1 and 2): signed by a key in the client's
   * `jwks_uri` that its `kid` names, typed, issued by the client, unexpired
   * and at most a day long, naming a public key and nothing about a User or
   * a Company. Returns the delegated public key.
   */
  async #verifyDelegation(client: ClientInfo, delegation: string): Promise<JWK> {
    const cached = this.#delegations.get(delegation);
    const now = Math.floor(Date.now() / 1000);
    if (cached && cached.clientId === client.clientId && cached.exp > now) return cached.jwk;
    /** Records `detail`, and refuses with `why` as the error_description. */
    const fail = (id: ViolationId, why: string, detail: Problem): HttpError => {
      this.violation(id, detail);
      return this.invalidSession(why);
    };
    let header;
    let claims: JWTPayload;
    try {
      header = decodeProtectedHeader(delegation);
      claims = decodeJwt(delegation);
    } catch {
      throw fail("delegation.not-jwt", "poppy_dlg is not a JWT", departure(ours("poppy_dlg"), ours("a JWT"), ours("a value that doesn't decode as one")));
    }
    if (header.typ !== "poppy-delegation+jwt") {
      throw fail("delegation.typ", `typ is ${JSON.stringify(header.typ)}, not poppy-delegation+jwt`, departure(ours("the delegation's typ"), ours("poppy-delegation+jwt"), show.value(header.typ)));
    }
    if (!header.alg || !DELEGATION_ALGS.includes(header.alg)) {
      throw fail("delegation.alg", `alg ${String(header.alg)} is not ES256 or PS384`, departure(ours("the delegation's alg"), ours("ES256 or PS384"), show.value(header.alg)));
    }
    const signer = client.jwks.keys.find((key) => key.kid === header.kid);
    if (!signer) {
      throw fail("delegation.kid", `kid ${JSON.stringify(header.kid)} names no key in jwks_uri`, departure(ours("the delegation's kid"), ours("the kid of a key in the client's jwks_uri"), show.value(header.kid)));
    }
    try {
      // The signature alone: its times are checked below, each with its own finding.
      await compactVerify(delegation, await importJWK(signer, header.alg), { algorithms: DELEGATION_ALGS });
    } catch (cause) {
      const message = cause instanceof Error ? cause.message : String(cause);
      throw fail("delegation.signature", `signature: ${message}`, departure(ours("the delegation"), ours("a signature by the key its kid names"), show.text(message)));
    }
    if (claims.iss !== client.clientId) {
      throw fail("delegation.iss", "iss isn't the Session JWT's iss", departure(ours("the delegation's iss"), shown`the Session JWT's iss, ${show.url(client.clientId)}`, urlOrKind(claims.iss)));
    }
    if (typeof claims.iat !== "number" || typeof claims.exp !== "number") {
      throw fail("delegation.lifetime", "iat and exp are required", departure(ours("the delegation's iat and exp"), ours("two numbers"), shown`iat as ${show.kind(claims.iat)} and exp as ${show.kind(claims.exp)}`));
    }
    if (claims.exp - claims.iat > DELEGATION_LIFETIME) {
      throw fail("delegation.lifetime", `exp is ${claims.exp - claims.iat} s after iat, more than 24 hours`, departure(ours("the delegation's lifetime"), shown`at most 24 hours (${DELEGATION_LIFETIME} s)`, shown`${claims.exp - claims.iat} s`));
    }
    if (claims.exp <= now - SKEW) throw fail("delegation.expired", "the delegation has expired", departure(ours("the delegation's exp"), ours("a time to come"), ours("a time past")));
    if (typeof claims.jti !== "string" || claims.jti.length < 22) {
      const got = typeof claims.jti === "string" ? shown`${claims.jti.length} characters` : show.kind(claims.jti);
      throw fail("delegation.jti", "jti is missing or guessable", departure(ours("the delegation's jti"), ours("128 random bits, 22 characters or more"), got));
    }
    const cnf = claims.cnf as { jwk?: unknown } | undefined;
    const jwk = cnf && typeof cnf.jwk === "object" && cnf.jwk !== null ? (cnf.jwk as JWK) : null;
    if (!jwk) throw fail("delegation.cnf", "cnf.jwk is missing", departure(ours("the delegation's cnf"), ours("an object with a jwk"), cnf === undefined ? ours("no cnf") : shown`jwk as ${show.kind(cnf.jwk)}`));
    if (isPrivateJwk(jwk as unknown as Record<string, unknown>)) {
      throw fail("delegation.private-key", "cnf.jwk contains private key members", departure(ours("the delegation's delegated key"), ours("a public key only"), privateMembers(jwk as unknown as Record<string, unknown>)));
    }
    const extra = Object.keys(claims).filter((name) => !["iss", "cnf", "iat", "exp", "jti", "nbf"].includes(name));
    if (extra.length > 0) {
      // 5.2: "MUST NOT put a User ID, an Agent ID, a Company's issuer, or anything else about the User or the Companies they use in a delegation."
      throw fail(
        "delegation.names-user",
        `carries ${extra.join(", ")}, which can name the User or a Company`,
        departure(ours("the delegation's claims"), ours("only iss, cnf, iat, exp, jti and nbf"), shown`also ${show.list(extra.map((name) => show.code(name)))}`, ours("Those can name the User or a Company"))
      );
    }
    this.#delegations.set(delegation, { clientId: client.clientId, jwk, exp: claims.exp });
    return jwk;
  }

  /**
   * 5.3: the Session header on a request to a resource, verified in order:
   * the client metadata, the delegation, the JWT's signature and claims,
   * `ath` against the access token, then the Session by `client_id` and
   * `sid`, started when new. Every failure is 400 `invalid_session`.
   */
  /** Operator key directories by URL, as fetched (5.3; Web Bot Auth 5.5). */
  readonly #operatorDirectories = new Map<string, Promise<{ keys: Record<string, unknown>[] } | null>>();

  /**
   * An operator signature, when a request carries one (5.3): an RFC 9421
   * signature in the Web Bot Auth profile, which this mock checks on its own
   * (not with the agent's code, so the two stay independent oracles). Its
   * absence is allowed (a SHOULD; "its absence does not make a Session JWT
   * invalid"); one that doesn't verify, or doesn't cover `poppy-session`, and
   * `authorization` when present, is recorded. Neither refuses the request:
   * the Session JWT is what authenticates it.
   */
  async #checkOperatorSignature(inbound: Inbound): Promise<void> {
    const headers = inbound.request.headers;
    const input = headers.get("Signature-Input");
    if (input === null) return;
    const subject = shown`the operator signature on ${requestAt(inbound)}`;
    const invalid = (expected: Shown, got: Shown) => this.violation("operator-signature.invalid", departure(subject, expected, got));
    const parsed = /^(\w+)=\(([^)]*)\)(;.*)$/.exec(input);
    const signature = parsed ? new RegExp(`^${parsed[1]}=:([^:]+):$`).exec(headers.get("Signature") ?? "") : null;
    const agent = parsed ? new RegExp(`^${parsed[1]}="([^"]+)"`).exec(headers.get("Signature-Agent") ?? "") : null;
    if (!parsed || !signature || !agent) return invalid(ours("Signature-Input, Signature and Signature-Agent under one label"), ours("headers that don't share one"));
    const [, label, list, params] = parsed;
    const items = list!.split(" ").filter(Boolean);
    const components = shown`components ${show.list(items.map((item) => show.name(item)))}`;
    const param = (name: string) => new RegExp(`;${name}=(?:"([^"]*)"|(\\d+))`).exec(params!)?.slice(1).find((v) => v !== undefined);
    if (param("tag") !== "web-bot-auth") return invalid(ours("tag web-bot-auth"), shown`tag ${show.value(param("tag"))}`);
    const now = Math.floor(Date.now() / 1000);
    if (!(Number(param("created")) <= now + 60 && Number(param("expires")) >= now)) return invalid(ours("now between its created and expires"), ours("a time outside them"));
    const covers = (id: string) => items.includes(`"${id}"`);
    if (!covers("poppy-session") || (headers.has("Authorization") && !covers("authorization"))) {
      this.violation("operator-signature.components", departure(subject, headers.has("Authorization") ? ours("components with poppy-session and authorization") : ours("components with poppy-session"), components));
    }
    if (!items.includes(`"signature-agent";key="${label}"`) || !(covers("@authority") || covers("@target-uri"))) return invalid(ours("components with @authority or @target-uri, and its Signature-Agent member"), components);
    const directoryUrl = `${new URL(agent[1]!).origin}/.well-known/http-message-signatures-directory`;
    let directory = this.#operatorDirectories.get(directoryUrl);
    if (!directory) {
      directory = this.#fetchAgent(directoryUrl).then(async (response) => (response.status === 200 ? ((await response.json()) as { keys: Record<string, unknown>[] }) : null)).catch(() => null);
      this.#operatorDirectories.set(directoryUrl, directory);
    }
    const jwk = (await directory)?.keys.find((key) => key.kid === param("keyid"));
    if (!jwk) return invalid(shown`a keyid in ${show.url(directoryUrl)}`, shown`keyid ${show.value(param("keyid"))}`);
    const lines: string[] = [];
    for (const item of items) {
      let value: string | null;
      if (item === '"@method"') value = inbound.request.method;
      else if (item === '"@authority"') value = inbound.url.host;
      else if (item === '"@path"') value = inbound.url.pathname;
      else if (item === '"@target-uri"') value = inbound.url.href;
      else if (item === `"signature-agent";key="${label}"`) value = `"${agent[1]}"`;
      else value = headers.get(item.replace(/^"|"$/g, ""));
      if (value === null) return invalid(ours("components the request has"), shown`${show.name(item)}, which it lacks`);
      lines.push(`${item}: ${value}`);
    }
    lines.push(`"@signature-params": (${list})${params}`);
    const key = await crypto.subtle.importKey("jwk", { kty: "OKP", crv: "Ed25519", x: jwk.x as string }, { name: "Ed25519" }, false, ["verify"]);
    const bytes = Uint8Array.from(atob(signature[1]!), (char) => char.charCodeAt(0));
    if (!(await crypto.subtle.verify({ name: "Ed25519" }, key, bytes, new TextEncoder().encode(lines.join("\n"))))) invalid(ours("a signature that verifies"), ours("one that doesn't"));
  }

  async verifySessionHeader(inbound: Inbound, accessToken: string | null): Promise<{ readonly client: ClientInfo; readonly session: Session }> {
    await this.#checkOperatorSignature(inbound);
    const where = requestAt(inbound);
    /** `part` of the Session header on this request, as a check's subject. */
    const on = (part: Shown): Shown => shown`${part} on ${where}`;
    /** Records `detail`, and refuses with `why` as the error_description. */
    const fail = (id: ViolationId, why: string, detail: Problem): HttpError => {
      this.violation(id, detail);
      return this.invalidSession(why);
    };
    const value = inbound.request.headers.get("Poppy-Session");
    if (!value) {
      throw accessToken !== null
        ? fail("session-jwt.missing-with-token", "an access token without the Session header", departure(on(ours("the request")), ours("a Poppy-Session header beside its access token"), ours("none")))
        : fail("session-jwt.missing", "no Poppy-Session header", departure(on(ours("the request")), ours("a Poppy-Session header"), ours("none")));
    }
    let header;
    let claims: JWTPayload;
    try {
      header = decodeProtectedHeader(value);
      claims = decodeJwt(value);
    } catch {
      throw fail("session-jwt.not-jwt", "Poppy-Session is not a JWT", departure(on(ours("Poppy-Session")), ours("a JWT"), ours("a value that doesn't decode as one")));
    }
    if (header.typ !== "poppy-session+jwt") {
      throw fail("session-jwt.typ", `typ is ${JSON.stringify(header.typ)}, not poppy-session+jwt`, departure(on(ours("the Session JWT's typ")), ours("poppy-session+jwt"), show.value(header.typ)));
    }
    if (header.alg !== "ES256") throw fail("session-jwt.alg", `alg ${String(header.alg)} is not ES256`, departure(on(ours("the Session JWT's alg")), ours("ES256"), show.value(header.alg)));
    if (typeof header.poppy_dlg !== "string") {
      throw fail("session-jwt.no-delegation", "no poppy_dlg delegation in the header", departure(on(ours("the Session JWT's poppy_dlg")), ours("a delegation, as a string"), show.kind(header.poppy_dlg)));
    }
    if (typeof claims.iss !== "string") throw fail("session-jwt.iss", "iss is missing", departure(on(ours("the Session JWT's iss")), ours("the client_id, as a string"), show.kind(claims.iss)));
    // 4.1: a refused Personal Agent gets `invalid_session` at a resource, as `invalid_client` at the authorization server.
    const registered = this.config.requireRegistration;
    if (registered && !registered.includes(claims.iss)) throw this.invalidSession("this Personal Agent is not accepted");
    let client: ClientInfo;
    try {
      client = await this.client(claims.iss);
    } catch (error) {
      if (error instanceof HttpError) throw this.invalidSession("the client metadata couldn't be used");
      throw error;
    }
    const jwk = await this.#verifyDelegation(client, header.poppy_dlg);
    if (header.kid !== (await calculateJwkThumbprint(jwk))) {
      throw fail("session-jwt.kid", "kid isn't the delegated key's JWK thumbprint", departure(on(ours("the Session JWT's kid")), ours("the delegated key's JWK thumbprint"), show.value(header.kid)));
    }
    try {
      await jwtVerify(value, await importJWK(jwk, "ES256"), { algorithms: ["ES256"], typ: "poppy-session+jwt" });
    } catch (cause) {
      const message = cause instanceof Error ? cause.message : String(cause);
      throw fail("session-jwt.signature", `signature: ${message}`, departure(on(ours("the Session JWT")), ours("a signature by the delegated key"), show.text(message)));
    }
    const delegation = this.#delegations.get(header.poppy_dlg)!;
    if (typeof claims.iat !== "number") throw fail("session-jwt.iat", "iat is missing", departure(on(ours("the Session JWT's iat")), ours("a number"), show.kind(claims.iat)));
    if (claims.iat > delegation.exp) {
      throw fail("session-jwt.after-delegation", "signed after its delegation expired", departure(on(ours("the Session JWT's iat")), ours("a time before its delegation's exp"), shown`one ${claims.iat - delegation.exp} s after it`));
    }
    if (Array.isArray(claims.aud) || claims.aud !== this.identifier) {
      const got = typeof claims.aud === "string" ? show.text(claims.aud, 200) : show.kind(claims.aud);
      throw fail("session-jwt.aud", `aud ${JSON.stringify(claims.aud)} isn't the Company's identifier ${this.identifier} as a single string`, departure(on(ours("the Session JWT's aud")), shown`the Company's identifier, ${show.text(this.identifier, 200)}, as a single string`, got));
    }
    if (claims.htm !== inbound.request.method) {
      throw fail("session-jwt.htm", `htm ${String(claims.htm)} isn't ${inbound.request.method}`, departure(on(ours("the Session JWT's htm")), shown`the request's method, ${show.value(inbound.request.method)}`, show.value(claims.htm)));
    }
    if (claims.htu !== `${inbound.url.origin}${inbound.url.pathname}`) {
      throw fail("session-jwt.htu", `htu ${String(claims.htu)} isn't this URL without its query`, departure(on(ours("the Session JWT's htu")), shown`the request URL without its query, ${show.url(`${inbound.url.origin}${inbound.url.pathname}`)}`, urlOrKind(claims.htu)));
    }
    // Session JWTs carry the agent's real time; the fake clock moves only request timing.
    if (Math.abs(Math.floor(Date.now() / 1000) - claims.iat) > SESSION_JWT_WINDOW + SKEW) {
      throw fail("session-jwt.iat", "iat is outside the acceptance window", departure(on(ours("the Session JWT's iat")), shown`a time within ${SESSION_JWT_WINDOW + SKEW} s of now`, offset(claims.iat, Math.floor(Date.now() / 1000))));
    }
    if (!this.freshJti("session-jwt", claims.jti)) throw this.invalidSession("jti missing or reused");
    if (typeof claims.sid !== "string" || !/^[A-Za-z0-9_-]{1,256}$/.test(claims.sid)) {
      throw fail("session-jwt.sid", "sid isn't 1 to 256 URL-safe characters", departure(on(ours("the Session JWT's sid")), ours("1 to 256 URL-safe characters"), show.value(claims.sid)));
    }
    if (typeof claims.sub !== "string" || claims.sub === "") {
      throw fail("session-jwt.sub", "sub (the User ID) is missing", departure(on(ours("the Session JWT's sub")), ours("the User ID, a non-empty string"), show.value(claims.sub)));
    }
    if ("agent_id" in claims && (typeof claims.agent_id !== "string" || claims.agent_id === "")) {
      throw fail("session-jwt.sub", "agent_id isn't a string", departure(on(ours("the Session JWT's agent_id")), ours("a non-empty string"), show.value(claims.agent_id)));
    }
    if (accessToken !== null) {
      if (claims.ath !== (await sha256b64(accessToken))) {
        throw fail("session-jwt.ath", "ath doesn't match the access token", departure(on(ours("the Session JWT's ath")), ours("the hash of the access token sent"), claims.ath === undefined ? ours("none") : ours("another value")));
      }
    } else if ("ath" in claims) {
      throw fail("session-jwt.ath-without-token", "ath without an access token", departure(on(ours("the Session JWT")), ours("no ath, with no access token sent"), ours("an ath")));
    }
    const thumbprint = header.kid;
    const first = this.delegatedKeyUsers.get(thumbprint);
    if (first === undefined) this.delegatedKeyUsers.set(thumbprint, `${client.clientId}|${claims.sub}`);
    else if (first !== `${client.clientId}|${claims.sub}`) {
      // 5.2: "MUST use each delegated key, and its delegation, for one User ID only."
      this.violation("delegation.key-shared", departure(shown`delegated key ${show.value(thumbprint)}`, ours("signatures for one User ID"), ours("one for another User ID")));
    }
    this.checkUserId(claims.sub);
    const agentId = typeof claims.agent_id === "string" ? claims.agent_id : null;
    const key = `${client.clientId}|${claims.sid}`;
    let session = this.sessionsBySid.get(key);
    if (!session) {
      session = { id: randomId("ses_", 8), sid: claims.sid, clientId: client.clientId, userId: claims.sub, agentId, account: null, boundAccount: null, grant: null, scope: [], ended: false };
      this.sessions.set(session.id, session);
      this.sessionsBySid.set(key, session);
    } else if (session.userId !== claims.sub || (session.agentId ?? null) !== agentId) {
      throw fail(
        "session-jwt.sub-changed",
        "a known sid with another User ID or Agent ID",
        departure(on(shown`Session ${show.value(claims.sid)}`), shown`the sub and agent_id it started with, ${show.value(session.userId)} and ${show.value(session.agentId ?? null)}`, shown`${show.value(claims.sub)} and ${show.value(agentId)}`)
      );
    }
    if (session.ended) throw this.sessionEnded("the Session has ended");
    this.#checkVersion(inbound, session, where);
    return { client, session };
  }

  /**
   * The Operations version a request may get operations under (Ops 2):
   * only with `operations` version 3 declared. Null: none.
   */
  operationsVersion(context: ResourceContext): "3" | null {
    return context.session.declaration?.declared.get("operations") === "3" ? "3" : null;
  }

  /**
   * `Poppy-Version` and `Poppy-Extensions` (3.4). A request without
   * `Poppy-Version`, or for a version the Company doesn't serve, gets
   * `version_unsupported`; the agent is at fault when it sent none, or one
   * the Company never listed. The values are fixed for a Session.
   */
  #checkVersion(inbound: Inbound, session: Session, where: Shown): void {
    const header = inbound.request.headers.get("Poppy-Version");
    const version = header ?? "";
    const extensions = inbound.request.headers.get("Poppy-Extensions") ?? "";
    for (const served of this.servedVersions) this.#listed.add(served);
    // 3.4: the agent declares the version it implements, compatible with the chosen one: 1.0 for a 1.1 document.
    if (header === null) this.violation("version.missing", departure(where, ours("a Poppy-Version header"), ours("none")));
    else if (![...this.#listed].some((listed) => compatible(listed, version))) {
      this.violation("version.unlisted", departure(shown`Poppy-Version on ${where}`, shown`a version compatible with one this Company listed: ${show.list([...this.#listed].map((listed) => show.code(listed)), "or")}`, show.code(header)));
    }
    if (!this.servedVersions.some((served) => compatible(served, version))) throw new HttpError(json({ error: "version_unsupported" }, 400, { "Cache-Control": "no-store" }));
    // The same RFC 9651 List however it is written: `"operations";v="3"` and `"operations"; v="3"` alike.
    if (session.declaration && (session.declaration.version !== version || extensionsKey(session.declaration.extensions) !== extensionsKey(extensions))) {
      this.violation(
        "version.changed-in-session",
        departure(
          shown`Poppy-Version and Poppy-Extensions on ${where}`,
          shown`what Session ${show.value(session.sid)} declared first, ${show.code(session.declaration.version)} with ${declaredExtensions(session.declaration.extensions)}`,
          shown`${show.code(version)} with ${declaredExtensions(extensions)}`
        )
      );
    }
    session.declaration ??= { version, extensions, declared: parseExtensions(extensions) };
  }

  /**
   * A resource request (5.3, 7). The Session header always; an access
   * token when signed in, with its DPoP proof when it is DPoP-bound. The
   * Session is signed in on this request when it carries a token for an
   * account, which it then keeps: a second account is refused (5.4).
   */
  async authorizeResource(inbound: Inbound, mcp = false): Promise<ResourceContext> {
    const queried = inbound.url.searchParams.get("access_token");
    // 5.6: tokens never come in a URL. A flawed Company takes one anyway, Session header or not.
    if (queried && this.flawed("accept-query-token")) {
      const token = this.accessTokens.get(queried);
      if (!token || token.expiresAt <= Date.now()) throw resourceError("Bearer", 401, "invalid_token");
      const { client, session } = await this.verifySessionHeader(inbound, null);
      return { token, session, client, signedIn: true, account: token.account, scope: token.scope };
    }
    const header = inbound.request.headers.get("Authorization");
    let token: AccessToken | null = null;
    let value: string | null = null;
    let scheme: "DPoP" | "Bearer" = this.config.dpopTokens ? "DPoP" : "Bearer";
    let given: string | null = null;
    if (header) {
      const [named, presented] = header.split(" ", 2) as [string, string | undefined];
      given = named;
      if (!presented || (given !== "Bearer" && given !== "DPoP")) throw resourceError(scheme, 401, "invalid_token");
      value = presented;
      token = this.accessTokens.get(presented) ?? null;
      scheme = token?.kind === "bearer" ? "Bearer" : "DPoP";
      if (!token || token.expiresAt <= Date.now() || (token.grant && this.#grantRevoked(token.grant))) {
        // Verify the Session header still, so a bad one is reported first (5.3).
        await this.verifySessionHeader(inbound, presented);
        throw resourceError(scheme, 401, "invalid_token");
      }
      if ((given === "DPoP") !== (token.kind === "dpop")) {
        this.violation("resource.bearer-scheme", departure(shown`the Authorization scheme on ${requestAt(inbound)}`, shown`${token.kind === "dpop" ? ours("DPoP") : ours("Bearer")}, the token's token_type`, show.code(given)));
        // A flawed Company takes a DPoP-bound token as Bearer, with no proof (RFC 9449 7.1 forbids it).
        if (!(given === "Bearer" && this.flawed("accept-bearer-scheme"))) throw resourceError(scheme, 401, "invalid_token");
      }
      // 4.5, 7: a token for one service only there, and an MCP server only takes its own. The conversation
      // endpoint on the API's host publishes no metadata of its own, so the default token works there (4.5).
      const conversations = inbound.url.pathname.startsWith(new URL(this.hosts.conversationsEndpoint).pathname);
      const resource = mcp ? this.hosts.mcpUrl : this.config.apiResource && inbound.url.origin === this.hosts.api && !conversations ? this.hosts.api : null;
      if (token.resource !== resource) {
        if (mcp) this.violation("mcp.wrong-token", departure(ours("the MCP request's access token"), shown`one issued for this MCP server, ${show.url(this.hosts.mcpUrl)}`, token.resource === null ? ours("one issued for no resource") : shown`one issued for ${show.url(token.resource)}`));
        throw resourceError(scheme, 401, "invalid_token", { headers: mcp ? { "WWW-Authenticate": `${scheme} error="invalid_token", resource_metadata="${new URL("/.well-known/oauth-protected-resource/mcp", this.hosts.mcpUrl).href}"` } : {} });
      }
    }
    const { client, session } = await this.verifySessionHeader(inbound, value);
    if (token && value) {
      if (token.clientId !== client.clientId) {
        // 5.3, step 3: the token was issued to the same client_id as iss. Sign-in names no User ID, so the token can't.
        this.violation("session-jwt.token-other-client", departure(ours("the access token"), shown`one issued to the Session JWT's iss, ${show.url(client.clientId)}`, shown`one issued to ${show.url(token.clientId)}`));
        throw this.invalidSession("the access token isn't this client's");
      }
      if (token.kind === "dpop" && given === "DPoP") {
        const jkt = await this.verifyDpop(inbound, value);
        if (jkt !== token.jkt) {
          this.violation("dpop.key-mismatch", departure(shown`the DPoP proof's key on ${requestAt(inbound)}`, ours("the key the token is bound to"), ours("another key")));
          if (!this.flawed("accept-other-key")) throw resourceError("DPoP", 401, "invalid_dpop_proof");
        }
      }
      if (session.boundAccount && session.boundAccount !== token.account) {
        // 5.4: "SHOULD start a new Session rather than use a second account in one Session"; the Company MAY refuse.
        this.violation("session.second-account", departure(shown`Session ${show.value(session.id)}`, shown`its one account, ${show.value(session.boundAccount)}`, shown`a second, ${show.value(token.account)}`));
        throw this.sessionEnded("this Session is for another account");
      }
      session.account = token.account;
      session.boundAccount = token.account;
      session.grant = token.grant;
      session.scope = [...token.scope];
    } else {
      session.account = null;
    }
    return { token, session, client, signedIn: token !== null, account: token?.account ?? null, scope: token?.scope ?? [] };
  }

  /** Whether the refresh token family `grant` was revoked: its access tokens are refused (RFC 7009 2.1). */
  #grantRevoked(grant: string): boolean {
    let any = false;
    for (const token of this.accountTokens.values()) {
      if (token.grant !== grant) continue;
      any = true;
      if (!token.revoked && !token.rotated) return false;
    }
    return any;
  }

  /** A challenge for the account (7: "No error code", 401, with the scopes needed), or `insufficient_scope`. */
  requireScopes(context: ResourceContext, needed: readonly string[], mcp = false): void {
    const schemes = mcp ? ["Bearer"] : this.config.dpopTokens ? ["DPoP", "Bearer"] : ["Bearer"];
    const scope = needed.join(" ");
    const metadata = mcp ? `, resource_metadata="${new URL("/.well-known/oauth-protected-resource/mcp", this.hosts.mcpUrl).href}"` : "";
    if (!context.signedIn) {
      throw new HttpError(json({}, 401, { "WWW-Authenticate": schemes.map((s) => `${s} scope="${scope}"${metadata}${s === "DPoP" ? ', algs="ES256"' : ""}`).join(", ") }));
    }
    if (!needed.every((entry) => context.scope.includes(entry))) {
      const scheme = context.token?.kind === "dpop" ? "DPoP" : "Bearer";
      throw new HttpError(json({ error: "insufficient_scope" }, 403, { "WWW-Authenticate": `${scheme} error="insufficient_scope", scope="${scope}"${metadata}` }));
    }
  }
}

/**
 * `Poppy-Extensions` (3.4): an RFC 9651 List of Strings, each with its
 * version as a String `v` parameter, as name → version. A value that fails
 * to parse declares no extensions (RFC 9651 4.2). The mock's own parser,
 * independent of the agent's serializer and the kit oracle's.
 */
export function parseExtensions(value: string): ReadonlyMap<string, string> {
  const declared = new Map<string, string>();
  if (value.trim() === "") return declared;
  // RFC 9651 3.1.2: a parameter is `";" *SP param-key [ "=" param-value ]`.
  const member = /^\s*"((?:[\x20\x21\x23-\x5b\x5d-\x7e]|\\["\\])*)"((?:; *[a-z*][a-z0-9_.*-]*(?:=(?:"(?:[\x20\x21\x23-\x5b\x5d-\x7e]|\\["\\])*"|[^;,\s]+))?)*)\s*(?:,|$)/;
  let rest = value;
  while (rest.trim() !== "") {
    const match = member.exec(rest);
    if (!match) return new Map();
    const version = /; *v="([^"]*)"/.exec(match[2]!)?.[1];
    if (version === undefined) return new Map();
    declared.set(match[1]!.replace(/\\(["\\])/g, "$1"), version);
    rest = rest.slice(match[0].length);
    if (match[0].trimEnd().endsWith(",") && rest.trim() === "") return new Map();
  }
  return declared;
}

/** A `Poppy-Extensions` value to compare with another: its parsed members, or the text when it doesn't parse. */
function extensionsKey(value: string): string {
  const declared = parseExtensions(value);
  if (declared.size === 0 && value.trim() !== "") return `text:${value}`;
  return JSON.stringify([...declared].sort(([a], [b]) => (a < b ? -1 : a > b ? 1 : 0)));
}
