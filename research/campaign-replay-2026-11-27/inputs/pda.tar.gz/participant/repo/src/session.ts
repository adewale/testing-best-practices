import { base64url, fromBase64url } from "./base64url";
import type { Provider } from "./config";
import { ours, ProblemError, type Problem } from "./diagnostic";

/** A request without a valid session. */
export class AuthError extends ProblemError {
  override name = "AuthError";
  constructor(problem: Problem) {
    super(problem);
  }
}

export type Identity = {
  readonly provider: Provider;
  /** The provider's stable user id: Google's `sub`, GitHub's numeric id. */
  readonly sub: string;
  readonly email: string | null;
  /** Google Workspace domain (the ID token's `hd`); null for personal Google accounts and GitHub. */
  readonly domain: string | null;
};

type SessionPayload = Identity & {
  /** Millisecond issuance for this app's signed cookie, not a JWT NumericDate. */
  readonly iat?: number;
  /** Random per-login identifier; revocation is held by the person's agent. */
  readonly sid: string;
  /** Expiry, in seconds since the epoch. */
  readonly exp: number;
};

export type BrowserIdentity = Identity & { readonly sessionId: string; readonly sessionExpiresAt: number; readonly sessionCreatedAt?: number };

/** `__Host-` pins the cookie to this origin: Secure, Path=/, no Domain. */
export const SESSION_COOKIE = "__Host-session";
export const SESSION_TTL_SECONDS = 30 * 24 * 60 * 60;

const encoder = new TextEncoder();

async function hmacKey(secret: string): Promise<CryptoKey> {
  return crypto.subtle.importKey(
    "raw",
    encoder.encode(secret),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign", "verify"]
  );
}

/** `<payload>.<signature>`, both base64url; HMAC-SHA256 over the payload. */
export async function sign(value: unknown, secret: string): Promise<string> {
  const body = base64url(encoder.encode(JSON.stringify(value)));
  const signature = await crypto.subtle.sign(
    "HMAC",
    await hmacKey(secret),
    encoder.encode(body)
  );
  return `${body}.${base64url(new Uint8Array(signature))}`;
}

/** The signed value, or null if the signature does not match. */
export async function unsign<T>(token: string, secret: string): Promise<T | null> {
  const [body, signature, extra] = token.split(".");
  if (!body || !signature || extra !== undefined) return null;
  try {
    const valid = await crypto.subtle.verify(
      "HMAC",
      await hmacKey(secret),
      fromBase64url(signature),
      encoder.encode(body)
    );
    if (!valid) return null;
    return JSON.parse(new TextDecoder().decode(fromBase64url(body))) as T;
  } catch {
    return null;
  }
}

export function readCookie(request: Request, name: string): string | null {
  const header = request.headers.get("Cookie");
  if (!header) return null;
  for (const part of header.split(";")) {
    const index = part.indexOf("=");
    if (index === -1) continue;
    if (part.slice(0, index).trim() === name) {
      return part.slice(index + 1).trim();
    }
  }
  return null;
}

/** A `Set-Cookie` value: HttpOnly, Secure, SameSite=Lax. */
export function cookie(
  name: string,
  value: string,
  options: { maxAge: number; path?: string }
): string {
  return [
    `${name}=${value}`,
    `Path=${options.path ?? "/"}`,
    `Max-Age=${options.maxAge}`,
    "HttpOnly",
    "Secure",
    "SameSite=Lax"
  ].join("; ");
}

/** The session cookie for a freshly signed-in person. */
export async function createSession(
  identity: Identity,
  secret: string,
  now = Date.now()
): Promise<string> {
  const payload: SessionPayload = {
    iat: now,
    sid: crypto.randomUUID(),
    provider: identity.provider,
    sub: identity.sub,
    email: identity.email,
    domain: identity.domain,
    exp: Math.floor(now / 1000) + SESSION_TTL_SECONDS
  };
  return cookie(SESSION_COOKIE, await sign(payload, secret), {
    maxAge: SESSION_TTL_SECONDS
  });
}

export function clearSession(): string {
  return cookie(SESSION_COOKIE, "", { maxAge: 0 });
}

/** The signed-in person, from the session cookie; anything else is an `AuthError`. */
export async function verifySession(
  request: Request,
  secret: string
): Promise<BrowserIdentity> {
  const token = readCookie(request, SESSION_COOKIE);
  if (!token) throw new AuthError(ours("No session cookie"));
  const payload = await unsign<SessionPayload>(token, secret);
  if (!payload) throw new AuthError(ours("Bad session signature"));
  if (
    (payload.provider !== "google" && payload.provider !== "github") ||
    typeof payload.sub !== "string" ||
    payload.sub === "" ||
    typeof payload.exp !== "number" || !Number.isSafeInteger(payload.exp) ||
    typeof payload.sid !== "string" || !/^[0-9a-f-]{36}$/.test(payload.sid)
    || (payload.iat !== undefined && (!Number.isSafeInteger(payload.iat) || payload.iat > Date.now()))
  ) {
    throw new AuthError(ours("Malformed session"));
  }
  if (payload.exp * 1000 <= Date.now()) throw new AuthError(ours("Session expired"));
  return {
    sessionCreatedAt: payload.iat ?? payload.exp * 1000 - SESSION_TTL_SECONDS * 1000,
    sessionId: payload.sid,
    sessionExpiresAt: payload.exp * 1000,
    provider: payload.provider,
    sub: payload.sub,
    email: typeof payload.email === "string" ? payload.email : null,
    domain: typeof payload.domain === "string" ? payload.domain : null
  };
}

/** The person's Durable Object name: hex SHA-256 of `<provider>:<sub>`. */
export async function agentNameFor(
  identity: Pick<Identity, "provider" | "sub">
): Promise<string> {
  const digest = await crypto.subtle.digest(
    "SHA-256",
    encoder.encode(`${identity.provider}:${identity.sub}`)
  );
  return [...new Uint8Array(digest)]
    .map((byte) => byte.toString(16).padStart(2, "0"))
    .join("");
}

export { base64url };
