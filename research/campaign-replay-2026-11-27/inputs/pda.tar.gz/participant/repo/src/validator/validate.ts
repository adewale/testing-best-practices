import { domainFromInput } from "../domain.ts";
import { compatibleVersions, protocolRevision } from "../poppy/protocol-version.ts";
/**
 * The validator's entry points. The same functions back the library, the
 * CLI, the HTTP endpoint and the form, and our own Poppy client uses
 * `validateCompany` to decide what it will ingest.
 */
import { departure, ours, show, shown, withoutStop, type Shown } from "../diagnostic.ts";
import { fetchDocument, metadataUrl, type Fetched, type IdentifiedFetcher } from "./fetch.ts";
import { parseJson } from "./json.ts";
import { refFor } from "./messages.ts";
import { Checker, isHostname, isObject, type DocumentKind, type Message } from "./primitives.ts";
import { pointer } from "./json.ts";
import { LATEST, PROFILES, profileForVersion } from "./profiles/index.ts";
import type { PoppyFacts, Profile } from "./profiles/profile.ts";

// 1.1.0: who answered a fetch is reported apart from what the Company served, so a 520, a bot refusal or a 429 is http-failed, no longer http-status.
// 1.2.0: a web page where a document should be is http-web-page, no longer json-syntax, and an unsettled issuer is noted (prm-unsettled).
// 1.3.0: every error and warning but a fact says what was expected and what was got, in its text and as the message's expected and got.
// 1.4.0: a departure also carries its subject and, when it has one, its detail, so a reader can show each part on its own.
export const VALIDATOR = { name: "poppy-validator", version: "1.4.0" } as const;

/**
 * The validator's name, for a Company's logs and bot rules, with where to read
 * about it: the hosted validator gives its own page, so another deployment
 * doesn't point Companies at ours, and the CLI gives its source project. The
 * library sends no name of its own, because the agent's discovery fetches
 * through it too and names itself (`withUserAgent` in fetch.ts).
 */
export function validatorUserAgent(about: string): string {
  return `PoppyValidator/${VALIDATOR.version} (+${about})`;
}

/**
 * valid: no errors. invalid: an error, which is a MUST, an RFC's MUST or a
 * normative statement without a key word broken (docs/conformance-levels.md).
 * indeterminate: fetching failed or a resource allowance prevented checks.
 * Limits are implementation choices informed by the Guides.
 */
export type Outcome = "valid" | "invalid" | "indeterminate";

export type DocumentResult = {
  readonly kind: DocumentKind;
  readonly url?: string;
  readonly finalUrl?: string;
  readonly status?: number;
  readonly contentType?: string;
  readonly maxAgeSeconds?: number | null;
  /** The parsed document, when it parsed. */
  readonly value?: unknown;
};

/** A check that needs context the input didn't give, such as the URL a document came from. */
export type Skipped = { readonly check: string; readonly reason: string };

export type Report = {
  readonly outputVersion: 1;
  readonly validator: typeof VALIDATOR;
  readonly outcome: Outcome;
  /** The protocol version the documents were checked against, such as "Draft 0.4". */
  readonly checkedAgainst: string;
  readonly protocolVersion: string;
  readonly specificationRevision: string;
  readonly documents: readonly DocumentResult[];
  readonly counts: { readonly error: number; readonly warning: number; readonly info: number };
  /**
   * Whether our own client refuses these documents, or would if it read
   * them (it reads only a Company's): a message that `refuses` (every error
   * but those the draft tells a reader to tolerate, and the warnings that
   * guard against hostile documents), or a document that couldn't be
   * checked. Separate from `outcome`, which is about the draft.
   */
  readonly refused: boolean;
  readonly messages: readonly Message[];
  readonly skipped: readonly Skipped[];
};

/** Messages after which the document wasn't fetched or read, so nothing in it was checked. */
const UNREACHABLE = new Set(["http-failed", "http-status", "http-web-page", "http-non-public-host", "http-non-public-address", "http-too-many-redirects", "http-redirect-not-allowed", "http-too-large", "json-resource-limit"]);

function report(profile: Profile, documents: DocumentResult[], checkers: Checker[], skipped: Skipped[]): Report {
  // Each link goes to the pages of the version the documents were checked against.
  const messages = checkers.flatMap((c) => c.messages).map((m) => ({ ...m, ref: refFor(m.ref, profile.version) }));
  const count = (severity: Message["severity"]) => messages.filter((m) => m.severity === severity).length;
  const unreachable = messages.some((m) => UNREACHABLE.has(m.id));
  const outcome: Outcome = unreachable
    ? "indeterminate"
    : count("error") > 0
      ? "invalid"
      : "valid";
  return {
    outputVersion: 1,
    validator: VALIDATOR,
    outcome,
    checkedAgainst: profile.name,
    protocolVersion: profile.version,
    specificationRevision: protocolRevision(profile.version)!, // Profiles only contain supported versions.
    documents,
    counts: { error: count("error"), warning: count("warning"), info: count("info") },
    refused: unreachable || messages.some((m) => m.refuses),
    messages,
    skipped
  };
}

/** Parse text into the checker's document; undefined if parsing is refused. */
function parse(c: Checker, text: string): unknown {
  const parsed = parseJson(text);
  if (!parsed.ok) {
    const { line, column } = parsed.position;
    c.report(parsed.resourceLimit ? "json-resource-limit" : "json-syntax", "", departure(shown`line ${line}, column ${column}`, parsed.expected, parsed.got), undefined, parsed.position);
    return undefined;
  }
  c.usePositions(parsed.positions);
  if (parsed.bom) c.report("json-bom", "", departure(ours("the document"), ours("JSON text without a byte order mark"), ours("one at the start")));
  for (const duplicate of parsed.duplicates) {
    c.report("json-duplicate-member", duplicate.pointer, departure(show.path(duplicate.pointer.slice(0, duplicate.pointer.lastIndexOf("/"))), ours("each member name once"), shown`${show.value(duplicate.name)} twice`), undefined, duplicate.position);
  }
  return parsed.value;
}

/**
 * The profile for a poppy.json's `protocol_version`, or undefined when its
 * wire version is unsupported (then nothing else is checked: the rules differ).
 */
function profileFor(c: Checker, doc: unknown): Profile | undefined {
  if (!isObject(doc) || !("protocol_version" in doc)) {
    if (isObject(doc)) c.report("missing-member", "/protocol_version", departure(ours("protocol_version"), ours('a version, such as "1.0"'), ours("none")));
    return LATEST;
  }
  const version = doc.protocol_version;
  const match = typeof version === "string" ? /^(0|[1-9]\d*)\.(0|[1-9]\d*)$/.exec(version) : null;
  if (!match) {
    c.report("version-format", "/protocol_version", departure(ours("protocol_version"), ours('major.minor, like "1.0"'), show.value(version)));
    return LATEST;
  }
  const profile = profileForVersion(version as string);
  if (!profile) {
    const known = show.list(PROFILES.map((p) => show.code(p.version)), "or");
    c.report(Number(match[1]) === 0 ? "version-unsupported" : "version-unsupported-major", "/protocol_version", departure(ours("protocol_version"), shown`a version this validator supports (${known})`, show.value(version)));
    return undefined;
  }
  newerMinor(c, version as string, profile);
  return profile;
}

/** From 1.0, a newer minor version is checked with its major version's newest rules we know (3.4). */
function newerMinor(c: Checker, version: string, profile: Profile): void {
  if (profile.version !== version) {
    const rules = show.code(profile.version);
    c.report("version-newer-minor", "/protocol_version", shown`poppy.json is protocol version ${show.code(version)}; it is checked with ${rules}'s rules, as a ${rules} Personal Agent uses it`);
  }
}

function documentResult(kind: DocumentKind, fetched: Fetched | undefined, value: unknown): DocumentResult {
  return {
    kind,
    ...(fetched
      ? {
          url: fetched.url,
          finalUrl: fetched.finalUrl,
          ...(fetched.status !== undefined ? { status: fetched.status } : {}),
          ...(fetched.contentType ? { contentType: fetched.contentType } : {}),
          maxAgeSeconds: fetched.maxAgeSeconds
        }
      : {}),
    ...(value !== undefined ? { value } : {})
  };
}

export type TextOptions = {
  /** poppy.json: the domain whose well-known URL served it. */
  readonly domain?: string;
  /** client-metadata: the URL it was fetched from. */
  readonly fetchedFrom?: string;
  /** Documents without their own version: which protocol version to check against; the default is the newest, 1.0 (LATEST). */
  readonly protocolVersion?: string;
};

function profileByOption(option: string | undefined, c: Checker): Profile | undefined {
  const profile = option === undefined ? LATEST : profileForVersion(option);
  if (!profile) c.report("version-unsupported", "", departure(ours("the protocol version asked for"), shown`one this validator supports (${show.list(PROFILES.map((p) => show.code(p.version)), "or")})`, show.value(option)));
  return profile;
}

/** Validate one pasted document. Checks that need other documents or a URL are listed as skipped. */
export function validateText(kind: DocumentKind, text: string, options: TextOptions = {}): Report {
  const c = new Checker(kind);
  if (new TextEncoder().encode(text).byteLength > 100_000) c.report("http-too-large", "", departure(ours("the document"), ours("at most 100 KB"), ours("more"), ours("Agents won't read it")));
  const value = parse(c, text);
  const skipped: Skipped[] = [];
  let profile = profileByOption(options.protocolVersion, c);
  if (value !== undefined && profile) {
    if (kind === "poppy") {
      const chosen = profileFor(c, value);
      if (chosen) {
        profile = chosen;
        profile.poppy(c, value, { ...(options.domain ? { requestedDomain: options.domain } : {}) });
      }
      if (!options.domain) skipped.push({ check: "organization.domain is the host that serves the document", reason: "No domain given." });
      skipped.push({ check: "The domain's protected resource metadata and the issuer's OAuth metadata", reason: "Validate by domain to fetch them." });
    } else if (kind === "oauth-metadata") {
      profile.oauthMetadata(c, value, undefined);
      skipped.push({ check: "issuer is the one the domain names, protected_resources includes the domain, scopes are described", reason: "Needs the poppy.json; validate by domain." });
    } else if (kind === "client-metadata") {
      profile.clientMetadata(c, value, { ...(options.fetchedFrom ? { fetchedFrom: options.fetchedFrom } : {}) });
      if (!options.fetchedFrom) skipped.push({ check: "client_id equals the URL fetched", reason: "No URL given." });
      skipped.push({ check: "The key set at jwks_uri", reason: "Validate by URL to fetch it." });
    } else if (kind === "protected-resource") {
      if (profile.protectedResource(c, value, { signIn: { direct: false, device: false, mediated: false } }) === null) {
        skipped.push({ check: "Nothing in poppy.json offers sign-in, as a Company without an issuer must not", reason: "Needs the poppy.json; validate by domain." });
      }
      skipped.push({ check: "resource is https://{organization.domain}; auth.issuer is one of authorization_servers", reason: "Needs the poppy.json; validate by domain." });
    } else {
      profile.jwks(c, value);
    }
  }
  return report(profile ?? LATEST, [documentResult(kind, undefined, value)], [c], skipped);
}

export type CompanyReport = Report & {
  /** The validated documents, for a client that ingests them. */
  readonly poppy?: unknown;
  readonly metadata?: unknown;
  /** The domain's protected resource metadata (3.2). */
  readonly protectedResource?: unknown;
  /** The issuer the documents settled on: the one the domain's protected resource metadata names. */
  readonly issuer?: string;
  /**
   * The Company's identifier (3.2): its issuer, or `https://{organization.domain}`
   * when the domain's protected resource metadata establishes it has none.
   * Unset when discovery didn't settle it.
   */
  readonly identifier?: string;
  /** The domain's protected resource metadata says the Company has no issuer (3.2): signed-out Sessions only. */
  readonly issuerless?: true;
  /** The shorter of the two documents' cache lifetimes, unbounded; null if neither said. */
  readonly maxAgeSeconds: number | null;
};

export { domainFromInput } from "../domain.ts";

/** Who asks for discovery, and so which versions may be chosen. */
export type CompanyOptions = {
  /** The protocol versions the caller speaks. By default, every version the validator knows. */
  readonly versions?: readonly string[];
};

/** `major.minor`, newest first. */
function newestFirst(a: string, b: string): number {
  const [aMajor, aMinor] = a.split(".").map(Number) as [number, number];
  const [bMajor, bMinor] = b.split(".").map(Number) as [number, number];
  return bMajor - aMajor || bMinor - aMinor;
}

const VERSION = /^(0|[1-9]\d*)\.(0|[1-9]\d*)$/;

/**
 * `supported_versions` (3.4), read in any version's poppy.json: each other
 * version the Company serves, by the URL of its document, which MUST be
 * HTTPS on the host that served poppy.json. An entry agents can't use is
 * reported and left out, as if that version weren't listed (readings.md).
 */
function linkedVersions(c: Checker, doc: Record<string, unknown>, own: unknown, host: string): Map<string, string> {
  const linked = new Map<string, string>();
  if (!("supported_versions" in doc)) return linked;
  const map = doc.supported_versions;
  if (!isObject(map)) {
    c.report("supported-version-unusable", "/supported_versions", departure(ours("supported_versions"), ours("an object mapping each version to its document's URL"), show.kind(map)));
    return linked;
  }
  for (const [version, url] of Object.entries(map)) {
    const at = pointer("/supported_versions", version);
    const named = show.value(version);
    const skip = ours("Agents skip it");
    const problem = !VERSION.test(version)
      ? departure(ours("a supported_versions key"), ours("a version as major.minor"), named, skip)
      : version === own
        ? departure(shown`${named} in supported_versions`, ours("a version other than this document's own protocol_version"), ours("the same version"), skip)
        : typeof url !== "string" || !URL.canParse(url)
          ? departure(shown`${named}'s document`, ours("a URL"), show.value(url), skip)
          : new URL(url).protocol !== "https:"
            ? departure(shown`${named}'s document`, ours("an https URL"), show.url(url), skip)
            : new URL(url).hostname.toLowerCase() !== host.toLowerCase()
              ? departure(shown`${named}'s document`, shown`a URL on ${show.name(host)}, which served poppy.json`, shown`one on ${show.name(new URL(url).hostname)}`, skip)
              : undefined;
    if (problem) c.report("supported-version-unusable", at, problem);
    else linked.set(version, url as string);
  }
  return linked;
}

/**
 * Discovery for one domain (spec 3): fetch poppy.json, choose the newest
 * version the caller speaks among its `protocol_version` and
 * `supported_versions` (3.4), fetch that version's document when it is
 * another one, and check it with that version's rules; then the domain's
 * protected resource metadata, which names the issuer, and the issuer's
 * OAuth metadata, checked against the chosen document (3.2).
 */
export async function validateCompany(fetcher: IdentifiedFetcher, domain: string, options: CompanyOptions = {}): Promise<CompanyReport> {
  const requested = domainFromInput(domain);
  const poppyChecker = new Checker("poppy");
  const checkers = [poppyChecker];
  const documents: DocumentResult[] = [];
  if (!isHostname(requested)) {
    poppyChecker.report("domain-invalid", "", departure(ours("the domain asked for"), ours("a domain name"), show.value(domain)));
    return { ...report(LATEST, documents, checkers, []), maxAgeSeconds: null };
  }
  const served = await fetchDocument(fetcher, `https://${requested}/.well-known/poppy.json`, poppyChecker);
  const root = served.text !== undefined ? parse(poppyChecker, served.text) : undefined;
  documents.push(documentResult("poppy", served, root));
  const servedHost = new URL(served.finalUrl).hostname;
  let profile = LATEST;
  let facts: PoppyFacts | undefined;
  let metadata: unknown;
  let poppy = root;
  let version: string | undefined;
  const ages = [served.maxAgeSeconds];
  if (root !== undefined) {
    const own = isObject(root) ? root.protocol_version : undefined;
    const linked = isObject(root) ? linkedVersions(poppyChecker, root, own, servedHost) : new Map<string, string>();
    const speaks = options.versions ?? PROFILES.map((known) => known.version);
    // 3.4: a version compatible with one the caller speaks, checked with that version's rules.
    const spoken = (candidate: string) => speaks.some((version) => compatibleVersions(version, candidate));
    const candidates = [...(typeof own === "string" ? [own] : []), ...linked.keys()]
      .filter((candidate) => VERSION.test(candidate) && spoken(candidate) && profileForVersion(candidate))
      .sort(newestFirst);
    for (const candidate of candidates) {
      if (candidate === own) {
        version = candidate;
        break;
      }
      const url = linked.get(candidate)!;
      const at = pointer("/supported_versions", candidate);
      const linkedChecker = new Checker("poppy");
      // 3.4: never follow a redirect from a linked document.
      const linkedFetched = await fetchDocument(fetcher, url, linkedChecker, { followRedirects: false });
      if (linkedFetched.status !== undefined && linkedFetched.status >= 300 && linkedFetched.status < 400) {
        poppyChecker.report("supported-version-unusable", at, departure(shown`${show.value(candidate)}'s document at ${show.url(url)}`, ours("the document, served at that URL (3.4)"), shown`a redirect (${show.status(linkedFetched.status)})`, ours("Agents skip it")));
        continue;
      }
      checkers.push(linkedChecker);
      const doc = linkedFetched.text !== undefined ? parse(linkedChecker, linkedFetched.text) : undefined;
      documents.push(documentResult("poppy", linkedFetched, doc));
      ages.push(linkedFetched.maxAgeSeconds);
      poppy = doc;
      version = candidate;
      if (doc === undefined) break;
      if (isObject(doc) && doc.protocol_version !== candidate) {
        linkedChecker.report("linked-document-version", "/protocol_version", departure(shown`the protocol_version of the document listed for ${show.value(candidate)}`, show.value(candidate), show.value(doc.protocol_version)));
        version = undefined;
        break;
      }
      if (isObject(doc) && "supported_versions" in doc) {
        linkedChecker.report("linked-document-supported-versions", "/supported_versions", departure(ours("the linked document"), ours("no supported_versions, which only poppy.json lists"), ours("one"), ours("Agents ignore it here")));
      }
      const rootDomain = isObject(root) && isObject(root.organization) ? root.organization.domain : undefined;
      const linkedDomain = isObject(doc) && isObject(doc.organization) ? doc.organization.domain : undefined;
      if (typeof rootDomain === "string" && typeof linkedDomain === "string" && rootDomain.toLowerCase() !== linkedDomain.toLowerCase()) {
        linkedChecker.report("linked-document-domain", "/organization/domain", departure(shown`the ${show.value(candidate)} document's organization.domain`, shown`${show.value(rootDomain)}, as in poppy.json`, show.value(linkedDomain)));
      }
      profile = profileForVersion(candidate)!;
      newerMinor(linkedChecker, candidate, profile);
      facts = profile.poppy(linkedChecker, doc, { requestedDomain: servedHost });
      break;
    }
    if (version === undefined && poppy === root) {
      // Nothing the caller speaks: poppy.json's own version decides what is reported.
      const chosen = profileFor(poppyChecker, root);
      if (chosen && typeof own === "string" && !spoken(own)) {
        poppyChecker.report("version-unsupported", "/protocol_version", departure(ours("poppy.json's versions"), shown`one this agent speaks (${show.list(speaks.map((v) => show.code(v)), "or")})`, shown`${show.value(own)}, and no other usable one`));
      } else if (chosen) {
        profile = chosen;
        facts = profile.poppy(poppyChecker, root, { requestedDomain: servedHost });
      }
    } else if (version !== undefined && version === own) {
      profile = profileForVersion(version)!;
      newerMinor(poppyChecker, version, profile);
      facts = profile.poppy(poppyChecker, root, { requestedDomain: servedHost });
    }
  }
  let protectedResource: unknown;
  let issuerless = false;
  if (facts) {
    // A redirect may change the host, never the path (3).
    const final = new URL(served.finalUrl);
    if (final.pathname !== "/.well-known/poppy.json" || final.search !== "") {
      poppyChecker.report("poppy-redirect-path", "", departure(ours("where the redirects led"), ours("/.well-known/poppy.json, on any host, with no query"), show.url(final)));
    }
    // The issuer is the one the domain's protected resource metadata names (3.2).
    const named = facts.issuer;
    facts.issuer = undefined;
    if (facts.domain && (facts.usesSessions || facts.needsIssuer || named !== undefined)) {
      const prmChecker = new Checker("protected-resource");
      checkers.push(prmChecker);
      // 3.2: a 404 means the Company has no issuer; any other failure settles nothing.
      const prmFetched = await fetchDocument(fetcher, `https://${facts.domain.toLowerCase()}/.well-known/oauth-protected-resource`, prmChecker, {
        notFoundIsAnswer: true,
        expected: ours("HTTP 404 (no issuer), or protected resource metadata as application/json")
      });
      protectedResource = prmFetched.text !== undefined ? parse(prmChecker, prmFetched.text) : undefined;
      documents.push(documentResult("protected-resource", prmFetched, protectedResource));
      // 3.2, 4.7: it may list the scopes agents can request, as well as or instead of the issuer.
      if (isObject(protectedResource) && Array.isArray(protectedResource.scopes_supported)) {
        facts.resourceScopes = protectedResource.scopes_supported.filter((scope): scope is string => typeof scope === "string");
      }
      ages.push(prmFetched.maxAgeSeconds);
      const context = { ...facts, ...(named !== undefined ? { issuer: named } : {}) };
      if (prmFetched.status === 404 && prmFetched.text === undefined) {
        profile.noIssuer(prmChecker, context, "not-found");
        issuerless = true;
      } else if (protectedResource !== undefined) {
        const settled = profile.protectedResource(prmChecker, protectedResource, context);
        if (settled === null) issuerless = true;
        else facts.issuer = settled;
      } else {
        // 3.2: nothing that parsed as metadata, and not a 404: what came back is reported above; this is what it means to an agent.
        prmChecker.report(
          "prm-unsettled",
          "",
          shown`Agents can't tell from ${show.url(prmFetched.url, prmFetched.url)} whether the Company has an OAuth issuer, so they don't fall back to ${show.url(`https://${facts.domain.toLowerCase()}`, `https://${facts.domain.toLowerCase()}`)} as its identifier and can't ${facts.usesSessions ? ours("open Sessions with it") : ours("sign in with it")}`
        );
      }
    }
  }
  if (facts?.issuer) {
    const metadataChecker = new Checker("oauth-metadata");
    checkers.push(metadataChecker);
    const metaFetched = await fetchDocument(fetcher, metadataUrl(facts.issuer), metadataChecker);
    metadata = metaFetched.text !== undefined ? parse(metadataChecker, metaFetched.text) : undefined;
    documents.push(documentResult("oauth-metadata", metaFetched, metadata));
    ages.push(metaFetched.maxAgeSeconds);
    if (metadata !== undefined) profile.oauthMetadata(metadataChecker, metadata, facts);
  }
  const known = ages.filter((age): age is number => age !== null);
  return {
    ...report(profile, documents, checkers, []),
    ...(poppy !== undefined ? { poppy } : {}),
    ...(metadata !== undefined ? { metadata } : {}),
    ...(protectedResource !== undefined ? { protectedResource } : {}),
    ...(facts?.issuer ? { issuer: facts.issuer, identifier: facts.issuer } : {}),
    ...(issuerless && facts?.domain ? { issuerless: true as const, identifier: `https://${facts.domain.toLowerCase()}` } : {}),
    maxAgeSeconds: known.length ? Math.min(...known) : null
  };
}

/** A Personal Agent's client metadata at its client_id URL, and its key set (spec 4.1). */
export async function validateClient(fetcher: IdentifiedFetcher, url: string, options: TextOptions = {}): Promise<Report> {
  const c = new Checker("client-metadata");
  const selected = profileByOption(options.protocolVersion, c);
  const profile = selected ?? LATEST;
  if (!selected) return report(profile, [], [c], []);
  const checkers = [c];
  const documents: DocumentResult[] = [];
  // Companies fetch client_id without following redirects (Guides, "Verifying personal agents").
  const fetched = await fetchDocument(fetcher, url, c, { followRedirects: false });
  const value = fetched.text !== undefined ? parse(c, fetched.text) : undefined;
  documents.push(documentResult("client-metadata", fetched, value));
  if (value !== undefined) {
    const facts = profile.clientMetadata(c, value, { fetchedFrom: url });
    if (facts.jwksUri) {
      const keys = new Checker("jwks");
      checkers.push(keys);
      const keysFetched = await fetchDocument(fetcher, facts.jwksUri, keys);
      const jwks = keysFetched.text !== undefined ? parse(keys, keysFetched.text) : undefined;
      documents.push(documentResult("jwks", keysFetched, jwks));
      if (jwks !== undefined) profile.jwks(keys, jwks);
    }
  }
  return report(profile, documents, checkers, []);
}

/**
 * Validate whatever is at a URL or domain: a bare domain or a poppy.json URL
 * checks the Company; anything else is taken as a client_id URL.
 */
export async function validateTarget(fetcher: IdentifiedFetcher, target: string, options: TextOptions = {}): Promise<Report> {
  const trimmed = target.trim();
  if (!/^https?:\/\//i.test(trimmed)) return validateCompany(fetcher, trimmed);
  const url = new URL(trimmed);
  if (url.pathname === "/.well-known/poppy.json" || url.pathname === "/") return validateCompany(fetcher, url.hostname);
  if (url.pathname.startsWith("/.well-known/oauth-authorization-server")) {
    const c = new Checker("oauth-metadata");
    const profile = profileByOption(options.protocolVersion, c);
    if (!profile) return report(LATEST, [], [c], []);
    const fetched = await fetchDocument(fetcher, url.href, c);
    const value = fetched.text !== undefined ? parse(c, fetched.text) : undefined;
    if (value !== undefined) profile.oauthMetadata(c, value, undefined);
    return report(profile, [documentResult("oauth-metadata", fetched, value)], [c], [
      { check: "issuer is the one the domain names, protected_resources includes the domain, scopes are described", reason: "Validate the Company's domain to check these." }
    ]);
  }
  return validateClient(fetcher, url.href, options);
}

/** One line per message our client refuses the documents over (every error but the tolerated ones, and the refusing warnings), for exceptions and logs. */
export function summarize(result: Report, limit = 3): Shown {
  const errors = result.messages.filter((m) => m.refuses);
  const said = show.join(errors.slice(0, limit).map((m) => withoutStop(m.text)));
  return errors.length > limit ? shown`${said} (and ${errors.length - limit} more)` : said;
}
