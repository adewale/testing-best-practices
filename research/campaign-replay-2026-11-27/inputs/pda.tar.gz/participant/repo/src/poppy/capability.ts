import { LifecycleCapability, type LifecycleJobContext, type LifecycleJobOutcome } from "agents/lifecycle";
import { code, currentEvent, id, literal, origin, plainUnits, recordCard, reportError, type Fields, type Units } from "../log";
import { buildActivity } from "./activity";
import { apiOperationFor } from "./apis";
import { handoverStart, type PoppyBrowser } from "./browser";
import { endChangedHandovers, endControl, heartbeat, liveView, takeControl, type HandoverLauncher } from "./handover";
import { PoppyClient, PoppyError, type JobName, type PoppyHost } from "./client";
import {
  closeConversation,
  conversation,
  declineDirect,
  readConversation,
  sayInDirect,
  startDirectConversation,
  updateAvailability
} from "./conversations";
import type { IdentifiedFetcher, PoppyTimeouts } from "./fetch";
import type { Json } from "./json";
import { decideAsAgent, decideLocal, decideLocalBatch, recoverApprovalBatches, recoverInterruptedApprovals, resolveApprovalOutcome } from "./operations";
import {
  expireSignIn,
  cancelSignIn,
  completeDirectSignIn,
  pushDirectSignIn,
  pollDeviceSignIn,
  recoverSignIns,
  signOut,
  submitCredentials,
  submitSignInCode
} from "./signin";
import { pendingSignOuts, recoverSignOuts, retryRevocation, retrySignOut } from "./signout";
import { protocolIndex, protocolLog, registerApiNamer } from "./protocol-log";
import { one, rows } from "../rows";
import { approvalsTable, cardsTable, migrate } from "./store";
import { addInstruction, InstructionRefused, instructions, ledger, newInstructionDecoder, withdrawInstruction } from "./instructions";
import type { Card, PoppyClientFrame, PoppyServerFrame } from "./wire";
import { issuerDecoder, type Issuer } from "./issuer";
import { clientFrame } from "./frames";
import { array, jsonText, object, optional, string, tryDecode } from "../decode";
import { isDiagnosticFlowId } from "./approval-outcome";
import { writeCard, type CardWriteOptions } from "./cards";
import { approvalDecisions } from "./approval-decisions";
import { ours, shown } from "../diagnostic";
import { noticeOf } from "./diagnostic-notice";

export type PoppyOptions = {
  readonly env: Env;
  readonly storage: DurableObjectStorage;
  readonly fetcher: IdentifiedFetcher;
  readonly browser: () => PoppyBrowser;
  /** Browsers to hand a website to the User in (handover.ts): Browser Run, or null while it is off. */
  readonly handover?: () => HandoverLauncher | null;
  /** While true, the page's frames do nothing: its approvals and sign-ins could otherwise start new Company work. */
  readonly framesRefused?: () => boolean;
  /** Hand a notice to the model, at most once per `operationId`. */
  readonly notifyModel: (text: string, operationId: string) => Promise<void>;
  /** Seconds a conversation read waits for events (spec 7.5). */
  readonly readWaitSeconds: number;
  /** Shortest gap between reads of an idle conversation. */
  readonly idleReadMs?: number;
  readonly sleep?: (ms: number) => Promise<void>;
  /** Now, in epoch ms, for waits and schedules; tests use a fake clock. */
  readonly now?: () => number;
  /** How long to wait on a Company; `POPPY_TIMEOUTS` by default. */
  readonly timeouts?: PoppyTimeouts;
  /** Where jobs, frames and the callback write their wide events (src/log.ts); `plainUnits` by default. */
  readonly units?: Units;
};

/** Frames that only read or keep the User present: no event of their own. */
const QUIET_FRAMES = new Set(["poppy.context", "poppy.activity", "poppy.protocol", "poppy.approvals.read"]);

/** The last locale and time zone the User's page sent: one row. */
const USER_CONTEXT_SCHEMA = `CREATE TABLE IF NOT EXISTS user_context (
  slot INTEGER PRIMARY KEY CHECK (slot = 1),
  locale TEXT,
  time_zone TEXT,
  updated_at INTEGER NOT NULL
)`;

/** The User counts as available while a page is open and was used recently (spec 7.4). */
const AVAILABLE_FOR_MS = 10 * 60_000;

// The protocol log names an OpenAPI call by its operation and path template.
registerApiNamer(apiOperationFor);

function html(status: number, message: string): Response {
  const escaped = message.replace(/[&<>"']/g, (char) => `&#${char.charCodeAt(0)};`);
  return new Response(
    `<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Poppy Demo Agent</title><body style="font:16px system-ui;margin:3rem auto;max-width:32rem;padding:0 1rem"><p>${escaped}</p></body>`,
    { status, headers: { "Content-Type": "text/html; charset=utf-8", "Cache-Control": "no-store" } }
  );
}

/**
 * Poppy as a Lifecycle capability on the person's Durable Object: it owns
 * the client, runs its durable jobs (conversation reads, device polling, sign-out retries,
 * operation tracking), takes `poppy.*` frames from the page before the chat
 * sees them, answers the Direct Sign-In callback, and pushes cards.
 */
export class PoppyCapability extends LifecycleCapability {
  readonly #options: PoppyOptions;
  #client: PoppyClient | undefined;
  #context: { locale?: string; time_zone?: string } = {};
  #lastActivity = 0;
  /** The last `poppy.activity` broadcast, so an unchanged one isn't sent again. */
  #lastActivityFrame = "";
  /** The last `poppy.protocol.index` broadcast, likewise. */
  #lastProtocolIndex = "";

  constructor(options: PoppyOptions) {
    super("poppy");
    this.#options = options;
  }

  /** Created on first use, so a missing Poppy secret doesn't break the chat. */
  get client(): PoppyClient {
    if (!this.#client) {
      migrate(this.#options.storage.sql);
      this.#client = new PoppyClient(this.#host());
    }
    return this.#client;
  }

  /** Tests: drop the client and its in-memory tokens and keys, as an eviction would. */
  forgetForTests(): void {
    this.#client = undefined;
  }

  /**
   * The User's IANA time zone, as their page last reported it
   * (`poppy.context`). Kept in `user_context` too, so reminders, scheduled
   * tasks and `now` still know it after an eviction, before a page
   * reconnects. Undefined until a page has ever sent one.
   */
  get timeZone(): string | undefined {
    return this.#context.time_zone ?? this.#storedContext().time_zone;
  }

  /** The last locale and time zone a page sent, from storage. */
  #storedContext(): { locale?: string; time_zone?: string } {
    const sql = this.#options.storage.sql;
    sql.exec(USER_CONTEXT_SCHEMA);
    const row = sql.exec("SELECT locale, time_zone FROM user_context WHERE slot = 1").toArray()[0];
    return {
      ...(typeof row?.locale === "string" ? { locale: row.locale } : {}),
      ...(typeof row?.time_zone === "string" ? { time_zone: row.time_zone } : {})
    };
  }

  /** Keep what the page sent; a field it left out keeps its last value. */
  #storeContext(context: { locale?: string; time_zone?: string }): void {
    if (context.locale === undefined && context.time_zone === undefined) return;
    const sql = this.#options.storage.sql;
    sql.exec(USER_CONTEXT_SCHEMA);
    sql.exec(
      `INSERT INTO user_context (slot, locale, time_zone, updated_at) VALUES (1, ?, ?, ?)
       ON CONFLICT (slot) DO UPDATE SET locale = COALESCE(excluded.locale, locale), time_zone = COALESCE(excluded.time_zone, time_zone), updated_at = excluded.updated_at`,
      context.locale ?? null,
      context.time_zone ?? null,
      Date.now()
    );
  }

  /** Send the Activity frame again, after something outside Poppy (a reminder, a scheduled task) added to it. */
  refreshActivity(): void {
    try {
      void this.client;
    } catch {
      return;
    }
    this.#sendActivity();
  }

  get browser(): PoppyBrowser {
    return this.#options.browser();
  }

  #host(): PoppyHost {
    const options = this.#options;
    return {
      env: options.env,
      sql: options.storage.sql,
      fetcher: options.fetcher,
      showCard: (card, options) => this.#showCard(card, options),
      notifyModel: (text, operationId) => options.notifyModel(text, operationId),
      schedule: async (fn, at, payload, id) => {
        await this.lifecycle.jobs.push({ fn, time: at, payload, id, singleflight: true });
        // Scheduled after a message, a new conversation or an operation update.
        this.#sendActivity();
      },
      hasJob: (id) => this.lifecycle.jobs.get(id) !== undefined,
      pushDirect: (update) => {
        this.#broadcast({ type: "poppy.direct", update });
        this.#sendActivity();
      },
      userContext: () => ({
        ...this.#context,
        user_available:
          this.lifecycle.sockets.get().length > 0 && Date.now() - this.#lastActivity < AVAILABLE_FOR_MS
      }),
      sleep: options.sleep ?? ((ms) => new Promise((resolve) => setTimeout(resolve, ms))),
      now: options.now ?? Date.now,
      ...(options.timeouts ? { timeouts: options.timeouts } : {}),
      ...(options.handover ? { handover: options.handover } : {})
    };
  }

  get #units(): Units {
    return this.#options.units ?? plainUnits;
  }

  override async onStart(): Promise<void> {
    if (!this.#hasPoppyState()) return;
    await this.#units.job({ job: literal("poppy.recover") }, async () => {
      await recoverInterruptedApprovals(this.client);
      await recoverApprovalBatches(this.client);
      // A Direct Sign-In the restart interrupted: finish it, or start a new Session (4.5).
      await recoverSignIns(this.client).catch((error: unknown) => reportError(error, { source: literal("poppy.signin_recovery") }));
      // A revocation still pending whose job is missing: schedule it again.
      await recoverSignOuts(this.client).catch((error: unknown) => reportError(error, { source: literal("poppy.signout_recovery") }));
    });
  }

  #hasPoppyState(): boolean {
    const found = this.#options.storage.sql
      .exec("SELECT name FROM sqlite_master WHERE type = 'table' AND name = 'poppy_approvals'")
      .toArray();
    return found.length > 0;
  }

  // ---------------------------------------------------------------- Page

  #broadcast(frame: PoppyServerFrame): void {
    const text = JSON.stringify(frame);
    for (const socket of this.lifecycle.sockets.get()) {
      try {
        socket.send(text);
      } catch {
        // Closed between listing and sending.
      }
    }
  }

  async #showCard(card: Card, options?: CardWriteOptions): Promise<void> {
    if (!writeCard(this.#options.storage.sql, card, Date.now(), options)) return;
    recordCard(card as { kind: string; open?: boolean });
    this.#sendCards();
    if (card.kind === "notice" || card.kind === "signin_link") this.#sendSettings();
    this.#sendActivity();
  }

  /**
   * What the agent is doing and has done at Companies, from its own tables:
   * to one socket on connect, otherwise to every page when it changed.
   */
  #sendActivity(socket?: WebSocket): void {
    if (!socket && !this.#hasPoppyState()) return;
    this.#sendProtocolIndex(socket);
    let text: string;
    try {
      text = JSON.stringify(buildActivity(this.client));
    } catch (error) {
      // The log is a view; failing to build it must never stop the work it describes.
      reportError(error, { source: literal("poppy.activity"), severe: false });
      return;
    }
    if (socket) {
      socket.send(text);
      return;
    }
    if (text === this.#lastActivityFrame) return;
    this.#lastActivityFrame = text;
    for (const open of this.lifecycle.sockets.get()) {
      try {
        open.send(text);
      } catch {
        // Closed between listing and sending.
      }
    }
  }

  /** A Company's name and verified domain, by issuer, for the protocol view. */
  #companyNames = (issuer: Issuer): { name: string; domain: string | null } => {
    try {
      const company = this.client.companyByIssuer(issuer);
      return { name: company.name, domain: company.domain };
    } catch {
      return { name: URL.canParse(issuer) ? new URL(issuer).host : issuer, domain: null };
    }
  };

  /**
   * Which Companies have a protocol log, without the entries, so it stays
   * small: to one socket on connect, otherwise to every page when it changed.
   * A page with a Company's log open asks for it again when its `lastSeq` moves.
   */
  #sendProtocolIndex(socket?: WebSocket): void {
    let text: string;
    try {
      text = JSON.stringify(protocolIndex(this.client.sql, this.#companyNames));
    } catch (error) {
      reportError(error, { source: literal("poppy.protocol_index"), severe: false });
      return;
    }
    if (socket) {
      socket.send(text);
      return;
    }
    if (text === this.#lastProtocolIndex) return;
    this.#lastProtocolIndex = text;
    for (const open of this.lifecycle.sockets.get()) {
      try {
        open.send(text);
      } catch {
        // Closed between listing and sending.
      }
    }
  }

  /** Take a closed card out of every page's list now, as dismissing it does. */
  retireCard(id: string): void {
    // An unresolved receipt is the User's route to checking the outcome.
    // Keep it until reconciled, including requests from a page left open before this update.
    this.#options.storage.sql.exec(`UPDATE poppy_cards SET open = 0, updated_at = 0 WHERE id = ?
      AND NOT COALESCE(json_extract(card, '$.kind') = 'approval' AND json_extract(card, '$.status') = 'unknown'
        AND json_extract(card, '$.outcomeResolution') IS NULL, 0)`, id);
    this.#sendCards();
  }

  /** A message of the User's selected these Companies: a card asking to contact one has its answer, which their message shows. */
  companiesSelected(domains: readonly string[]): void {
    // The tables come with the client; before it, no card has been shown.
    const sql = this.#options.storage.sql;
    if (!domains.length || !sql.exec("SELECT 1 FROM sqlite_master WHERE type = 'table' AND name = 'poppy_cards'").toArray().length) return;
    let closed = 0;
    for (const domain of domains) {
      closed += sql.exec("UPDATE poppy_cards SET open = 0, card = json_set(card, '$.open', json('false')), updated_at = 0 WHERE id = ? AND open = 1", `company-access-${domain}`).rowsWritten;
    }
    if (closed) this.#sendCards();
  }

  /** Open cards, recent receipts and unresolved outcomes, however long checking them takes. */
  #sendCards(socket?: WebSocket): void {
    const cards = rows(
      this.#options.storage.sql,
      cardsTable.pick("card", "updated_at"),
      `SELECT card, updated_at FROM poppy_cards WHERE open = 1 OR updated_at > ?
        OR (json_extract(card, '$.kind') = 'approval' AND json_extract(card, '$.status') = 'unknown'
          AND json_extract(card, '$.outcomeResolution') IS NULL) ORDER BY updated_at`,
      Date.now() - 60 * 60_000
    ).map((row) => ({ ...(JSON.parse(row.card) as Card), at: row.updated_at }));
    const frame: PoppyServerFrame = { type: "poppy.cards", cards };
    if (socket) socket.send(JSON.stringify(frame));
    else this.#broadcast(frame);
  }

  #sendSettings(socket?: WebSocket): void {
    const client = this.client;
    const name = (issuer: Issuer) => {
      try {
        return client.companyByIssuer(issuer).name;
      } catch {
        return issuer;
      }
    };
    const frame: PoppyServerFrame = {
      type: "poppy.settings",
      accounts: client.accounts().map((row) => ({
        issuer: row.issuer,
        company: name(row.issuer),
        account: row.account,
        scope: row.scope,
        expiresAt: row.expires_at
      })),
      // Never the token: what the page shows about each sign-out the Company hasn't accepted.
      signOuts: pendingSignOuts(client).map((row) => ({
        id: row.id,
        issuer: row.issuer,
        company: name(row.issuer),
        account: row.account,
        reason: row.reason,
        error: row.last_error,
        attempts: row.attempts,
        expiresAt: row.expires_at,
        nextAt: row.next_at
      })),
      instructions: instructions(client).map((item) => ({
        ...item,
        company: name(item.issuer),
        approvals: ledger(client, item.id).map((entry) => {
          const approval = one(client.sql, approvalsTable.pick("summary", "status"), "SELECT summary, status FROM poppy_approvals WHERE id = ?", entry.approvalId);
          return { approvalId: entry.approvalId, summary: approval?.summary ?? "", status: approval?.status ?? "unknown", spend: entry.state, amount: entry.amount, currency: entry.currency, at: entry.at };
        })
      }))
    };
    if (socket) socket.send(JSON.stringify(frame));
    else this.#broadcast(frame);
  }

  /** `poppy.*` frames from the page; everything else goes on to the chat. */
  async onWebSocketMessage(socket: WebSocket, message: string | ArrayBuffer | ArrayBufferView): Promise<boolean> {
    if (typeof message !== "string" || !message.includes('"poppy.')) return false;
    let parsed: unknown;
    try {
      parsed = JSON.parse(message);
    } catch {
      return false;
    }
    const type = typeof parsed === "object" && parsed !== null ? (parsed as { type?: unknown }).type : undefined;
    if (typeof type !== "string" || !type.startsWith("poppy.")) return false;
    // Every member checked (an issuer is an issuer, a decision one of the page's): a frame that isn't one is ignored.
    const decoded = tryDecode(clientFrame, parsed, "page frame");
    if (!decoded.ok) return true;
    const frame = decoded.value;
    if (frame.type !== "poppy.result_links.checked") this.#lastActivity = Date.now();
    try {
      if (this.#options.framesRefused?.()) throw new PoppyError("refused", ours("Your agent is being deleted."), 0);
      if (QUIET_FRAMES.has(frame.type)) await this.#handleFrame(socket, frame);
      else await this.#units.frame(code(frame.type) ?? literal("poppy.unknown"), frameFields(frame), () => this.#handleFrame(socket, frame));
      if (!QUIET_FRAMES.has(frame.type)) this.#sendActivity();
    } catch (error) {
      if (QUIET_FRAMES.has(frame.type)) reportError(error, { source: code(frame.type) ?? literal("poppy.unknown"), severe: false });
      this.#broadcast({
        type: "poppy.cards",
        cards: [
          {
            id: `error-${Date.now()}`,
            kind: "notice",
            company: "",
            open: false,
            ...noticeOf(ours("That didn't work"), error)
          }
        ]
      });
    }
    return true;
  }

  async onWebSocketClose(): Promise<boolean> {
    if (this.#hasPoppyState()) await updateAvailability(this.client).catch(() => undefined);
    return false;
  }

  async #handleFrame(socket: WebSocket, frame: PoppyClientFrame): Promise<void> {
    const client = this.client;
    switch (frame.type) {
      case "poppy.context": {
        const wasAvailable = client.host.userContext().user_available;
        this.#context = {
          ...(typeof frame.locale === "string" && /^[A-Za-z]{2,3}(-[A-Za-z0-9]{2,8})*$/.test(frame.locale) ? { locale: frame.locale } : {}),
          ...(typeof frame.time_zone === "string" && /^[A-Za-z_]+(\/[A-Za-z0-9_+-]+)*$/.test(frame.time_zone) ? { time_zone: frame.time_zone } : {})
        };
        this.#storeContext(this.#context);
        this.#sendCards(socket);
        this.#sendSettings(socket);
        this.#sendActivity(socket);
        if (!wasAvailable) await updateAvailability(client).catch(() => undefined);
        return;
      }
      case "poppy.activity":
        return;
      case "poppy.approvals.read": {
        const decisions = approvalDecisions(client.sql, frame.ids, issuer => {
          try { return client.companyByIssuer(issuer).name; } catch { return issuer; }
        });
        socket.send(JSON.stringify({ type: "poppy.approvals.state", ids: frame.ids, decisions } satisfies PoppyServerFrame));
        return;
      }
      case "poppy.protocol":
        // Read-only, from our own table, to the page that asked.
        if (typeof frame.key === "string") socket.send(JSON.stringify(protocolLog(client.sql, frame.key, this.#companyNames)));
        return;
      case "poppy.credentials":
        // Straight to the sign-in code; never the model, the transcript or a log.
        await submitCredentials(client, frame.signInId, frame.values);
        await this.#afterSignIn();
        return;
      case "poppy.code":
        await submitSignInCode(client, frame.signInId, frame.code);
        await this.#afterSignIn();
        return;
      case "poppy.signin.cancel":
        await cancelSignIn(client, frame.signInId);
        return;
      case "poppy.result_links.checked": {
        const target = frame.cardId.startsWith("result-") ? frame.cardId.slice(7) : "";
        if (!isDiagnosticFlowId(target)) return;
        const stored = one(client.sql, cardsTable.pick("card"), "SELECT card FROM poppy_cards WHERE id = ?", frame.cardId);
        if (!stored) return;
        const decoded = tryDecode(jsonText(object({ kind: string, links: array(object({ label: string, url: string })) })), stored.card, "result links");
        if (!decoded.ok || decoded.value.kind !== "notice" || frame.checks.some(check => check.index >= decoded.value.links.length)) return;
        const attributeEqual = frame.checks.filter(check => check.attribute_equal).length;
        const resolvedEqual = frame.checks.filter(check => check.resolved_equal).length;
        currentEvent()?.set({ approval_id: id(target), result_link_rendered: {
          client_reported: true, links: frame.checks.length,
          attribute_equal: attributeEqual, attribute_different: frame.checks.length - attributeEqual,
          resolved_equal: resolvedEqual, resolved_different: frame.checks.length - resolvedEqual
        } });
        return;
      }
      case "poppy.approval":
        await decideLocal(client, frame.approvalId, frame.decision);
        return;
      case "poppy.approval.resolve":
        await resolveApprovalOutcome(client, frame.approvalId, frame.outcome);
        return;
      case "poppy.approvals":
        await decideLocalBatch(client, frame.decisions);
        return;
      case "poppy.direct.start":
        await startDirectConversation(client, frame.conversationId, frame.text, frame.eventId);
        return;
      case "poppy.direct.decline":
        await declineDirect(client, frame.conversationId);
        return;
      case "poppy.direct.say":
        await sayInDirect(client, frame.conversationId, frame.text);
        return;
      case "poppy.direct.close": {
        const row = conversation(client, frame.conversationId);
        if (row) await closeConversation(client, client.companyByIssuer(row.issuer), row.id);
        return;
      }
      case "poppy.signout":
        await signOut(client, frame.issuer, frame.account);
        // A browser handed to the User for that account closes with it.
        await endChangedHandovers(client);
        this.#sendSettings();
        return;
      case "poppy.browser.take":
      case "poppy.browser.view": {
        // The live view goes to this page alone: whoever holds the link controls the browser.
        const start = handoverStart(client, this.browser);
        const view = frame.type === "poppy.browser.take" ? await takeControl(client, start, frame.handoverId) : await liveView(client, start, frame.handoverId);
        socket.send(JSON.stringify({ type: "poppy.browser.view", handoverId: frame.handoverId, url: view.url, expiresAt: view.expiresAt } satisfies PoppyServerFrame));
        return;
      }
      case "poppy.browser.return":
        await endControl(client, frame.handoverId, "returned");
        return;
      case "poppy.browser.cancel":
        await endControl(client, frame.handoverId, "cancelled");
        return;
      case "poppy.revoke.retry":
        await retryRevocation(client, frame.id);
        this.#sendSettings();
        return;
      case "poppy.card.dismiss":
        this.retireCard(frame.id);
        return;
      case "poppy.instruction.add": {
        // From the User's page only; the model has no way to send this frame.
        const decoded = tryDecode(newInstructionDecoder, { issuer: frame.issuer, account: frame.account ?? null, text: frame.text, conditions: frame.conditions, budget: frame.budget ?? null }, "instruction");
        try {
          if (!decoded.ok) throw new InstructionRefused(shown`That instruction can't be used: ${decoded.problem}`);
          addInstruction(client, decoded.value);
        } catch (error) {
          if (!(error instanceof InstructionRefused)) throw error;
          await this.#showCard({ id: `instruction-refused-${Date.now()}`, kind: "notice", company: "Your agent", open: true, ...noticeOf(ours("Your instruction wasn't saved"), error) });
        }
        this.#sendSettings();
        return;
      }
      case "poppy.instruction.withdraw":
        withdrawInstruction(client, frame.id);
        this.#sendSettings();
        return;
    }
  }

  /** After any sign-in: the Companies page shows the new account. */
  async #afterSignIn(): Promise<void> {
    this.#sendSettings();
  }

  // ---------------------------------------------------------------- HTTP

  /** `GET /poppy/callback` and `GET /poppy/sign-in`, forwarded by the Worker for the signed-in person. */
  async onRequest({ request }: { request: Request }): Promise<Response | undefined> {
    const url = new URL(request.url);
    const requestId = id(request.headers.get("x-request-id"));
    if (url.pathname === "/poppy/sign-in") {
      return this.#units.request({ hop: literal("agent"), method: literal("GET"), route: literal("/poppy/sign-in"), ...(requestId ? { request_id: requestId } : {}) }, async (event) => {
        let pushed: Awaited<ReturnType<typeof pushDirectSignIn>>;
        try {
          pushed = await pushDirectSignIn(this.client, url.searchParams.get("id") ?? "");
        } catch (error) {
          event.fail(error).set({ status: 500 });
          return html(500, "Signing in didn't start. Go back to the chat and start it again.");
        }
        event.set({ status: pushed.ok ? 303 : pushed.status, outcome: literal(pushed.ok ? "success" : "refused") });
        return pushed.ok
          ? new Response(null, { status: 303, headers: { Location: pushed.location, "Cache-Control": "no-store", "Referrer-Policy": "no-referrer" } })
          : html(pushed.status, pushed.message);
      });
    }
    if (url.pathname !== "/poppy/callback") return undefined;
    return this.#units.request({ hop: literal("agent"), method: literal("GET"), route: literal("/poppy/callback"), ...(requestId ? { request_id: requestId } : {}) }, async (event) => {
      let result: Awaited<ReturnType<typeof completeDirectSignIn>>;
      try {
        result = await completeDirectSignIn(this.client, url);
      } catch (error) {
        // Recorded here, by class and code. Thrown on, it would reach the Worker's event as a plain error whose message may be a Company's words.
        event.fail(error).set({ status: 500 });
        return html(500, "Signing in didn't finish. Go back to the chat and start it again.");
      }
      if (result.ok) await this.#afterSignIn();
      event.set({ status: result.ok ? 200 : 400, outcome: literal(result.ok ? "success" : "refused") });
      return html(result.ok ? 200 : 400, result.message);
    });
  }

  // ---------------------------------------------------------------- Jobs

  async onJob({ job }: LifecycleJobContext): Promise<LifecycleJobOutcome | void> {
    // A job's payload is ours, stored before a restart or a deploy: read, not trusted.
    const decoded = tryDecode(object({ id: optional(string), issuer: optional(issuerDecoder) }), job.payload, "job payload");
    const payload: { id?: string; issuer?: Issuer } = decoded.ok ? decoded.value : {};
    const fn = job.fn as JobName;
    const client = this.client;
    // Which job, and the Company's ids it works on; never a device sign-in's id.
    const fields: Fields = {
      job: literal(fn),
      ...(fn === "poppy-read" ? { conversation_id: id(payload.id) } : {}),
      ...(fn === "poppy-revoke" ? { issuer: origin(payload.issuer) } : {})
    };
    return this.#units.job(fields, async (event) => {
      let next: number | null = null;
      try {
        if (fn === "poppy-read" && payload.id) {
          next = await readConversation(client, payload.id, this.#options.readWaitSeconds, this.#options.idleReadMs);
        } else if (fn === "poppy-device" && payload.id) {
          next = await pollDeviceSignIn(client, payload.id);
          if (next === null) await this.#afterSignIn();
        } else if (fn === "poppy-signin-expiry" && payload.id) {
          await expireSignIn(client, payload.id);
        } else if (fn === "poppy-revoke" && payload.id) {
          // A sign-out the Company refused: try again (signout.ts). Its notice resends the Companies page.
          next = await retrySignOut(client, payload.id);
        } else if (fn === "poppy-agent-approval" && payload.id) {
          // An operation a standing instruction covers (instructions.ts): approved and sent, unless decided or withdrawn since.
          await decideAsAgent(client, payload.id);
        } else if (fn === "poppy-handover" && payload.id) {
          // A browser the User controls: still connected, navigator.poppy in place, its Session unchanged (handover.ts).
          next = await heartbeat(client, payload.id);
        }
      } catch (error) {
        event.fail(error);
        next = Date.now() + 60_000;
      }
      this.#sendActivity();
      event.set({ rescheduled: next !== null });
      return next === null ? undefined : { rescheduleAt: next };
    });
  }
}

/** What a frame's event records: which decision, and which Company. Never values, codes, text or ids the User typed. */
function frameFields(frame: PoppyClientFrame): Fields {
  return {
    ...("decision" in frame ? { decision: code(frame.decision) } : {}),
    ...("issuer" in frame ? { issuer: origin(frame.issuer) } : {}),
    ...(frame.type === "poppy.approval" || frame.type === "poppy.approval.resolve" ? { approval_id: id(frame.approvalId) } : {}),
    ...(frame.type === "poppy.approval.resolve" ? { outcome: code(frame.outcome) } : {}),
    ...(frame.type === "poppy.approvals" ? { approvals: frame.decisions.length, approved: frame.decisions.filter((item) => item.decision === "approve").length } : {})
  };
}

export type { Json };
