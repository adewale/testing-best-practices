/**
 * Local approvals: a request the agent makes only once the User has
 * approved it on a card of ours: uploads of the User's files, website forms,
 * and operations a Company returned (Operations 3, `operations-v2.ts`).
 * Task requests share their durable dispatch/recovery machinery without
 * inventing a preliminary approval; exact requests and outcomes survive replay. Also what a card shows of an operation's
 * terms, and where they disagree with its summary or the request (Ops 5).
 */
import { approvalAttachments, approvalBatchKey, readApproval, storedApproval, type ApprovalKind, type ApprovalOf, type NewApproval } from "./approvals";
import { answerOf, PoppyClient, PoppyError, unreadableAnswerOf } from "./client";
import { tokenHostAllowed, type Company } from "./discovery";
import { canonicalJson, isObject, toJson, type Json } from "./json";
import { json, jsonText } from "../decode";
import { randomId, sha256 } from "./jwt";
import { described, onInstruction, type OperationV2 } from "./operations-v2";
import { settleSpend, standingInstructionFor, type Instruction } from "./instructions";
import { ApprovalDeclined, declineForModel, declineText, recordDecline } from "./declines";
import type { ApprovalTerms } from "./wire";
import { one, rows, type RowOf } from "../rows";
import { approvalBatchesTable, approvalsTable, cardsTable, intent, intentsTable, taskCallsTable, type Sql } from "./store";
import { approvalResult, checkedOutcomeText, isTaskRequest, storedResolution } from "./approval-outcome";
import { linkedDecision, taskRequested } from "./approval-projection";
import type { CardWriteOptions } from "./cards";
import { inspectResultLinks } from "./result-links";
import { currentEvent, currentTool, id as logId } from "../log";
import { departure, ours, ProblemError, sentence, show, shown, type Problem, type Shown } from "../diagnostic";

/** Digits after the decimal point in a currency's amounts (ISO 4217): 2 for USD, 0 for JPY; null for a code this runtime doesn't know. */
function minorDigits(currency: unknown): number | null {
  if (typeof currency !== "string" || !/^[A-Z]{3}$/.test(currency) || !Intl.supportedValuesOf("currency").includes(currency)) return null;
  return new Intl.NumberFormat("en", { style: "currency", currency }).resolvedOptions().maximumFractionDigits ?? null;
}

/**
 * An amount in whole units, as the card shows it. 0.4 Ops 3 leaves the keys of `terms`
 * to the Company, so `{ "amount": 1200, "currency": "USD" }` can be in cents. An
 * integer amount in a currency with minor units is read in them when the summary,
 * which MUST name any cost too, writes that reading ("$12.00") and never the amount
 * as written (1200). Anything else is as written ([reading](../../docs/readings.md#v04-terms-minor-units)).
 */
export function wholeAmount(amount: string | number, currency: unknown, summary: string | undefined): string {
  const written = String(amount);
  const digits = minorDigits(currency);
  if (summary === undefined || !digits || !/^-?\d+$/.test(written) || (typeof amount === "number" && !Number.isSafeInteger(amount))) return written;
  const sign = written.startsWith("-") ? "-" : "";
  const padded = written.replace(/^-/, "").padStart(digits + 1, "0");
  const minor = `${sign}${padded.slice(0, -digits)}.${padded.slice(-digits)}`;
  const numbers = numbersIn(summary);
  const says = (value: string) => numbers.includes(Math.abs(Number(value)));
  return says(minor) && !says(written) ? minor : written;
}

/**
 * What the Guides ask an approval to point out (Operations section): costs,
 * dates and conditions found in `terms`, and whether the action can be undone.
 * Amounts are in whole units as `wholeAmount` reads them against `summary`.
 */
export function highlights(terms: Json | undefined, summary?: string): string[] {
  const found: string[] = [];
  let reversibility: string | null = null;
  const walk = (value: Json, path: string) => {
    if (!isObject(value)) {
      if (Array.isArray(value)) value.forEach((item, index) => walk(item, `${path}[${index}]`));
      return;
    }
    if (typeof value.amount === "string" || typeof value.amount === "number") {
      found.push(`Cost (${path || "amount"}): ${wholeAmount(value.amount, value.currency, summary)}${typeof value.currency === "string" ? ` ${value.currency}` : ""}`);
      return;
    }
    for (const [key, item] of Object.entries(value)) {
      const where = path ? `${path}.${key}` : key;
      if (/(date|_at$|time|deadline|until|from)/i.test(key) && typeof item === "string") {
        found.push(`Date (${where}): ${item}`);
      } else if (/(reversible|undo|cancellable|refundable)/i.test(key) && typeof item === "boolean") {
        // Before conditions, whose `cancel` and `refund` would otherwise take `cancellable` and `refundable`.
        reversibility = item ? "The company says this can be undone." : "The company says this can't be undone.";
      } else if (/(condition|cancel|refund|fee|penalt|restock)/i.test(key) && (typeof item === "string" || typeof item === "number" || typeof item === "boolean")) {
        found.push(`Condition (${where}): ${String(item)}`);
      }
      walk(item, where);
    }
  };
  if (terms !== undefined) walk(terms, "");
  found.push(reversibility ?? "The company hasn't said whether this can be undone.");
  return found;
}

/**
 * The total `terms` name, shown large on the card: the `{ amount, currency }`
 * under a key with "total" in it (and not "sub") nearest the top, "total"
 * or "grand_total" first, or a number there beside a `currency`
 * (`{ "total": 1200, "currency": "USD" }`), in whole units as `wholeAmount`
 * reads them against `summary`. None when terms don't name
 * one; the card then has no large figure, and the highlights still list every cost.
 */
export function termsTotal(terms: Json | undefined, summary?: string): { amount: string; currency: string } | undefined {
  let level: Json[] = terms === undefined ? [] : [terms];
  for (let depth = 0; depth < 4 && level.length; depth++) {
    const next: Json[] = [];
    for (const value of level) {
      if (Array.isArray(value)) next.push(...value);
      if (!isObject(value)) continue;
      // "total" or "grand_total" before any other total at the same depth; a subtotal never.
      const totals = Object.entries(value)
        .filter(([key]) => /total/i.test(key) && !/sub/i.test(key))
        .sort(([a], [b]) => Number(!/^(grand[_ -]?)?total$/i.test(a)) - Number(!/^(grand[_ -]?)?total$/i.test(b)));
      for (const [, item] of totals) {
        if (isObject(item) && (typeof item.amount === "string" || typeof item.amount === "number") && typeof item.currency === "string") {
          return { amount: wholeAmount(item.amount, item.currency, summary), currency: item.currency };
        }
        if (typeof item === "number" && typeof value.currency === "string") {
          return { amount: wholeAmount(item, value.currency, summary), currency: value.currency };
        }
      }
      next.push(...Object.values(value));
    }
    level = next;
  }
  return undefined;
}

/**
 * Previews `terms` link to, such as a print's crop: HTTPS URLs on the
 * Company's own hosts under a key with "preview" in it, each labelled by
 * where it is ("items 1 preview"). The page links them; it never loads them,
 * since its Content-Security-Policy takes images from our origin only.
 */
export function termsPreviews(company: Company, terms: Json | undefined): { label: string; url: string }[] {
  const found: { label: string; url: string }[] = [];
  const walk = (value: Json, path: string[], inPreview: boolean) => {
    if (found.length >= 12) return;
    if (typeof value === "string") {
      if (!inPreview || !URL.canParse(value)) return;
      const url = new URL(value);
      if (url.protocol !== "https:" || url.username || url.password || !tokenHostAllowed(company, url)) return;
      found.push({ label: path.join(" ").replace(/[_-]+/g, " ").replace(/\s+/g, " ").trim() || "preview", url: url.href });
      return;
    }
    if (Array.isArray(value)) value.forEach((item, index) => walk(item, [...path, String(index + 1)], inPreview));
    else if (isObject(value)) for (const [key, item] of Object.entries(value)) walk(item, [...path, key], inPreview || /preview/i.test(key));
  };
  if (terms !== undefined) walk(terms, [], false);
  return found;
}

/** The longest value a difference quotes, so a Company's long string can't fill the card. */
const QUOTE_LIMIT = 80;
const quoted = (value: string | number | boolean) => {
  const text = String(value);
  return text.length > QUOTE_LIMIT ? `${text.slice(0, QUOTE_LIMIT)}…` : text;
};

/** Every number written in a text, commas dropped: "$1,070.50 more" → [1070.5]. */
function numbersIn(text: string): number[] {
  return [...text.matchAll(/\d[\d,]*(?:\.\d+)?/g)].map((match) => Number(match[0].replace(/,/g, ""))).filter(Number.isFinite);
}

type Scalar = string | number | boolean;
const isScalar = (value: Json | undefined): value is Scalar => typeof value === "string" || typeof value === "number" || typeof value === "boolean";

/** The scalar at exactly `path` in a value, if there is one: what the request asked for in that place. */
function scalarAtPath(value: Json | undefined, path: readonly (string | number)[]): Scalar | undefined {
  let at: Json | undefined = value;
  for (const segment of path) {
    if (typeof segment === "number") at = Array.isArray(at) ? at[segment] : undefined;
    else at = isObject(at) && Object.hasOwn(at, segment) ? at[segment] : undefined;
  }
  return isScalar(at) ? at : undefined;
}

/** Every scalar in a value to six levels, by the keys that lead to it, array places left out: `items[1].sku` is `items.sku`. */
function namedScalars(value: Json | undefined): { named: string; value: Scalar }[] {
  const found: { named: string; value: Scalar }[] = [];
  const walk = (item: Json, keys: readonly string[], depth: number) => {
    if (depth > 6) return;
    if (isScalar(item)) found.push({ named: keys.join("."), value: item });
    else if (Array.isArray(item)) item.forEach((each) => walk(each, keys, depth + 1));
    else if (isObject(item)) for (const [key, each] of Object.entries(item)) walk(each, [...keys, key], depth + 1);
  };
  if (value !== undefined) walk(value, [], 0);
  return found;
}

/**
 * What the request asked for in the place the terms name, where it has
 * none at exactly that place: its scalars whose keys end with the terms'
 * keys, so `order_id` is the request's `params.order_id` and
 * `address.name` its `body.address.name`, but `products[0].name` is not
 * `address.name`. None when those keys lead to two different places in
 * the request, which leaves them ambiguous.
 */
function scalarsNamed(asked: Json | undefined, keys: readonly string[]): Scalar[] {
  const named = keys.join(".");
  const matches = namedScalars(asked).filter((item) => item.named === named || item.named.endsWith(`.${named}`));
  return new Set(matches.map((item) => item.named)).size === 1 ? matches.map((item) => item.value) : [];
}

/**
 * Where an operation's terms disagree with its summary or with the request
 * that returned it (Ops 5: the agent "SHOULD check that they agree with the
 * `summary` and with what it asked for ... and point out any difference").
 * Two checks, both mechanical: every amount the terms name appears as a
 * number in the summary (its size: a refund of -20.00 may be written
 * "20.00"), and every scalar the terms name has the request's value: the
 * request's at the same place, or, where the request has none there, one
 * of the request's under the same keys (`scalarsNamed`), if it used them.
 * So an order of several items, each with its own `sku`, agrees with
 * itself, and a recipient's `name` isn't compared with a product's. Wording,
 * dates and anything else the summary says are left to the User, who
 * reads it in full. Without a summary (version 3) the card shows the
 * terms' own values, so only the request is compared.
 */
export function termsDifferences(operation: Pick<OperationV2, "summary" | "terms">, asked: Json | undefined): string[] {
  const differences: string[] = [];
  const written = operation.summary === undefined ? null : numbersIn(operation.summary);
  const walk = (value: Json, path: string, segments: readonly (string | number)[]) => {
    if (differences.length >= 8) return;
    if (Array.isArray(value)) return value.forEach((item, index) => walk(item, `${path}[${index}]`, [...segments, index]));
    if (!isObject(value)) return;
    if (typeof value.amount === "string" || typeof value.amount === "number") {
      const amount = Number(wholeAmount(value.amount, value.currency, operation.summary));
      const currency = typeof value.currency === "string" ? ` ${value.currency}` : "";
      if (written && (!Number.isFinite(amount) || !written.includes(Math.abs(amount)))) {
        differences.push(`The terms name ${quoted(value.amount)}${quoted(currency)} (${path || "amount"}), which the summary doesn't mention.`);
      }
      return;
    }
    for (const [key, item] of Object.entries(value)) {
      const where = path ? `${path}.${key}` : key;
      if (isScalar(item)) {
        const here = scalarAtPath(asked, [...segments, key]);
        const sent = here === undefined ? scalarsNamed(asked, [...segments, key].filter((segment) => typeof segment === "string")) : [here];
        if (sent.length > 0 && !sent.some((value) => String(value) === String(item))) {
          differences.push(`The terms say ${where} is ${quoted(item)}, but the request asked for ${quoted(sent[0]!)}.`);
        }
      } else {
        walk(item, where, [...segments, key]);
      }
    }
  };
  if (operation.terms !== undefined) walk(operation.terms, "", []);
  return differences.slice(0, 8);
}

/** What the approval card shows of an operation (Ops 5): the Company's summary, its expiry, and what its terms name. */
export function approvalTerms(company: Company, operation: OperationV2, asked: Json | undefined): ApprovalTerms {
  const total = termsTotal(operation.terms, operation.summary);
  const previews = termsPreviews(company, operation.terms);
  const differences = termsDifferences(operation, asked);
  return {
    summary: described(operation),
    expiresAt: operation.expires_at,
    highlights: highlights(operation.terms, operation.summary),
    ...(total ? { total } : {}),
    ...(previews.length ? { previews } : {}),
    ...(differences.length ? { differences } : {})
  };
}

// ---------------------------------------------------------------- Local approvals

/**
 * What an executor throws when the request it sent, as the User approved
 * it, came back with an operation of the Company's (Ops 4): our card's
 * request was sent, and nothing is done until the User approves the
 * Company's terms on the card that now waits.
 */
export class TermsRequested extends ProblemError {
  /** What the receipt says. */
  readonly result: string;
  constructor(problem: Problem, readonly approvalId: string) {
    super(problem);
    this.result = this.message;
  }
}

/** An approval message was accepted, but that acknowledgement doesn't establish the action's outcome. */
export class OperationOutcomeUnknown extends ProblemError {
  constructor(problem: Problem) {
    super(problem);
  }
}

/** The same action cannot acquire fresh authority until its earlier outcome is reconciled. */
export class ActionOutcomePending extends PoppyError {
  constructor(readonly previousApprovalId: string) {
    super("approval_changed", ours("Another approved action at this Company has an unknown outcome. Check with the Company, then record what happened on its receipt before approving further writes there. Nothing was sent."), 0);
  }
}

/**
 * What differs between a request as first recorded and as it is now, by the
 * names of its parts, never their values: a request can carry the User's
 * details. A status or summary is compared only when both sides give one.
 */
function changedRequest(
  first: { readonly issuer: string; readonly label: string; readonly request: string; readonly summary?: string; readonly status?: string },
  now: { readonly issuer: string; readonly label: string; readonly request: string; readonly summary?: string; readonly status?: string }
): Shown {
  const changed = [
    ...(first.status !== undefined && now.status !== undefined && first.status !== now.status ? [ours("status")] : []),
    ...(first.issuer !== now.issuer ? [ours("Company")] : []),
    ...(first.label !== now.label ? [ours("account")] : []),
    ...(first.request !== now.request ? [ours("details")] : []),
    ...(first.summary !== undefined && now.summary !== undefined && first.summary !== now.summary ? [ours("summary")] : [])
  ];
  return changed.length ? shown`one whose ${show.list(changed)} changed` : ours("a different one");
}

/** The parts of a Company's terms a revision fixes (0.4 Ops 3), by name. */
const TERM_PARTS = { expiresAt: ours("expiry"), highlights: ours("highlights"), total: ours("total"), previews: ours("previews"), differences: ours("differences") } as const;

function changedTerms(first: ApprovalTerms, now: ApprovalTerms): Shown {
  const before = toJson(first);
  const after = toJson(now);
  const changed = isObject(before) && isObject(after) ? Object.entries(TERM_PARTS).filter(([key]) => canonicalJson(before[key]) !== canonicalJson(after[key])).map(([, name]) => name) : [];
  return changed.length ? shown`terms whose ${show.list(changed)} changed` : ours("other terms");
}

/** How an approved local action of one kind is carried out (registered by the APIs and browser). */
/** One approved request being carried out: its approval's ID, when it was approved (epoch ms), and the check before each send. */
export type ApprovalExecution = {
  readonly approvalId: string;
  readonly approvedAt: number;
  readonly beforeDispatch: () => void;
  /** Who approved (0.4 Ops 6): the User, or the agent on a standing instruction. */
  readonly approver?: "user" | "agent";
};
export type ApprovalExecutor<K extends ApprovalKind> = (client: PoppyClient, company: Company, approval: ApprovalOf<K>, label: string, execution: ApprovalExecution) => Promise<string>;
const executors: { [K in ApprovalKind]?: ApprovalExecutor<K> } = {};

export function registerExecutor<K extends ApprovalKind>(kind: K, executor: ApprovalExecutor<K>): void {
  (executors as Record<K, ApprovalExecutor<K>>)[kind] = executor;
}

function run<K extends ApprovalKind>(client: PoppyClient, company: Company, approval: ApprovalOf<K>, label: string, execution: ApprovalExecution): Promise<string> {
  const executor = executors[approval.kind] as ApprovalExecutor<K> | undefined;
  if (!executor) throw new Error(`No executor for ${approval.kind}`);
  return executor(client, company, approval, label, execution);
}

type ActionIdentity = { readonly key: string; readonly owner: string; readonly operationId: string | null };

/**
 * Exact request identity, independent of transport retry keys and operation revisions.
 * Account operations span Sessions; signed-out actions belong to one Session.
 * Company operation ids also connect revisions returned through different interfaces.
 */
async function actionIdentity(approval: NewApproval): Promise<ActionIdentity> {
  const binding = approval.binding;
  const owner = canonicalJson(binding.account !== null ? ["account", binding.account]
    : (approval.kind === "browse-submit" || approval.kind === "web-operation") && binding.sessionId === null ? ["context", approval.binding.contextId] : ["session", binding.sessionId]);
  const operationId = approval.kind === "message-approval" || approval.kind === "web-operation" ? approval.approval.operation_id
    : approval.kind === "openapi" || approval.kind === "mcp" ? approval.call.approval?.operation_id ?? null : null;
  let action: Json;
  switch (approval.kind) {
    case "openapi":
      action = ["openapi", approval.method, approval.url, toJson(approval.call.params), approval.call.body !== undefined, approval.call.body ?? null, toJson(approval.call.files ?? {})];
      break;
    case "mcp": action = ["mcp", approval.call.apiUrl, approval.call.tool, approval.call.args]; break;
    case "message-approval": action = ["operation", approval.approval.operation_id]; break;
    case "browse-submit": action = toJson(["browse-submit", approval.submission]); break;
    // The browser's request that returned it: approving the operation repeats exactly that (0.4 Ops 6).
    case "web-operation": action = toJson(["browse-submit", approval.submission]); break;
  }
  return { key: await sha256(canonicalJson(action)), owner, operationId };
}

/**
 * Exact identities serialize concurrent attempts. An unknown outcome holds all writes at the issuer:
 * aliases, changed arguments, new Sessions and a different interface cannot prove a different action (Ops 7).
 * Reads do not ask for an approval and remain available to check what happened.
 */
function requireKnownOutcome(client: PoppyClient, issuer: string, action: ActionIdentity, except: readonly string[] = []): void {
  const handoffs = rows(client.sql, approvalRow, "SELECT * FROM poppy_approvals WHERE issuer = ? AND status = 'executing' AND terms_approval_id IS NOT NULL", issuer);
  const allowed = new Set(except);
  for (;;) {
    let added = false;
    for (const parent of handoffs) if (parent.terms_approval_id && allowed.has(parent.terms_approval_id) && !allowed.has(parent.id)) { allowed.add(parent.id); added = true; }
    if (!added) break;
  }
  const unresolved = rows(client.sql, approvalRow, `SELECT * FROM poppy_approvals
    WHERE issuer = ? AND outcome_resolution IS NULL AND (status = 'unknown' OR
      (status = 'executing' AND action_owner = ? AND (action_key = ? OR (? IS NOT NULL AND operation_id = ?))))`,
    issuer, action.owner, action.key, action.operationId, action.operationId).find(row => !allowed.has(row.id));
  if (unresolved) throw new ActionOutcomePending(unresolved.id);
}

/**
 * A write no operation covers (any write at a Company without the
 * extension, or one whose description doesn't say it proposes), an upload,
 * or a website submit waits for the User's click: the exact request is
 * stored, and only an approval makes it, once (spec, Safety). Returns the
 * approval id.
 */
export async function proposeLocal(
  client: PoppyClient,
  company: Company,
  label: string,
  summary: string,
  approval: NewApproval,
  /** A fixed id, so a replayed tool call shows the same card rather than a second one. */
  fixedId?: string,
  /** An operation's terms, for a Company's approval (Ops 5). */
  terms?: ApprovalTerms,
  /** A known approval_required response may hand its current executing request to a terms card. */
  replacesExecuting?: string,
  /** Task dispatch is durable too, but does not ask the User to approve an HTTP request. */
  publish = true,
  /** Persist a task call's canonical reference in the same synchronous step as selection. */
  recordTask?: (id: string) => string
): Promise<string> {
  if (publish && ((approval.kind === "mcp" && !approval.call.approval) ||
      (approval.kind === "openapi" && !approval.call.approval && !Object.keys(approval.call.files ?? {}).length))) {
    throw new PoppyError(
      "approval_changed",
      departure(ours("this write's approval"), ours("an approval of the Company's own terms"), ours("a preliminary approval, which isn't supported"), ours("Start the task again for the Company's current terms")),
      0
    );
  }
  const id = fixedId ?? randomId("apr_");
  const action = await actionIdentity(approval);
  const stored = storedApproval(approval);
  const attachments = approvalAttachments(stored);
  const existing = one(client.sql, approvalRow, "SELECT * FROM poppy_approvals WHERE id = ?", id);
  if (!publish && existing) {
    if (existing.issuer !== company.issuer || existing.label !== label || existing.request !== stored) {
      throw new PoppyError(
        "approval_changed",
        departure(ours("this tool call's request"), ours("the request it made first"), changedRequest(existing, { issuer: company.issuer, label, request: stored }), ours("Nothing will be sent again")),
        0
      );
    }
    return recordTask?.(id) ?? id;
  }
  if (!publish) {
    await expirePendingTerms(client, company.issuer, action);
    const candidates = rows(client.sql, approvalRow, "SELECT * FROM poppy_approvals WHERE issuer = ? AND action_owner = ? AND action_key = ? AND status IN ('pending', 'executing', 'terms')", company.issuer, action.owner, action.key)
      .filter(row => {
        const saved = readApproval(row.request);
        return saved.ok && (isTaskRequest(row.id) || ((saved.value.kind === "openapi" || saved.value.kind === "mcp") && saved.value.call.approval !== undefined) || (row.terms === null && row.terms_approval_id === null && fileDisclosure(saved.value))) &&
          canonicalJson(toJson(saved.value.binding)) === canonicalJson(toJson(approval.binding));
      }).sort((a, b) => {
        const priority = (row: typeof a) => row.status === "executing" ? 6 : isTaskRequest(row.id) ? 5 : row.terms !== null ? 4 : 1;
        return priority(b) - priority(a);
      });
    const waiting = candidates[0];
    requireKnownOutcome(client, company.issuer, action, waiting ? [waiting.id] : []);
    if (waiting) {
      // Retire every equivalent old disclosure synchronously. A late decision
      // on any sibling cannot create another send; each follows this outcome.
      for (const sibling of candidates) {
        const saved = readApproval(sibling.request);
        if (sibling.id === waiting.id || sibling.status !== "pending" || sibling.terms !== null || !saved.ok || !fileDisclosure(saved.value)) continue;
        client.sql.exec("UPDATE poppy_approvals SET status = 'terms', terms_approval_id = ? WHERE id = ? AND status = 'pending'", waiting.id, sibling.id);
        intent(client.sql, `task-selected|${sibling.id}`, () => "task");
        traceApproval(sibling.id);
      }
      return recordTask?.(waiting.id) ?? waiting.id;
    }
  }
  // 0.4 Ops 3: "A `summary` reworded without changing the terms can keep its revision." The card keeps
  // the words the User was shown. Other terms under a revision already shown break the Company's MUST, and aren't used.
  if (terms && existing?.terms && existing.issuer === company.issuer && existing.label === label && existing.request === stored) {
    if (canonicalJson(toJson({ ...existing.terms, summary: "" })) !== canonicalJson(toJson({ ...terms, summary: "" }))) {
      // A sentence's full stop closes it: a notice adds one of its own after it (conversations.ts).
      throw new PoppyError(
        "unusable_proposal",
        departure(shown`${show.name(company.name)}'s terms under a revision it had already sent`, ours("the terms it sent first under that revision"), changedTerms(existing.terms, terms), ours("They weren't used. The earlier card stands")),
        0
      );
    }
    summary = existing.summary;
    terms = existing.terms;
  }
  const replacing = replacesExecuting ? one(client.sql, approvalRow, "SELECT * FROM poppy_approvals WHERE id = ? AND issuer = ? AND status = 'executing'", replacesExecuting, company.issuer) : undefined;
  requireKnownOutcome(client, company.issuer, action, [
    ...(existing?.status === "pending" ? [id] : []), ...(replacing ? [replacing.id] : [])
  ]);
  // Returning the revision currently being sent is a known refusal; never
  // replace its request or make a self-link. Decision records are immutable.
  if (terms && existing?.status === "executing" && id === replacesExecuting && existing.issuer === company.issuer && existing.label === label && existing.summary === summary) return id;
  if (existing && (existing.issuer !== company.issuer || existing.label !== label || existing.request !== stored || existing.summary !== summary)) {
    throw new PoppyError(
      "approval_changed",
      departure(ours("this tool call's request"), ours("the request it proposed first"), changedRequest(existing, { issuer: company.issuer, label, request: stored, summary }), ours("Use a new call for fresh approval")),
      0
    );
  }
  if (publish) traceApproval(id);
  if (existing && existing.status !== "pending") return id;
  if (!existing) {
    client.rememberCompany("approval", id, company);
    client.sql.exec(
      "INSERT INTO poppy_approvals (id, issuer, label, summary, request, status, created_at, terms, action_key, action_owner, operation_id) VALUES (?, ?, ?, ?, ?, 'pending', ?, ?, ?, ?, ?)",
      id,
      company.issuer,
      label,
      summary,
      stored,
      Date.now(),
      terms ? JSON.stringify(terms) : null,
      action.key, action.owner, action.operationId
    );
  }
  // The known refusal handed this executing request to its terms card before the User can act reentrantly.
  if (replacing && replacing.id !== id) client.sql.exec("UPDATE poppy_approvals SET terms_approval_id = ? WHERE id = ? AND status = 'executing'", id, replacing.id);
  if (!publish) return recordTask?.(id) ?? id;
  await client.host.showCard({
    id: `approval-${id}`,
    kind: "approval",
    company: company.name,
    domain: company.domain,
    open: true,
    approvalId: id,
    summary,
    status: "pending",
    ...(terms ? { terms } : {}),
    ...attachments,
    ...batchKeyOf(company.issuer, stored)
  });
  return id;
}

function traceApproval(approvalId: string): void {
  const safe = logId(approvalId);
  if (!safe) return;
  const tool = currentTool();
  if (tool) tool.approval_id = safe;
  const event = currentEvent();
  const previous = event?.fields.approval_ids;
  const ids = Array.isArray(previous) ? previous.flatMap(value => logId(value) ?? []) : [];
  event?.set({ approval_ids: [...new Set([...ids, safe])].slice(-BATCH_LIMIT) });
}

function batchKeyOf(issuer: string, request: string): { batchKey?: string } {
  const key = approvalBatchKey(issuer, request);
  return key ? { batchKey: key } : {};
}

const approvalRow = approvalsTable.pick("id", "issuer", "label", "summary", "request", "status", "terms", "result", "terms_approval_id", "action_key", "action_owner", "operation_id", "notification_batch_id", "outcome_resolution", "outcome_resolved_at");

/** A fresh task may request new terms, but never revive or send an expired revision. */
async function expirePendingTerms(client: PoppyClient, issuer: string, action: ActionIdentity): Promise<void> {
  for (const row of rows(client.sql, approvalRow, "SELECT * FROM poppy_approvals WHERE issuer = ? AND action_owner = ? AND action_key = ? AND status = 'pending' AND terms IS NOT NULL", issuer, action.owner, action.key)) {
    if (!row.terms || Date.parse(row.terms.expiresAt) > Date.now()) continue;
    client.sql.exec("UPDATE poppy_approvals SET status = 'failed', result = 'Not sent: the Company terms expired before the User decided. Request current terms.' WHERE id = ? AND status = 'pending'", row.id);
    await repairTerminalApprovalCard(client, row.id);
  }
  await settleTermsApprovals(client);
}

/**
 * Send a task-authorized request, retaining its exact payload and outcome across replay.
 * Only a Company's operation (or a separate file-disclosure decision) asks for a click.
 * A fresh model call for a request already awaiting terms reuses those terms, without another send.
 */
export async function dispatchTaskRequest(client: PoppyClient, company: Company, label: string, summary: string, request: Extract<NewApproval, { kind: "openapi" | "mcp" }>, fixedId: string, beforeDispatch?: () => void): Promise<Json> {
  // Authority is captured in the immutable request, not the call fingerprint:
  // replay returns that original attempt even after sign-out or a known Session restart.
  const { binding: _binding, ...intent } = request;
  const hash = await sha256(canonicalJson(toJson({ issuer: company.issuer, label, request: intent })));
  const bound = one(client.sql, taskCallsTable.row, "SELECT * FROM poppy_task_calls WHERE call_id = ?", fixedId);
  if (bound && bound.request_hash !== hash) {
    throw new PoppyError("approval_changed", departure(ours("this tool call's task request"), ours("the request it made first"), ours("a different one"), ours("Nothing will be sent again")), 0);
  }
  const record = (target: string): string => {
    client.sql.exec("INSERT OR IGNORE INTO poppy_task_calls (call_id, request_id, request_hash) VALUES (?, ?, ?)", fixedId, target, hash);
    const saved = one(client.sql, taskCallsTable.row, "SELECT * FROM poppy_task_calls WHERE call_id = ?", fixedId);
    if (!saved || saved.request_hash !== hash) {
      throw new PoppyError("approval_changed", departure(ours("this task call's recorded request"), ours("the request this call makes"), saved ? ours("a different one") : ours("none"), ours("Nothing will be sent")), 0);
    }
    return saved.request_id;
  };
  const id = bound?.request_id ?? await proposeLocal(client, company, label, summary, request, fixedId, undefined, undefined, false, record);
  const trace = currentTool();
  if (trace) {
    const parent = isTaskRequest(id) ? id : one(client.sql, approvalsTable.pick("id"), "SELECT id FROM poppy_approvals WHERE terms_approval_id = ? AND id GLOB 'req_*' LIMIT 1", id)?.id;
    trace.task_request_id = logId(parent ?? id);
    trace.reused_pending = id !== fixedId;
  }
  return completeTaskRequest(client, id, beforeDispatch);
}

/** Canonical lifecycle projection across linked terms/revisions, without reading bodies. */
export function taskProjection(client: PoppyClient, id: string): { id: string; result: import("./approval-outcome").ApprovalResult } {
  const projection = approvalsTable.pick("id", "issuer", "label", "status", "outcome_resolution", "outcome_resolved_at");
  const initial = one(client.sql, projection, "SELECT id, issuer, label, status, outcome_resolution, outcome_resolved_at FROM poppy_approvals WHERE id = ?", id);
  if (!initial) throw new PoppyError("invalid_response", ours("The recorded lifecycle is missing. Nothing will be resent."), 0);
  let row: RowOf<typeof projection> = initial;
  const seen = new Set<string>([row.id]);
  for (;;) {
    const parent: RowOf<typeof projection> | undefined = one(client.sql, projection, "SELECT id, issuer, label, status, outcome_resolution, outcome_resolved_at FROM poppy_approvals WHERE terms_approval_id = ? AND issuer = ? AND label = ? ORDER BY (id GLOB 'req_*') DESC, created_at, id LIMIT 1", row.id, row.issuer, row.label);
    if (!parent) {
      const actual = linkedDecision(client.sql, row.id) ?? row;
      return { id: row.id, result: approvalResult(actual.status, storedResolution(actual)) };
    }
    if (seen.has(parent.id)) throw new PoppyError("invalid_response", ours("The task's lifecycle links are cyclic. Nothing will be resent."), 0);
    seen.add(parent.id);
    row = parent;
  }
}

async function closeLinkedDisclosures(client: PoppyClient, id: string): Promise<void> {
  const actual = one(client.sql, approvalRow, "SELECT * FROM poppy_approvals WHERE id = ?", id);
  if (!actual) return;
  const saved = readApproval(actual.request);
  const automatic = isTaskRequest(id) || (saved.ok && fileDisclosure(saved.value));
  const siblings = rows(client.sql, approvalRow, "SELECT * FROM poppy_approvals WHERE status = 'terms' AND terms_approval_id = ?", id).filter(row => taskRequested(client.sql, row.id));
  if (!siblings.length) return;
  let company = "the Company";
  let domain: string | undefined;
  try { const known = client.companyByIssuer(actual.issuer); company = known.name; domain = known.domain; } catch { /* Cached outcomes need no new discovery. */ }
  const status = actual.status === "executing" ? "approved" : actual.status === "pending" ? automatic ? "approved" : "terms" : actual.status;
  for (const sibling of siblings) {
    try {
      await client.host.showCard({ id: `approval-${sibling.id}`, kind: "approval", company, ...(domain ? { domain } : {}), open: false,
        approvalId: sibling.id, summary: sibling.summary, status, taskRequested: true,
        ...(actual.result ? { result: actual.result } : {}),
        ...approvalAttachments(sibling.request), ...batchKeyOf(sibling.issuer, sibling.request) });
    } catch { currentEvent()?.count("receipt_publication_failures"); } // Its durable decision is already retired; recovery repairs presentation.
  }
}

function fileDisclosure(request: NewApproval): boolean {
  return request.kind === "openapi" && !request.call.approval && Object.keys(request.call.files ?? {}).length > 0;
}

/** Only callers that verified their immutable input may resume this mapping. */
export async function resumeRecordedTask(client: PoppyClient, callId: string, beforeDispatch?: () => void): Promise<Json | undefined> {
  const bound = one(client.sql, taskCallsTable.pick("request_id"), "SELECT request_id FROM poppy_task_calls WHERE call_id = ?", callId);
  if (!bound) return undefined;
  const row = one(client.sql, approvalRow, "SELECT * FROM poppy_approvals WHERE id = ?", bound.request_id);
  if (!row) throw new PoppyError("invalid_response", ours("The recorded task is missing. Nothing will be resent."), 0);
  const trace = currentTool();
  if (trace) { trace.task_request_id = logId(row.id); trace.reused_pending = row.id !== callId; }
  return completeTaskRequest(client, row.id, beforeDispatch);
}

async function completeTaskRequest(client: PoppyClient, id: string, beforeDispatch?: () => void): Promise<Json> {
  const before = one(client.sql, approvalRow, "SELECT * FROM poppy_approvals WHERE id = ?", id);
  const saved = before ? readApproval(before.request) : undefined;
  const adopted = !isTaskRequest(id) && before?.terms === null && saved?.ok === true && fileDisclosure(saved.value);
  let failure: unknown;
  await closeLinkedDisclosures(client, id);
  if (isTaskRequest(id) || adopted) {
    try {
      await decideOne(client, id, "approve", undefined, { failed: error => { failure = error; }, beforeDispatch, showReceipt: adopted });
      await settleTermsApprovals(client);
      client.sql.exec("UPDATE poppy_approvals SET notification_pending = 0 WHERE id = ? AND status IN ('done', 'terms', 'refused', 'failed')", id);
      if (adopted) await repairTerminalApprovalCard(client, id);
    } catch (error) { failure ??= error; currentEvent()?.count("completion_repairs_needed"); }
  }
  const row = one(client.sql, approvalRow, "SELECT * FROM poppy_approvals WHERE id = ?", id);
  // Publication is not the business outcome. A committed success remains a
  // success, and an unknown outcome retains its own durable reference.
  if (row?.status === "done" && row.result) return jsonText(json)(row.result, "stored task result");
  if (row && failure && !(failure instanceof TermsRequested)) {
    const problem = failure instanceof ProblemError ? failure.problem : failure instanceof Error ? shown`The task failed: ${show.text(failure.message)}` : ours("The task failed");
    const error = failure instanceof PoppyError ? failure : new PoppyError("approval_changed", problem, 0);
    throw new PoppyError(error.code, error.problem, error.status, { ...error.detail, poppyTask: taskProjection(client, row.id) });
  }
  if (!row) throw new PoppyError("invalid_response", ours("The task's durable request is missing. Nothing will be resent."), 0);
  if (row.status === "terms" || (row.status === "pending" && !isTaskRequest(id))) {
    const trace = currentTool();
    if (trace) trace.approval_id = logId(row.terms_approval_id ?? id);
    const proposed = row.terms_approval_id ?? id;
    const instruction = standingInstructionFor(client, proposed);
    return instruction
      ? { proposed, ...onInstruction(instruction), again: "Do not make this request again." }
      : { proposed, note: "Waiting for the User's decision on the Company's terms. Do not make this request again." };
  }
  if (row.status === "pending" || row.status === "executing") return { status: "in_progress", note: "This request is already being handled. Do not send it again." };
  // Its recorded outcome can quote a Company's answer.
  const handled = row.result ? shown`This request was already handled: ${show.text(row.result, 1_000)}` : ours("This request was already handled. Check its outcome rather than sending it again.");
  throw new PoppyError("approval_changed", handled, 0, { poppyTask: taskProjection(client, row.id) });
}

/** Links reach the User without a model having to transcribe a signed checkout URL. */
async function showResultLinks(client: PoppyClient, id: string, company: string, result: string): Promise<void> {
  let value: Json;
  try { value = jsonText(json)(result, "stored Company result"); } catch { return; }
  const { links, rejected } = inspectResultLinks(value);
  const event = currentEvent();
  event?.set({ result_link_rejections: rejected });
  if (!links.length) return;
  event?.count("result_links", links.length);
  await client.host.showCard({
    id: `result-${id}`, kind: "notice", company, open: false,
    text: "Links returned by the Company. Each opens in a new tab; opening checkout is not confirmation of payment.",
    links
  }, { repair: true });
}

/** Reconstruct a committed outcome if its process died before returning the original notice. */
function recoveredDecisionNotice(client: PoppyClient, row: RowOf<typeof approvalRow>): string {
  let company = "the Company";
  try { company = client.companyByIssuer(row.issuer).name; } catch { /* Retain the generic name. */ }
  const resolution = storedResolution(row);
  if (resolution) return `[system] ${checkedOutcomeText(company, resolution.outcome)} Action: ${row.summary}. The original uncertain receipt is preserved. No request was resent.`;
  if (row.status === "unknown") return `[system] ${taskRequested(client.sql, row.id) ? "A task request" : "An approved action"} was interrupted and its outcome is unknown: ${row.summary}. Tell the User to check with ${company}; it won't be retried automatically.`;
  if (taskRequested(client.sql, row.id)) return `[system] Task request ${row.status}: ${row.summary}.${row.result ? ` Result: ${row.result}` : ""}`;
  const status = row.status === "terms" ? "Sent as the User approved; the Company's terms still need approval and nothing has happened yet" : BATCH_STATUS[row.status];
  return `[system] ${status ?? "The User decided this request"}: ${row.summary}.${row.result ? ` Result: ${row.result}` : ""}`;
}

/** Durable outbox: the claim arms it; a stable harness operation ID makes a replay idempotent. */
async function notifyApprovalDecision(client: PoppyClient, id: string, notice?: string): Promise<void> {
  const pending = one(client.sql, approvalsTable.pick("notification_pending", "notification"), "SELECT notification_pending, notification FROM poppy_approvals WHERE id = ?", id);
  if (!pending?.notification_pending) return;
  const row = one(client.sql, approvalRow, "SELECT * FROM poppy_approvals WHERE id = ?", id);
  if (!row || row.status === "pending" || row.status === "executing") return;
  // A handoff to terms is not completion and must not wake the model to recreate the request.
  // The terms card delivers the final decision, including for legacy two-card requests.
  if (row.status === "terms" || (taskRequested(client.sql, id) && row.status === "done")) {
    client.sql.exec("UPDATE poppy_approvals SET notification_pending = 0 WHERE id = ?", id);
    return;
  }
  if (!pending.notification) client.sql.exec("UPDATE poppy_approvals SET notification = ? WHERE id = ? AND notification IS NULL", JSON.stringify({ v: 1, id: randomId(`poppy-approval-${id}-`), text: notice ?? recoveredDecisionNotice(client, row) }), id);
  await deliverApprovalNotification(client, id, "decision");
}

/** Both outboxes retain their exact payload until the idempotent callback acknowledges it. */
async function deliverApprovalNotification(client: PoppyClient, id: string, kind: "decision" | "resolution"): Promise<void> {
  const row = one(client.sql, approvalsTable.pick("notification_pending", "notification", "resolution_notification_pending", "resolution_notification"),
    "SELECT notification_pending, notification, resolution_notification_pending, resolution_notification FROM poppy_approvals WHERE id = ?", id);
  if (!row) return;
  const pending = kind === "decision" ? row.notification_pending : row.resolution_notification_pending;
  const saved = kind === "decision" ? row.notification : row.resolution_notification;
  if (!pending || !saved) return;
  const prefix = kind === "decision" ? "" : "resolution_";
  await deliverSavedNotification(client, saved, () => {
    client.sql.exec(`UPDATE poppy_approvals SET ${prefix}notification_pending = 0 WHERE id = ? AND json_extract(${prefix}notification, '$.id') = ?`, id, saved.id);
  });
}

/** Delivery failure leaves the exact saved operation available for a later retry. */
async function deliverSavedNotification(client: PoppyClient, saved: { readonly id: string; readonly text: string }, acknowledge: () => void): Promise<void> {
  await client.host.notifyModel(saved.text, saved.id);
  acknowledge();
}

function outcomeResolution(row: { readonly outcome_resolution: "performed" | "not_performed" | null; readonly outcome_resolved_at: number | null }) {
  const resolution = storedResolution(row);
  return resolution ? { outcomeResolution: resolution } : {};
}

/** Rebuild the page's receipt from the durable User assertion, including after interruption. */
async function showResolvedApprovalCard(client: PoppyClient, id: string, options?: CardWriteOptions): Promise<void> {
  const current = one(client.sql, approvalRow, "SELECT * FROM poppy_approvals WHERE id = ?", id);
  if (!current || current.status !== "unknown" || current.outcome_resolution === null) return;
  if (isTaskRequest(id) && current.terms_approval_id) return;
  const company = client.companyByIssuer(current.issuer);
  await client.host.showCard({
    id: `approval-${current.id}`, kind: "approval", company: company.name, domain: company.domain,
    open: false, approvalId: current.id, summary: current.summary, status: "unknown",
    ...(current.terms ? { terms: current.terms } : {}), ...(current.result ? { result: current.result } : {}),
    ...outcomeResolution(current), ...approvalAttachments(current.request), ...batchKeyOf(current.issuer, current.request)
  }, options);
}

/** A committed terminal result must reach the receipt before its pending notice is acknowledged. */
async function repairTerminalApprovalCard(client: PoppyClient, id: string): Promise<void> {
  const current = one(client.sql, approvalRow, "SELECT * FROM poppy_approvals WHERE id = ?", id);
  if (!current || !finishedApproval(current.status)) return;
  if (isTaskRequest(id) && current.terms_approval_id) return;
  if (current.status === "done" && current.result) {
    let company = "the Company";
    try { company = client.companyByIssuer(current.issuer).name; } catch { /* Keep historical receipts repairable. */ }
    await showResultLinks(client, id, company, current.result);
    if (isTaskRequest(id)) return;
  }
  const previous = one(client.sql, cardsTable.pick("card"), "SELECT card FROM poppy_cards WHERE id = ?", `approval-${id}`);
  if (previous) {
    try {
      const card: unknown = JSON.parse(previous.card);
      // Keep a valid existing answer's status/code and other presentation details.
      if (isObject(card) && card.kind === "approval" && card.status === current.status &&
          JSON.stringify(card.outcomeResolution) === JSON.stringify(outcomeResolution(current).outcomeResolution)) return;
    } catch { /* Reconstruct an unreadable receipt from its durable decision. */ }
  }
  let company = "the Company";
  let domain: string | undefined;
  try {
    const stored = client.companyByIssuer(current.issuer);
    company = stored.name;
    domain = stored.domain;
  } catch { /* Historical records can lack a resumable Company context. */ }
  await client.host.showCard({
    id: `approval-${id}`, kind: "approval", company, ...(domain ? { domain } : {}),
    open: false, approvalId: id, summary: current.summary, status: current.status,
    ...(taskRequested(client.sql, id) ? { taskRequested: true } : {}),
    ...(current.terms ? { terms: current.terms } : {}), ...(current.result ? { result: current.result } : {}),
    ...outcomeResolution(current), ...approvalAttachments(current.request), ...batchKeyOf(current.issuer, current.request)
  }, { repair: true });
}

/**
 * Only the trusted page can record the User's reconciliation after checking with the Company.
 * Preserve the original unknown receipt, and record this assertion separately. It never resends a request.
 */
export async function resolveApprovalOutcome(client: PoppyClient, id: string, outcome: "performed" | "not_performed"): Promise<void> {
  const selected = one(client.sql, approvalRow, "SELECT * FROM poppy_approvals WHERE id = ?", id);
  if (!selected || selected.status !== "unknown") {
    throw new PoppyError(
      "invalid_request",
      departure(ours("the receipt to reconcile"), ours("one with an unknown outcome"), selected ? shown`one whose status is ${show.code(selected.status)}` : ours("no such receipt"), ours("Nothing was sent")),
      0
    );
  }
  // One request can have an internal task record and several Company revisions.
  const candidates = rows(client.sql, approvalRow, "SELECT * FROM poppy_approvals WHERE issuer = ? AND label = ? AND status IN ('unknown', 'terms')", selected.issuer, selected.label);
  const linked = new Set([id]);
  for (;;) {
    let added = false;
    for (const row of candidates) {
      if (row.terms_approval_id && (linked.has(row.id) || linked.has(row.terms_approval_id))) {
        for (const next of [row.id, row.terms_approval_id]) if (!linked.has(next)) { linked.add(next); added = true; }
      }
    }
    if (!added) break;
  }
  const at = Date.now();
  const group = candidates.filter(row => linked.has(row.id));
  // Claim the whole linked action before showing any card: two pages may reconcile opposite outcomes.
  const earlier = group.filter(row => row.outcome_resolution !== null && row.outcome_resolved_at !== null)
    .sort((a, b) => a.outcome_resolved_at! - b.outcome_resolved_at!)[0];
  const resolved = earlier?.outcome_resolution ?? outcome;
  const resolvedAt = earlier?.outcome_resolved_at ?? at;
  const notice = JSON.stringify({ v: 1, id: randomId(`poppy-resolution-${id}-`), text: `[system] The User checked with the Company and reports that this action ${resolved === "performed" ? "happened" : "did not happen"}: ${selected.summary}. The original uncertain receipt is preserved. No request was resent.` });
  if (group.length) client.sql.exec(`UPDATE poppy_approvals SET outcome_resolution = ?, outcome_resolved_at = ?,
    resolution_notification_pending = CASE WHEN id = ? AND ? THEN 1 ELSE resolution_notification_pending END,
    resolution_notification = CASE WHEN id = ? AND ? THEN ? ELSE resolution_notification END
    WHERE id IN (${group.map(() => "?").join(",")}) AND outcome_resolution IS NULL AND status IN ('unknown', 'terms')`,
    resolved, resolvedAt, id, earlier ? 0 : 1, id, earlier ? 0 : 1, notice, ...group.map(row => row.id));
  for (const row of candidates) {
    if (!linked.has(row.id)) continue;
    await showResolvedApprovalCard(client, row.id, { repair: earlier !== undefined });
  }
  for (const row of group) await deliverApprovalNotification(client, row.id, "resolution");
}

type FinishedApproval = "declined" | "done" | "refused" | "failed" | "unknown";
function finishedApproval(status: string): status is FinishedApproval {
  return status === "declined" || status === "done" || status === "refused" || status === "failed" || status === "unknown";
}

/** Carry the attempt's outcome and any User reconciliation through linked terms cards. */
async function settleTermsApprovals(client: PoppyClient): Promise<void> {
  // A child can finish before its parent receives TermsRequested, or during a restart.
  // Re-read durable links rather than relying on the order in which cards arrived.
  for (;;) {
    const parents = rows(client.sql, approvalRow, "SELECT * FROM poppy_approvals WHERE status = 'terms' AND terms_approval_id IS NOT NULL");
    let changed = false;
    for (const parent of parents) {
      const child = one(client.sql, approvalRow, "SELECT * FROM poppy_approvals WHERE id = ? AND issuer = ? AND label = ?", parent.terms_approval_id, parent.issuer, parent.label);
      if (!child || !finishedApproval(child.status)) continue;
      const company = client.companyByIssuer(parent.issuer);
      if (!isTaskRequest(parent.id)) await client.host.showCard({
        id: `approval-${parent.id}`, kind: "approval", company: company.name, domain: company.domain,
        open: false, approvalId: parent.id, summary: parent.summary, status: child.status,
        ...(taskRequested(client.sql, parent.id) ? { taskRequested: true } : {}),
        ...(parent.terms ? { terms: parent.terms } : {}),
        ...(child.result ? { result: child.result } : {}),
        ...outcomeResolution(child),
        ...approvalAttachments(parent.request), ...batchKeyOf(parent.issuer, parent.request)
      });
      // Persist the card first. A crash before this update leaves a durable link
      // to replay on recovery, rather than a terminal row with a stale card.
      const claimed = client.sql.exec(
        "UPDATE poppy_approvals SET status = ?, result = ?, outcome_resolution = ?, outcome_resolved_at = ? WHERE id = ? AND status = 'terms' AND terms_approval_id = ? RETURNING id",
        child.status, child.result, child.outcome_resolution, child.outcome_resolved_at, parent.id, child.id
      ).toArray();
      changed ||= claimed.length > 0;
    }
    if (!changed) break;
  }
}

/**
 * Decide one local approval and do what it says. Returns what the model is to
 * be told, or null when it was already decided; the caller tells the model,
 * once for one card and once for a batch (`decideLocal`, `decideLocalBatch`).
 */
async function decideOne(
  client: PoppyClient,
  id: string,
  decision: "approve" | "decline",
  batch?: string,
  task?: { failed(error: unknown): void; beforeDispatch?: (() => void) | undefined; showReceipt?: boolean },
  /** The agent approves on this standing instruction (0.4 Ops 5), instead of the User's tap. */
  agent?: Instruction
): Promise<string | null> {
  const row = one(client.sql, approvalRow, "SELECT * FROM poppy_approvals WHERE id = ?", id);
  if (!row || row.status !== "pending") return null;
  const company = await client.resumeCompany(row.issuer, "approval", id);
  // Discovery may have yielded to another decision. Only one handler may
  // claim this exact pending request, including a decline racing an approval.
  const claimed = client.sql.exec(
    "UPDATE poppy_approvals SET status = ?, notification_pending = 1, notification = NULL, notification_batch_id = ?, approver = ?, instruction_id = ? WHERE id = ? AND status = 'pending' AND issuer = ? AND label = ? AND request = ? AND summary = ? RETURNING id",
    decision === "decline" ? "declined" : "executing", batch ?? null, agent ? "agent" : "user", agent?.id ?? null, id, row.issuer, row.label, row.request, row.summary
  ).toArray();
  if (claimed.length === 0) return null;
  const approvedAt = Date.now();
  if (task) intent(client.sql, `task-selected|${id}`, () => "task");
  // The claim is authoritative even if a crash precedes this compatibility snapshot.
  if (batch) client.sql.exec("UPDATE poppy_approval_batches SET ids = (SELECT json_group_array(id) FROM poppy_approvals WHERE notification_batch_id = ?) WHERE id = ?", batch, batch);
  const card = async (status: "approved" | "declined" | "done" | "terms" | "refused" | "failed" | "unknown", result?: string, answer?: { status: number; error?: string }) => {
    if (status === "done" && result) await showResultLinks(client, id, company.name, result);
    if (task && !task.showReceipt && status !== "unknown" && status !== "failed" && status !== "refused") return;
    await client.host.showCard({
      id: `approval-${id}`,
      kind: "approval",
      company: company.name,
      domain: company.domain,
      open: false,
      approvalId: id,
      summary: row.summary,
      status,
      ...(taskRequested(client.sql, id) ? { taskRequested: true } : {}),
      ...(row.terms ? { terms: row.terms } : {}),
      ...(result ? { result } : {}),
      ...(answer ? { answer } : {}),
      ...approvalAttachments(row.request),
      ...batchKeyOf(row.issuer, row.request)
    });
  };
  if (decision === "decline") {
    await card("declined");
    return `[system] The User declined: ${row.summary}`;
  }
  // A request stored in another form, or tampered with, is never sent.
  const read = readApproval(row.request);
  if (!read.ok) {
    const result = `Not sent: this approval can't be sent, because ${read.problem}. Nothing was sent; ask again if you still want it.`;
    client.sql.exec("UPDATE poppy_approvals SET status = 'failed', result = ? WHERE id = ?", result, id);
    await card("failed", result);
    return `[system] The User approved, but the stored request couldn't be sent (${read.problem}), so nothing was sent: ${row.summary}. Ask again if the User still wants it.`;
  }
  // The card says it is being sent, so a page shows each one's progress (a batch's tiles, the step that asked).
  await card("approved");
  const sent = task ? "Sent for your task" : agent ? `Sent on your instruction "${agent.text}"` : "Sent as you approved";
  // What the model is told approved it.
  const approvedBy = agent ? `the agent approved on the User's standing instruction "${agent.text}"` : "the User approved";
  let result: string;
  try {
    result = await run(client, company, read.value, row.label, { approvalId: id, approvedAt, ...(agent ? { approver: "agent" as const } : {}), beforeDispatch: () => {
      const current = one(client.sql, approvalRow, "SELECT * FROM poppy_approvals WHERE id = ?", id);
      if (!current || current.status !== "executing" || current.request !== row.request || current.issuer !== row.issuer || current.label !== row.label) {
        throw new PoppyError(
          "approval_changed",
          departure(ours("the stored approval"), ours("the request as approved, still being sent"), current ? changedRequest({ ...row, status: "executing" }, current) : ours("none"), ours("No further attempt will be sent")),
          0
        );
      }
      // Ops 5: an instruction withdrawn before the approval is sent stops it.
      if (agent && !standingInstructionFor(client, id)) {
        throw new PoppyError("approval_changed", shown`The User withdrew the instruction ${show.text(agent.text)}, so this approval wasn't sent`, 0);
      }
      task?.beforeDispatch?.();
      if (current.action_key && current.action_owner) requireKnownOutcome(client, current.issuer, { key: current.action_key, owner: current.action_owner, operationId: current.operation_id }, [id]);
    } });
  } catch (error) {
    task?.failed(error);
    if (error instanceof OperationOutcomeUnknown) {
      // A Company message read while sending may already have settled it, as a decline does (0.4 Ops 6).
      const settled = one(client.sql, approvalsTable.pick("status"), "SELECT status FROM poppy_approvals WHERE id = ?", id);
      if (settled && settled.status !== "executing") return null;
      client.sql.exec("UPDATE poppy_approvals SET status = 'unknown', result = ? WHERE id = ?", error.message, id);
      await card("unknown", error.message);
      return `[system] ${error.message} Check with ${company.name} before approving this action again.`;
    }
    if (error instanceof ApprovalDeclined) {
      // 0.4 Ops 6: not a failure and never resent; after it, only the User approves this action again.
      recordDecline(client, row.issuer, error.operationId);
      const result = `${sent}. ${declineText(company, error)}`;
      client.sql.exec("UPDATE poppy_approvals SET status = 'refused', result = ? WHERE id = ?", result, id);
      await card("refused", result, { status: 403, error: "approval_declined" });
      return declineForModel(company, error, row.summary);
    }
    if (error instanceof TermsRequested) {
      client.sql.exec("UPDATE poppy_approvals SET status = 'terms', result = ?, terms_approval_id = ? WHERE id = ?", error.result, error.approvalId, id);
      await card("terms", error.result);
      return `[system] Sent as ${approvedBy}, and ${company.name} asks the User to approve its exact terms first, on a new card; nothing has happened yet: ${row.summary}. Don't tell the User it was done.`;
    }
    // A Company's refusal keeps its code, as tool failures show it.
    const message = error instanceof PoppyError ? `${sentence(error.problem)} [${error.code}]` : error instanceof Error ? error.message : String(error);
    const answer = answerOf(error);
    const name = company.name;
    const unreadableStatus = unreadableAnswerOf(error);
    if (unreadableStatus !== undefined) {
      const result = `${sent}; ${name} answered HTTP ${unreadableStatus}, but its response could not be read or validated. It may have processed the request. Check with ${name} before asking again; this request will not be resent automatically.`;
      client.sql.exec("UPDATE poppy_approvals SET status = 'unknown', result = ? WHERE id = ?", result, id);
      await card("unknown", result, { status: unreadableStatus });
      return `[system] The approved request reached ${name} and answered HTTP ${unreadableStatus}, but its result could not be read or validated. It may have happened. Tell the User to check with ${name}; do not retry automatically: ${row.summary}.`;
    }
    if (answer === "none") {
      // Sent, and no answer came: it may have happened (Safety). Never retried.
      const result = `${sent}, but no answer came from ${name}, so it may or may not have reached them. Check with ${name} before asking again.`;
      client.sql.exec("UPDATE poppy_approvals SET status = 'unknown', result = ? WHERE id = ?", result, id);
      await card("unknown", result);
      return `[system] Sent as ${approvedBy}, but no answer came from ${name} (${message}), so it may or may not have happened: ${row.summary}. Tell the User to check with ${name}; it won't be retried automatically.`;
    }
    if (typeof answer === "number" && answer >= 500) {
      const result = `${sent}; ${name} answered HTTP ${answer}, which does not establish whether the action took effect. Check with ${name} before approving further writes there.`;
      client.sql.exec("UPDATE poppy_approvals SET status = 'unknown', result = ? WHERE id = ?", result, id);
      await card("unknown", result, { status: answer });
      return `[system] ${result} No new operation for this action may be approved until its outcome is known: ${row.summary}.`;
    }
    if (typeof answer === "number") {
      // The Company answered, and not with success: sent as approved, not done as far as it says.
      const code = error instanceof PoppyError && error.code !== `http_${answer}` ? error.code : undefined;
      const answered = `${answer}${code ? ` (${code})` : ""}`;
      const result = `${sent}, but ${name} answered ${answered}. Nothing changed unless ${name} says otherwise.`;
      client.sql.exec("UPDATE poppy_approvals SET status = 'refused', result = ? WHERE id = ?", result, id);
      await card("refused", result, { status: answer, ...(code ? { error: code } : {}) });
      return `[system] Sent as ${approvedBy}, but ${name} answered ${answered}, so it wasn't done as far as ${name} says: ${row.summary}. Don't tell the User it was done. ${message}`;
    }
    // No answer marked: the agent refused it before sending, couldn't get an access token, or couldn't read the answer.
    client.sql.exec("UPDATE poppy_approvals SET status = 'failed', result = ? WHERE id = ?", message, id);
    await card("failed", message);
    return `[system] The approved action failed: ${row.summary}. ${message}`;
  }
  // A receipt failure cannot change a completed business action into a failed one.
  client.sql.exec("UPDATE poppy_approvals SET status = 'done', result = ? WHERE id = ?", result, id);
  await card("done", result);
  return `[system] Done, as ${approvedBy}: ${row.summary}. Result: ${result}`;
}

/**
 * The `poppy-agent-approval` job: approve a revision on the standing
 * instruction the check found for it (instructions.ts), unless the User has
 * decided it since or withdrawn the instruction, and tell the model what
 * happened. Never run inside the request that returned the operation.
 */
export async function decideAsAgent(client: PoppyClient, id: string): Promise<void> {
  const instruction = standingInstructionFor(client, id);
  const row = one(client.sql, approvalRow, "SELECT * FROM poppy_approvals WHERE id = ?", id);
  if (!instruction || !row || row.status !== "pending") {
    settleSpend(client, id);
    return;
  }
  let notice: string | null;
  try {
    notice = await decideOne(client, id, "approve", undefined, undefined, instruction);
  } finally {
    settleSpend(client, id);
  }
  await settleTermsApprovals(client);
  if (notice) await notifyApprovalDecision(client, id, notice);
}

/** Decide one local approval, from its own card, and tell the model what happened. */
export async function decideLocal(client: PoppyClient, id: string, decision: "approve" | "decline"): Promise<void> {
  let notice = await decideOne(client, id, decision);
  await settleTermsApprovals(client);
  const settled = one(client.sql, approvalRow, "SELECT * FROM poppy_approvals WHERE id = ?", id);
  if (notice && settled?.terms_approval_id && finishedApproval(settled.status)) {
    // The child may have been decided while the original request was still
    // returning its terms. Do not tell the model it is still waiting.
    notice = `[system] The Company's terms for ${settled.summary} are ${settled.status}.${settled.result ? ` Result: ${settled.result}` : ""}`;
  }
  if (notice) await notifyApprovalDecision(client, id, notice);
}

/** The most approvals one card decides: a print shop keeps 100 photos a Session. */
export const BATCH_LIMIT = 100;

/**
 * Approvals the User decided together on one card (`poppy.approvals`). Every
 * one must still be waiting and share one batch key (`approvalBatchKey`):
 * uploads of the User's photos to one Company's same method and URL. A batch
 * that mixes anything else is refused whole, so a request can't ride along
 * on another's card. They are sent one at a time, each recorded on its own
 * row, and the model is told once, when all are done, rather than starting
 * a turn for each. Ones already decided are skipped, so a replay is harmless.
 */
export async function decideLocalBatch(client: PoppyClient, decisions: readonly { approvalId: string; decision: "approve" | "decline" }[]): Promise<void> {
  const ids = decisions.map((item) => item.approvalId);
  if (decisions.length === 0 || decisions.length > BATCH_LIMIT || new Set(ids).size !== ids.length) {
    const got = new Set(ids).size !== ids.length ? ours("the same request more than once") : show.count(decisions.length, ours("request"), ours("requests"));
    throw new PoppyError("batch_refused", departure(ours("the requests decided at once"), shown`1 to ${BATCH_LIMIT} different requests`, got), 0);
  }
  const waiting = decisions.flatMap((item) => {
    const row = one(client.sql, approvalRow, "SELECT * FROM poppy_approvals WHERE id = ?", item.approvalId);
    return row && row.status === "pending" ? [{ ...item, row }] : [];
  });
  if (waiting.length === 0) return;
  const keys = new Set(waiting.map((item) => approvalBatchKey(item.row.issuer, item.row.request)));
  if (keys.size !== 1 || keys.has(undefined)) {
    throw new PoppyError(
      "batch_refused",
      departure(
        ours("the requests decided together"),
        ours("uploads of the User's photos to one Company's same method and URL"),
        keys.has(undefined) ? ours("a request that isn't such an upload") : ours("uploads to different places"),
        ours("Decide each on its own card")
      ),
      0
    );
  }
  // Only IDs read from validated, owned rows—not arbitrary frame strings.
  currentEvent()?.set({ approval_ids: waiting.map(item => logId(item.row.id)).flatMap(value => value ?? []) });
  const batch = randomId("apb_");
  client.sql.exec(
    "INSERT INTO poppy_approval_batches (id, ids, told, created_at) VALUES (?, ?, 0, ?)",
    batch,
    "[]",
    Date.now()
  );
  const lines: string[] = [];
  for (const item of waiting) {
    try {
      const notice = await decideOne(client, item.approvalId, item.decision, batch);
      if (notice) lines.push(notice.replace(/^\[system\] /, ""));
    } catch (error) {
      // Publication can fail after the action committed. Report its durable outcome, never undo it.
      const committed = one(client.sql, approvalRow, "SELECT * FROM poppy_approvals WHERE id = ?", item.approvalId);
      if (committed?.notification_batch_id === batch && finishedApproval(committed.status)) lines.push(recoveredDecisionNotice(client, committed).replace(/^\[system\] /, ""));
      else lines.push(`This one couldn't be decided (${error instanceof PoppyError ? error.code : "error"}): ${item.row.summary}`);
    }
  }
  await settleTermsApprovals(client);
  await tellBatch(client, batch, lines);
}

async function tellBatch(client: PoppyClient, batch: string, lines: readonly string[]): Promise<void> {
  for (const row of rows(client.sql, approvalsTable.pick("id"),
    "SELECT id FROM poppy_approvals WHERE notification_batch_id = ? OR id IN (SELECT value FROM json_each((SELECT ids FROM poppy_approval_batches WHERE id = ?)))", batch, batch)) {
    await repairTerminalApprovalCard(client, row.id);
  }
  if (lines.length) {
    const notification = { v: 1, id: `poppy-approvals-${batch}`, text: `[system] The User decided ${lines.length === 1 ? "this request" : `${lines.length} requests together`} on one card:\n${lines.map((line, index) => `${index + 1}. ${line}`).join("\n")}` };
    client.sql.exec("UPDATE poppy_approval_batches SET notification = ? WHERE id = ? AND notification IS NULL", JSON.stringify(notification), batch);
  }
  const saved = one(client.sql, approvalBatchesTable.pick("notification"), "SELECT notification FROM poppy_approval_batches WHERE id = ?", batch)?.notification;
  const acknowledge = () => {
    client.sql.exec("UPDATE poppy_approval_batches SET told = 1 WHERE id = ?", batch);
    client.sql.exec("UPDATE poppy_approvals SET notification_pending = 0 WHERE notification_batch_id = ?", batch);
  };
  if (saved) await deliverSavedNotification(client, saved, acknowledge);
  else acknowledge();
}

const BATCH_STATUS: Record<string, string> = {
  declined: "The User declined",
  done: "Done, as the User approved",
  refused: "Sent as the User approved, but the Company refused it, so it wasn't done as far as the Company says",
  failed: "The approved action failed",
  unknown: "Its outcome is unknown: it may or may not have happened, and it won't be retried automatically"
};

/**
 * After a restart: a batch the agent stopped part way through. Run after
 * `recoverInterruptedApprovals`, so one stopped mid-call already reads
 * unknown. The model is told what each row says; one still waiting keeps its
 * card, for the User to decide again.
 */
export async function recoverApprovalBatches(client: PoppyClient): Promise<void> {
  await settleTermsApprovals(client);
  for (const batch of rows(client.sql, approvalBatchesTable.pick("id", "ids", "notification"), "SELECT id, ids, notification FROM poppy_approval_batches WHERE told = 0")) {
    if (batch.notification) {
      await tellBatch(client, batch.id, []);
      continue;
    }
    let ids: unknown;
    try {
      ids = JSON.parse(batch.ids);
    } catch {
      ids = [];
    }
    const members = new Set(Array.isArray(ids) ? ids.filter((id): id is string => typeof id === "string") : []);
    for (const row of rows(client.sql, approvalsTable.pick("id"), "SELECT id FROM poppy_approvals WHERE notification_batch_id = ?", batch.id)) members.add(row.id);
    const lines = [...members].flatMap((id) => {
      const row = typeof id === "string" ? one(client.sql, approvalsTable.pick("summary", "status", "result", "issuer", "outcome_resolution", "outcome_resolved_at"), "SELECT summary, status, result, issuer, outcome_resolution, outcome_resolved_at FROM poppy_approvals WHERE id = ?", id) : undefined;
      const resolution = row ? storedResolution(row) : undefined;
      if (row && ["waiting", "in_progress"].includes(approvalResult(row.status, resolution))) return [];
      if (row && resolution) {
        let company = "the Company";
        try { company = client.companyByIssuer(row.issuer).name; } catch { /* Keep the generic name. */ }
        return [`${checkedOutcomeText(company, resolution.outcome)} Action: ${row.summary}.`];
      }
      const status = row ? BATCH_STATUS[row.status] : undefined;
      if (!row || !status) return [];
      return [`${status}: ${row.summary}.${row.status === "done" && row.result ? ` Result: ${row.result}` : ""}`];
    });
    await tellBatch(client, batch.id, lines);
  }
}

/**
 * An approved request the Company answered with success, but whose result it
 * said wasn't ready, kept before the agent follows it up (openapi-dispatch.ts
 * `settledAnswer`): the result a restart during those waits finishes it with.
 */
const answeredKey = (approvalId: string) => `answered-before-follow-up|${approvalId}`;
export function recordAnsweredBeforeFollowUp(sql: Sql, approvalId: string, result: string): void {
  intent(sql, answeredKey(approvalId), () => result);
}

/** Recover interrupted attempts without resending, and repair reconciled receipts without reviving history. */
export async function recoverInterruptedApprovals(client: PoppyClient): Promise<void> {
  // A known approval_required handoff belongs to its terms card even if publication
  // interrupted the initial task before it could record the final waiting state.
  client.sql.exec("UPDATE poppy_approvals SET status = 'terms' WHERE status = 'executing' AND terms_approval_id IS NOT NULL");
  // A task record created before dispatch began is not a card waiting for a click.
  // After a crash report that no action was sent rather than leaving it pending forever.
  client.sql.exec("UPDATE poppy_approvals SET status = 'failed', result = 'Interrupted before dispatch. Nothing was sent.', notification_pending = 1 WHERE id GLOB 'req_*' AND status = 'pending'");
  // One in a batch the model hasn't heard about yet is told with its batch (recoverApprovalBatches).
  // Old batches lack authoritative ownership. Their individual pending notices remain eligible;
  // a one-time duplicate is safer than discarding a decision another handler may have owned.
  const batched = new Set(rows(client.sql, approvalsTable.pick("id"),
    "SELECT a.id FROM poppy_approvals a JOIN poppy_approval_batches b ON b.id = a.notification_batch_id WHERE b.told = 0").map(row => row.id));
  for (const row of rows(client.sql, approvalRow, "SELECT * FROM poppy_approvals WHERE status = 'executing'")) {
    let company = "the company";
    let domain: string | undefined;
    try {
      ({ name: company, domain } = client.companyByIssuer(row.issuer));
    } catch {
      // Unknown issuer; keep the generic name.
    }
    // The Company answered with success before the agent stopped following it up: it was done.
    const answered = one(client.sql, intentsTable.pick("value"), "SELECT value FROM poppy_intents WHERE call_key = ?", answeredKey(row.id))?.value;
    if (answered !== undefined) {
      client.sql.exec("UPDATE poppy_approvals SET status = 'done', result = ?, notification_pending = 1 WHERE id = ? AND status = 'executing'", answered, row.id);
      await showResultLinks(client, row.id, company, answered);
      await client.host.showCard({
        id: `approval-${row.id}`, kind: "approval", company, ...(domain ? { domain } : {}), open: false, approvalId: row.id, summary: row.summary, status: "done",
        ...(taskRequested(client.sql, row.id) ? { taskRequested: true } : {}),
        ...(row.terms ? { terms: row.terms } : {}),
        result: answered,
        ...approvalAttachments(row.request), ...batchKeyOf(row.issuer, row.request)
      });
      if (batched.has(row.id)) continue;
      await notifyApprovalDecision(client, row.id,
        `[system] Done, as approved: ${row.summary}. ${company} said its result wasn't ready yet, and the agent restarted before it was, so details such as a payment link may be missing. Result: ${answered} Tell the User, and offer to check with ${company}; don't send the request again.`);
      continue;
    }
    client.sql.exec(
      "UPDATE poppy_approvals SET status = 'unknown', result = ?, notification_pending = 1 WHERE id = ?",
      `Interrupted ${taskRequested(client.sql, row.id) ? "during your task" : "after you approved"}, so it may or may not have reached ${company}. Check with ${company} before asking again.`,
      row.id
    );
    await client.host.showCard({
      id: `approval-${row.id}`,
      kind: "approval",
      company,
      open: false,
      approvalId: row.id,
      summary: row.summary,
      status: "unknown",
      ...(taskRequested(client.sql, row.id) ? { taskRequested: true } : {}),
      ...(row.terms ? { terms: row.terms } : {}),
      result: `It may have happened: check with ${company} before asking again.`,
      ...approvalAttachments(row.request)
    });
    if (batched.has(row.id)) continue;
    await notifyApprovalDecision(client, row.id,
      `[system] ${taskRequested(client.sql, row.id) ? "A task request" : "An approved action"} was interrupted and its outcome is unknown: ${row.summary}. Tell the User to check with ${company}; it won't be retried automatically.`,
    );
  }
  await settleTermsApprovals(client);
  // Terms can be committed and linked before their first card reaches storage.
  // Repair publication only: never decide, resend, or show the internal req_ row.
  for (const row of rows(client.sql, approvalRow, "SELECT * FROM poppy_approvals WHERE status = 'pending' AND terms IS NOT NULL")) {
    if (isTaskRequest(row.id) || !row.terms) continue;
    const saved = readApproval(row.request);
    if (!saved.ok) continue;
    const company = client.companyByIssuer(row.issuer);
    await client.host.showCard({
      id: `approval-${row.id}`, kind: "approval", company: company.name, domain: company.domain,
      open: true, approvalId: row.id, summary: row.summary, status: "pending", terms: row.terms,
      ...approvalAttachments(row.request), ...batchKeyOf(row.issuer, row.request)
    }, { repair: true });
  }
  for (const row of rows(client.sql, approvalsTable.pick("id"), "SELECT id FROM poppy_approvals WHERE notification_pending = 1")) {
    await repairTerminalApprovalCard(client, row.id);
    if (!batched.has(row.id)) await notifyApprovalDecision(client, row.id);
  }
  for (const row of rows(client.sql, approvalRow, "SELECT * FROM poppy_approvals WHERE status = 'unknown' AND outcome_resolution IS NOT NULL")) {
    await showResolvedApprovalCard(client, row.id, { repair: true });
  }
  for (const row of rows(client.sql, approvalsTable.pick("id"), "SELECT id FROM poppy_approvals WHERE resolution_notification_pending = 1")) {
    await deliverApprovalNotification(client, row.id, "resolution");
  }
}
