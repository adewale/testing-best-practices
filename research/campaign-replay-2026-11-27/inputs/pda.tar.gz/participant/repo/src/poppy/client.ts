import type { JWK } from "jose";
import {
  boundedCacheSeconds,
  discover,
  isCompany,
  tokenHostAllowed,
  DiscoveryError,
  type Company,
  type WebsiteOnly
} from "./discovery";
import { assertPublicHost, fetchJson, POPPY_TIMEOUTS, raceAbort, readLimited, timeoutError, withDeadline, type IdentifiedFetcher, type PoppyTimeouts } from "./fetch";
import { isObject, JsonError, parseStrictJson, type Json } from "./json";
import { sameAuthority, sessionAuthority } from "./authority";
import { DecodeError, number, object, optional, string, type Decoded } from "../decode";
import {
  clientAssertion,
  delegate,
  delegationUsable,
  dpopProof,
  newDpopKey,
  newStoredDpopKey,
  randomId,
  sessionJwt,
  storedDpopKey,
  type Delegated,
  type DpopKey
} from "./jwt";
import { currentKey, readIdentity, type AgentIdentity } from "./keys";
import { recordDiscovery, recordLimitWait, recordOauth, recordPageLimit, recordResource, type Followup, type ResourceAuth } from "./protocol-log";
import { found, one, rows, type RowOf } from "../rows";
import { accountsTable, domainsTable, dpopKeysTable, dpopNoncesTable, intentsTable, taskContextsTable, Sealer, sessionsTable, userIdsTable, type Sql } from "./store";
import type { Card, DirectUpdate } from "./wire";
import type { CheckedApiRequest } from "./apis";
import { declaration, declarationHeaders, sameDeclaration, type Declaration } from "./declaration";
import { companyErrorCode, type KnownErrorCode, type PoppyErrorCode } from "./error-codes";
import type { EndpointRequest } from "./outgoing";
import type { Issuer } from "./issuer";
import { FOREIGN_TEXT, literal, reportError, type ForeignText } from "../log";
import { domainFromInput } from "../domain";
import { operatorKey, signRequest } from "./operator";
import { assertSupported, protocolRevision, supportsProtocol } from "./protocol-version";
import { refusedBeforeSending } from "../validator/fetch.ts";
import { departure, isDeparture, ours, ProblemError, show, shown, type Problem } from "../diagnostic";

/** What the Poppy client needs from the Durable Object it runs in. */
export type PoppyHost = {
  readonly env: Env;
  readonly sql: Sql;
  readonly fetcher: IdentifiedFetcher;
  /** Show or update a card in the person's chat page. */
  readonly showCard: (card: Card, options?: import("./cards").CardWriteOptions) => Promise<void>;
  /** Tell the model something happened, at most once per `operationId`. */
  readonly notifyModel: (text: string, operationId: string) => Promise<void>;
  /** Run a durable job later; the same `id` replaces an earlier one. */
  readonly schedule: (fn: JobName, at: number, payload: Json, id: string) => Promise<void>;
  /** Whether a durable job with this `id` is waiting or running. */
  readonly hasJob: (id: string) => boolean;
  /** Push live updates for an open Direct Conversation to the page. */
  readonly pushDirect: (update: DirectUpdate) => void;
  /** The person's situation, for conversation `context` (spec 7.4). */
  readonly userContext: () => {
    locale?: string;
    time_zone?: string;
    user_available: boolean;
  };
  /** Wait, in ms; tests make it instant. */
  readonly sleep: (ms: number) => Promise<void>;
  /**
   * Now, in epoch ms, for waits and schedules: rate limits, polling and
   * operation tracking. Tests run it on a fake clock that `sleep` advances.
   */
  readonly now: () => number;
  /** How long to wait on a Company; `POPPY_TIMEOUTS` unless a test shortens them. */
  readonly timeouts?: PoppyTimeouts;
  /** Browsers to hand a website to the User in (handover.ts); null while Browser Run is off. */
  readonly handover?: () => import("./handover").HandoverLauncher | null;
};

export type JobName = "poppy-read" | "poppy-device" | "poppy-revoke" | "poppy-signin-expiry" | "poppy-agent-approval" | "poppy-handover";

/**
 * An OAuth or Poppy error from a Company, with its code (4.7, 7, 8.13).
 * Its message is for the model and the User, and is often built from what
 * the Company sent (its `error_description`, its body), so a wide event
 * records only its class and code (`ForeignText`, src/log.ts).
 */
export class PoppyError extends ProblemError implements ForeignText {
  override name = "PoppyError";
  readonly [FOREIGN_TEXT] = true as const;
  constructor(
    readonly code: PoppyErrorCode,
    problem: Problem,
    readonly status: number,
    readonly detail: {
      readonly scope?: string;
      readonly retryAfter?: number;
      readonly body?: Json;
      /** The extension an `extension_required` error names (spec 3.3). */
      readonly extension?: string;
      /** Our durable action projection; never taken from a Company's body. */
      readonly poppyTask?: { readonly id: string; readonly result: import("./approval-outcome").ApprovalResult };
    } = {}
  ) {
    super(problem);
  }

  /** Whether the code is one of these. Only codes we or the draft define can be named, so a misspelt one is a type error. */
  is(...codes: readonly KnownErrorCode[]): boolean {
    return (codes as readonly string[]).includes(this.code);
  }
}

/**
 * The Company's OAuth endpoints. A Company without an issuer has none, and
 * offers only signed-out Sessions (3.2), so anything that needs one is
 * refused before a request is built.
 */
export function issuerEndpoints(company: Company): NonNullable<Company["endpoints"]> {
  if (!company.endpoints) throw new PoppyError("no_sign_in", shown`${show.name(company.name)} has no OAuth issuer, so it offers no sign-in: only signed-out use`, 0);
  return company.endpoints;
}

/** Whether `error` is a `PoppyError` with one of these codes. */
/** Whether `after` has everything `before` has: a list may gain items, an object members. */
function keeps(before: unknown, after: unknown): boolean {
  if (Array.isArray(before)) return Array.isArray(after) && before.every((item) => after.some((other) => keeps(item, other)));
  if (before !== null && typeof before === "object") {
    if (after === null || typeof after !== "object" || Array.isArray(after)) return false;
    const other = after as Record<string, unknown>;
    return Object.entries(before).every(([key, value]) => value === undefined || (key in other && keeps(value, other[key])));
  }
  return before === after;
}

/** A Session label for work kept in an older version (8.2): `label` and the version, apart from the label's own Session. */
export function versionLabel(label: string, version: string): string {
  return `${label}@${version}`;
}

/** The label a task was given, without the version `versionLabel` added. */
export function baseLabel(label: string): string {
  return label.replace(/@\d+\.\d+$/, "");
}

export function hasCode(error: unknown, ...codes: readonly KnownErrorCode[]): error is PoppyError {
  return error instanceof PoppyError && error.is(...codes);
}

/**
 * What a request to a Company's API that ended in an error got back: `none`,
 * no answer at all (a timeout, or the network failed), so it may or may not
 * have reached the Company; or the HTTP status the API answered with. An
 * error with no mark never reached the API: the agent refused it, or a token
 * couldn't be had. An approved write's receipt says which (operations.ts).
 */
export type RequestAnswer = number | "none";
const answers = new WeakMap<object, RequestAnswer>();
const unreadableAnswers = new WeakMap<object, number>();

/** Mark `error` with what its request got back, and return it. */
export function withAnswer<T>(error: T, answer: RequestAnswer): T {
  if (typeof error === "object" && error !== null) answers.set(error, answer);
  return error;
}

/** What the request that threw `error` got back, if it reached a Company's API. */
export function answerOf(error: unknown): RequestAnswer | undefined {
  return typeof error === "object" && error !== null ? answers.get(error) : undefined;
}

/** Headers arrived, but the dispatched request's response cannot establish its outcome. */
export function withUnreadableAnswer<T>(error: T, status: number): T {
  withAnswer(error, status);
  if (typeof error === "object" && error !== null) unreadableAnswers.set(error, status);
  return error;
}

export function unreadableAnswerOf(error: unknown): number | undefined {
  return typeof error === "object" && error !== null ? unreadableAnswers.get(error) : undefined;
}

/** A preparation failure is not an answer to the approved application request. */
export function withoutAnswer<T>(error: T): T {
  if (typeof error === "object" && error !== null) { answers.delete(error); unreadableAnswers.delete(error); }
  return error;
}

/** The Company asked us to wait longer than we hold a request open for. */
export class RateLimitedError extends PoppyError {
  constructor(readonly waitMs: number) {
    super("rate_limited", shown`The company asked us to wait ${Math.ceil(waitMs / 1000)} s`, 429, {
      retryAfter: Math.ceil(waitMs / 1000)
    });
  }
}

/**
 * Resolves Direct Sign-Ins whose code exchange was interrupted (4.5).
 * `signin.ts` registers it, so this module needn't import that one.
 */
let signInRecovery: ((client: PoppyClient, issuer: Issuer) => Promise<void>) | undefined;

export function registerSignInRecovery(recover: (client: PoppyClient, issuer: Issuer) => Promise<void>): void {
  signInRecovery = recover;
}

/** Longest `Retry-After` we wait out inline; longer ones fail the call. */
const INLINE_WAIT_MS = 5_000;
/** Refresh an access token this long before it expires. */
const RENEW_EARLY_MS = 30_000;

/**
 * A token response (4.7, RFC 6749 5.1), decoded whole: a member of the
 * wrong type is a malformed response, not a value to coerce. Plain OAuth's:
 * it names no Session. `scope` may be absent when it is what was asked for.
 */
export const tokenResponse = object({
  access_token: string,
  token_type: optional(string),
  expires_in: number,
  scope: optional(string),
  refresh_token: optional(string),
  refresh_token_expires_in: optional(number)
});
type TokenResponse = Decoded<typeof tokenResponse>;

const sessionRow = sessionsTable.pick("issuer", "label", "session_id", "account", "signed_in", "scope", "authority_generation");
const declaredRow = sessionsTable.pick("session_id", "declared");
type SessionRow = RowOf<typeof sessionRow>;

const accountRow = accountsTable.pick("issuer", "account", "token", "scope", "expires_at");
export type AccountRow = RowOf<typeof accountRow>;

/** An access token in memory, bound to the DPoP key that was current when issued if it is DPoP-bound. */
type HeldToken = {
  readonly value: string;
  readonly account: string;
  readonly accountGeneration: number;
  readonly type: "DPoP" | "Bearer";
  readonly expiresAt: number;
  readonly scope: string;
  readonly signedIn: boolean;
  readonly keyThumbprint: string | null;
};

/** How a request authenticates at a Company resource. */
export type TokenOptions = {
  /** Which Session: tasks running in parallel use different labels. */
  readonly label?: string;
  /** RFC 8707 `resource`: a token for one service, such as an MCP server's `url` (4.5, 7). */
  readonly resource?: string;
  /** Ask for fewer scopes than the account has, e.g. read-only lookups. */
  readonly scope?: string;
  /** Internal authority check, after every asynchronous preparation and before each transport attempt. */
  readonly beforeDispatch?: () => void;
  /** Only a known `session_ended` refusal may advance an unapproved task's guard to its replacement Session. */
  readonly onSessionRestart?: (previousSessionId: string, nextSessionId: string) => void;
  /**
   * The service a signed-in request goes to (an OpenAPI description's
   * server, a conversation endpoint), whose protected resource metadata
   * says whether it takes only its own tokens (4.5). Ignored when
   * `resource` is set.
   */
  readonly service?: string;
  /** The Session header alone, never an access token, even signed in: 0.4's tasks endpoint (9). */
  readonly noToken?: boolean;
  /**
   * The request means the same in any protocol version, so after
   * `version_unsupported` it may be sent again under the version chosen
   * afresh (3.4): an API call without an approval. A conversation keeps its
   * versions, and an approval's statement belongs to one, so neither is.
   */
  readonly versionNeutral?: boolean;
};

export function scopeSet(scope: string | undefined | null): Set<string> {
  return new Set((scope ?? "").split(" ").filter(Boolean));
}

export function covers(granted: string | null | undefined, needed: Iterable<string>): boolean {
  const have = scopeSet(granted);
  for (const scope of needed) if (!have.has(scope)) return false;
  return true;
}

/**
 * The scope a token response granted: RFC 6749 5.1 leaves `scope` out when
 * it is exactly what was asked for (4.7), so an omitted one means
 * `requested`. A refresh that asked for none keeps the refresh token's.
 */
export function grantedScope(response: { readonly scope?: unknown }, requested: string): string {
  return typeof response.scope === "string" ? response.scope : requested;
}

function withScope<T extends TokenResponse>(response: T, requested: string): T {
  return { ...response, scope: grantedScope(response, requested) };
}

/** `WWW-Authenticate: DPoP error="…", scope="…"` (RFC 6750, RFC 9449). */
export function parseWwwAuthenticate(header: string | null): { error?: string; scope?: string; resourceMetadata?: string; resourceMetadataAmbiguous?: true } {
  if (!header) return {};
  const params: Record<string, string> = {};
  const metadata: string[] = [], errors: string[] = [];
  // A quoted-string may hold quoted-pairs (RFC 9110 §5.6.4), such as `\"` in a description.
  for (const match of header.matchAll(/(?:^|[,\s])([\w-]+)\s*=\s*"((?:[^"\\]|\\.)*)"/g)) {
    const name = match[1]!.toLowerCase(), value = match[2]!.replace(/\\(.)/g, "$1");
    params[name] ??= value;
    if (name === "resource_metadata") metadata.push(value);
    if (name === "error") errors.push(value);
  }
  // Parameter-like text inside a URI or description is not another challenge.
  const outsideValues = header.replace(/"(?:[^"\\]|\\.)*"/g, '""');
  const metadataCount = (outsideValues.match(/(?:^|[,\s])resource_metadata\s*=/gi) ?? []).length;
  const ambiguous = metadataCount !== metadata.length || new Set(metadata).size > 1 ||
    (metadataCount > 0 && errors.includes("invalid_token") && errors.some((value) => value !== "invalid_token"));
  return {
    ...(params.error ? { error: params.error } : {}),
    ...(params.scope ? { scope: params.scope } : {}),
    ...(params.resource_metadata ? { resourceMetadata: params.resource_metadata } : {}),
    ...(ambiguous ? { resourceMetadataAmbiguous: true as const } : {})
  };
}

/**
 * `extension_required` (3.3): the Company handles the request only with an
 * extension it didn't declare. The model and the User are told which, from
 * the JSON body's `extension`.
 */
export function extensionRequired(company: Company, extension: string | undefined, status: number, body?: Json): PoppyError {
  return withAnswer(
    new PoppyError("extension_required", shown`${show.name(company.name)} requires the extension ${extension === undefined ? ours("(unnamed)") : show.name(extension)}, which this agent doesn't support`, status, {
      ...(body !== undefined ? { body } : {}),
      ...(extension ? { extension } : {})
    }),
    status
  );
}

/** `extension_required` in a JSON body (3.3), at an API or a protocol endpoint; null for any other answer. */
export function extensionRequiredBody(company: Company, body: Json | undefined, status: number): PoppyError | null {
  if (status !== 403 || !isObject(body) || body.error !== "extension_required") return null;
  return extensionRequired(company, typeof body.extension === "string" ? body.extension : undefined, status, body);
}

/**
 * Public HTTPS URLs on hosts the Company has already vouched for, or on the
 * origin of the service being asked about, which `poppy.json` or a
 * description it lists names (4.5, 5.2); metadata never carries credentials.
 */
function serviceMetadataUrl(company: Company, value: string, service?: string): URL | undefined {
  if (!URL.canParse(value)) return undefined;
  const url = new URL(value);
  const ofService = service !== undefined && URL.canParse(service) && new URL(service).origin === url.origin;
  if (url.protocol !== "https:" || url.username || url.password || url.hash || !(tokenHostAllowed(company, url) || ofService)) return undefined;
  try { assertPublicHost(url); } catch { return undefined; }
  return url;
}

/** A metadata response is trusted only for this issuer and one of this Company's resources, or the service's own. */
function metadataResource(company: Company, value: Json, service?: string): string | undefined {
  if (!isObject(value) || typeof value.resource !== "string" || !Array.isArray(value.authorization_servers) || !value.authorization_servers.includes(company.issuer)) return undefined;
  return serviceMetadataUrl(company, value.resource, service) ? value.resource : undefined;
}

/**
 * Whether metadata's `resource` is exactly the identifier its URL was derived from (RFC 9728 3.1, 3.3):
 * the service URL as listed, or the origin and path the well-known segment was inserted into. Anything
 * else, even a parent of the service or another case, means the metadata isn't used (0.4, 4.5).
 */
function identifiesService(resource: string, service: string): boolean {
  const url = new URL(service);
  return resource === service || resource === `${url.origin}${url.pathname === "/" ? "" : url.pathname}`;
}

/** RFC 9110 §5.6.7 HTTP-date: IMF-fixdate, and the obsolete RFC 850 and asctime forms recipients must also read. */
const HTTP_DATE = [
  /^(?:Mon|Tue|Wed|Thu|Fri|Sat|Sun), \d{2} (?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec) \d{4} \d{2}:\d{2}:\d{2} GMT$/,
  /^(?:Monday|Tuesday|Wednesday|Thursday|Friday|Saturday|Sunday), \d{2}-(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)-\d{2} \d{2}:\d{2}:\d{2} GMT$/,
  /^(?:Mon|Tue|Wed|Thu|Fri|Sat|Sun) (?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec) [ \d]\d \d{2}:\d{2}:\d{2} \d{4}$/
];

/**
 * `Retry-After` (RFC 9110 §10.2.3) in ms from `now`: delay-seconds, or an
 * HTTP-date (zero once it has passed). Anything else is no `Retry-After` at
 * all; `Date.parse` alone would read junk such as `:0` as a date long past,
 * and so retry at once.
 */
export function retryAfterMs(response: Response, now: number): number | null {
  const header = response.headers.get("Retry-After")?.trim();
  if (!header) return null;
  if (/^\d+$/.test(header)) return Number(header) * 1000;
  if (!HTTP_DATE.some((form) => form.test(header))) return null;
  // asctime has no zone; it is GMT.
  const at = Date.parse(HTTP_DATE[2]!.test(header) ? `${header} GMT` : header);
  return Number.isNaN(at) ? null : Math.max(0, at - now);
}

/** `RateLimit` (IETF draft): both `remaining=, reset=` and `r=;t=` forms. */
export function parseRateLimit(header: string | null): { remaining: number; reset: number } | null {
  if (!header) return null;
  const remaining = /(?:remaining=|\br=)(\d+)/.exec(header);
  const reset = /(?:reset=|\bt=)(\d+)/.exec(header);
  return remaining && reset ? { remaining: Number(remaining[1]), reset: Number(reset[1]) } : null;
}

/** Why a request got no answer, for the protocol log: our deadline, or the network. */
function noAnswer(error: unknown): string {
  return error instanceof Error && error.name === "TimeoutError" ? "timeout" : "network";
}

async function readJson(response: Response, signal: AbortSignal): Promise<Json> {
  const text = await readLimited(response, 2_000_000, signal);
  if (!text) return null;
  try {
    return parseStrictJson(text);
  } catch {
    return null;
  }
}

/**
 * The Poppy Personal Agent client for one person. Everything a Company sees
 * from this person goes through here: their User IDs, Sessions, DPoP keys and
 * tokens. Model-facing tools and the chat page call into it; they never see
 * tokens, keys, codes or credentials.
 */
export class PoppyClient {
  readonly host: PoppyHost;
  readonly identity: AgentIdentity;
  readonly sealer: Sealer;
  /** DPoP keys by issuer and User ID, so each key serves one User ID (4.5); generated on first use, then kept sealed in `poppy_dpop_keys` (1.0: 4.4). */
  readonly #dpopKeys = new Map<string, Promise<DpopKey>>();
  /** Access tokens by issuer, Session label, resource and scope. */
  readonly #tokens = new Map<string, HeldToken>();
  /** New sign-ins and withdrawals invalidate held access; ordinary refresh rotation does not. */
  readonly #accountGenerations = new Map<string, number>();
  /** The latest `DPoP-Nonce` from each server origin, read through from `poppy_dpop_nonces`. */
  readonly #nonces = new Map<string, string | null>();
  /** The delegated key and delegation each Company's User ID signs with (5.2), memory only. */
  readonly #delegated = new Map<Issuer, Promise<Delegated>>();
  /** Cache public service metadata by URL; its issuer and host checks are specific to each Company (4.5). */
  readonly #serviceResources = new Map<string, { readonly metadata: Json | null; readonly expiresAt: number }>();
  /**
   * One token-endpoint exchange at a time per Company. Refresh tokens can
   * rotate on use, so two parallel renewals (say, a send and a background
   * read) would use one twice (4.4).
   */
  readonly #locks = new Map<string, Promise<unknown>>();
  /**
   * Steps this object has started and not finished: a confirm, a code
   * exchange. Memory only, so after a restart the stored state of such a
   * step, with no entry here, means it was interrupted and is recovered.
   */
  readonly inFlight = new Set<string>();

  #serial<T>(issuer: Issuer, work: () => Promise<T>): Promise<T> {
    const previous = this.#locks.get(issuer) ?? Promise.resolve();
    const next = previous.then(work, work);
    this.#locks.set(issuer, next.catch(() => undefined));
    return next;
  }

  /**
   * Run `work` with no other token-endpoint exchange for this Company beside
   * it: refreshes and sign-ins with a refresh token wait until it is done.
   * Signing out (signout.ts) runs so, so no renewal uses the account, or
   * renews its Sessions, while the revocation is under way. `work` must not
   * itself ask for a token.
   */
  exclusive<T>(issuer: Issuer, work: () => Promise<T>): Promise<T> {
    return this.#serial(issuer, work);
  }

  constructor(host: PoppyHost) {
    this.host = host;
    this.identity = readIdentity(host.env);
    this.sealer = new Sealer(host.env);
  }

  get sql(): Sql {
    return this.host.sql;
  }


  get timeouts(): PoppyTimeouts {
    return this.host.timeouts ?? POPPY_TIMEOUTS;
  }

  /**
   * A Company's response body, up to `maxBytes`, within `timeouts.bodyMs`:
   * a body that stalls fails as a `PoppyFetchError` rather than hanging.
   */
  async readBody(response: Response, maxBytes = 2_000_000): Promise<string> {
    return withDeadline(this.timeouts.bodyMs, (signal) => readLimited(response, maxBytes, signal)).catch((error: unknown) => {
      throw timeoutError(error, response.url ? shown`Reading ${show.url(response.url)}` : ours("Reading the response"));
    });
  }

  /** `readBody`, as JSON: null for an empty or unreadable one. */
  async readJson(response: Response): Promise<Json> {
    return withDeadline(this.timeouts.bodyMs, (signal) => readJson(response, signal)).catch((error: unknown) => {
      throw timeoutError(error, response.url ? shown`Reading ${show.url(response.url)}` : ours("Reading the response"));
    });
  }

  // ---------------------------------------------------------------- Companies

  /** A Company by any of its domains, from cache or discovery (spec 3). */
  async company(domain: string): Promise<Company> {
    const found = await this.lookup(domain);
    if (!isCompany(found)) {
      throw new DiscoveryError(shown`${show.name(found.name)} publishes poppy.json without auth, so it can only be browsed as a website`);
    }
    return found;
  }

  /**
   * A Company by domain: the documents discovery kept, until their HTTP cache
   * lifetime (bounded to between a minute and a day) is up, then discovery
   * again (spec 3 and 3.2: SHOULD cache by HTTP caching headers; the bounds
   * are the Guides'). Timed by the host's clock, like the client's waits.
   */
  async lookup(domain: string, options: { readonly fresh?: boolean } = {}): Promise<Company | WebsiteOnly> {
    const key = domainFromInput(domain);
    const cached = one(
      this.sql,
      domainsTable.pick("company", "expires_at"),
      "SELECT company, expires_at FROM poppy_domains WHERE domain = ?",
      key
    );
    // `fresh`: discovery again whatever the cache says, as after `version_unsupported` (3.4).
    if (cached && cached.expires_at > this.host.now() && !options.fresh) {
      const value = JSON.parse(cached.company) as Company | WebsiteOnly;
      if (!isCompany(value) || (supportsProtocol(value.protocolVersion) && value.specificationRevision === protocolRevision(value.protocolVersion))) return value;
    }
    let discovered: Awaited<ReturnType<typeof discover>>;
    try {
      discovered = await discover(this.host.fetcher, domain);
    } catch (error) {
      // The protocol view shows a refused Company too, under its domain.
      if (error instanceof DiscoveryError) recordDiscovery(this.sql, key, error.report, null);
      throw error;
    }
    const { result, cacheSeconds } = discovered;
    // The domain's last Company document, kept apart from the cache: a website-only answer in between
    // replaces the cached entry, but not what the domain was known to be.
    const knownKey = `known-company|${key}`;
    const knownRow = one(this.sql, intentsTable.pick("value"), "SELECT value FROM poppy_intents WHERE call_key = ?", knownKey);
    const cachedValue = cached ? (JSON.parse(cached.company) as Company | WebsiteOnly) : undefined;
    const known = knownRow ? (JSON.parse(knownRow.value) as Company) : cachedValue && isCompany(cachedValue) ? cachedValue : undefined;
    // A cached Company from before this record existed is kept as the history before anything replaces it,
    // so a website-only answer as the first discovery after an upgrade doesn't lose the issuer either.
    if (!knownRow && known) this.sql.exec("INSERT OR IGNORE INTO poppy_intents (call_key, value, created_at) VALUES (?, ?, ?)", knownKey, JSON.stringify(known), this.host.now());
    // 3.2: never fall back to the domain for a Company whose issuer we know unless discovery explicitly
    // establishes the issuer was removed. Our reading (docs/readings.md): protected resource metadata
    // that lists no authorization server does; a 404 alone, which a misconfiguration can produce, doesn't.
    if (isCompany(result) && result.issuerless && known && !known.issuerless && discovered.report.protectedResource === undefined) {
      recordDiscovery(this.sql, key, discovered.report, null);
      throw new DiscoveryError(shown`${show.name(result.name)} named the OAuth issuer ${show.url(known.issuer)} before, and its protected resource metadata is now missing (HTTP 404). A missing document doesn't show the issuer was removed, so the agent won't treat ${show.name(key)} as signed-out only.`);
    }
    // A removed issuer ends account access even when the identifier stays the same: an issuer of exactly
    // https://{domain} gives way to the same domain identifier, with nothing left to sign in with or refresh at.
    if (isCompany(result) && known && (known.issuer !== result.issuer || (!known.issuerless && result.issuerless))) await this.#identifierChanged(key, known, result);
    // 3.2: domains sharing an issuer are one Company. They SHOULD publish the same scope descriptions and
    // hints, and MAY expose different scopes and capabilities, so differing `auth` objects aren't refused;
    // each domain's own document is used for that domain.
    if (isCompany(result) && result.domain.toLowerCase() !== key) {
      await this.host.showCard({ id: `company-redirect-${key}`, kind: "notice", company: result.name, domain: result.domain, open: false, text: `You asked for ${key}. Its discovery leads to ${result.name} at ${result.domain}; this is the Company your agent will use.` });
    }
    recordDiscovery(this.sql, key, discovered.report, isCompany(result) ? result : null);
    if (isCompany(result)) this.sql.exec("INSERT OR REPLACE INTO poppy_intents (call_key, value, created_at) VALUES (?, ?, ?)", knownKey, JSON.stringify(result), this.host.now());
    this.sql.exec(
      "INSERT OR REPLACE INTO poppy_domains (domain, issuer, company, expires_at) VALUES (?, ?, ?, ?)",
      key,
      isCompany(result) ? result.issuer : null,
      JSON.stringify(result),
      this.host.now() + cacheSeconds * 1000
    );
    return result;
  }

  /**
   * The most recently discovered document for an issuer, or, once no domain
   * names it any more (its identifier changed, 3.2), the last one recorded
   * for it, so its accounts can still be revoked at its own endpoints.
   */
  companyByIssuer(issuer: Issuer): Company {
    const row = one(
      this.sql,
      domainsTable.pick("company"),
      "SELECT company FROM poppy_domains WHERE issuer = ? ORDER BY expires_at DESC LIMIT 1",
      issuer
    ) ?? one(this.sql, taskContextsTable.pick("company"), "SELECT company FROM poppy_task_contexts WHERE issuer = ? ORDER BY rowid DESC LIMIT 1", issuer);
    if (!row) throw new DiscoveryError(shown`No company known for issuer ${show.url(issuer)}`);
    return JSON.parse(row.company) as Company;
  }

  /** Where a domain's discovery led: its `organization.domain`, which the User who chose the domain may never have typed. */
  discoveredDomain(domain: string): string | undefined {
    const row = one(this.sql, domainsTable.pick("company"), "SELECT company FROM poppy_domains WHERE domain = ?", domain.toLowerCase());
    return row ? (JSON.parse(row.company) as Company).domain?.toLowerCase() : undefined;
  }

  /** Every domain's latest document for an issuer: domains sharing one are one Company, but may describe different scopes (3.2). */
  companiesForIssuer(issuer: Issuer): Company[] {
    return rows(this.sql, domainsTable.pick("company"), "SELECT company FROM poppy_domains WHERE issuer = ?", issuer)
      .map((row) => JSON.parse(row.company) as Company | WebsiteOnly)
      .filter(isCompany);
  }

  /**
   * The Company to revoke an issuer's refresh tokens at: the newest record
   * for it that still has OAuth endpoints. After an issuer is removed, the
   * domain's record is the issuerless one, which may share its identifier
   * (an issuer of exactly https://{domain}), so the record kept when the
   * change was seen supplies the revocation endpoint.
   */
  revocationCompany(issuer: Issuer): Company {
    const current = this.companyByIssuer(issuer);
    if (current.endpoints) return current;
    const kept = rows(this.sql, taskContextsTable.pick("company"), "SELECT company FROM poppy_task_contexts WHERE issuer = ? ORDER BY rowid DESC", issuer)
      .map((row) => JSON.parse(row.company) as Company)
      .find((company) => company.endpoints !== undefined);
    return kept ?? current;
  }

  /**
   * A domain's Company identifier changed (3.2): an issuer was added, changed
   * or explicitly removed. A removed issuer counts even when the identifier
   * stays the same. The new identifier gets new User IDs and Sessions,
   * and nothing transfers. Accounts held under the old one can't be used from
   * this domain any more, so they are signed out: the usual sign-out record,
   * whose revoke job sends the revocation to the old issuer, retries, and
   * shows the User what is still pending. The User is told.
   */
  async #identifierChanged(domain: string, known: Company, current: Company): Promise<void> {
    this.rememberCompany("identifier-change", `${domain}|${known.issuer}`, known);
    const accounts = this.accounts(known.issuer);
    if (accounts.length === 0) return;
    await this.host.showCard({
      id: `identifier-change-${domain}-${known.issuer}`,
      kind: "notice",
      company: current.name,
      domain: current.domain,
      open: true,
      text: current.issuerless
        ? `${current.name} no longer has a sign-in service for personal agents, so your agent uses ${domain} signed out only. It is signing out of the account it held there before; nothing from that sign-in carries over.`
        : `${current.name} moved to a different sign-in service. Your agent is signing out of the account it held through the old one, and you can sign in again when a task needs your account; nothing from the old sign-in carries over.`
    });
    // Queued, not awaited: discovery may run under another lock, and the revoke job retries on its own.
    const { queueSignOut } = await import("./signout");
    for (const account of accounts) {
      try {
        await queueSignOut(this, known.issuer, account.account);
      } catch (error) {
        reportError(error, { source: literal("poppy.identifier-change"), severe: false });
      }
    }
  }

  /** Bind pending work to the interface where it began; never overwrite it. */
  rememberCompany(kind: string, id: string, company: Company): void {
    this.sql.exec("INSERT OR IGNORE INTO poppy_task_contexts (kind, task_id, issuer, company) VALUES (?, ?, ?, ?)", kind, id, company.issuer, JSON.stringify(company));
  }

  /** Revalidate the original domain before resuming credentials or consequential work. */
  /**
   * The Company domain a task belongs to, from its stored discovery context,
   * or the issuer's only domain for an older task without one; undefined
   * when that can't be told.
   */
  taskDomain(issuer: Issuer, kind: string, id: string): string | undefined {
    const context = one(this.sql, taskContextsTable.pick("company"), "SELECT company FROM poppy_task_contexts WHERE kind = ? AND issuer = ? AND task_id = ?", kind, issuer, id);
    if (context) return (JSON.parse(context.company) as Company).domain;
    const domains = new Set(rows(this.sql, domainsTable.pick("company"), "SELECT company FROM poppy_domains WHERE issuer = ?", issuer).map((row) => (JSON.parse(row.company) as Company).domain));
    return domains.size === 1 ? [...domains][0] : undefined;
  }

  /**
   * `keepVersion`: the task keeps the versions it began in, as a conversation
   * does (8.2). When the Company has since chosen another version but still
   * serves the old one, its document for the old one is used; when it no
   * longer does, `version_mismatch` is thrown and no card shown, for the
   * caller to say what that means for its task.
   */
  async resumeCompany(issuer: Issuer, kind: string, id: string, options: { readonly keepVersion?: boolean } = {}): Promise<Company> {
    let context = one(this.sql, taskContextsTable.pick("company"), "SELECT company FROM poppy_task_contexts WHERE kind = ? AND issuer = ? AND task_id = ?", kind, issuer, id);
    if (!context) {
      const candidates = rows(this.sql, domainsTable.pick("company"), "SELECT company FROM poppy_domains WHERE issuer = ?", issuer);
      const domains = new Set(candidates.map((row) => (JSON.parse(row.company) as Company).domain));
      if (domains.size !== 1) throw new PoppyError("company_changed", ours("This older task has no unambiguous Company domain; start it again"), 0);
      context = candidates[0];
    }
    if (!context) throw new DiscoveryError(ours("No discovery context for this task"));
    const original = JSON.parse(context.company) as Company;
    let current = await this.company(original.domain);
    const moved = options.keepVersion && current.issuer === issuer && current.protocolVersion !== original.protocolVersion;
    if (moved) {
      const kept = await this.#companyAt(original.domain, original.protocolVersion);
      if (!kept) throw new PoppyError("version_mismatch", shown`${show.name(current.name)} no longer serves Poppy ${show.code(original.protocolVersion)}, the version this began in`, 0);
      current = kept;
    }
    // The conversation endpoint, not its description: rewording what the agent can help with (1.0 8.1) changes no interface.
    const interfaces = (company: Company) => [company.endpoints, company.signIn, company.web, company.conversations?.endpoint, company.extensions, company.apis.map((api) => [api.type, api.url])];
    // A Company that moved to another version may add to what it shares across versions, such as the
    // poppy:browser-sign-in scope (6); work kept in the old version needs only that nothing it had changed.
    const same = (before: unknown, after: unknown) => moved ? keeps(before, after) : JSON.stringify(before) === JSON.stringify(after);
    if (current.issuer !== issuer || current.protocolVersion !== original.protocolVersion ||
        (original.authFingerprint && !same(JSON.parse(original.authFingerprint), current.authFingerprint ? JSON.parse(current.authFingerprint) : null)) || interfaces(original).some((part, index) => !same(part, interfaces(current)[index])) ||
        (original.specificationRevision && current.specificationRevision !== original.specificationRevision)) {
      await this.host.showCard({ id: `company-changed-${kind}-${id}`, kind: "notice", company: original.name, domain: original.domain, open: false, text: "This Company changed its protocol or interfaces while work was pending. Review its current status before starting a new task; an uncertain action must not be repeated." });
      throw new PoppyError("company_changed", ours("The Company's issuer, protocol or interfaces changed while this task was pending; reconcile it before continuing"), 0);
    }
    this.rememberCompany(kind, id, current);
    return current;
  }

  /**
   * The Company's document for one version it still serves (3.4), from its
   * `supported_versions`; null when it serves it no longer. Fetched afresh
   * and not cached: the domain's cache holds the version the agent chooses.
   */
  async #companyAt(domain: string, version: string): Promise<Company | null> {
    try {
      const { result } = await discover(this.host.fetcher, domain, [version]);
      return isCompany(result) && result.protocolVersion === version ? result : null;
    } catch (error) {
      if (error instanceof DiscoveryError) return null;
      throw error;
    }
  }

  /**
   * The Session label for work that keeps versions the Company no longer
   * chooses (8.2): `label` while they are its choice; otherwise a Session of
   * its own declaring them, signed in to the account `label` is, so the
   * agent's other work in `label` keeps the Company's current versions.
   */
  async versionSession(company: Company, label: string): Promise<string> {
    const chosen = await this.company(company.domain);
    if (chosen.protocolVersion === company.protocolVersion) return label;
    const own = versionLabel(label, company.protocolVersion);
    const session = this.session(company.issuer, label);
    const kept = this.session(company.issuer, own);
    if (session?.signed_in && session.account) {
      if (!kept?.signed_in || kept.account !== session.account) this.#bindAccount(company, own, session.account, session.scope);
    } else if (kept?.signed_in) {
      this.signOutSession(company.issuer, own);
    }
    return own;
  }

  /**
   * The User ID for this person at one Company (5.1): random, stored,
   * never derived from who they are. Domains that share an issuer share it.
   */
  userId(issuer: Issuer): string {
    const row = one(
      this.sql,
      userIdsTable.pick("user_id"),
      "SELECT user_id FROM poppy_user_ids WHERE issuer = ?",
      issuer
    );
    if (row) return row.user_id;
    const userId = randomId("usr_");
    this.sql.exec("INSERT INTO poppy_user_ids (issuer, user_id) VALUES (?, ?)", issuer, userId);
    return userId;
  }

  // ---------------------------------------------------------------- Keys

  /**
   * The DPoP key for this Company and User ID. It outlives restarts, so a
   * refresh token is always refreshed with the key it was issued with, as 1.0
   * requires (4.4) and 0.4 allows; it is the same key until the agent's data
   * is deleted.
   */
  dpopKey(issuer: Issuer): Promise<DpopKey> {
    const userId = this.userId(issuer);
    const id = `${issuer}|${userId}`;
    let key = this.#dpopKeys.get(id);
    if (!key) {
      key = this.#storedDpopKey(issuer, userId);
      this.#dpopKeys.set(id, key);
      // A failure to open or store it isn't remembered: the next request tries again.
      key.catch(() => this.#dpopKeys.delete(id));
    }
    return key;
  }

  async #storedDpopKey(issuer: Issuer, userId: string): Promise<DpopKey> {
    const context = `dpop|${issuer}|${userId}`;
    const stored = () => one(this.sql, dpopKeysTable.pick("key"), "SELECT key FROM poppy_dpop_keys WHERE issuer = ? AND user_id = ?", issuer, userId);
    const row = stored();
    if (row) {
      const { plaintext, current } = await this.sealer.openChecked(row.key, context);
      // Sealed under TOKEN_ENC_KEY_PREVIOUS: seal it again under the current key.
      if (!current) this.sql.exec("UPDATE poppy_dpop_keys SET key = ? WHERE issuer = ? AND user_id = ? AND key = ?", await this.sealer.seal(plaintext, context), issuer, userId, row.key);
      return storedDpopKey(JSON.parse(plaintext) as JWK);
    }
    const { key, privateJwk } = await newStoredDpopKey();
    const sealed = await this.sealer.seal(JSON.stringify(privateJwk), context);
    // One lookup at a time per key (#dpopKeys), so no other key for this User ID is stored meanwhile.
    this.sql.exec("INSERT INTO poppy_dpop_keys (issuer, user_id, key, created_at) VALUES (?, ?, ?, ?)", issuer, userId, sealed, Date.now());
    return key;
  }

  /**
   * The latest nonce from `origin`. It is stored, since the keys that used it
   * outlive a restart, so their next proof carries it instead of being
   * challenged again (RFC 9449 8).
   */
  #nonce(origin: string): string | undefined {
    let nonce = this.#nonces.get(origin);
    if (nonce === undefined) {
      // null: the server has sent none, kept so most requests read no row (#keepNonce is the only writer).
      nonce = one(this.sql, dpopNoncesTable.pick("nonce"), "SELECT nonce FROM poppy_dpop_nonces WHERE origin = ?", origin)?.nonce ?? null;
      this.#nonces.set(origin, nonce);
    }
    return nonce ?? undefined;
  }

  #keepNonce(origin: string, nonce: string): void {
    if (this.#nonce(origin) === nonce) return;
    this.#nonces.set(origin, nonce);
    this.sql.exec("INSERT OR REPLACE INTO poppy_dpop_nonces (origin, nonce) VALUES (?, ?)", origin, nonce);
  }

  // ---------------------------------------------------------------- Rate limits

  #limiter(issuer: Issuer) {
    return this.host.env.CompanyLimiter.getByName(issuer);
  }

  /** Wait for the Company's shared limit, inline if short, else fail (5.6). */
  async #respectLimit(issuer: Issuer): Promise<void> {
    const delay = await this.#limiter(issuer).delay(this.host.now());
    if (delay <= 0) return;
    recordLimitWait(this.sql, issuer, delay, delay <= INLINE_WAIT_MS);
    if (delay > INLINE_WAIT_MS) throw new RateLimitedError(delay);
    await this.host.sleep(delay);
  }

  /** Record what a response says about limits; returns ms to wait before retrying, if any. */
  async #observeLimits(issuer: Issuer, response: Response): Promise<number | null> {
    const limit = parseRateLimit(response.headers.get("RateLimit"));
    const now = this.host.now();
    if (limit) await this.#limiter(issuer).observe(limit.remaining, now + limit.reset * 1000);
    if (response.status !== 429 && response.status !== 503) return null;
    const wait = retryAfterMs(response, now);
    if (wait === null) return response.status === 429 ? 1_000 : null;
    await this.#limiter(issuer).blockUntil(now + wait);
    return wait;
  }

  /** The Company's shared limit, before a request that doesn't go through `resource()`: a website page. */
  async beforeRequest(company: Company): Promise<void> {
    await this.#respectLimit(company.issuer);
  }

  /**
   * A website page answered (5.6): on 429 or 503, record its
   * `Retry-After` for every User's agent and wait it out inline when short,
   * returning true so the caller loads the page again. A longer wait throws
   * `RateLimitedError`; any other status returns false.
   */
  async pageLimited(company: Company, status: number, retryAfter: string | undefined): Promise<boolean> {
    if (status !== 429 && status !== 503) return false;
    const response = new Response(null, { status, headers: retryAfter ? { "Retry-After": retryAfter } : {} });
    const wait = await this.#observeLimits(company.issuer, response);
    recordPageLimit(this.sql, company.issuer, status, wait, wait !== null && wait <= INLINE_WAIT_MS);
    if (wait === null) return false;
    if (wait > INLINE_WAIT_MS) throw new RateLimitedError(wait);
    await this.host.sleep(wait);
    return true;
  }

  // ---------------------------------------------------------------- Token endpoint

  /**
   * One request to the Company's token, device or revocation endpoint, with
   * our client assertion and, when the issuer asks for DPoP and `dpop` isn't
   * false, a DPoP proof. Nonces, short `Retry-After` waits and fresh
   * assertions on every attempt are handled here. The client assertion's
   * `aud` is the issuer at every endpoint (4.1), so it can't be replayed at
   * another Company. Never the Session header (5.2).
   */
  async oauthRequest(
    company: Company,
    endpoint: string,
    params: () => Promise<Record<string, string>>,
    options: { dpop: boolean; beforeDispatch?: () => void }
  ): Promise<{ status: number; body: Json; headers: Headers }> {
    const signing = await currentKey(this.host.env);
    const clientId = this.identity.clientId;
    // A proof only when the issuer lists dpop_signing_alg_values_supported (4.5).
    const dpop = options.dpop && company.dpop === true;
    // One retry for a new DPoP nonce, whenever it comes: after a 429 too.
    let nonceRetried = false;
    // The issuer, as a single string, whatever endpoint is called (4.1).
    const audience = company.issuer;
    for (let attempt = 0; attempt < 3; attempt++) {
      await this.#respectLimit(company.issuer);
      // Each attempt gets new assertions and a new proof: Companies reject a reused jti.
      const fields = await params();
      const form = new URLSearchParams({
        ...fields,
        client_id: clientId,
        client_assertion_type: "urn:ietf:params:oauth:client-assertion-type:jwt-bearer",
        client_assertion: await clientAssertion(signing, clientId, audience)
      });
      const headers = new Headers({
        "Content-Type": "application/x-www-form-urlencoded",
        Accept: "application/json"
      });
      const origin = new URL(endpoint).origin;
      // For the protocol log, which reads only the fields it names (never a token, code, verifier or assertion).
      const logged = { endpoint, form: fields, dpop, nonce: dpop && this.#nonce(origin) !== undefined };
      if (dpop) {
        const nonce = this.#nonce(origin);
        headers.set(
          "DPoP",
          await dpopProof(await this.dpopKey(company.issuer), {
            method: "POST",
            url: endpoint,
            ...(nonce ? { nonce } : {})
          })
        );
      }
      // Account access may have changed while assertions and proofs were signed.
      options.beforeDispatch?.();
      // One deadline for the answer and its body.
      const { response, body } = await withDeadline(this.timeouts.oauthMs, async (signal) => {
        const response = await raceAbort(
          this.host.fetcher(new Request(endpoint, { method: "POST", headers, body: form, redirect: "manual", signal })),
          signal
        );
        return { response, body: await readJson(response, signal) };
      }).catch((error: unknown) => {
        recordOauth(this.sql, company, logged, { failed: noAnswer(error) });
        throw timeoutError(error, show.url(endpoint));
      });
      const nonce = response.headers.get("DPoP-Nonce");
      if (nonce) this.#keepNonce(origin, nonce);
      const wait = await this.#observeLimits(company.issuer, response);
      const error = isObject(body) && typeof body.error === "string" ? body.error : undefined;
      const answer = { status: response.status, body };
      if (error === "use_dpop_nonce" && nonce && !nonceRetried) {
        recordOauth(this.sql, company, logged, answer, { kind: "nonce" });
        nonceRetried = true;
        continue;
      }
      if (wait !== null) {
        const retrying = wait <= INLINE_WAIT_MS && attempt < 2;
        recordOauth(this.sql, company, logged, answer, { kind: "wait", ms: wait, retrying });
        if (!retrying) throw new RateLimitedError(wait);
        await this.host.sleep(wait);
        continue;
      }
      recordOauth(this.sql, company, logged, answer);
      return { status: response.status, body, headers: response.headers };
    }
    throw new PoppyError("rate_limited", ours("The company kept refusing the request"), 429);
  }

  /** A token request that must succeed; OAuth errors become `PoppyError`s. */
  async tokenRequest(
    company: Company,
    params: () => Promise<Record<string, string>>,
    options: { dpop: boolean; beforeDispatch?: () => void } = { dpop: true }
  ): Promise<TokenResponse> {
    const { status, body } = await this.oauthRequest(company, issuerEndpoints(company).token, params, options);
    if (status === 200 && isObject(body) && typeof body.access_token === "string") {
      let decoded: TokenResponse;
      try {
        decoded = tokenResponse(body, "the token response");
      } catch (error) {
        // Where and what: a member of the wrong type. The access token is a string by now, so never shown.
        if (error instanceof DecodeError) throw new PoppyError("invalid_response", error.problem, status);
        throw error;
      }
      if (!(decoded.expires_in > 0)) {
        throw new PoppyError("invalid_response", departure(ours("the token response's expires_in"), ours("a positive number of seconds"), show.value(decoded.expires_in)), status);
      }
      return decoded;
    }
    const code = isObject(body) && body.error !== undefined ? companyErrorCode(body.error, status) : "server_error";
    const description = isObject(body) && typeof body.error_description === "string" ? shown`: ${show.text(body.error_description)}` : ours("");
    throw new PoppyError(code, shown`${show.name(company.name)} refused the token request (${show.code(code)})${description}`, status, {
      ...(body !== null ? { body } : {})
    });
  }

  // ---------------------------------------------------------------- Sessions

  session(issuer: Issuer, label: string): SessionRow | undefined {
    return one(
      this.sql,
      sessionRow,
      "SELECT issuer, label, session_id, account, signed_in, scope, authority_generation FROM poppy_sessions WHERE issuer = ? AND label = ?",
      issuer,
      label
    );
  }

  sessions(issuer?: Issuer): SessionRow[] {
    return issuer
      ? rows(this.sql, sessionRow, "SELECT * FROM poppy_sessions WHERE issuer = ?", issuer)
      : rows(this.sql, sessionRow, "SELECT * FROM poppy_sessions");
  }

  /** Stop using a Session, and drop its tokens: the next request starts a new one, with a new `sid` (5.5). */
  abandonSession(issuer: Issuer, label: string): void {
    this.#forgetSession(issuer, label);
  }

  /**
   * Before any token for a Company: resolve a Direct Sign-In whose code
   * exchange was interrupted, so its refresh token is stored before anything
   * asks for one. Cheap when there is none.
   */
  /** Finish sign-ins an interruption left half done, so a caller reads the Session as it really is. */
  async recoverSignIns(issuer: Issuer): Promise<void> {
    await this.#recoverSignIns(issuer);
  }

  async #recoverSignIns(issuer: Issuer): Promise<void> {
    if (!signInRecovery) return;
    const pending = one(
      this.sql,
      found,
      "SELECT 1 AS found FROM poppy_signins WHERE issuer = ? AND status IN ('exchanging', 'exchanged', 'stored') LIMIT 1",
      issuer
    );
    if (pending) await signInRecovery(this, issuer);
  }

  /** A new `sid` for the Session `label`, keeping its account (5.5, `session_ended`). */
  #restartSession(issuer: Issuer, label: string): void {
    const session = this.session(issuer, label);
    this.#forgetTokens(issuer, label);
    if (session) this.#writeSession(issuer, label, randomId(), session.account, session.scope);
  }

  #forgetSession(issuer: Issuer, label: string): void {
    this.sql.exec("DELETE FROM poppy_sessions WHERE issuer = ? AND label = ?", issuer, label);
    for (const key of [...this.#tokens.keys()]) {
      if (key.startsWith(`${issuer}|${label}|`)) this.#tokens.delete(key);
    }
  }

  // ---------------------------------------------------------------- Refresh tokens (poppy_accounts)

  account(issuer: Issuer, account: string): AccountRow | undefined {
    const row = one(
      this.sql,
      accountRow,
      "SELECT issuer, account, token, scope, expires_at FROM poppy_accounts WHERE issuer = ? AND account = ?",
      issuer,
      account
    );
    if (row && row.expires_at !== null && row.expires_at <= Date.now()) {
      this.deleteAccount(issuer, account);
      return undefined;
    }
    return row;
  }

  accounts(issuer?: Issuer): AccountRow[] {
    return issuer
      ? rows(this.sql, accountRow, "SELECT * FROM poppy_accounts WHERE issuer = ?", issuer)
      : rows(this.sql, accountRow, "SELECT * FROM poppy_accounts");
  }

  /** The authority of memory-only access tokens and browser contexts for this account. */
  accountGeneration(issuer: Issuer, account: string): number {
    return this.#accountGenerations.get(JSON.stringify([issuer, account])) ?? 0;
  }

  #advanceAccountGeneration(issuer: Issuer, account: string): void {
    this.#accountGenerations.set(JSON.stringify([issuer, account]), this.accountGeneration(issuer, account) + 1);
  }

  #checkAccountGeneration(issuer: Issuer, account: string, expected: number): void {
    if (this.accountGeneration(issuer, account) !== expected) {
      throw new PoppyError("approval_changed", ours("The account's access changed while this request was being prepared. Start it again."), 0);
    }
  }

  #checkAccount(row: AccountRow): void {
    if (this.account(row.issuer, row.account)?.token !== row.token) {
      throw new PoppyError("approval_changed", ours("The account's refresh token changed while this request was being prepared. Start it again."), 0);
    }
  }

  /**
   * The additional data a refresh token is sealed with: its issuer, the
   * User ID there and its account, so it opens only for its own account. A
   * token waiting to be revoked (signout.ts) keeps it.
   */
  accountContext(issuer: Issuer, account: string): string {
    return `account|${issuer}|${this.userId(issuer)}|${account}`;
  }

  /** The refresh token itself, decrypted only for a token-endpoint request. */
  async #accountToken(row: AccountRow): Promise<{ value: string; row: AccountRow }> {
    const context = this.accountContext(row.issuer, row.account);
    const { plaintext, current } = await this.sealer.openChecked(row.token, context);
    // Sealed under TOKEN_ENC_KEY_PREVIOUS, or before values were versioned: seal it again under the current key.
    if (!current) {
      const sealed = await this.sealer.seal(plaintext, context);
      const changed = this.sql.exec(
        "UPDATE poppy_accounts SET token = ? WHERE issuer = ? AND account = ? AND token = ? RETURNING account",
        sealed,
        row.issuer,
        row.account,
        row.token
      ).toArray();
      if (changed.length) row = { ...row, token: sealed };
    }
    this.#checkAccount(row);
    return { value: plaintext, row };
  }

  /** Store new sign-in access encrypted; a withdrawal while sealing wins. */
  async storeAccountToken(
    issuer: Issuer,
    account: string,
    token: string,
    scope: string,
    expiresInSeconds: number | undefined
  ): Promise<void> {
    const generation = this.accountGeneration(issuer, account);
    const sealed = await this.sealer.seal(token, this.accountContext(issuer, account));
    this.#checkAccountGeneration(issuer, account, generation);
    this.sql.exec(
      `INSERT OR REPLACE INTO poppy_accounts (issuer, account, token, scope, expires_at, updated_at)
       VALUES (?, ?, ?, ?, ?, ?)`,
      issuer,
      account,
      sealed,
      scope,
      expiresInSeconds ? Date.now() + expiresInSeconds * 1000 : null,
      Date.now()
    );
    this.#advanceAccountGeneration(issuer, account);
  }

  deleteAccount(issuer: Issuer, account: string): void {
    this.sql.exec("DELETE FROM poppy_accounts WHERE issuer = ? AND account = ?", issuer, account);
    this.#advanceAccountGeneration(issuer, account);
    // Sessions signed in to it continue signed out (5.5), now: an approval bound to the account
    // (apis.ts `checkApprovalBinding`) is withdrawn before anything awaits, not at the next renewal.
    for (const session of this.sessions(issuer)) {
      if (session.account === account) this.signOutSession(issuer, session.label);
    }
  }

  #forgetTokens(issuer: Issuer, label: string): void {
    for (const key of [...this.#tokens.keys()]) {
      if (key.startsWith(`${issuer}|${label}|`)) this.#tokens.delete(key);
    }
  }

  // ---------------------------------------------------------------- Access tokens

  /** Drop a token the Company rejected, so the next call gets a new one. */
  dropToken(company: Company, options: TokenOptions = {}): void {
    this.#forgetTokens(company.issuer, options.label ?? "main");
  }

  /** After any use of a refresh token: a new one replaces it at once (4.4). */
  async #afterAccountUse(company: Company, account: AccountRow, response: TokenResponse): Promise<void> {
    this.#checkAccount(account);
    if (response.refresh_token) {
      const sealed = await this.sealer.seal(response.refresh_token, this.accountContext(company.issuer, account.account));
      const changed = this.sql.exec(
        "UPDATE poppy_accounts SET token = ?, scope = ?, expires_at = ?, updated_at = ? WHERE issuer = ? AND account = ? AND token = ? RETURNING account",
        sealed, account.scope, response.refresh_token_expires_in ? Date.now() + response.refresh_token_expires_in * 1000 : null,
        Date.now(), company.issuer, account.account, account.token
      ).toArray();
      if (!changed.length) throw new PoppyError("approval_changed", ours("The account's refresh token changed before its rotated token could be stored. Start it again."), 0);
    }
  }

  /** `invalid_grant` for a refresh token: delete it, continue signed out, tell the User (5.5). */
  async #accountGone(company: Company, account: string): Promise<void> {
    this.deleteAccount(company.issuer, account);
    await this.host.showCard({
      id: `account-gone-${company.issuer}-${account}`,
      kind: "notice",
      company: company.name,
      domain: company.domain,
      open: true,
      text: `${company.name} has ended this agent's access to your account. Sign in again when a task needs it.`
    });
  }

  /**
   * Sign a Session in with a refresh token we already hold (4.4), so the
   * User isn't asked again. Returns false when there is none that covers
   * `scopes`.
   */
  async signInWithAccount(
    company: Company,
    label: string,
    scopes: readonly string[],
    accountLabel?: string
  ): Promise<boolean> {
    await this.#recoverSignIns(company.issuer);
    return this.#serial(company.issuer, () => this.#signInWithAccount(company, label, scopes, accountLabel));
  }

  async #signInWithAccount(
    company: Company,
    label: string,
    scopes: readonly string[],
    accountLabel?: string
  ): Promise<boolean> {
    const candidates = accountLabel
      ? [this.account(company.issuer, accountLabel)].filter((row): row is AccountRow => !!row)
      : this.accounts(company.issuer);
    const account = candidates.find((row) => covers(row.scope, scopes));
    if (!account) return false;
    // Sign-in is plain OAuth and needs no Session (5.4): the Session uses the account from its next request.
    this.#bindAccount(company, label, account.account, account.scope);
    const key = `${company.issuer}|${label}|||access`;
    return (await this.#refresh(company, label, key, {}, company.dpop ? await this.dpopKey(company.issuer) : null)) !== null;
  }

  /**
   * Record a completed sign-in: its refresh token, and the Session signed in
   * to the account (5.4). Returns the account as it was when a step-up
   * replaced its refresh token with another, still holding the old token
   * sealed, for the caller to revoke (signout.ts); null when nothing was
   * replaced.
   */
  async completeSignIn(
    company: Company,
    label: string,
    account: string,
    response: TokenResponse
  ): Promise<AccountRow | null> {
    const finishing = `signin-store|${randomId()}`;
    this.inFlight.add(finishing);
    try {
      const previous = this.account(company.issuer, account);
      const previousGeneration = this.accountGeneration(company.issuer, account);
      // Compared before the new token is stored, so nothing awaits between storing it and the caller recording the old one.
      // One that won't open is taken as replaced: its revocation then says it can't be sent.
      const same = async (sealed: string, token: string) =>
        (await this.sealer.open(sealed, this.accountContext(company.issuer, account)).catch(() => null)) === token;
      const replaced = previous && response.refresh_token && !(await same(previous.token, response.refresh_token)) ? previous : null;
      this.#checkAccountGeneration(company.issuer, account, previousGeneration);
      if (response.refresh_token) {
        await this.storeAccountToken(
          company.issuer,
          account,
          response.refresh_token,
          response.scope ?? "",
          response.refresh_token_expires_in
        );
      } else this.#advanceAccountGeneration(company.issuer, account);
      this.#checkAccountGeneration(company.issuer, account, previousGeneration + 1);
      this.#bindAccount(company, label, account, response.scope ?? "");
      const generation = this.accountGeneration(company.issuer, account);
      const bound = sessionAuthority(this.session(company.issuer, label));
      // The sign-in's own access token serves the Session's next request, when it came with the answer
      // (a sign-in finished after an interruption kept only the refresh token) and we can use it.
      const dpop = company.dpop ? await this.dpopKey(company.issuer) : null;
      this.#checkAccountGeneration(company.issuer, account, generation);
      if (!sameAuthority(bound, sessionAuthority(this.session(company.issuer, label)))) {
        throw new PoppyError("approval_changed", ours("The Session changed while sign-in was being completed. Start it again."), 0);
      }
      const held = response.access_token ? this.#usable(response, dpop, account, generation) : null;
      if (held) this.#tokens.set(`${company.issuer}|${label}|||access`, held);
      return replaced;
    } finally { this.inFlight.delete(finishing); }
  }

  // ---------------------------------------------------------------- Sessions (5)

  /**
   * The delegated key this Company's User ID signs with, and its
   * delegation (5.2): a new key and delegation before the old one runs out.
   * One per Company, so one per User ID: never shared between Companies.
   */
  async #delegatedFor(company: Company): Promise<Delegated> {
    const held = this.#delegated.get(company.issuer);
    if (held) {
      const current = await held.catch(() => null);
      if (current && delegationUsable(current)) return current;
      if (this.#delegated.get(company.issuer) !== held) return this.#delegatedFor(company);
    }
    const next = (async () => delegate(await currentKey(this.host.env), this.identity.clientId, await newDpopKey()))();
    this.#delegated.set(company.issuer, next);
    return next;
  }

  /**
   * The headers for a website page the agent fetches with its own HTTP
   * client rather than a browser (0.4 5.2): the Session header, signed out
   * (no `ath`; a page never gets a token), the Session's declared versions,
   * and the operator signature. Only where the Company lists
   * no `browser_session_endpoint` (where it does, the fetch browser joins
   * the Session as a browser and sends no header; decision 44), and only to
   * exactly `organization.domain`. Null otherwise.
   */
  async pageHeaders(company: Company, label: string, request: { readonly method: string; readonly url: string }): Promise<Headers | null> {
    const url = new URL(request.url);
    if (!this.signsPages(company) || url.protocol !== "https:") return null;
    if (url.host.toLowerCase() !== company.domain.toLowerCase()) return null;
    const { session, declared } = this.#declaredSession(company, label);
    const headers = new Headers({ "Poppy-Session": await this.sessionHeader(company, session.session_id, { method: request.method, url: url.href }) });
    for (const [name, value] of declarationHeaders(declared)) headers.set(name, value);
    const operator = operatorKey(this.host.env);
    if (operator) await signRequest(await operator, this.identity.origin, { method: request.method, url: url.href, headers });
    return headers;
  }

  /** Whether pages fetched without a browser carry the Session header at this Company (`pageHeaders`). */
  signsPages(company: Company): boolean {
    return !company.web?.browserSessionEndpoint;
  }

  /** The label's Session as its next request will use it: started, with the declaration the Company calls for (3.4). */
  preparedSession(company: Company, label: string): SessionRow {
    return this.#declaredSession(company, label).session;
  }

  /** The Session header for one request (5.2). */
  async sessionHeader(company: Company, sid: string, request: { readonly method: string; readonly url: string; readonly accessToken?: string }): Promise<string> {
    return sessionJwt(await this.#delegatedFor(company), {
      clientId: this.identity.clientId,
      issuer: company.issuer,
      sid,
      userId: this.userId(company.issuer),
      method: request.method,
      url: request.url,
      ...(request.accessToken !== undefined ? { accessToken: request.accessToken } : {})
    });
  }

  /**
   * The Session for `label`, started when there is none: a new random
   * `sid`, signed out (5.2, 5.4). It lives in `poppy_sessions` as earlier
   * versions' Sessions do, its `sid` in `session_id`.
   */
  sessionFor(company: Company, label: string): SessionRow {
    const existing = this.session(company.issuer, label);
    if (existing) return existing;
    this.#writeSession(company.issuer, label, randomId(), null, "");
    return this.session(company.issuer, label)!;
  }

  /**
   * The Session for `label`, and what its requests declare (3.4). The
   * values are fixed for a `sid`: when the Company's document now calls for
   * others, as after it moves to another version or extension version, the
   * Session restarts, keeping its account, before anything is sent. A
   * Session that hasn't declared anything yet (a new `sid`) declares these;
   * migration marked those stored before declarations as 0.3 Sessions.
   */
  /** What this agent's Sessions with `company` declare (3.4): Browser Control only where it can hand over a browser. */
  declaration(company: Company): Declaration {
    return declaration(company, this.host.handover?.() != null);
  }

  #declaredSession(company: Company, label: string): { session: SessionRow; declared: Declaration } {
    const wanted = this.declaration(company);
    const stored = one(this.sql, declaredRow, "SELECT session_id, declared FROM poppy_sessions WHERE issuer = ? AND label = ?", company.issuer, label)?.declared ?? null;
    if (stored && !sameDeclaration(stored, wanted)) this.#restartSession(company.issuer, label);
    const session = this.sessionFor(company, label);
    if (!stored || !sameDeclaration(stored, wanted)) {
      this.sql.exec("UPDATE poppy_sessions SET declared = ? WHERE issuer = ? AND label = ? AND session_id = ?", JSON.stringify(wanted), company.issuer, label, session.session_id);
    }
    return { session, declared: wanted };
  }

  /**
   * A Session's row: `account` is the account it is signed in to now,
   * and `used_account` the one it was used with, kept after it continues
   * signed out, so signing in to another account later starts a new
   * Session (5.4) rather than mixing them.
   */
  #writeSession(issuer: Issuer, label: string, sid: string, account: string | null, scope: string, used: string | null = account, authorityGeneration?: number): void {
    // Reusing a sid/account after sign-out must not restore its earlier approvals.
    const generation = authorityGeneration ?? this.session(issuer, label)?.authority_generation ?? 0;
    // A declaration belongs to its sid (3.4): kept while the sid is, and made again for a new one.
    const before = one(this.sql, declaredRow, "SELECT session_id, declared FROM poppy_sessions WHERE issuer = ? AND label = ?", issuer, label);
    const declared = before?.session_id === sid ? before.declared : null;
    this.sql.exec(
      `INSERT OR REPLACE INTO poppy_sessions (issuer, label, session_id, account, signed_in, scope, updated_at, used_account, authority_generation, declared)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      issuer,
      label,
      sid,
      account,
      account ? 1 : 0,
      scope,
      Date.now(),
      used,
      generation,
      declared === null ? null : JSON.stringify(declared)
    );
  }

  /** The account a Session was used with, signed in now or not. */
  #usedAccount(issuer: Issuer, label: string): string | null {
    return one(this.sql, sessionsTable.pick("used_account"), "SELECT used_account FROM poppy_sessions WHERE issuer = ? AND label = ?", issuer, label)?.used_account ?? null;
  }

  /**
   * The Session continues signed out (5.5): the same `sid`, no
   * account. Its cart and conversations carry on; what used the account
   * gets a challenge.
   */
  signOutSession(issuer: Issuer, label: string): void {
    const session = this.session(issuer, label);
    if (session) this.#writeSession(
      issuer, label, session.session_id, null, "", this.#usedAccount(issuer, label) ?? session.account,
      session.authority_generation + (session.signed_in ? 1 : 0)
    );
    this.#forgetTokens(issuer, label);
  }

  /**
   * Sign the Session `label` in to `account`. A Session already used
   * with another account gets a new `sid` instead (5.4: "start a new
   * Session rather than use a second account in one Session").
   */
  #bindAccount(company: Company, label: string, account: string, scope: string): void {
    const session = this.session(company.issuer, label);
    const used = session ? this.#usedAccount(company.issuer, label) ?? session.account : null;
    const sid = session && (!used || used === account) ? session.session_id : randomId();
    this.#forgetTokens(company.issuer, label);
    this.#writeSession(company.issuer, label, sid, account, scope);
  }

  /**
   * Whether a service takes only its own tokens (4.5): its protected
   * resource metadata, at the URL RFC 9728 3.1 defines from the service's
   * URL, names a `resource` other than the Company's domain. Fetched
   * without redirects, cached like discovery documents; no metadata, or
   * metadata whose `resource` isn't that service, means the default token.
   */
  async serviceResource(company: Company, service: string): Promise<string | undefined> {
    let cached = this.#serviceResources.get(service);
    if (!cached || cached.expiresAt <= this.host.now()) {
      const url = new URL(service);
      // RFC 9728 3.1 inserts the well-known segment before the exact service path.
      const path = url.pathname === "/" ? "" : url.pathname;
      let metadata: Json | null = null;
      let seconds: number | null = null;
      try {
        const fetched = await fetchJson(this.host.fetcher, `${url.origin}/.well-known/oauth-protected-resource${path}`, { maxRedirects: 0 });
        metadata = fetched.json;
        seconds = fetched.maxAgeSeconds;
      } catch {
        // No metadata: the default token works there (4.5).
      }
      cached = { metadata, expiresAt: this.host.now() + boundedCacheSeconds(seconds) * 1000 };
      this.#serviceResources.set(service, cached);
    }
    const resource = metadataResource(company, cached.metadata, service);
    if (resource === undefined || !identifiesService(resource, service)) return undefined;
    return resource.toLowerCase() !== `https://${company.domain}` ? resource : undefined;
  }

  /**
   * An invalid_token challenge refreshes stale service metadata once, without trusting a new issuer or
   * following a redirect. Its `resource` must be exactly the service, as at the derived URL (RFC 9728 3.3,
   * decision 43): a challenge can't send a token request to another resource.
   */
  async #refreshServiceMetadata(company: Company, service: string, hint: string, expectedResource?: string): Promise<string | undefined> {
    this.#serviceResources.delete(service);
    const url = serviceMetadataUrl(company, hint, service);
    if (!url) throw new PoppyError("invalid_response", departure(ours("the service's resource_metadata challenge"), ours("a public HTTPS metadata URL on one of this Company's hosts or the service's origin"), show.url(hint)), 0);
    let fetched: Awaited<ReturnType<typeof fetchJson>>;
    try { fetched = await fetchJson(this.host.fetcher, url.href, { maxRedirects: 0 }); }
    catch { throw new PoppyError("invalid_response", ours("The service's challenged resource metadata could not be fetched safely"), 0); }
    const resource = metadataResource(company, fetched.json, service);
    if (!resource || !identifiesService(resource, service) || (expectedResource !== undefined && resource !== expectedResource)) {
      const wanted = expectedResource ?? service;
      throw new PoppyError(
        "invalid_response",
        departure(
          ours("the refreshed resource metadata"),
          shown`the resource ${show.url(wanted, wanted)}, under this Company's issuer`,
          resource ? shown`the resource ${show.url(resource, resource)}` : ours("no resource this Company's issuer vouches for")
        ),
        0
      );
    }
    this.#serviceResources.set(service, { metadata: fetched.json, expiresAt: this.host.now() + boundedCacheSeconds(fetched.maxAgeSeconds) * 1000 });
    // An explicitly selected resource (MCP's exact URL) remains explicit even if it names the Company domain.
    return expectedResource ?? (resource.toLowerCase() === `https://${company.domain}` ? undefined : resource);
  }

  /**
   * The access token for a signed-in Session, from memory or by refresh
   * (4.4, 4.5); null for a signed-out one, which sends the Session header
   * alone. A refresh token the Company no longer honours signs the Session
   * out, and the request goes signed out (5.5). It starts the Session
   * `label` when there is none, so callers use it to have one.
   */
  async token(company: Company, options: TokenOptions = {}): Promise<HeldToken | null> {
    assertSupported(company);
    return this.#token(company, options);
  }

  async #token(company: Company, options: TokenOptions): Promise<HeldToken | null> {
    await this.#recoverSignIns(company.issuer);
    const label = options.label ?? "main";
    const session = this.sessionFor(company, label);
    if (!session.signed_in || !session.account) return null;
    const key = `${company.issuer}|${label}|${options.resource ?? ""}|${options.scope ?? ""}|access`;
    const dpop = company.dpop ? await this.dpopKey(company.issuer) : null;
    const usable = () => {
      const held = this.#tokens.get(key);
      return held && held.account === session.account && held.accountGeneration === this.accountGeneration(company.issuer, held.account)
        && held.expiresAt - RENEW_EARLY_MS > Date.now() && (held.type === "Bearer" || held.keyThumbprint === dpop?.thumbprint) ? held : undefined;
    };
    const held = usable();
    if (held) return held;
    return this.#serial(company.issuer, async () => usable() ?? this.#refresh(company, label, key, options, dpop));
  }

  async #refresh(company: Company, label: string, key: string, options: TokenOptions, dpop: DpopKey | null): Promise<HeldToken | null> {
    const session = this.session(company.issuer, label);
    const account = session?.account ? this.account(company.issuer, session.account) : undefined;
    if (!session?.account || !account) {
      this.signOutSession(company.issuer, label);
      return null;
    }
    const generation = this.accountGeneration(company.issuer, account.account);
    const credential = await this.#accountToken(account);
    const check = () => { this.#checkAccountGeneration(company.issuer, account.account, generation); this.#checkAccount(credential.row); };
    let response: TokenResponse;
    try {
      response = withScope(
        await this.tokenRequest(company, async () => ({
          grant_type: "refresh_token",
          refresh_token: credential.value,
          ...(options.resource ? { resource: options.resource } : {}),
          ...(options.scope ? { scope: options.scope } : {})
        }), { dpop: true, beforeDispatch: check }),
        options.scope ?? account.scope
      );
    } catch (error) {
      if (!hasCode(error, "invalid_grant")) throw error;
      check();
      await this.#accountGone(company, account.account);
      return null;
    }
    await this.#afterAccountUse(company, credential.row, response);
    this.#checkAccountGeneration(company.issuer, account.account, generation);
    const token = this.#held(response, dpop, account.account, generation);
    // Another scope or resource must not revive an older token (4.5).
    this.#forgetTokens(company.issuer, label);
    this.#tokens.set(key, token);
    return token;
  }

  /** An access token: its scheme is the one `token_type` names (4.5), and a DPoP-bound one needs the proof we sent. */
  #held(response: TokenResponse, dpop: DpopKey | null, account: string, generation: number): HeldToken {
    const held = this.#usable(response, dpop, account, generation);
    if (!held) throw new PoppyError("invalid_response", ours("The token response names a token_type this request can't use"), 0);
    return held;
  }

  #usable(response: TokenResponse, dpop: DpopKey | null, account: string, generation: number): HeldToken | null {
    const type = response.token_type?.toLowerCase();
    if (type !== "bearer" && !(type === "dpop" && dpop)) return null;
    return {
      value: response.access_token,
      account,
      accountGeneration: generation,
      type: type === "dpop" ? "DPoP" : "Bearer",
      expiresAt: Date.now() + response.expires_in * 1000,
      scope: response.scope ?? "",
      signedIn: true,
      keyThumbprint: type === "dpop" ? dpop!.thumbprint : null
    };
  }

  // ---------------------------------------------------------------- Resources

  /**
   * One request to a Company API, conversation, MCP server or other endpoint
   * the protocol defines: the Session header, signed for this request (5.2),
   * and the access token when signed in (4.5), with a DPoP proof when it is
   * DPoP-bound. Nonces, `invalid_token` refreshes, one new Session after
   * `session_ended`, and short `Retry-After` waits are handled; other auth
   * errors come back as `PoppyError`s. It takes only a request one of the
   * checking constructors made: an `EndpointRequest` to an endpoint
   * `poppy.json` names, or a `CheckedApiRequest` (apis.ts).
   */
  async resource(chosen: Company, outgoing: EndpointRequest | CheckedApiRequest, options: TokenOptions = {}): Promise<Response> {
    // The Company's document; after `version_unsupported`, the one chosen afresh (3.4).
    let company = chosen;
    const request = outgoing.init();
    const url = new URL(request.url);
    if (url.protocol !== "https:") {
      recordResource(this.sql, company, request, { token: "none", nonce: false }, { refused: "not_https" });
      throw new PoppyError("invalid_request", departure(ours("the request's URL"), ours("an https:// URL"), show.url(url)), 0);
    }
    // Tokens and Session JWTs go only to the Company's own hosts (N10), or to a server a description
    // poppy.json lists names, which 5.2 makes a Session destination; a checked API request carries it.
    const described = "describedServer" in outgoing && outgoing.company.issuer === company.issuer && request.url.startsWith(outgoing.describedServer.replace(/\/*$/, ""));
    // An endpoint a Company response named for this Session gets the Session header only (EndpointRequest.listed).
    const listed = "listed" in outgoing && outgoing.listed;
    if (listed) options = { ...options, noToken: true };
    if (!tokenHostAllowed(company, url) && !described && !listed) {
      recordResource(this.sql, company, request, { token: "none", nonce: false }, { refused: "untrusted_host" });
      throw new PoppyError(
        "untrusted_host",
        departure(
          ours("the request's host"),
          shown`one of ${show.name(company.name)}'s hosts: listed in its poppy.json, under ${show.name(company.domain)}, or in a URL in its issuer's protected_resources`,
          show.name(url.hostname),
          ours("It never gets a token or Session JWT")
        ),
        0
      );
    }
    const label = options.label ?? "main";
    let renewed = false;
    let restarted = false;
    let rechosen = false;
    let challengedResource: { readonly value: string | undefined } | undefined;
    for (let attempt = 0; attempt < 4; attempt++) {
      await this.#respectLimit(company.issuer);
      const { session: prepared, declared } = this.#declaredSession(company, label);
      let preparedToken: HeldToken | null | undefined;
      const sameSession = () => {
        const current = this.session(company.issuer, label);
        return sameAuthority(sessionAuthority(prepared), sessionAuthority(current)) && current?.signed_in === prepared.signed_in;
      };
      const sameBinding = () => sameSession() && (!preparedToken ||
        preparedToken.accountGeneration === this.accountGeneration(company.issuer, preparedToken.account));
      const checkRetry = () => {
        if (!sameBinding()) throw new PoppyError("approval_changed", ours("The account or Session changed after this request was sent. No further attempt will be sent."), 0);
      };
      // A signed-in request to a service that takes only its own tokens asks for one (4.5).
      let effective = options;
      if (challengedResource) {
        const { resource: _previous, ...rest } = options;
        effective = { ...rest, ...(challengedResource.value ? { resource: challengedResource.value } : {}) };
      } else if (!options.resource && options.service && prepared.signed_in) {
        const resource = await this.serviceResource(company, options.service);
        if (resource) effective = { ...options, resource };
      }
      const token = effective.noToken ? null : await this.token(company, effective);
      preparedToken = token;
      if (!sameBinding()) {
        if (sameSession()) throw new PoppyError("approval_changed", ours("The account's access changed while this request was being prepared. Start it again."), 0);
        // A sign-in or sign-out may have won while refresh was pending. Its
        // old response must neither travel nor populate the new Session's cache.
        this.#forgetTokens(company.issuer, label);
        if (attempt === 3) throw new PoppyError("approval_changed", ours("The account or Session changed while this request was being prepared. Start it again."), 0);
        continue;
      }
      // Tokens never travel in a URL (5.6), whatever a description or a model supplies.
      if (token && url.href.includes(token.value)) {
        recordResource(this.sql, company, request, { token: token.type, nonce: false }, { refused: "token_in_url" });
        throw new PoppyError("invalid_request", departure(ours("the request's URL"), ours("a URL without the access token in it"), ours("one that contains it")), 0);
      }
      const auth: ResourceAuth = { token: token?.type ?? "none", nonce: token?.type === "DPoP" && this.#nonce(url.origin) !== undefined };
      const log = (answer: Parameters<typeof recordResource>[4], next?: Followup) => recordResource(this.sql, company, request, auth, answer, next);
      const headers = new Headers(request.headers);
      headers.set("Accept", request.accept ?? "application/json");
      if (request.body !== undefined && !request.form) headers.set("Content-Type", "application/json");
      // Every request carries the Session header, signed for it alone (5.2); `ath` binds it to the token.
      const sid = prepared.session_id;
      headers.set("Poppy-Session", await this.sessionHeader(company, sid, { method: request.method, url: url.href, ...(token ? { accessToken: token.value } : {}) }));
      // 0.4: the versions the Session declared, on every request that carries its header (3.4).
      for (const [name, value] of declarationHeaders(declared)) headers.set(name, value);
      if (!token) {
        // Signed out (5): the Session header alone.
      } else if (token.type === "Bearer") {
        headers.set("Authorization", `Bearer ${token.value}`);
      } else {
        const nonce = this.#nonce(url.origin);
        headers.set("Authorization", `DPoP ${token.value}`);
        headers.set(
          "DPoP",
          await dpopProof(await this.dpopKey(company.issuer), {
            method: request.method,
            url: url.href,
            accessToken: token.value,
            ...(nonce ? { nonce } : {})
          })
        );
      }
      // 5.3: an operator signature for bot defenses, after the Session header, token and proof it covers.
      const operator = operatorKey(this.host.env);
      if (operator) await signRequest(await operator, this.identity.origin, { method: request.method, url: url.href, headers });
      const outbound = new Request(url.href, {
        method: request.method,
        headers,
        // Never follow a redirect with this proof or token (Guides).
        redirect: "manual",
        ...(request.form ? { body: request.form } : request.body !== undefined ? { body: JSON.stringify(request.body) } : {})
      });
      // No await between the authority check and fetch: a revocation during
      // token renewal, nonce retries or a rate-limit wait wins before sending.
      // Signing the Session JWT or DPoP proof also yields: the authority callback
      // must observe the same binding as the already prepared outbound request.
      if (!sameBinding()) {
        if (!sameSession()) this.#forgetTokens(company.issuer, label);
        throw new PoppyError("approval_changed", ours("The account or Session changed while this request was being prepared. Start it again."), 0);
      }
      options.beforeDispatch?.();
      // A deadline for the answer to start; the caller reads the body with `readBody`.
      const response = await withDeadline(this.timeouts.requestMs + (request.waitMs ?? 0), (signal) =>
        raceAbort(
          this.host.fetcher(outbound),
          signal
        )
      ).catch((error: unknown) => {
        log({ failed: noAnswer(error) });
        // Refused before anything was sent (a port a Worker won't honour): it never reached the Company, so no unknown outcome.
        if (refusedBeforeSending(error)) throw withoutAnswer(error);
        throw withAnswer(timeoutError(error, show.url(url)), "none");
      });
      const nonce = response.headers.get("DPoP-Nonce");
      if (nonce) this.#keepNonce(url.origin, nonce);
      const wait = await this.#observeLimits(company.issuer, response);
      const challenge = parseWwwAuthenticate(response.headers.get("WWW-Authenticate"));
      if (wait !== null) {
        await response.body?.cancel();
        const retrying = wait <= INLINE_WAIT_MS && attempt < 3;
        log({ status: response.status, error: challenge.error ?? null }, { kind: "wait", ms: wait, retrying });
        if (!retrying) throw withAnswer(new RateLimitedError(wait), response.status);
        checkRetry();
        await this.host.sleep(wait);
        checkRetry();
        continue;
      }
      if (response.status === 401 && challenge.error === "use_dpop_nonce" && nonce) {
        await response.body?.cancel();
        log({ status: 401, error: challenge.error }, { kind: "nonce" });
        checkRetry();
        continue;
      }
      if (response.status === 401 && challenge.error === "invalid_token" && !renewed) {
        // Expired or revoked: refresh it and retry once (7, 4.4).
        await response.body?.cancel();
        log({ status: 401, error: challenge.error }, { kind: "refresh" });
        checkRetry();
        this.dropToken(company, options);
        if (challenge.resourceMetadataAmbiguous) {
          this.#serviceResources.delete(options.service ?? options.resource ?? url.href);
          throw new PoppyError("invalid_response", ours("The service's authentication challenge has conflicting or malformed resource metadata"), 401);
        }
        if (challenge.resourceMetadata) {
          const service = options.service ?? options.resource ?? url.href;
          if (!sameBinding()) throw new PoppyError("approval_changed", ours("The account or Session changed before refreshing service metadata"), 0);
          const value = await this.#refreshServiceMetadata(company, service, challenge.resourceMetadata, options.resource);
          if (!sameBinding()) throw new PoppyError("approval_changed", ours("The account or Session changed while service metadata was being refreshed"), 0);
          challengedResource = { value };
        }
        renewed = true;
        continue;
      }
      // An error's code from its body, for the log and the check below; never a stream, which may not end.
      const peek =
        response.status >= 400 && !(response.headers.get("Content-Type") ?? "").includes("text/event-stream")
          ? ((await this.readJson(response.clone()).catch(() => null)) as { error?: unknown } | null)
          : null;
      // `session_ended` (5.5, 7: 400, in a JSON body; a 401 is read the same): start a new
      // Session once; an account it was signed in to stays with the new one. `invalid_session`
      // isn't retried: a new Session would fail the same way (7), so it reaches the caller.
      if ((response.status === 400 || response.status === 401) && !restarted && peek?.error === "session_ended") {
        await response.body?.cancel();
        log({ status: response.status, error: "session_ended" }, { kind: "restart" });
        checkRetry();
        this.#restartSession(company.issuer, label);
        options.onSessionRestart?.(sid, this.sessionFor(company, label).session_id);
        restarted = true;
        continue;
      }
      // 3.4: a version the Company doesn't serve, refused unhandled. Fetch poppy.json afresh and choose
      // again; a new choice takes a new Session, and the request is sent once more only if it means the
      // same in the new version (readings.md, v04-version-unsupported).
      if (response.status === 400 && !rechosen && peek?.error === "version_unsupported") {
        await response.body?.cancel();
        rechosen = true;
        const sent = company.protocolVersion;
        const fresh = await this.lookup(company.domain, { fresh: true }).catch(() => null);
        const again = fresh && isCompany(fresh) && fresh.issuer === company.issuer && fresh.protocolVersion !== sent ? fresh : null;
        log({ status: 400, error: "version_unsupported" }, again && options.versionNeutral ? { kind: "restart" } : undefined);
        if (!again) throw withAnswer(new PoppyError("version_unsupported", shown`${show.name(company.name)} refused protocol version ${show.code(sent)}, and its poppy.json offers no other this agent speaks. Nothing was handled.`, 400), 400);
        if (!options.versionNeutral) {
          throw withAnswer(new PoppyError("version_unsupported", shown`${show.name(company.name)} no longer serves protocol version ${show.code(sent)}; the agent now uses ${show.code(again.protocolVersion)} there. Nothing was handled, and this request wasn't sent again because it belongs to ${show.code(sent)}. Start it again.`, 400), 400);
        }
        checkRetry();
        company = again;
        if (!tokenHostAllowed(company, url) && !listed && !("describedServer" in outgoing && outgoing.company.issuer === company.issuer)) {
          throw new PoppyError("untrusted_host", departure(ours("the request's host"), shown`one of ${show.name(company.name)}'s hosts in its new poppy.json`, show.name(url.hostname), ours("The request wasn't sent again")), 0);
        }
        // The new declaration starts a new Session (#declaredSession), which a task's guard follows.
        options.onSessionRestart?.(sid, this.preparedSession(company, label).session_id);
        continue;
      }
      // 7: a 401 with no error code and the scopes needed is handled as insufficient_scope.
      const code = challenge.error ?? (response.status === 401 && challenge.scope ? "insufficient_scope" : undefined);
      log({ status: response.status, error: code ?? (typeof peek?.error === "string" ? peek.error : null) });
      if (code && (response.status === 401 || response.status === 403)) {
        await response.body?.cancel();
        throw withAnswer(
          new PoppyError(companyErrorCode(code, response.status), shown`${show.name(company.name)}: ${show.code(code)}`, response.status, {
            ...(challenge.scope ? { scope: challenge.scope } : {})
          }),
          response.status
        );
      }
      return response;
    }
    throw new PoppyError("server_error", shown`${show.name(company.name)} kept refusing the request`, 0);
  }

  /** `resource()` for JSON endpoints: non-2xx bodies with an `error` become `PoppyError`s. */
  async resourceJson(
    company: Company,
    request: EndpointRequest | CheckedApiRequest,
    options: TokenOptions = {}
  ): Promise<{ status: number; body: Json; headers: Headers }> {
    const response = await this.resource(company, request, options);
    let body: Json;
    try {
      const text = await this.readBody(response);
      try { body = text ? parseStrictJson(text) : null; }
      catch (error) {
        // Where the JSON broke, and what came there.
        const at = error instanceof JsonError && isDeparture(error.problem) ? error.problem : null;
        throw new PoppyError("invalid_response", at ? departure(shown`${show.name(company.name)}'s answer at ${at.subject}`, at.expected, at.got) : shown`${show.name(company.name)} returned malformed JSON`, response.status);
      }
    } catch (error) { throw withUnreadableAnswer(error, response.status); }
    if (response.status >= 400) {
      const required = extensionRequiredBody(company, body, response.status);
      if (required) throw required;
      const code = companyErrorCode(isObject(body) ? body.error : undefined, response.status);
      throw withAnswer(new PoppyError(code, shown`${show.name(company.name)} returned ${show.code(code)}`, response.status, {
        ...(body !== null ? { body } : {})
      }), response.status);
    }
    return { status: response.status, body, headers: response.headers };
  }
}
