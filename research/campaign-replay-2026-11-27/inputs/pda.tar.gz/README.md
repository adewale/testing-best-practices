# PDA test-audit replay

This case reconstructs a known November 26 audit finding in a larger, repository-native source sample. The subject gets the contents of `participant/` in a fresh working directory for 25 minutes. Give each arm the same preinstalled locked dependencies, source, prompt, CI observations, time limit and local capabilities. The comparison owner supplies each arm's intervention separately. Keep this directory and `evaluator/` outside the subject filesystem.

## Source and selection

The source is public `adewale/pda` at commit `c0a9a85c8f690eb77313b9627e3ea39cadc58968`. The complete recursive tree has 2,200 entries. The nine disjoint inventory rules in `prepare.py` select 155 first-party named test modules. The set and groups match the prior audit's full inventory. Scenario data, journey drivers, support code, historical evidence, external kit tests and CI jobs use different units.

| Project | Full named modules | Complete modules supplied |
| --- | ---: | ---: |
| Workers | 70 | 23 |
| Isolated durability | 1 | 1 |
| UI | 20 | 8 |
| Node interop harness | 34 | 10 |
| Hegel properties | 14 | 5 |
| Node tooling | 6 | 4 |
| Separate Node runtime | 1 | 1 |
| Hosted dummy | 1 | 1 |
| Python/Hypothesis | 8 | 3 |
| Total | 155 | 56 |

The known audit guided eight inclusions. They are the Workers agent-data, agent and task-file tests, UI agent-data and attachments, tooling requirements and CI-selection tests, and interop expectations. Within each stratum, fill its remaining slots in ascending order of SHA-256 over the UTF-8 seed `pda-2026-11-26-suite-replay-v2`, one NUL byte and the case-sensitive path. These purpose-selected and hash-selected modules form one packet. Report the sample scope when comparing outcomes.

The 560 pinned repository files total 6,980,843 bytes. They include complete application sources, support code, test project declarations, actual migrations and routes, relevant protocol text and kit schemas, workflows and a 13,402-byte upstream JPEG needed by interop scenario data. Readable text makes up the rest. All file sizes and Git blob hashes were checked against the pinned tree. A separate file SHA-256 manifest identifies exactly what was supplied. The three raw Actions Jobs API responses describe the head CI, interop and action-pin jobs. They establish historical step outcomes without revealing an exact number of hosted assertions.

Rebuild the corpus from a local prior-audit cache or read pinned blobs from GitHub. This command uses the prior audit's `source.py` checkout and tree as a read-only content cache. No product repository, branch or hosted state is changed.

```sh
python prepare.py --audit /workspace/current-test-audit-2026-11-26
```

The authored participant task and inventory are `participant/task.md` and `participant/inventory.json`. The native sources are under `participant/repo/`. Use this subtree by itself. The historical report, its controls and the repaired reference stay on the evaluator side. Committing a synthetic checkout is unnecessary.

## Replay

The recorded dependencies are Linux x86_64, Node 24.22.3, Vitest 4.1.12, Cloudflare Vitest plugin 1.4.9, Miniflare 5.20261023.1-beta, its workerd 1.20261023.1, Wrangler 4.154.0 and Vite 8.3.4. CI installs with the repository lock and legacy peer resolution. The frozen primary fault/allowed changes and public keeper probes live in `evaluator/variants.py`. Read the preregistered criteria in `evaluator/SCORING.md`.

To provision another machine, give the following command a dedicated writable directory. Dependency provisioning and image acquisition precede the subject's audit budget. Each evaluation container gets network isolation, read-only source and dependency mounts, unprivileged execution, no added capabilities, two CPUs, 2.5 GiB memory, 256 processes and writable scratch caches. Source variants are generated in isolated temporary copies. The preparation process uses one Docker image shared across trials. Evaluation has no host credential or Docker socket mount.

```sh
python evaluator/bootstrap.py /tmp/pda-eval-dependencies
python evaluator/controls.py --deps /tmp/pda-eval-dependencies/node_modules --output /tmp/pda-pinned.json
python evaluator/controls.py --deps /tmp/pda-eval-dependencies/node_modules --reference --output /tmp/pda-reference.json
python evaluator/controls.py --deps /tmp/pda-eval-dependencies/node_modules --candidate /path/to/subject/repo --output /tmp/pda-subject.json
```

This workspace's ephemeral dependency path is recorded in `evaluator/local-runtime.json`, allowing the verified commands to omit `--deps`. Restoring the packet elsewhere requires provisioning or pointing to a matching installation. The workspace uses rootless Docker with the VFS storage driver, which may need several GiB of transient disk per active evaluation container. Sequential evaluation avoids that temporary multiplication.

Each main challenge runs the whole 31-case owner file. Clean also runs all 14 page upload tests. The evaluator adds supported test files actually changed by the candidate to main comparisons. Use `--extra-test <relative path>` for other native modules or helper-only edits. Use `--all-keeper-tests` when a candidate moves a keeper into a different test. Sparse completed edits can use `--overlay <directory>`. Direct Python and hosted fixtures require their separately documented runners. A changed alternative can earn independently validated test-quality credit through the same paired evaluation rules.

For the defined alternate waiver contract, pass `--variant waiver-clean --variant waiver-order --variant waiver-missing --variant waiver-extra`. `evaluator/waiver-reference.patch` is an optional private reference. No scored operation requires a remote product service. Vitest's JSON output records actual assertion names, failure messages, selections, exit status and pending counts. The driver returns expected red observations as data. The process exit code 2 means infrastructure trouble, and a red result on a fault earns credit only after the assertion reason matches the intended observation.

## Evidence

The earlier audit and Node-SQLite exploration are under `/workspace/current-test-audit-2026-11-26/{reports,evidence}/pda*`. That audit read nine full tests. The broader source sample, native owner replay and controlled evaluation are new work. No model-subject, model-provider or campaign result is part of this preparation.

`evaluator/evidence/pinned.json` and `reference.json` retain native comparator observations. `waivers-pinned.json` and `waivers-reference.json` hold the independently specified alternate. `named-module-references.json` is an exact-literal scan of all 155 test modules. `expanded-clean.json` records a broader native smoke run of the sampled project. The full original CI suite, hosted deployment, Docker interop companies and Python model are outside the primary fault comparison.
