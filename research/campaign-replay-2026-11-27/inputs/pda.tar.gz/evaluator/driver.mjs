// Runs in a network-disabled container. Only compact, per-file reporter data returns to the orchestrator.
import { spawnSync } from "node:child_process";
import { closeSync, openSync, readFileSync, statSync } from "node:fs";

const groups = JSON.parse(process.argv[2]);
const output = [];
for (const [index, group] of groups.entries()) {
  if (group.config === "node:test") {
    const args = ["--test", "--test-reporter=tap", ...group.files];
    const command = spawnSync(process.execPath, args, { cwd: "/work", encoding: "utf8", timeout: 120000, maxBuffer: 2 * 1024 * 1024 });
    const tap = command.stdout ?? "";
    const count = word => Number(new RegExp("^# " + word + " (\\d+)$", "m").exec(tap)?.[1] ?? 0);
    const found = [...tap.matchAll(/^(not )?ok \d+ - (.+)$/gm)];
    const fail = count("fail");
    output.push({ config: group.config, files: group.files, exit: command.status, signal: command.signal,
      passed: count("pass"), failed: fail, skipped: count("skipped"), todo: count("todo"),
      success: command.status === 0 && found.length > 0 && !fail,
      assertions: found.map(m => ({ file: group.files.join(", "), name: m[2], status: m[1] ? "failed" : "passed" })),
      ...(found.length ? {} : { runnerError: "no TAP assertions", log: (command.stderr ?? "").slice(-800) }) });
    continue;
  }
  const resultPath = `/tmp/runner-${index}.json`;
  const logPath = `/tmp/runner-${index}.log`;
  const args = ["node_modules/vitest/vitest.mjs", "run", "--maxWorkers=1", "--config", group.config,
    ...group.files, ...(group.name ? ["-t", group.name] : []), "--reporter=json", "--outputFile", resultPath];
  const fd = openSync(logPath, "w");
  const result = spawnSync(process.execPath, args, { cwd: "/work", stdio: ["ignore", fd, fd], timeout: 120000 });
  closeSync(fd);
  const item = { config: group.config, files: group.files, pattern: group.name ?? null, exit: result.status, signal: result.signal };
  try {
    if (statSync(resultPath).size > 16 * 1024 * 1024) throw Error("runner report too large");
    const report = JSON.parse(readFileSync(resultPath, "utf8"));
    Object.assign(item, { passed: report.numPassedTests, failed: report.numFailedTests,
      skipped: report.numPendingTests, todo: report.numTodoTests, success: report.success,
      assertions: report.testResults.flatMap(file => file.assertionResults.map(a => ({
        file: file.name.replace(/^\/work\//, ""), name: a.fullName, status: a.status,
        ...(a.status === "failed" ? { message: (a.failureMessages?.[0] ?? "").slice(0, 1250) } : {})
      }))) });
  } catch (e) {
    item.runnerError = String(e);
    try { item.log = readFileSync(logPath, "utf8").slice(-2000); } catch {}
  }
  output.push(item);
}
console.log(JSON.stringify({ node: process.version, results: output }));
