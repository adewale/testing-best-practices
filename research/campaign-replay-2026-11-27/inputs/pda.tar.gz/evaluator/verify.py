#!/usr/bin/env python3
"""Verify the directional controls from retained native Vitest evidence."""
from pathlib import Path
import hashlib
import json

HERE = Path(__file__).resolve().parent
EV = HERE / "evidence"
PRIMARY = ("clean", "empty-data", "tail-bit", "physical-order", "member-order", "auth-keeper", "isolation-keeper", "upload-byte-keeper")
ALT = ("waiver-clean", "waiver-order", "waiver-missing", "waiver-extra")
OWNER = "exports the caller's records and chunked photos"
UI = "sends a picked photo to the User's own agent"
WAIVER = "abandons exactly the credentials it showed"


def get(path):
    return json.loads(path.read_text())


def check(kind, ref=False, alt=False):
    raw = get(EV/(kind+".json"))
    variants = ALT if alt else PRIMARY
    assert set(variants) == set(raw["variants"]), kind
    short = {}
    for variant in variants:
        groups = raw["variants"][variant]["results"]
        assert groups and all("runnerError" not in x and x["signal"] is None for x in groups), (kind,variant)
        if alt:
            fail = variant in ("waiver-missing", "waiver-extra") or (variant == "waiver-order" and not ref)
            expected = [(5-int(fail), int(fail))]
        elif variant == "clean":
            expected = [(31, 0), (14, 0)]
        elif variant.endswith("-keeper"):
            expected = [(0, 1)]
        elif ref and variant in ("empty-data","tail-bit"):
            expected = [(30, 1)]
        else:
            expected = [(31, 0)]
        observed = [(x["passed"],x["failed"]) for x in groups]
        assert observed == expected, (kind, variant, observed, expected)
        for group in groups:
            assert group["exit"] == int(group["failed"] > 0)
            assert group["todo"] == 0
            if not variant.endswith("-keeper"):
                assert group["skipped"] == 0
            for r in group["assertions"]:
                if r["status"] == "failed":
                    intended = WAIVER if alt else UI if variant == "upload-byte-keeper" else OWNER
                    assert intended in r["name"], (kind,variant,r["name"])
                    assert r["message"].startswith("AssertionError"), (kind,variant,r["message"])
        short[variant] = [{"passes": r["passed"], "failures": r["failed"], "skipped": r["skipped"]} for r in groups]
    return short


def main():
    frozen = get(HERE/"frozen.json")["file_sha256"]
    assert all(hashlib.sha256((HERE.parent/p).read_bytes()).hexdigest() == sha for p,sha in frozen.items())
    manifest = get(HERE/"source-manifest.json")["files"]
    source = HERE.parent/"participant/repo"
    assert all(hashlib.sha256((source/file["path"]).read_bytes()).hexdigest()==file["sha256"] for file in manifest)
    sample = get(HERE.parent/"participant/inventory.json")
    assert sample["modules_total"] == 155 and sample["modules_supplied"] == 56
    assert sum(r["supplied"] for r in sample["modules"]) == 56
    assert [r["path"] for r in sample["modules"] if r["supplied"] and not (source/r["path"]).is_file()] == []
    result = {
        "inventory": 155, "supplied": 56, "pinned_source_files": len(manifest),
        "pinned": check("pinned"), "reference": check("reference",ref=True),
        "waivers_pinned": check("waivers-pinned",alt=True),
        "waivers_reference": check("waivers-reference",ref=True,alt=True),
        "directional_calibration_verified": True,
        "scope": "Complete 31-case owner and 14-case client upload files on clean, full worker owner file on main variants, designated preexisting affected tests on keeper probes. Complete 5-case alternate page file across four alternate controls.",
    }
    (EV/"verified-summary.json").write_text(json.dumps(result,indent=2)+"\n")
    print("Verified pinned/reference directions, intended failed assertions, receipts, source and sample.")

if __name__ == "__main__":
    main()
