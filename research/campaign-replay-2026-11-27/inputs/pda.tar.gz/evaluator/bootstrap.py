#!/usr/bin/env python3
"""Provision reusable dependencies outside the participant directory."""
from pathlib import Path
import argparse
import json
import os
import shutil
import subprocess

HERE = Path(__file__).resolve().parent
IMAGE = "node@sha256:49f7adaf9f1574bc45c20ea317139b39a59d7e758d0e93745e112fd85cb42623"

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("directory", type=Path)
    args = parser.parse_args()
    target = args.directory.resolve()
    target.mkdir(exist_ok=True, parents=True)
    lock = HERE.parent / "participant/repo/package-lock.json"
    if (target/"package-lock.json").exists() and (target/"package-lock.json").read_bytes() != lock.read_bytes():
        raise SystemExit("use a directory dedicated to this locked dependency graph")
    for name in ("package.json", "package-lock.json"):
        shutil.copyfile(HERE.parent/"participant/repo"/name, target/name)
    if not subprocess.run(["node", "--version"], text=True, capture_output=True, check=True).stdout.startswith("v24."):
        raise SystemExit("Node 24 is required to provision these Linux x86_64 dependencies")
    subprocess.run(["npm", "ci", "--legacy-peer-deps", "--no-audit", "--no-fund", "--cache", str(target/".npm-cache")], cwd=target, check=True)
    for part in (".vite", ".vite-temp"):
        (target/"node_modules"/part).mkdir(exist_ok=True)
    subprocess.run(["docker", "pull", IMAGE], check=True)
    print(json.dumps({"node_modules": str(target/"node_modules"), "image": IMAGE}))

if __name__ == "__main__":
    main()
