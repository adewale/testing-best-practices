#!/usr/bin/env python3
"""Run frozen owner, compatibility and sensitivity challenges in disposable, networkless containers."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import tempfile
import uuid
from variants import EDITS, KEEPERS, MAIN, apply

HERE = Path(__file__).resolve().parent
PUBLIC = HERE.parent / "participant/repo"
IMAGE = "node@sha256:49f7adaf9f1574bc45c20ea317139b39a59d7e758d0e93745e112fd85cb42623"
OWNER = "test/agent-data.test.ts"
PAGE = "test/ui/attachments.test.tsx"
OWNER_CHECK = "exports the caller's records and chunked photos"
PAGE_CHECK = "sends a picked photo to the User's own agent"
CONFIG = {
    "workers": "test/vitest.config.ts", "durability": "test/durability/vitest.config.ts",
    "ui": "test/ui/vitest.config.ts", "interop": "interop/vitest.config.ts",
    "properties": "test/properties/vitest.config.ts",
}


def project(path):
    if re.fullmatch(r"test/[^/]+\.test\.ts", path):
        return "workers"
    for kind, pattern in [("durability", r"test/durability/.*\.test\.ts"), ("ui", r"test/ui/.*\.test\.tsx"),
                          ("interop", r"interop/test/.*\.test\.(?:mjs|ts)"),
                          ("properties", r"test/properties/.*\.test\.ts")]:
        if re.fullmatch(pattern, path):
            return kind
    if re.fullmatch(r"scripts/(?:[^/]+\.test\.mjs|node-runtime\.check\.mjs)", path):
        return "node"
    return None


def test_path(path):
    verification = {
        ".github/workflows/ci.yml", ".github/workflows/interop.yml",
        "scripts/ci-scope.mjs", "scripts/check-requirements.mjs", "scripts/check-docs.mjs",
        "scripts/check-spec.mjs", "scripts/test-projects.mjs", "interop/runner/expectations.ts",
    }
    if path in verification:
        return True
    return (path.startswith(("test/", "interop/test/")) and path.endswith((".ts", ".tsx", ".mjs", ".py", ".json")) or
            project(path) == "node") and "vitest.config" not in path and not path.endswith(("vitest.shared.ts", "wrangler.jsonc"))


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def candidate_overlay(candidate, repo, manifest, partial):
    changed, notes = [], []
    if candidate is None:
        return changed, notes
    candidate = candidate.resolve()
    if not candidate.is_dir():
        raise ValueError("candidate must name a source directory")
    if not partial and not (candidate / "package.json").is_file():
        raise ValueError("candidate must be a full participant repo, or use --overlay for changed files")
    paths = set(manifest) if not partial else set()
    for root, dirs, files in os.walk(candidate, followlinks=False):
        if Path(root) == candidate:
            dirs[:] = [d for d in dirs if d in ("src", "test", "interop", "scripts", ".github")]
        dirs[:] = [d for d in dirs if not d.startswith(".") and d not in {"node_modules", "__pycache__", "results"}]
        for name in files:
            paths.add((Path(root) / name).relative_to(candidate).as_posix())
    for path in sorted(paths):
        src, dest = candidate / path, repo / path
        if not src.exists():
            if not partial and path in manifest:
                if not test_path(path):
                    raise ValueError(f"candidate removed a non-test file: {path}")
                if path in (OWNER, PAGE):
                    raise ValueError(f"candidate removed a public keeper module: {path}")
                dest.unlink()
                changed.append(path)
            continue
        if src.is_symlink() or candidate not in src.resolve().parents or not src.is_file():
            raise ValueError(f"unexpected candidate file type: {path}")
        if path not in manifest and not test_path(path):
            if path.startswith(("src/", "test/", "scripts/", "interop/", ".github/")):
                notes.append(f"outside test overlay: {path}")
            continue
        if src.stat().st_size > 2_000_000:
            raise ValueError(f"candidate source file too large: {path}")
        if path in manifest and digest(src) == manifest[path]:
            continue
        if not test_path(path):
            raise ValueError(f"candidate changed a non-test file: {path}")
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(src, dest)
        changed.append(path)
    return changed, notes


def plans(variant, extra, all_keepers=False):
    if variant.startswith("waiver-"):
        return [{"config": CONFIG["ui"], "files": sorted({"test/ui/agent-data.test.tsx", *(p for p in extra if project(p) == "ui")})}]
    if variant in ("auth-keeper", "isolation-keeper"):
        if all_keepers:
            return [{"config": CONFIG["workers"], "files": sorted({OWNER, *(p for p in extra if project(p) == "workers")})}]
        return [{"config": CONFIG["workers"], "files": [OWNER], "name": OWNER_CHECK}]
    if variant == "upload-byte-keeper":
        if all_keepers:
            return [{"config": CONFIG["ui"], "files": sorted({PAGE, *(p for p in extra if project(p) == "ui")})}]
        return [{"config": CONFIG["ui"], "files": [PAGE], "name": PAGE_CHECK}]
    files = {OWNER, *extra}
    if variant == "clean":
        files.add(PAGE)
    groups = []
    for kind in (*CONFIG, "node"):
        selected = sorted(p for p in files if project(p) == kind)
        if selected:
            groups.append({"config": CONFIG.get(kind, "node:test"), "files": selected})
    return groups


def execute(repo, deps, groups):
    container = "pda-replay-" + uuid.uuid4().hex
    for directory in ("node_modules", ".wrangler", ".hegel"):
        (repo / directory).mkdir(exist_ok=True)
    subprocess.run(["git", "init", "--template=", "-q", str(repo)], check=True)
    docker = ["docker", "run", "--pull=never", "--rm", "--init", "--name", container,
              "--network=none", "--read-only", "--cap-drop=ALL", "--security-opt=no-new-privileges",
              "--user", f"{os.getuid()}:{os.getgid()}", "--cpus=2", "--memory=2500m", "--pids-limit=256",
              "--tmpfs", "/tmp:rw,exec,mode=1777,size=350m",
              "--mount", f"type=bind,src={repo},dst=/work,readonly",
              "--mount", f"type=bind,src={deps},dst=/work/node_modules,readonly",
              "--mount", f"type=bind,src={HERE/'driver.mjs'},dst=/driver.mjs,readonly",
              "--env", "CI=true", "--env", "WRANGLER_SEND_METRICS=false", "--env", "XDG_CONFIG_HOME=/tmp/config",
              "--env", "XDG_CACHE_HOME=/tmp/cache", "--env", "RAYON_NUM_THREADS=2", "--workdir", "/work"]
    for key in ("ALL_PROXY", "HTTP_PROXY", "HTTPS_PROXY", "NO_PROXY",
                "all_proxy", "http_proxy", "https_proxy", "no_proxy"):
        docker.extend(["--env", key + "="])
    for part, size in (("node_modules/.vite", "220m"), ("node_modules/.vite-temp", "40m"),
                       (".wrangler", "80m"), (".hegel", "40m")):
        docker.extend(["--tmpfs", f"/work/{part}:rw,exec,mode=1777,size={size}"])
    docker.extend([IMAGE, "node", "/driver.mjs", json.dumps(groups)])
    try:
        proc = subprocess.run(docker, capture_output=True, text=True, timeout=145 * len(groups) + 20)
    except subprocess.TimeoutExpired:
        subprocess.run(["docker", "rm", "-f", container], capture_output=True, timeout=30)
        return {"error": "container timed out"}
    if proc.returncode:
        return {"error": f"runner exited {proc.returncode}", "log": (proc.stderr + proc.stdout)[-2200:]}
    try:
        return json.loads(proc.stdout)
    except ValueError:
        return {"error": "missing runner output", "log": (proc.stderr + proc.stdout)[-2200:]}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    pick = parser.add_mutually_exclusive_group()
    pick.add_argument("--candidate", type=Path, help="complete subject repo with changes")
    pick.add_argument("--overlay", type=Path, help="sparse directory containing only added/updated test files")
    pick.add_argument("--reference", action="store_true", help="exercise private calibration patch")
    parser.add_argument("--variant", choices=EDITS, action="append", help="default is all frozen variants")
    parser.add_argument("--all-keeper-tests", action="store_true", help="run whole affected modules when public tests moved/renamed")
    parser.add_argument("--extra-test", action="append", default=[], help="repository-relative native test module")
    parser.add_argument("--deps", type=Path, help="absolute node_modules path installed from the packet lock")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    local = HERE / "local-runtime.json"
    hint = json.loads(local.read_text())["node_modules"] if local.exists() else ""
    deps = (args.deps or Path(os.environ.get("PDA_REPLAY_DEPS", hint))).resolve()
    if not (deps / "vitest/vitest.mjs").is_file():
        parser.error("prepare locked dependencies with evaluator/bootstrap.py, or pass --deps")
    for part in [".vite", ".vite-temp"]:
        (deps / part).mkdir(exist_ok=True)
    manifest = {r["path"]:r["sha256"] for r in json.loads((HERE / "source-manifest.json").read_text())["files"]}
    for path, sha in manifest.items():
        assert digest(PUBLIC/path) == sha, f"modified packet file: {path}"
    output = {"container_image": IMAGE, "repository": "adewale/pda", "sha": "c0a9a85c8f690eb77313b9627e3ea39cadc58968",
              "mode": "reference" if args.reference else "candidate" if args.candidate or args.overlay else "pinned",
              "variants": {}, "scope": "Selected native modules. The default runs the complete owner file on every main variant and the page file on clean. Keeper probes are filtered to their original affected test."}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    for variant in args.variant or (*MAIN, *KEEPERS):
        with tempfile.TemporaryDirectory(prefix="pda-replay-check-") as tmp:
            repo = Path(tmp)/"repo"
            shutil.copytree(PUBLIC, repo, ignore=shutil.ignore_patterns(".git", "node_modules", ".wrangler", "__pycache__"))
            changed, notes = candidate_overlay(args.candidate or args.overlay, repo, manifest, bool(args.overlay))
            if args.reference:
                subprocess.run(["git", "apply", str(HERE/"reference.patch")], cwd=repo, check=True)
                changed = [OWNER]
            tests = sorted(set(args.extra_test) | {p for p in changed if project(p) and (repo/p).is_file()})
            notes += [f"separate execution required for {p}" for p in changed if (p.endswith(".py") or "/hosted/" in p) and not project(p)]
            if any(project(p) is None or not (repo/p).is_file() for p in tests):
                raise ValueError(f"unrecognized or absent selected module: {tests}")
            groups = plans(variant, tests, args.all_keeper_tests)
            output.update(changed_test_files=changed, extra_test_modules=tests, overlay_notes=notes)
            try:
                apply(repo, variant)
                observation = execute(repo, deps, groups)
            except ValueError as ex:
                observation = {"error": str(ex)}
            output["variants"][variant] = observation
        args.output.write_text(json.dumps(output, indent=2) + "\n")
        counts = [(r["config"], r.get("passed"), r.get("failed"), r.get("runnerError")) for r in observation.get("results", [])]
        print(f"{variant}: {counts or observation.get('error')}", flush=True)
    infrastructure = any("error" in v or any(r.get("runnerError") for r in v.get("results", []))
                         for v in output["variants"].values())
    raise SystemExit(2 if infrastructure else 0)


if __name__ == "__main__":
    main()
