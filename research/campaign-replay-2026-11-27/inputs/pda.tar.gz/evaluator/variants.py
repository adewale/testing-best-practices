"""Private, frozen comparator variants. Apply only to disposable trees."""
from pathlib import Path

EXPORT = "src/agent-data-export.ts"
ATTACH = "src/attachments.ts"
HELPER = "test/agent-helpers.ts"
UI = "src/ui/attachments.tsx"
ENCODE = 'record[key] = { encoding: "base64", data: btoa(binary) };'
EXECUTE = "  return worker.fetch(request, { ...env, ...overrides });"
WRITE = "  for (let seq = 0, offset = 0; offset < bytes.byteLength; seq++, offset += CHUNK_BYTES) {"
# A label/row-preserving historical reconstruction, an independent calibration for length-only oracles,
# two semantics-preserving representations, and public test sensitivity calibrations.
EDITS = {
    "clean": None,
    "empty-data": (EXPORT, ENCODE, 'record[key] = { encoding: "base64", data: "" };'),
    "tail-bit": (EXPORT, ENCODE, '''if (table === "attachment_chunks" && row.part === "file" && Number(row.seq) > 0 && binary.length) {
        binary = binary.slice(0, -1) + String.fromCharCode(binary.charCodeAt(binary.length - 1) ^ 1);
      }
      ''' + ENCODE),
    "physical-order": (ATTACH, WRITE,
        "  for (let seq = Math.ceil(bytes.byteLength / CHUNK_BYTES) - 1; seq >= 0; seq--) {\n    const offset = seq * CHUNK_BYTES;"),
    "member-order": (EXPORT, ENCODE, 'record[key] = { data: btoa(binary), encoding: "base64" };'),
    # Inert test-response probes; no production authentication logic or storage permissions change.
    "auth-keeper": (HELPER, EXECUTE, '''  const response = await worker.fetch(request, { ...env, ...overrides });
  if (request.method === "GET" && new URL(request.url).pathname === "/api/agent-data" && response.status === 401)
    return new Response(null, { status: 200 }); // empty synthetic response in this test harness
  return response;'''),
    "isolation-keeper": (HELPER, EXECUTE, '''  const response = await worker.fetch(request, { ...env, ...overrides });
  if (request.method === "GET" && new URL(request.url).pathname === "/api/agent-data" && response.ok) {
    const data = await response.json() as Record<string, unknown>;
    return Response.json({ ...data, comparisonFixture: "SOMEONE_ELSES_NOTE" }, { headers: response.headers });
  }
  return response;'''),
    "upload-byte-keeper": (UI, 'form.append("file", file, file.name);',
        'form.append("file", new File([new Uint8Array(file.size)], file.name, { type: file.type }), file.name);'),
}
# Separately nominated known alternative: the page sends a set of waiver IDs to the server.
WAIVER = "abandonRevocations: abandon.map(item => item.id)"
EDITS.update({
    "waiver-clean": None,
    "waiver-order": ("src/ui/agent-data.tsx", WAIVER, "abandonRevocations: abandon.map(item => item.id).reverse()"),
    "waiver-missing": ("src/ui/agent-data.tsx", WAIVER, "abandonRevocations: abandon.slice(1).map(item => item.id)"),
    "waiver-extra": ("src/ui/agent-data.tsx", WAIVER, 'abandonRevocations: [...abandon.map(item => item.id), "so_unshown_fixture"]'),
})
MAIN = ("clean", "empty-data", "tail-bit", "physical-order", "member-order")
KEEPERS = ("auth-keeper", "isolation-keeper", "upload-byte-keeper")


def apply(repo: Path, variant: str):
    edit = EDITS[variant]
    if edit is None:
        return
    name, before, after = edit
    path = repo / name
    source = path.read_text()
    if source.count(before) != 1:
        raise ValueError(f"{variant}: unique source precondition failed in {name}")
    path.write_text(source.replace(before, after))
