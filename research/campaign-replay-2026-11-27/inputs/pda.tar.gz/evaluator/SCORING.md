# Evaluator instructions

This is a reconstruction of the 2026-11-26 PDA audit. The primary behavior comes from finding pda-02. The prior report read nine complete test modules and sections of other files. This packet contains 56 complete test modules across nine native test groups. Prior knowledge influenced eight inclusions and the choice of comparator. Treat the result as a replay on a larger suite sample. An auditor can reasonably identify a different consequential issue.

## Prespecified evidence

The export promises personal data and the original photos. See `pda-spec.md:344`, `docs/using.md:79` and the download's instructions in `src/agent-data-export.ts`. The input fixture exists before serialization. `src/agent.ts` passes attachment bytes to `saveAttachment`, which writes file chunks to real SQLite using its migration and sequence key. The authenticated GET in `src/agent-data-routes.ts` calls this agent's export. The comparison point is the downloaded file as consumed using the documented attachment ID, part and sequence. A test at a narrower boundary can earn corresponding evidence when it exercises an actual producer and independently reconstructs the payload. Name the boundary precisely.

The two photo assertions at `test/agent-data.test.ts:97` check row count and the first encoding label. Other assertions in the same test separately establish the caller's memory, absence of a second person's memory, omission of credentials, anonymous 401 and no-store response. The renderer-to-upload test at `test/ui/attachments.test.tsx:111` verifies the exact bytes of a selected file on the client side. It covers another boundary. Inspect all modified or removed assertions.

| Challenge | Behavior | Expected original | Expected repaired photo proof |
| --- | --- | --- | --- |
| clean | Pinned production and test fixtures | Pass | Pass |
| empty-data | The serializer emits empty strings for SQL BLOBs, retaining the rows and base64 labels | Pass full original 31-owner-test file | Fail on missing restored bytes |
| tail-bit | One trailing bit changes in each original-file chunk after sequence zero; lengths, identifiers and base64 remain valid | Pass full original 31-owner-test file | Fail on changed content |
| physical-order | The private writer inserts chunks in descending sequence order while each serialized key and payload stays correct | Pass | Pass |
| member-order | The serialized byte object's keys are emitted data-first | Pass | Pass |
| auth-keeper | The test harness alone substitutes an empty 200 at the unauthenticated GET response after exercising the route | Original combined test fails on expected 401 | Retain this sensitivity |
| isolation-keeper | The test harness adds a synthetic second-person sentinel to the exported JSON after the route returns | Original combined test fails on forbidden sentinel | Retain this sensitivity |
| upload-byte-keeper | The page sends a same-name/type/size file with zeroed bytes to its existing stubbed fetch | Original page test fails on uploaded byte content | Retain this sensitivity |

The complete owner module runs on the five main challenges. The clean case also runs all 14 page attachment tests. The three keeper probes select their original affected case by name. If a subject splits or renames a check, select all changed tests against the same test-harness fault and adjudicate the equivalent observation independently. A renamed/filtered case that selected zero is unverified. An added case in another native test file runs on the main challenges if supplied as part of the full candidate or with `--extra-test`. A failing entry must be the relevant test and assertion. Startup or unrelated failures, an unconditional failure, disabled assertions, timeouts and empty selections provide no fault-detection credit.

Record each dimension independently:

- **Detected byte loss:** clean passes and the candidate's own relevant assertion fails for `empty-data`, while the complete original owner file accepts that same change.
- **Detected content corruption:** the candidate detects `tail-bit` with the clean case passing. Checking length, base64 syntax or file magic alone gives no content-equality credit.
- **Accepted permitted changes:** run both representation variants. Note row-order assumptions, serialized-object snapshots or internals that make a clean reconstruction turn red.
- **Preserved evidence:** record which of the existing auth, isolation, redaction and upload-byte checks survive. Inspect source and record all three controlled keeper outcomes. Missing probes are unresolved until rerun or adjudicated with equivalent fixtures.
- **Strength of the proof:** describe independent expected bytes and actual seams. Distinctive data on both sides of a real boundary avoids masked duplicates or transpositions. Length plus high-quality digest or full byte equality is acceptable. An invented copy of the production algorithm, mocks that decide both sides, or claims about unexecuted tiers lose the corresponding evidence.
- **Alternate valid repair:** record discovery of this target separately from a different demonstrated improvement. For a different finding, preserve its actual changed test, run baseline and candidate on the same credible behavioral fault or allowed implementation change, and check the opposite-direction control. Record its independent expected value, original failure mode and relevant keepers. Static leads, coverage counts, or a self-reported run stay labelled as such. Judge the proof's value on that contract separately. An unrelated improvement does not earn a photo result.

The optional, preregistered pda-05 alternative is a page assertion on waiver membership versus order. `src/agent-data.ts:53` stores a set and `src/agent.ts:753` checks membership. The `waiver-order` control reverses the same IDs. `waiver-missing` and `waiver-extra` omit one shown ID or add one unshown fixture ID. The original page should pass on clean, fail on all three, and a test that proves exactly the permitted membership should accept the permutation and reject both membership errors. Run the complete `test/ui/agent-data.test.tsx` for all four variants. The public task names neither this case nor the photo case.

## Scope of evidence

The native Workers project uses Miniflare/workerd, the repository's faked external services and generated test credentials, the real Durable Object storage API, production attachment migration/write and structured HTTP export. The page project uses happy-dom and its preexisting fetch stub. The primary execution does not establish that the complete 70-file Workers project or every other CI tier accepts a fault. A separate literal scan of all 155 named modules found only the route owner, the page controls and the dependency-free live preflight naming this surface. That search cannot establish absence of dynamic or indirect coverage.

The original report's earlier Node-SQLite bridge was a focused exploration. This replay independently reruns the complete owner file natively. Hosted success and historical owner reviews are complementary evidence only.
