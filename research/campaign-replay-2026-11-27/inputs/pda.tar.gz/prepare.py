#!/usr/bin/env python3
"""Build the pinned public participant project from individual blobs and the small interop JPEG fixture."""
from concurrent.futures import ThreadPoolExecutor
import argparse
import hashlib
import json
from pathlib import Path
import re
import time
from urllib.parse import quote
from urllib.request import Request, urlopen

HERE = Path(__file__).resolve().parent
REPO = "adewale/pda"
SHA = "c0a9a85c8f690eb77313b9627e3ea39cadc58968"
SEED = "pda-2026-11-26-suite-replay-v2"
QUOTAS = {"workers": 23, "durability": 1, "ui": 8, "interop": 10, "properties": 5,
          "scripts": 4, "node-runtime": 1, "hosted": 1, "hypothesis": 3}
# Include the audited boundaries and sibling evidence. The remaining slots use a stable hash rank.
ANCHORS = {
    "workers": ["test/agent-data.test.ts", "test/agent.test.ts", "test/poppy-task-files.test.ts"],
    "ui": ["test/ui/agent-data.test.tsx", "test/ui/attachments.test.tsx"],
    "scripts": ["scripts/check-requirements.test.mjs", "scripts/ci-scope.test.mjs"],
    "interop": ["interop/test/expectations.test.ts"],
}
ROOT_FILES = {".nvmrc", ".gitignore", ".dockerignore", "CLAUDE.md", "LICENSE", "README.md",
              "package.json", "package-lock.json", "tsconfig.json", "tsconfig.scripts.json", "env.d.ts",
              "vite.config.ts", "wrangler.jsonc", "index.html", "deployment.example.json", "pda-spec.md"}
DOCS = {"architecture", "company-testing", "conformance-levels", "interop-spec", "operation-authorization",
        "upgrading", "poppy-0.4-conformance", "poppy-1.0-upgrade", "using", "readings", "decisions"}
ACTIVE_SPEC = ["spec/draft-0.4-retrieved-2026-11-11/", "spec/version-1.0-retrieved-2026-11-19/"]
ACTIVE_KIT = ["spec/company-kit-2026-11-11/", "spec/company-kit-2026-11-19/"]


def suite(path):
    rules = [
        ("workers", r"test/[^/]+\.test\.ts"),
        ("durability", r"test/durability/[^/]+\.test\.ts"),
        ("ui", r"test/ui/[^/]+\.test\.tsx"),
        ("interop", r"interop/test/[^/]+\.test\.(?:ts|mjs)"),
        ("properties", r"test/properties/[^/]+\.test\.ts"),
        ("scripts", r"scripts/[^/]+\.test\.mjs"),
        ("node-runtime", r"scripts/node-runtime\.check\.mjs"),
        ("hosted", r"test/hosted/company-security\.node\.mjs"),
        ("hypothesis", r"test/hypothesis/test_[^/]+\.py"),
    ]
    return next((name for name, pattern in rules if re.fullmatch(pattern, path)), None)


def selected_modules(groups):
    sample = set()
    for name, count in QUOTAS.items():
        anchors = set(ANCHORS.get(name, []))
        assert anchors <= groups[name] and len(anchors) <= count
        def rank(path):
            return hashlib.sha256((SEED + "\0" + path).encode()).hexdigest(), path
        complement = sorted(groups[name] - anchors, key=rank)
        sample.update(anchors | set(complement[:count-len(anchors)]))
    return sample


def support(path):
    if path in ROOT_FILES or path.startswith(("src/", "public/", ".github/workflows/", "scripts/", "test/", "interop/")):
        return True
    if path in {f"docs/{name}.md" for name in DOCS}:
        return True
    if path.startswith("spec/") and path.count("/") == 1:
        return True
    if any(path.startswith(prefix) for prefix in ACTIVE_SPEC):
        return "/pages/" in path or path.endswith("/manifest.json")
    return any(path.startswith(prefix) for prefix in ACTIVE_KIT) and (
        "/schemas/" in path or path.endswith(("/validate/schema.ts", "/manifest.json", "/LICENSE")))


def git_hash(data):
    return hashlib.sha1(f"blob {len(data)}\0".encode() + data).hexdigest()


def write_json(dest, value):
    dest.write_text(json.dumps(value, indent=2) + "\n")


def network(url):
    for attempt in range(4):
        try:
            with urlopen(Request(url, headers={"User-Agent": "pda-audit-replay-prep"}), timeout=35) as response:
                return response.read()
        except Exception:
            if attempt == 3:
                raise
            time.sleep(attempt + 1)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--audit", type=Path, default=Path("/workspace/current-test-audit-2026-11-26"),
                        help="Optional cache made by the prior audit's source.py")
    parser.add_argument("--output", type=Path, default=HERE / "participant")
    args = parser.parse_args()
    tree_path = args.audit / "evidence/pda/tree.json"
    tree = json.loads(tree_path.read_bytes() if tree_path.is_file() else network(
        f"https://api.github.com/repos/{REPO}/git/trees/{SHA}?recursive=1"))
    assert tree["sha"] == SHA and not tree["truncated"] and len(tree["tree"]) == 2200
    blobs = {e["path"]: e for e in tree["tree"] if e["type"] == "blob"}
    groups = {name: {path for path in blobs if suite(path) == name} for name in QUOTAS}
    prior = args.audit / "evidence/pda/test-inventory.json"
    if prior.is_file():
        assert groups == {k: set(v) for k, v in json.loads(prior.read_text()).items()}
    assert sum(map(len, groups.values())) == 155
    sample = selected_modules(groups)
    assert len(sample) == 56
    paths = sorted(p for p in blobs if (p in sample if suite(p) else support(p)))
    source = args.output / "repo"
    source.mkdir(parents=True, exist_ok=True)
    def fetch(path):
        dest = source / path
        cache = args.audit / "checkouts/pda" / path
        expected = blobs[path]["sha"]
        for loc in (dest, cache):
            if loc.is_file():
                raw = loc.read_bytes()
                if git_hash(raw) == expected:
                    break
        else:
            raw = network(f"https://raw.githubusercontent.com/{REPO}/{SHA}/" + quote(path, safe="/"))
        assert git_hash(raw) == expected, path
        if path != "interop/files/lake.jpg":
            raw.decode("utf-8")
            assert b"\0" not in raw, path
        dest.parent.mkdir(parents=True, exist_ok=True)
        if not dest.is_file() or dest.read_bytes() != raw:
            dest.write_bytes(raw)
        dest.chmod(0o755 if blobs[path]["mode"] == "100755" else 0o644)
        return {"path": path, "git_blob_sha1": expected, "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}
    with ThreadPoolExecutor(max_workers=10) as pool:
        manifest = list(pool.map(fetch, paths))
    inventory = {
        "repository": REPO, "ref": SHA, "pinned_tree_entries": len(tree["tree"]), "tree_truncated": False,
        "inventory_unit": "First-party named test modules, classified against native test projects and separately invoked commands. Vendored test files, interop scenario JSON, manual journey drivers, fixtures and CI commands are separate.",
        "modules_total": 155, "modules_supplied": len(sample),
        "strata": {name: {"total": len(group), "supplied": sum(p in sample for p in group)} for name, group in groups.items()},
        "modules": [{"path": p, "project": suite(p), "supplied": p in sample} for p in sorted(set.union(*groups.values()))],
    }
    write_json(args.output / "inventory.json", inventory)
    ci_dir = args.output / "ci"
    ci_dir.mkdir(exist_ok=True)
    for run in (45800972889, 45800972796, 45800972780):
        cached = args.audit / f"evidence/pda/jobs-{run}.json"
        raw = cached.read_bytes() if cached.is_file() else network(f"https://api.github.com/repos/{REPO}/actions/runs/{run}/jobs")
        jobs = json.loads(raw)
        assert jobs["total_count"] == 1 and jobs["jobs"][0]["head_sha"] == SHA
        (ci_dir / f"jobs-{run}.json").write_bytes(raw)
    brief = HERE / "participant/task.md"
    if (args.output / "task.md").resolve() != brief.resolve():
        (args.output / "task.md").write_bytes(brief.read_bytes())
    ev = HERE / "evaluator"
    ev.mkdir(exist_ok=True)
    write_json(ev / "source-manifest.json", {"repository": REPO, "sha": SHA, "files": manifest})
    print(json.dumps({"files": len(paths), "bytes": sum(x["bytes"] for x in manifest), "tests": len(sample),
                      "strata": inventory["strata"]}))


if __name__ == "__main__":
    main()
